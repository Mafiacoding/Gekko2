// Differential replay of owner-private snapshots; no guest data is embedded here.
#include "runtime/ps2_memory.h"
#include "runtime/ps2_vu1.h"
#include "runtime/gs/gs_frontend.h"
#include <algorithm>
#include <cassert>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <vector>

int main(int argc, char **argv)
{
    assert(argc == 2 || argc == 3);
    const bool split = argc == 3;
    PS2Memory referenceMemory, nativeMemory;
    assert(referenceMemory.initialize() && nativeMemory.initialize());
    GS referenceGs, nativeGs;
    std::vector<std::filesystem::path> paths;
    for (const auto &entry : std::filesystem::directory_iterator(argv[1]))
        if (entry.path().extension() == ".bin") paths.push_back(entry.path());
    std::sort(paths.begin(), paths.end());
    assert(!paths.empty());
    double referenceSeconds = 0, nativeSeconds = 0;
    uint64_t upper = 0, lower = 0, fallbackUpper = 0, fallbackLower = 0, blocks = 0;
    unsigned cases = 0;
    for (const auto &path : paths)
    {
        FILE *file = std::fopen(path.c_str(), "rb"); assert(file);
        uint32_t header[6]; assert(std::fread(header, sizeof(header), 1, file) == 1);
        assert(header[0] == sizeof(VU1State) && header[1] == PS2_VU1_CODE_SIZE && header[2] == PS2_VU1_DATA_SIZE);
        VU1State initial, historical;
        std::vector<uint8_t> code(header[1]), data(header[2]), historicalData(header[2]);
        assert(std::fread(&initial, sizeof(initial), 1, file) == 1);
        assert(std::fread(code.data(), code.size(), 1, file) == 1);
        assert(std::fread(data.data(), data.size(), 1, file) == 1);
        assert(std::fread(&historical, sizeof(historical), 1, file) == 1);
        assert(std::fread(historicalData.data(), historicalData.size(), 1, file) == 1);
        assert(std::fgetc(file) == EOF); std::fclose(file);
        // Historical output is not the oracle: compare the CURRENT reference.
        VU1Interpreter reference, native;
        reference.setAotEnabled(false);
        reference.state() = initial; native.state() = initial;
        auto prepare = [&](PS2Memory &memory, GS &gs) {
            std::memcpy(memory.getVU1Code(), code.data(), code.size());
            std::memcpy(memory.getVU1Data(), data.data(), data.size());
            memory.markVU1CodeModified();
            std::memset(memory.getGSVRAM(), 0, PS2_GS_VRAM_SIZE);
            gs.init(memory.getGSVRAM(), PS2_GS_VRAM_SIZE, &memory.gs());
        };
        prepare(referenceMemory, referenceGs); prepare(nativeMemory, nativeGs);
        auto run = [&](VU1Interpreter &vu, PS2Memory &memory, GS &gs, double &seconds, bool resume = false, unsigned budget = 65536) {
            auto start = std::chrono::steady_clock::now();
            if (resume)
                vu.resume(memory.getVU1Code(), header[1], memory.getVU1Data(), header[2], gs, &memory, header[4], header[5], budget);
            else vu.execute(memory.getVU1Code(), header[1], memory.getVU1Data(), header[2],
                            gs, &memory, header[3], header[4], header[5], budget);
            seconds += std::chrono::duration<double>(std::chrono::steady_clock::now() - start).count();
        };
        auto compare = [&]() {
        if (std::memcmp(&reference.state(), &native.state(), sizeof(VU1State)) ||
            std::memcmp(referenceMemory.getVU1Data(), nativeMemory.getVU1Data(), PS2_VU1_DATA_SIZE) ||
            std::memcmp(referenceMemory.getGSVRAM(), nativeMemory.getGSVRAM(), PS2_GS_VRAM_SIZE)) {
            std::fprintf(stderr, "AOT mismatch at case %u\n", cases); std::abort();
        }
        };
        if (split) {
            unsigned step = 0;
            for (unsigned budget : {1u,2u,3u,4u,7u,16u,32u,64u,65536u}) {
                run(reference,referenceMemory,referenceGs,referenceSeconds,step!=0,budget);
                run(native,nativeMemory,nativeGs,nativeSeconds,step!=0,budget);
                compare(); ++step;
            }
            if (!cases && native.aotStats().nativeBlocks) {
                // A change outside the executed entry must still invalidate the
                // full-program proof, even at the same native source pointer.
                for (auto *vu : {&reference,&native}) { vu->reset(); vu->state()=initial; }
                prepare(referenceMemory,referenceGs); prepare(nativeMemory,nativeGs);
                referenceMemory.getVU1Code()[16383]^=1; nativeMemory.getVU1Code()[16383]^=1;
                referenceMemory.markVU1CodeModified(); nativeMemory.markVU1CodeModified();
                const auto previousBlocks=native.aotStats().nativeBlocks;
                run(reference,referenceMemory,referenceGs,referenceSeconds);
                run(native,nativeMemory,nativeGs,nativeSeconds); compare();
                assert(native.aotStats().nativeBlocks==previousBlocks);
                for (auto *vu : {&reference,&native}) { vu->reset(); vu->state()=initial; }
                prepare(referenceMemory,referenceGs); prepare(nativeMemory,nativeGs);
                run(reference,referenceMemory,referenceGs,referenceSeconds);
                run(native,nativeMemory,nativeGs,nativeSeconds); compare();
                assert(native.aotStats().nativeBlocks>previousBlocks);
            }
        } else if (cases & 1) {
            run(native,nativeMemory,nativeGs,nativeSeconds);
            run(reference,referenceMemory,referenceGs,referenceSeconds);
        } else {
            run(reference,referenceMemory,referenceGs,referenceSeconds);
            run(native,nativeMemory,nativeGs,nativeSeconds);
        }
        compare();
        const auto &stats = native.aotStats();
        blocks += stats.nativeBlocks;
        upper += stats.nativeUpper; lower += stats.nativeLower;
        fallbackUpper += stats.fallbackUpper; fallbackLower += stats.fallbackLower;
        ++cases;
    }
    assert(upper && lower); // Refuse a vacuous all-fallback success.
    std::printf("{\"cases\":%u,\"native_upper\":%llu,\"native_lower\":%llu,"
                "\"native_blocks\":%llu,\"fallback_upper\":%llu,\"fallback_lower\":%llu,"
                "\"reference_seconds\":%.9f,\"native_seconds\":%.9f}\n",
                cases, (unsigned long long)upper, (unsigned long long)lower,
                (unsigned long long)blocks, (unsigned long long)fallbackUpper, (unsigned long long)fallbackLower,
                referenceSeconds, nativeSeconds);
}
