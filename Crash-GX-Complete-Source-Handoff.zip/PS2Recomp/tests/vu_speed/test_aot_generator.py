#!/usr/bin/env python3
"""Validate generic AOT generation without embedding game instructions/assets."""
import importlib.util
import sys
from pathlib import Path
import tempfile
import json
import unittest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tools/vu'))
spec = importlib.util.spec_from_file_location('vu_aot', ROOT/'tools/vu/generate_aot.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

verify_spec = importlib.util.spec_from_file_location('vu_aot_verify', ROOT/'tools/vu/verify_aot.py')
verify_module = importlib.util.module_from_spec(verify_spec)
verify_spec.loader.exec_module(verify_module)

class GeneratorTests(unittest.TestCase):
    def test_specialization_and_deduplication(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            report = module.generate({'upper':[0x2ff,0x2ff], 'lower':[0x8000033c]}, out)
            self.assertEqual(report['counts'], {'upper':1,'lower':1})
            upper = (out/'vu_aot_upper.cpp').read_text()
            lower = (out/'vu_aot_lower.cpp').read_text()
            self.assertIn('constexpr uint32_t instr = Instruction;', upper)
            self.assertIn('&runUpper<0x000002ffu>', upper)
            self.assertNotIn('void VU1Interpreter::execUpper(uint32_t', upper)
            self.assertIn('&runLower<0x8000033cu>', lower)
            self.assertNotIn('void VU1Interpreter::execLower(uint32_t', lower)
            self.assertIn(': nullptr;', lower) # Exact missing-word fallback.
    def test_rejects_stale_semantics(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            report = module.generate({'upper':[], 'lower':[]}, out)
            verify_module.verify(out)
            report['semantic_sha256']['upper'] = '0'*64
            (out/'manifest.json').write_text(json.dumps(report))
            with self.assertRaisesRegex(ValueError, 'Stale VU AOT upper'):
                verify_module.verify(out)

    def test_empty_registry(self):
        with tempfile.TemporaryDirectory() as tmp:
            module.generate({'upper':[], 'lower':[]}, Path(tmp))
            self.assertIn('return nullptr;', (Path(tmp)/'vu_aot_upper.cpp').read_text())

    def test_rejects_changed_generated_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            module.generate({'upper': [], 'lower': []}, out)
            with (out/'vu_aot_upper.cpp').open('a') as source:
                source.write('\n// Partial or modified output\n')
            with self.assertRaisesRegex(ValueError, 'Changed or incomplete'):
                verify_module.verify(out)

    def test_rejects_missing_source_digest(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            report = module.generate({'upper': [], 'lower': []}, out)
            del report['files_sha256']['vu_aot_upper.cpp']
            (out/'manifest.json').write_text(json.dumps(report))
            with self.assertRaisesRegex(ValueError, 'Incomplete generated-source hashes'):
                verify_module.verify(out)

    def test_removes_stale_block_source(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            (out/'vu_aot_blocks.cpp').write_text('stale block registry')
            module.generate({'upper': [], 'lower': [], 'programs': []}, out)
            self.assertFalse((out/'vu_aot_blocks.cpp').exists())
            verify_module.verify(out)

    def test_rejects_invalid_block_programs(self):
        for programs in ({}, [None], [{'unit': 0, 'words': [0]*4096}],
                         [{'unit': 1, 'words': [0]*4}],
                         [{'unit': 1, 'words': [0]*4096, 'blocks': [1]}],
                         [{'unit': 1, 'words': [0]*4096, 'blocks': [True]}]):
            with self.subTest(programs_type=type(programs)), tempfile.TemporaryDirectory() as tmp:
                with self.assertRaises(ValueError):
                    module.generate({'upper': [], 'lower': [], 'programs': programs}, Path(tmp))

    def test_block_sharing_preserves_program_and_pc_identity(self):
        # Two synthetic uploads differ only at the second block. Both tables
        # must retain independent exact-image guards and all 256 PC slots.
        words = [word for _ in range(2048) for word in (0x8000033c, 0x2ff)]
        changed = words.copy()
        changed[16] = 0x8000033d
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            module.generate({'upper': [], 'lower': [], 'programs': [
                {'unit': 1, 'words': words}, {'unit': 1, 'words': changed}]}, out)
            source = (out/'vu_aot_blocks.cpp').read_text()
            self.assertIn('__attribute__((noinline)) void VU1Interpreter::execUpperAot()', source)
            self.assertIn('__attribute__((noinline)) void VU1Interpreter::execUpperAot()',
                          (out/'vu_aot_upper.cpp').read_text())
            self.assertEqual(source.count('void VU1AotBlockCompiler::block_'), 257)
            self.assertIn('void VU1AotBlockCompiler::block_1_8(', source)
            self.assertNotIn('void VU1AotBlockCompiler::block_1_0(', source)
            self.assertIn('static const uint8_t code_0[]', source)
            self.assertIn('static const uint8_t code_1[]', source)
            self.assertIn('std::memcmp(p.code+64u,code+64u,4u)', source)
            self.assertIn('std::memcmp(p.code,code,size)==0', source)
            self.assertEqual(source.count('&VU1AotBlockCompiler::block_0_0'), 2)
            self.assertEqual(source.count('&VU1AotBlockCompiler::block_0_8,'), 1)
            verify_module.verify(out)

    def test_sparse_blocks_keep_native_word_fallback(self):
        words = [word for _ in range(2048) for word in (0x8000033c, 0x2ff)]
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            module.generate({'upper': [0x2ff], 'lower': [0x8000033c],
                             'programs': [{'unit': 1, 'words': words, 'blocks': [0, 64]}]}, out)
            source = (out/'vu_aot_blocks.cpp').read_text()
            self.assertEqual(source.count('void VU1AotBlockCompiler::block_'), 2)
            table = source.split('static const VU1AotProgram::Block blocks_0[]={',1)[1].split('};',1)[0]
            self.assertEqual(table.split(',').count('nullptr'), 254)
            self.assertIn('!p->blocks[slot])return false;', source)
            self.assertIn('&runUpper<0x000002ffu>', (out/'vu_aot_upper.cpp').read_text())
            verify_module.verify(out)
    def test_rejects_invalid_instruction_words(self):
        for bad in ([-1], [2**32], [True], ['0x2ff'], None):
            with self.subTest(bad=bad), tempfile.TemporaryDirectory() as tmp:
                with self.assertRaises(ValueError):
                    module.generate({'upper':bad,'lower':[]}, Path(tmp))

    def test_opt_in_opcode_flag_specialization(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            report = module.generate({'upper': [0x2ff], 'lower': [],
                                      'specialize_flags': True}, out)
            text = (out/'vu_aot_upper.cpp').read_text()
            self.assertTrue(report['specialize_flags'])
            self.assertIn('void VU1AotRegistry::normalizeFmacResult', text)
            self.assertIn('VU1AotRegistry::applyFmacDest<', text)
            self.assertIn('((vu.m_currentUpperInstruction & 0xfffff800u) | Opcode)', text)
            verify_module.verify(out)

    def test_rejects_nonboolean_flag_specialization(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, 'specialize_flags must be boolean'):
                module.generate({'upper': [], 'lower': [], 'specialize_flags': 1}, Path(tmp))

    def test_opt_in_inline_flag_helpers(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)
            report=module.generate({'upper':[0x2ff], 'lower':[],
                                    'specialize_flags':True,'inline_flag_helpers':True},out)
            self.assertTrue(report['inline_flag_helpers'])
            self.assertIn('__attribute__((always_inline)) inline void VU1AotRegistry::normalizeFmacResult',
                          (out/'vu_aot_upper.cpp').read_text())
            verify_module.verify(out)
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError,'inline_flag_helpers must be boolean'):
                module.generate({'upper':[],'lower':[],'inline_flag_helpers':1},Path(tmp))

    def test_generated_per_unit_usage(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp)
            report = module.generate({'upper': [0x2ff], 'lower': [0x8000033c],
                                      'predecode_usage': True}, out)
            self.assertTrue(report['predecode_usage'])
            for half in ('upper', 'lower'):
                source = (out/f'vu_aot_{half}.cpp').read_text()
                self.assertIn('InstructionUsage zero, one;', source)
                self.assertIn('unit==VU1Interpreter::Unit::VU0?entry.zero:entry.one', source)
            verify_module.verify(out)

    def test_rejects_nonboolean_usage_generation(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, 'predecode_usage must be boolean'):
                module.generate({'upper': [], 'lower': [], 'predecode_usage': 'yes'}, Path(tmp))

if __name__ == '__main__': unittest.main()
