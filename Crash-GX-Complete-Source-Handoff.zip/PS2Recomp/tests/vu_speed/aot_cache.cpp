// Generate an AOT registry containing the constants documented below, then link
// against the production runtime. The unknown IADDIU must remain a true miss.
#include "runtime/ps2_memory.h"
#include "runtime/ps2_vu1.h"
#include "runtime/ps2_vu1_aot.h"
#include "runtime/gs/gs_frontend.h"
#include <cassert>
#include <cstdio>
#include <cstring>

int main()
{
    PS2Memory memory; assert(memory.initialize());
    GS gs; gs.init(memory.getGSVRAM(), PS2_GS_VRAM_SIZE, &memory.gs());
    unsigned checks = 0;
    unsigned unknownImmediate = 2;
    while(unknownImmediate < 2048 && VU1AotRegistry::lower(0x10010000u|unknownImmediate)) ++unknownImmediate;
    assert(unknownImmediate < 2048);
    for (unsigned unit = 0; unit < 2; ++unit)
    {
        auto *code = unit ? memory.getVU1Code() : memory.getVU0Code();
        auto *data = unit ? memory.getVU1Data() : memory.getVU0Data();
        auto mark = [&] { if (unit) memory.markVU1CodeModified(); else memory.markVU0CodeModified(); };
        VU1Interpreter reference(unit ? VU1Interpreter::Unit::VU1 : VU1Interpreter::Unit::VU0);
        VU1Interpreter native(unit ? VU1Interpreter::Unit::VU1 : VU1Interpreter::Unit::VU0);
        reference.setAotEnabled(false);
        Ps2GuestWrite<uint32_t>(code, 0x10010001u); // Known IADDIU VI1, VI0, 1
        Ps2GuestWrite<uint32_t>(code+4, 0x41e208e8u); // Known E-bit ADD VF3, VF1, VF2
        Ps2GuestWrite<uint32_t>(code+8, 0x8000033cu);
        Ps2GuestWrite<uint32_t>(code+12, 0x2ffu);
        mark();
        for (unsigned stage = 0; stage < 4; ++stage)
        {
            reference.reset(); native.reset();
            for (unsigned c = 0; c < 4; ++c) {
                reference.state().vf[1][c] = native.state().vf[1][c] = float(c+1);
                reference.state().vf[2][c] = native.state().vf[2][c] = float(c+2);
            }
            uint8_t external[16]; std::memcpy(external, code, sizeof(external));
            uint8_t *active = stage == 3 ? external : code;
            for (auto *vu : {&reference, &native}) {
                vu->execute(active, 16, data, unit ? PS2_VU1_DATA_SIZE : PS2_VU0_DATA_SIZE, gs, &memory, 0,0,0,1);
                vu->resume(active, 16, data, unit ? PS2_VU1_DATA_SIZE : PS2_VU0_DATA_SIZE, gs, &memory, 0,0,64);
            }
            assert(std::memcmp(&reference.state(), &native.state(), sizeof(VU1State)) == 0);
            assert(native.state().vi[1] == (stage ? int(unknownImmediate) : 1));
            assert(native.state().vf[3][0] == 3.0f);
            if (!stage) {
                assert(native.aotStats().nativeUpper > 0 && native.aotStats().nativeLower > 0);
                assert(native.aotStats().fallbackUpper == 0 && native.aotStats().fallbackLower == 0);
                // Same pointer, changed generation: stale cached native VI1=1 must not execute.
                Ps2GuestWrite<uint32_t>(code, 0x10010000u|unknownImmediate); // Intentionally absent from registry.
                mark();
            } else assert(native.aotStats().fallbackLower > 0);
            ++checks;
        }
    }
    std::printf("PASS: %u native/fallback VU0/VU1 generation, resume, cache reuse and untracked-code cases\n", checks);
}
