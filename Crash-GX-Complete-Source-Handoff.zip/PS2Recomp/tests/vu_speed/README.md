# VU operand preparation experiments

These are synthetic workloads, with no game code or assets. They exercise the
production VU implementation. `state_corpus.cpp` writes completed VU states for
both units, seven upper opcodes, all destination masks, four register aliases
and sixteen float patterns. Compare the entire output from a baseline and a
candidate build; do not compare states before pending pipeline writes drain.
`benchmark.cpp MODE CYCLES` times equal cycle budgets and then drains writes
outside the timed interval. Compare cycles and both hashes before using times.
Modes: VU1 NOP, VU1 ADD, VU1 ADD/MUL, VU0 NOP, untracked-code NOP.

Compile/link each source separately against the same runtime objects and
required registration/host support as the existing VU regression executable,
without its test main. Use identical compiler/link flags on both sides. Replace
only `ps2_vu1_upper.cpp.o` with a separately compiled copy:

- Baseline: no `PS2X_VU_OPERAND_FASTPATH` definition.
- Candidate: `-DPS2X_VU_OPERAND_FASTPATH`.

Keep assertions enabled. Alternate baseline/candidate execution order over
multiple trials and compare medians of paired time ratios. The private local
validation used GCC 14, C++20, `-O1 -msse4.1 -ffp-contract=off`, five million
cycles and seven paired trials. Game-generated registration objects used by
that local linker setup and all real-game snapshots remain private.

The Wii and headless CMake configurations expose an OFF-by-default option of
the same name. This is an experimental VU optimization, not native GX rendering,
VU block AOT or a measurement of game FPS. See `docs/wii/VU-OPERAND-EXPERIMENT.md`.


Instruction-AOT comparisons are documented in `docs/wii/VU-AOT.md`.
`aot_compare.cpp` compares full current-reference/native VU state, data and GS
VRAM on private snapshots, and reports actual native/fallback instruction counts.
`aot_cache.cpp` covers tracked code changes and resume on both VU units. These
are separate from the older operand-preparation experiment above.
