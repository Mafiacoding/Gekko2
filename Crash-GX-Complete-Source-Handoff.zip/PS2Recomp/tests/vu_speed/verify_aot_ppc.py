#!/usr/bin/env python3
"""Compare selected native VU handlers with reference PPC code in Unicorn.

Inputs may contain owner-private code; only aggregate results are printed.
This is an isolated semantics check, not a complete-game or timing test.
"""
from pathlib import Path
import argparse, os
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--elf',type=Path,required=True)
parser.add_argument('--manifest',type=Path,required=True)
parser.add_argument('--profile',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--half',choices=('upper','lower'),default='upper')
parser.add_argument('--rounding',type=int,choices=range(4),default=1,
                    help='PPC FPSCR RN bits; default 1 matches the VU run loop (toward zero)')
parser.add_argument('--nm',default=os.environ.get('DEVKITPPC','/opt/devkitpro/devkitPPC')+'/bin/powerpc-eabi-nm')
args=parser.parse_args()
import subprocess,struct,json,collections
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN,UC_HOOK_CODE
from unicorn.ppc_const import *
nm=args.nm
def symbols(path):return {v[2]:int(v[0],16) for l in subprocess.check_output([nm,str(path)],text=True).splitlines() if len(v:=l.split())==3}
base=args.elf;bs=symbols(base)
u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x1800000);u.mem_map(0x90000000,0x4000000)
def load(path):
 d=path.read_bytes();ph=struct.unpack_from('>I',d,28)[0];step,count=struct.unpack_from('>HH',d,42)
 for i in range(count):
  kind,off,addr,_,size,*_=struct.unpack_from('>8I',d,ph+i*step)
  if kind==1 and size:u.mem_write(addr,d[off:off+size])
load(base)
size,stateoff,statesize,cycleoff=struct.unpack('>4I',args.manifest.read_bytes());obj=0x93200000;stop=0x80001000
counter=[0];hits=collections.Counter()
def count(uc,address,size,user):
 counter[0]+=1
 if address==bs["_ZNK14VU1Interpreter16normalizeOperandEf"]:hits["normalize"]+=1
u.hook_add(UC_HOOK_CODE,count)
def call(address,*register_args):
 counter[0]=0;hits.clear()
 u.reg_write(UC_PPC_REG_FPSCR,args.rounding)
 for r,v in [(UC_PPC_REG_1,0x817f0000),(UC_PPC_REG_2,bs['__SDATA2_START__']+0x8000),(UC_PPC_REG_13,bs['__SDATA_START__']+0x8000),(UC_PPC_REG_LR,stop),(UC_PPC_REG_MSR,0x2000)]:u.reg_write(r,v)
 for index,value in enumerate(register_args):u.reg_write(UC_PPC_REG_3+index,value)
 u.emu_start(address,stop,count=1000000)
 assert u.reg_read(UC_PPC_REG_PC)==stop,hex(u.reg_read(UC_PPC_REG_PC))
 return counter[0]
ctor=bs['_ZN14VU1InterpreterC1ENS_4UnitE'];fn='_ZN14VU1Interpreter9execUpperEj'
if args.half=='lower':fn=next(k for k in bs if k.startswith('_ZN14VU1Interpreter9execLowerE'))
u.mem_write(obj,bytes(size));call(ctor,obj,1);initial=bytes(u.mem_read(obj,size));print('layout',size,stateoff,statesize,cycleoff,flush=True)
profile=json.loads(args.profile.read_text());rows=[]
patterns=[0x3f800000,0x80000000,0x00000001,0x7f800000,0xff800000,0x7fc01234,0x7f7fffff,0xbf800000]
for instr in profile[args.half]:
 prefix='_ZN14VU1AotRegistry8run'+args.half.title()+'ILj'+str(instr)+'EEEvR14VU1Interpreter'
 address=bs[prefix+('PhjR2GSP9PS2Memory' if args.half=='lower' else '')]
 assert 0x80000000 <= address < 0x81800000
 counts=[0,0]
 for pattern in patterns:
  values=[]
  for variant,entry in enumerate([bs[fn],address]):
   u.mem_write(obj,initial)
   for reg in range(1,32):u.mem_write(obj+stateoff+reg*16,struct.pack('>4I',pattern,pattern^0x80000000,0x3f000000,0x40000000))
   if args.half=='lower':
    data=0x93280000;gs=0x93320000
    u.mem_write(data,bytes((i*13)&255 for i in range(16384)))
    counts[variant]+=call(entry,*([obj,instr,data,16384,gs,0,0x2ff] if variant==0 else [obj,data,16384,gs,0]))
    values.append(bytes(u.mem_read(obj,size))+bytes(u.mem_read(data,16384)))
   else:
    counts[variant]+=call(entry,obj,instr)
    values.append(bytes(u.mem_read(obj,size)))
  assert values[0]==values[1],(hex(instr),hex(pattern),next((i for i,(a,b) in enumerate(zip(*values)) if a!=b),None))
 rows.append(dict(instruction=instr,reference_instructions=counts[0],aot_instructions=counts[1]))
report=dict(scope=f'Isolated PPC {args.half} semantics in Unicorn, not FPS or timing',rounding=args.rounding,words=len(rows),patterns=len(patterns),cases=len(rows)*len(patterns),all_handlers_in_mem1=True,rows=rows)
args.output.write_text(json.dumps(report,indent=2)+'\n')
print({k:v for k,v in report.items() if k!='rows'})
