#include "runtime/ps2_memory.h"
#include "runtime/ps2_guest_memory.h"
#include <cassert>
#include <cstring>
#include <cstdio>
int main(){PS2Memory memory;assert(memory.initialize());auto *ram=memory.getRDRAM();
 for(unsigned unit=0;unit<2;++unit){
  auto generation=[&]{return unit?memory.getVU1CodeGeneration():memory.getVU0CodeGeneration();};
  auto submit=[&](unsigned bytes){if(unit)memory.processVIF1Data(0x1000,bytes);else memory.processVIF0Data(0x1000,bytes);};
  auto *code=unit?memory.getVU1Code():memory.getVU0Code();
  std::memset(ram+0x1000,0,64);Ps2GuestWrite<uint32_t>(ram+0x1000,0x4a020004u);
  for(unsigned i=0;i<16;++i)ram[0x1004+i]=uint8_t(i+1);
  auto before=generation();submit(20);assert(generation()==before+1&&std::memcmp(code+32,ram+0x1004,16)==0);
  before=generation();submit(20);assert(generation()==before);
  ram[0x100b]^=0x40;submit(20);assert(generation()==before+1&&std::memcmp(code+32,ram+0x1004,16)==0);
  before=generation();ram[0x100b]^=0x40;submit(12);assert(generation()==before); // Incomplete MPG never writes.
  assert(std::memcmp(code+32,ram+0x1004,16)!=0);
  submit(20);assert(generation()==before+1&&std::memcmp(code+32,ram+0x1004,16)==0);
 }
 std::puts("PASS: VIF0/VIF1 changed, repeated identical, one-byte change and truncated MPG uploads");
}
