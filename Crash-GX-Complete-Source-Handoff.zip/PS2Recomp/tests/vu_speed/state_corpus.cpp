#include "runtime/ps2_memory.h"
#include "runtime/ps2_vu1.h"
#include "runtime/gs/gs_frontend.h"
#include <cassert>
#include <cstdio>
#include <cstring>
static uint32_t next(uint32_t&s){s=s*1664525u+1013904223u;return s;}
int main(int argc,char**argv){assert(argc==2);FILE*f=std::fopen(argv[1],"wb");assert(f);
 PS2Memory memory;assert(memory.initialize());GS gs;gs.init(memory.getGSVRAM(),PS2_GS_VRAM_SIZE,nullptr);
 const uint32_t edges[]={0u,0x80000000u,1u,0x80000001u,0x007fffffu,0x807fffffu,0x00800000u,0x80800000u,0x3f800000u,0xbf800000u,0x7f7fffffu,0xff7fffffu,0x7f800000u,0xff800000u,0x7fc01234u,0x7f801234u};
 const uint32_t ops[]={0x00,0x04,0x08,0x0c,0x18,0x1c,0x1e,0x20,0x21,0x22,0x23,
  0x24,0x25,0x26,0x27,0x28,0x29,0x2a,0x2b,0x2c,0x2d,0x2e,0x2f,
  0x2ff,0x33c,0xbc,0xfc,0x1fc,0x23d,0x27d,0x2be};unsigned cases=0;
 for(unsigned unit=0;unit<2;++unit){VU1Interpreter vu(unit?VU1Interpreter::Unit::VU1:VU1Interpreter::Unit::VU0);
 auto*code=unit?memory.getVU1Code():memory.getVU0Code();auto*data=unit?memory.getVU1Data():memory.getVU0Data();
 for(unsigned oi=0;oi<sizeof(ops)/sizeof(ops[0]);++oi)for(unsigned dest=0;dest<16;++dest)for(unsigned alias=0;alias<4;++alias)for(unsigned pattern=0;pattern<16;++pattern){
  vu.reset();uint32_t seed=0x19841u+cases*101u;
  for(unsigned r=1;r<32;++r)for(unsigned c=0;c<4;++c){uint32_t raw=((r+c)&1)?next(seed):edges[(pattern+r+c)%16];std::memcpy(&vu.state().vf[r][c],&raw,4);}
  for(unsigned c=0;c<4;++c){uint32_t raw=edges[(pattern+c)%16];std::memcpy(&vu.state().acc[c],&raw,4);}
  std::memcpy(&vu.state().q,&edges[pattern],4);std::memcpy(&vu.state().i,&edges[(pattern+1)%16],4);
  vu.state().mac=next(seed)&0xffff;vu.state().status=next(seed)&0xfff;vu.state().clip=next(seed)&0xffffff;
  unsigned fd=alias==0?3:alias==1?1:alias==2?2:0;
  uint32_t upper=(dest<<21)|(2u<<16)|(1u<<11)|ops[oi];if(ops[oi]<0x3c)upper|=fd<<6;
  upper|=1u<<30;
  Ps2GuestWrite<uint32_t>(code,0x8000033c);Ps2GuestWrite<uint32_t>(code+4,upper);
  Ps2GuestWrite<uint32_t>(code+8,0x8000033c);Ps2GuestWrite<uint32_t>(code+12,0x2ff);
  if(unit)memory.markVU1CodeModified();else memory.markVU0CodeModified();
  vu.execute(code,16,data,unit?PS2_VU1_DATA_SIZE:PS2_VU0_DATA_SIZE,gs,&memory,0,0,0,64);
  assert(vu.state().cycles<64);
  assert(std::fwrite(&vu.state(),sizeof(vu.state()),1,f)==1);++cases;
 }}
 assert(std::fclose(f)==0);std::printf("cases=%u state_bytes=%zu\n",cases,sizeof(VU1State));
}
