#include "runtime/ps2_memory.h"
#include "runtime/ps2_vu1.h"
#include "runtime/gs/gs_frontend.h"
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cassert>
static uint64_t hash(const void*p,size_t n){auto*b=(const unsigned char*)p;uint64_t h=1469598103934665603ull;while(n--){h^=*b++;h*=1099511628211ull;}return h;}
int main(int argc,char**argv){
 unsigned mode=argc>1?std::strtoul(argv[1],nullptr,10):0,cycles=argc>2?std::strtoul(argv[2],nullptr,10):1000000;
 PS2Memory memory;assert(memory.initialize());GS gs;gs.init(memory.getGSVRAM(),PS2_GS_VRAM_SIZE,nullptr);
 auto unit=(mode==3)?VU1Interpreter::Unit::VU0:VU1Interpreter::Unit::VU1;
 VU1Interpreter vu(unit);auto*code=mode==3?memory.getVU0Code():memory.getVU1Code();auto*data=mode==3?memory.getVU0Data():memory.getVU1Data();
 const unsigned size=mode==2?1024:8;std::vector<uint8_t>untracked(size<16?16:size);
 for(unsigned p=0;p<size;p+=8){uint32_t lower=0x8000033cu,upper=0x2ffu;
  if(mode==1||mode==2){upper=(15u<<21)|(2u<<16)|(1u<<11)|(3u<<6)|((p&8)?0x2au:0x28u);}
  Ps2GuestWrite<uint32_t>(code+p,lower);Ps2GuestWrite<uint32_t>(code+p+4,upper);
 }
 if(mode==4){std::memcpy(untracked.data(),code,size);code=untracked.data();cycles/=10;}
 for(unsigned c=0;c<4;++c){vu.state().vf[1][c]=float(c+1);vu.state().vf[2][c]=float(c+2)*.25f;}
 auto start=std::chrono::steady_clock::now();
 vu.execute(code,size,data,mode==3?PS2_VU0_DATA_SIZE:PS2_VU1_DATA_SIZE,gs,&memory,0,0,0,cycles);
 auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
 assert(vu.state().cycles==cycles);
 // Drain pending writes through a real E-bit sequence before comparing state.
 Ps2GuestWrite<uint32_t>(code,0x8000033cu);Ps2GuestWrite<uint32_t>(code+4,0x400002ffu);
 Ps2GuestWrite<uint32_t>(code+8,0x8000033cu);Ps2GuestWrite<uint32_t>(code+12,0x2ffu);
 if(mode==3)memory.markVU0CodeModified();else memory.markVU1CodeModified();
 vu.state().pc=0;vu.resume(code,16,data,mode==3?PS2_VU0_DATA_SIZE:PS2_VU1_DATA_SIZE,gs,&memory,0,0,64);
 if(mode==1)assert(vu.state().vf[3][0]==1.5f);
 std::printf("{\"mode\":%u,\"cycles\":%u,\"seconds\":%.9f,\"state_hash\":\"%016llx\",\"data_hash\":\"%016llx\"}\n",mode,cycles,elapsed,(unsigned long long)hash(&vu.state(),sizeof(vu.state())),(unsigned long long)hash(data,mode==3?PS2_VU0_DATA_SIZE:PS2_VU1_DATA_SIZE));
}
