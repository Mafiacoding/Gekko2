#include <array>
#include <vector>
#include <cstddef>
#include <cstdint>
#define private public
#include "runtime/ps2_vu1.h"
#undef private
extern "C" __attribute__((used)) const uint32_t vu_manifest[]={sizeof(VU1Interpreter),offsetof(VU1Interpreter,m_state),sizeof(VU1State),offsetof(VU1Interpreter,m_cycle)};
