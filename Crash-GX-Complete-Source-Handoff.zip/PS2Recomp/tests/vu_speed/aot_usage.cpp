// Compare generated metadata with the production decoder for both VU units.
// The binary word catalog is owner-private: uint32 counts, upper words, lower words.
#include <array>
#include <vector>
#include <cstdint>
#include <cstddef>
#include <tuple>
#include <cassert>
#include <cstdio>
#define private public
#include "runtime/ps2_vu1.h"
#undef private
#include "runtime/ps2_vu1_aot.h"

static void same(const VU1Interpreter::InstructionUsage &a,
                 const VU1Interpreter::InstructionUsage &b)
{
    for (unsigned i = 0; i < a.vfRead.size(); ++i)
        assert(a.vfRead[i].reg == b.vfRead[i].reg && a.vfRead[i].lanes == b.vfRead[i].lanes);
    assert(a.vfWrite.reg == b.vfWrite.reg && a.vfWrite.lanes == b.vfWrite.lanes);
    assert(std::tie(a.vfReadCount,a.viRead,a.viWrite,a.accRead,a.accWrite,a.latency,
                    a.vfLatency,a.viLatency,a.pipeline,a.waitQ,a.waitP,a.readsClip,
                    a.writesClip,a.delaysNextBranchRead,a.reserved) ==
           std::tie(b.vfReadCount,b.viRead,b.viWrite,b.accRead,b.accWrite,b.latency,
                    b.vfLatency,b.viLatency,b.pipeline,b.waitQ,b.waitP,b.readsClip,
                    b.writesClip,b.delaysNextBranchRead,b.reserved));
}
int main(int argc, char **argv)
{
    assert(argc == 2);
    FILE *input = std::fopen(argv[1], "rb"); assert(input);
    uint32_t counts[2]; assert(std::fread(counts, sizeof(counts), 1, input) == 1);
    assert(counts[0] <= 65536 && counts[1] <= 65536);
    std::vector<uint32_t> words[2];
    for (unsigned half = 0; half < 2; ++half) {
        words[half].resize(counts[half]);
        assert(std::fread(words[half].data(), 4, counts[half], input) == counts[half]);
    }
    assert(std::fgetc(input) == EOF); std::fclose(input);
    unsigned cases = 0;
    for (auto unit : {VU1Interpreter::Unit::VU0, VU1Interpreter::Unit::VU1}) {
        VU1Interpreter vu(unit);
        for (uint32_t word : words[0]) {
            VU1Interpreter::InstructionUsage generated;
            const auto handler = VU1AotRegistry::upper(word, unit, &generated);
            assert(handler && handler == VU1AotRegistry::upper(word));
            same(generated, vu.decodeUpperUsage(word)); ++cases;
        }
        for (uint32_t word : words[1]) {
            VU1Interpreter::InstructionUsage generated;
            const auto handler = VU1AotRegistry::lower(word, unit, &generated);
            assert(handler && handler == VU1AotRegistry::lower(word));
            same(generated, vu.decodeLowerUsage(word)); ++cases;
        }
        // Missing entries must leave caller metadata untouched for the fallback.
        uint32_t missing = 0xdead0000u;
        while (VU1AotRegistry::upper(missing)) ++missing;
        VU1Interpreter::InstructionUsage untouched; untouched.vfReadCount = 17;
        assert(!VU1AotRegistry::upper(missing, unit, &untouched));
        assert(untouched.vfReadCount == 17);
    }
    std::printf("PASS: %u generated VU0/VU1 dependency records match production decoding\n", cases);
}
