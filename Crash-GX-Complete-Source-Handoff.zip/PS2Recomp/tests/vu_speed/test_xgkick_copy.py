#!/usr/bin/env python3
"""Compare the production wrapped qword copy with its byte-wise oracle."""
from pathlib import Path
import subprocess
import tempfile
import os
root = Path(__file__).resolve().parents[2]
core = (root/'ps2xRuntime/src/lib/vu/ps2_vu1_core.cpp').read_text()
a = core.index('    void copyWrappedQword(')
b = core.index('    constexpr uint8_t laneForComponent(', a)
helper = core[a:b]
source = r'''
#include <algorithm>
#include <array>
#include <vector>
#include <cstdint>
#include <cstring>
#include <limits>
#include <cassert>
HELPER
int main(){
 uint32_t seed=0x5900750;auto next=[&]{seed=seed*1664525u+1013904223u;return seed;};
 for(unsigned size=1;size<=257;++size)for(unsigned kind=0;kind<8;++kind){
  std::vector<uint8_t> expected(size+64),actual;
  for(auto &b:expected)b=uint8_t(next());actual=expected;
  uint32_t address=kind==0?0:kind==1?size-1:kind==2?size:kind==3?UINT32_MAX-7:next();
  const unsigned dest=kind<4?size+32:kind==4?0:kind==5?size/2:kind==6?size-1:1;
  for(unsigned i=0;i<16;++i)expected[dest+i]=expected[uint32_t(address+i)%size];
  copyWrappedQword(actual.data()+dest,actual.data(),size,address);
  assert(actual==expected);
 }
}
'''.replace('HELPER', helper)
with tempfile.TemporaryDirectory() as tmp:
    p=Path(tmp);(p/'copy.cpp').write_text(source)
    subprocess.run(['c++','-std=c++20','-O2','-fsanitize=address,undefined',str(p/'copy.cpp'),'-o',str(p/'copy')],check=True)
    subprocess.run([str(p/'copy')],check=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
print('PASS: 2,056 production XGKICK copy cases, including small RAM, wrap, aliases and uint32 overflow')
