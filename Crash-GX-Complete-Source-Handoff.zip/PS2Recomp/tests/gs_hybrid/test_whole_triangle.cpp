// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_native_whole_triangle.h"
#include <cstdio>
#include <cstdlib>
#include <limits>
static void Check(bool b){if(!b)std::abort();}
int main(){
 GSPrimitiveBatch b;b.vertexCount=3;auto &s=b.state;auto &c=s.context;
 s.prim.type=GS_PRIM_TRIANGLE;s.colclamp=1;c.frame.psm=GS_PSM_CT24;
 c.scissor={0,639,0,479};c.test=uint64_t(1)<<17;c.zbuf.zmask=true;
 b.vertices[0].x=4;b.vertices[0].y=4;b.vertices[1].x=60;b.vertices[1].y=8;b.vertices[2].x=16;b.vertices[2].y=56;
 float xy[6];Check(GSNativeWholeTriangle::Prepare(b,xy));
 const auto base=b;
 for(unsigned test=0;test<12;++test){
  b=base;
  switch(test){
   case 0:b.state.context.test|=1u;break; // Alpha NEVER.
   case 1:b.state.context.test|=0x4000;break; // Destination alpha.
   case 2:b.state.context.test=uint64_t(2)<<17;break;
   case 3:b.state.context.zbuf.zmask=false;break;
   case 4:b.state.scanmsk=2;break;
   case 5:b.state.prim.abe=true;b.state.pabe=true;break;
   case 6:b.vertices[0].x+=.03125f;break;
   case 7:b.vertices[0].x=-1;break;
   case 8:b.state.context.scissor.x1=32;break;
   case 9:b.vertices[1].y=std::numeric_limits<float>::infinity();break;
   case 10:b.state.context.frame.fbmsk=1;break;
   case 11:b.state.prim.aa1=true;break;
  }
  Check(!GSNativeWholeTriangle::Prepare(b,xy));
 }
 b=base;b.state.context.xyoffset.ofx=8;
 for(auto &v:b.vertices)v.x+=.5f;
 Check(GSNativeWholeTriangle::Prepare(b,xy));
 b=base;for(unsigned i=0;i<3;++i){b.vertices[i].x+=i/16.f;b.vertices[i].y+=(3-i)/16.f;}Check(GSNativeWholeTriangle::Prepare(b,xy));
 b=base;b.state.context.test|=3u;Check(GSNativeWholeTriangle::Prepare(b,xy)); // Alpha ALWAYS.
 std::puts("whole-triangle eligibility: 12.4/offset admission and 12 rejection families passed");
}
