// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/ps2_gs_memory.h"
#include <algorithm>
#include <cstdio>
#include <stdexcept>
static void check(bool ok,const char *why){if(!ok)throw std::runtime_error(why);}
int main(){try{
 const unsigned formats[]={GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH,GS_PSM_Z32,GS_PSM_Z24,GS_PSM_Z16,GS_PSM_Z16S};
 std::vector<uint8_t> vram(4*1024*1024);GSCpuBackend backend;backend.Initialize(vram.data(),vram.size());
 for(unsigned psm:formats){
  backend.Reset();GSDrawState s;s.context.tex0.psm=psm;s.context.tex0.tbp0=16352;s.context.tex0.tbw=16;s.context.tex0.tw=s.context.tex0.th=10;s.textureWidth=s.textureHeight=1024;s.texa.ta0=s.texa.ta1=128;
  const bool indexed=psm==GS_PSM_T8||psm==GS_PSM_T4||psm==GS_PSM_T8H||psm==GS_PSM_T4HL||psm==GS_PSM_T4HH;
  const bool sixteen=psm==GS_PSM_CT16||psm==GS_PSM_CT16S||psm==GS_PSM_Z16||psm==GS_PSM_Z16S;
  if(indexed){s.context.tex0.cpsm=GS_PSM_CT32;s.context.tex0.cbp=256;s.context.tex0.csm=1;s.context.tex0.cld=1;backend.WriteVram(0,256,1,1,0,0x80123456);backend.WriteVram(0,256,1,2,0,0x8000ee00);GSTexClutReg clut;clut.cbw=1;backend.LoadClut(s.context.tex0,clut);}
  const uint32_t raw=indexed?1:sixteen?0x801f:0x80123456;
  GSCpuBackend::NativeTextureRect rect{512,256,4,4};
  for(unsigned y=0;y<4;y++)for(unsigned x=0;x<4;x++)backend.WriteVram(psm,16352,16,rect.x+x,rect.y+y,raw);
  GSCpuBackend::NativeTextureStamp stamp,before;
  check(!backend.GetNativeTextureRectStamp(s,rect,stamp),"uncached rectangle received stamp");
  std::vector<uint32_t> pixels;check(backend.DecodeNativeTextureRect(s,rect,pixels),"large logical texture crop rejected");
  const uint32_t expected=sixteen?0x800000f8:psm==GS_PSM_Z24?0x00123456:0x80123456;
  if(pixels.size()!=16||!std::all_of(pixels.begin(),pixels.end(),[&](auto p){return p==expected;})){std::fprintf(stderr,"format=%x got=%08x expected=%08x\n",psm,pixels[0],expected);throw std::runtime_error("crop decode/TEXA/CLUT differs");}
  check(backend.GetNativeTextureRectStamp(s,rect,before),"decoded crop not latched");
  backend.WriteVram(psm,16352,16,512,256,2);
  check(backend.DecodeNativeTextureRect(s,rect,pixels)&&pixels[0]==expected,"unflushed source write lost retained crop");
  std::vector<uint32_t> sentinel{0xdeadbeef};
  const unsigned pageWidth=(psm==GS_PSM_T8||psm==GS_PSM_T4)?128:64;
  GSCpuBackend::NativeTextureRect cross{uint16_t(pageWidth-1),0,2,1};
  check(!backend.DecodeNativeTextureRect(s,cross,sentinel)&&sentinel==std::vector<uint32_t>{0xdeadbeef},"cross-page rectangle changed output");
  check(backend.GetNativeTextureRectStamp(s,rect,stamp)&&stamp.texels==before.texels&&stamp.clut==before.clut,"rejected rectangle changed latch");
  check(!backend.DecodeNativeTextureRect(s,{0,0,129,1},sentinel),"oversize rectangle accepted");
  backend.TextureFlush();check(!backend.GetNativeTextureRectStamp(s,rect,stamp),"flushed crop kept stamp");
  check(backend.DecodeNativeTextureRect(s,rect,pixels)&&pixels[0]!=expected,"crop TEXFLUSH did not refresh");
 }
 backend.Reset();GSDrawState s;s.context.tex0.psm=GS_PSM_CT32;s.context.tex0.tbw=16;s.context.tex0.tw=s.context.tex0.th=4;s.textureWidth=s.textureHeight=16;s.context.clamp=3|(3<<2);
 backend.WriteVram(0,0,16,512,256,0x80123456);std::vector<uint32_t> pixels;
 check(backend.DecodeNativeTextureRect(s,{512,256,1,1},pixels)&&pixels[0]==0x80123456,"already-mapped region coordinate wrapped twice");
 std::puts("PASS: 13 swizzled/aliased formats, large logical source crops, physical wrapping, cache/CLUT/TEXA and rejection lifetime");return 0;
 }catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
