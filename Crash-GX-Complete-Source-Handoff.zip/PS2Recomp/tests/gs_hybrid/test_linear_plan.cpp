// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_native_linear_plan.h"
#include "runtime/gs/gs_cpu_backend.h"
#include <cstdio>
#include <stdexcept>
int main(){try{
 std::vector<uint8_t> vram(4*1024*1024);GSCpuBackend oracle;oracle.Initialize(vram.data(),vram.size());
 unsigned cases=0,pixels=0;
 for(unsigned edge=0;edge<4;++edge)for(unsigned clip=0;clip<4;++clip)
 for(unsigned scan=0;scan<4;++scan)for(unsigned winding=0;winding<2;++winding){
  GSPrimitiveBatch b;b.vertexCount=3;auto&s=b.state;s.prim.type=GS_PRIM_TRIANGLE;s.colclamp=1;
  s.context.frame={128,10,GS_PSM_CT32,0};s.context.zbuf.zmask=true;s.context.test=uint64_t(1)<<17;
  const unsigned ox=edge&1?620:0,oy=edge&2?460:0;
  s.context.scissor={uint16_t(ox+clip),uint16_t(ox+19-clip),uint16_t(oy+clip),uint16_t(oy+19-clip)};s.scanmsk=scan;
  for(unsigned i=0;i<3;++i){auto&v=b.vertices[i];v.x=ox+(i==1?19.75f:.25f);v.y=oy+(i==2?19.75f:.25f);v.r=31;v.g=79;v.b=123;v.a=128;}
  if(winding)std::swap(b.vertices[1],b.vertices[2]);
  GSNativeLinearPlan p;if(!GSNativeLinearPlan::Prepare(b,p))throw std::runtime_error("viewport-edge plan rejected");
  if((p.x|p.y|p.width|p.height)&3)throw std::runtime_error("unaligned resident tile extent");
  std::fill(vram.begin(),vram.end(),0);oracle.Submit(b);
  for(unsigned y=oy;y<oy+20;++y)for(unsigned x=ox;x<ox+20;++x){
   const int row=int(y)-p.y,col=int(x)-p.x;
   const bool inside=row>=0&&row<p.height&&col>=p.left[row]&&col<p.right[row];
   const bool drawn=oracle.ReadVram(0,128*32,10,x,y)!=0;
   if(inside!=drawn)throw std::runtime_error("linear geometry differs from canonical raster");
   pixels+=drawn;
  }++cases;
 }
 // SCANMSK suppresses framebuffer/Z writes after canonical texture sampling.
 // Compare the retained page against an actual software draw, not just spans.
 for(unsigned scan=0;scan<4;++scan){
  GSPrimitiveBatch b;b.vertexCount=3;auto&s=b.state;s.prim.type=GS_PRIM_TRIANGLE;s.prim.tme=true;s.linearFilter=true;s.colclamp=1;
  s.context.frame={128,1,GS_PSM_CT32,0};s.context.scissor={0,63,0,63};s.context.zbuf.zmask=true;s.context.test=uint64_t(1)<<17;
  s.scanmsk=scan;s.textureWidth=s.textureHeight=128;s.context.tex0={0,2,GS_PSM_CT32,7,7,1,1,0,0,0,0,0};s.context.clamp=5;
  for(unsigned n=0;n<3;++n){auto&v=b.vertices[n];v.x=4+(n==1?36:0);v.y=4+(n==2?36:0);v.s=n==1?.8f:.1f;v.t=n==2?.95f:.1f;v.q=1;v.a=128;}
  GSNativeLinearPlan p;if(!GSNativeLinearPlan::Prepare(b,p))throw std::runtime_error("scan texture plan rejected");
  std::vector<uint8_t> memory(4*1024*1024);GSCpuBackend native;native.Initialize(memory.data(),memory.size());
  oracle.TextureFlush();oracle.Submit(b);
  if(!native.CommitCoherentNativeSample(s,p.lastSample[0],p.lastSample[1],p.lastSample[2]))throw std::runtime_error("scan final commit rejected");
  for(unsigned y=0;y<128;y+=8)for(unsigned x=0;x<128;x+=8){GSCpuBackend::NativeTextureStamp a,bb;
   if(native.GetNativeTextureRectStamp(s,{uint16_t(x),uint16_t(y),1,1},a)!=oracle.GetNativeTextureRectStamp(s,{uint16_t(x),uint16_t(y),1,1},bb))throw std::runtime_error("scan mask changed final retained texture page");
  }
 }
 std::printf("PASS: %u linear plans / %u covered pixels; viewport boundaries, clipping, scan masks, winding\n",cases,pixels);return 0;
}catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
