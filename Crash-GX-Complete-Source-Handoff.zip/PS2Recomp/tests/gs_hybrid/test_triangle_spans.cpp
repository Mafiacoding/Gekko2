// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_triangle_coverage.h"
#include <algorithm>
#include <cstdio>
#include <stdexcept>
int main(){
    uint32_t random=0x7505900;auto next=[&]{random=random*1664525u+1013904223u;return random;};
    try{
        unsigned long long checks=0;
        for(unsigned n=0;n<4096;++n){
            const int widths[]={1,8,31,32,33,64,127,640};
            const int width=widths[n%8];
            int32_t xy[6];for(auto &v:xy)v=int(next()%1025)-256;
            if(n%16==0){xy[4]=xy[2];xy[5]=xy[3];}
            const int ox=int(next()%33)-16,oy=int(next()%33)-16;
            GSFixedTriangleCoverage c(xy,ox*16+8,oy*16+8);
            for(int y=0;y<32;++y){
                auto span=c.rowSpan(y,width);
                if(span.begin<0||span.end>width||span.begin>span.end)throw std::runtime_error("span outside clip");
                for(int x=0;x<width;++x){
                    bool oracle=c.area!=0;
                    for(const auto &edge:c.edges)oracle&=edge.contains(edge.value+edge.stepX*x+edge.stepY*y);
                    ++checks;
                    if(oracle!=(x>=span.begin&&x<span.end))throw std::runtime_error("analytic span differs from canonical raster coverage");
                }
            }
            if(c.rowSpan(-1,32).end||c.rowSpan(0,0).end)throw std::runtime_error("invalid clip admitted");
        }
        std::printf("PASS: 4096 fractional/clipped/winding/degenerate triangles, widths 1..640, %llu canonical pixel checks\n",checks);return 0;
    }catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}
}
