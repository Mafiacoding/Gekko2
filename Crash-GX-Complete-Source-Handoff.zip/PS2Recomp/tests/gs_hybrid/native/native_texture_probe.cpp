// SPDX-License-Identifier: GPL-3.0-or-later
// Native GX point-texture sampling with the canonical software texel/CLUT cache.
#include <gccore.h>
#include <unistd.h>
#include <malloc.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_hybrid_backend.h"
#include "runtime/gs/gs_triangle_coverage.h"
#include "ps2_wii_gx_driver.h"
extern "C" {
#include "core/hw/gs_gx.h"
#include "core/hw/gs_mem.h"
int probe_bind(uint8_t*,uint32_t);int probe_unbind(void);int probe_gx_init(void);
uint32_t gs_scanout_read_rgb(uint32_t bp,uint32_t bw,uint32_t x,uint32_t y,uint32_t psm){if(psm>1)std::abort();return gs_mem_read_psmct32(bp,bw,x,y);}
volatile uint32_t probe_result[64];
}
namespace {
constexpr unsigned Size=4*1024*1024;
alignas(32) uint8_t actual[Size],expected[Size];
void Check(bool ok,const char *message){if(!ok)throw std::runtime_error(message);}
using TextureDriver=PS2WiiGXTextureDriver;

GSPrimitiveBatch Batch(unsigned psm,unsigned scale,unsigned destination=64)
{
    GSPrimitiveBatch b;b.vertexCount=2;b.state.prim.type=GS_PRIM_SPRITE;b.state.prim.tme=true;b.state.prim.fst=true;
    b.state.context.frame={destination,1,GS_PSM_CT32,0};b.state.context.scissor={0,63,0,63};b.state.context.test=uint64_t(1)<<17;b.state.context.zbuf.zmask=true;b.state.colclamp=1;
    auto &t=b.state.context.tex0;t.psm=psm;t.tbw=(psm==GS_PSM_T8||psm==GS_PSM_T4)?2:1;t.tw=t.th=3;t.tcc=1;t.tfx=1;t.cbp=128;t.cpsm=GS_PSM_CT32;t.csm=1;t.cld=1;
    b.state.textureWidth=b.state.textureHeight=8;b.state.texa.ta0=b.state.texa.ta1=128;
    b.vertices[0].x=4;b.vertices[0].y=4;b.vertices[1].x=4+(scale==0?8:scale==1?16:4);b.vertices[1].y=4+(scale==2?4:8);
    b.vertices[1].u=b.vertices[1].v=128;b.vertices[1].a=0x33;return b;
}
void Fill(GSCpuBackend &oracle,const GSPrimitiveBatch &b,bool varyingAlpha=false)
{
    auto &t=b.state.context.tex0;
    bool indexed=t.psm==GS_PSM_T8||t.psm==GS_PSM_T4||t.psm==GS_PSM_T8H||t.psm==GS_PSM_T4HL||t.psm==GS_PSM_T4HH;
    for(unsigned i=0;i<256;++i)oracle.WriteVram(0,128,1,i,0,0x80000000|((i*17&255)<<16)|((i*31&255)<<8)|(i*7&255));
    for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x){
        uint32_t value=indexed?(x+y*8)%16:t.psm==GS_PSM_CT16||t.psm==GS_PSM_CT16S||t.psm==GS_PSM_Z16||t.psm==GS_PSM_Z16S?0x8000|(x*3&31)|((y*4&31)<<5):
           ((varyingAlpha?((x+y)&1?128:32):128)<<24)|(x*29)|(y*31<<8)|((x+y)*13<<16);
        oracle.WriteVram(t.psm,t.tbp0,t.tbw,x,y,value);
    }
}
void Compare(GSHybridBackend &hybrid)
{
    std::vector<uint8_t> snapshot;hybrid.SnapshotVram(snapshot);
    if(snapshot.size()!=Size||std::memcmp(snapshot.data(),expected,Size)){
        for(unsigned i=0;i<Size;++i)if(snapshot[i]!=expected[i]){probe_result[7]=i;probe_result[15]=snapshot[i];probe_result[16]=expected[i];break;}
        throw std::runtime_error("texture VRAM mismatch");
    }
    probe_result[1]=probe_result[1]+1;
}
void One(unsigned psm,unsigned scale,unsigned n,unsigned mode=0)
{
    std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
    auto b=Batch(psm,scale);if(n&1)b.state.context.scissor={5,18,5,18};b.state.scanmsk=(n/2)&3;
    if(n&2)b.state.context.frame.psm=1;if(n&4)b.state.context.tex0.tcc=0;
    bool fallback=mode!=0&&mode!=6&&mode!=9;
    if(mode==1)b.state.linearFilter=true;
    if(mode==2){b.state.context.frame.psm=0;b.state.context.tex0.tcc=1;}
    if(mode==3)b.state.context.frame.fbp=0;
    if(mode==4)b.vertices[0].u=8;
    if(mode==5)b.state.context.clamp=2;
    if(mode==6){b.state.context.frame.psm=1;b.state.context.tex0.tcc=1;}
    if(mode==7)b.state.context.tex1=1u<<2;
    if(mode==8)b.state.context.tex0.tbp0=1;
    if(mode==11){b.vertices[0].y=480;b.vertices[1].y=488;b.state.context.scissor={0,63,480,511};}
    if(mode==12){b.vertices[0].y=4;b.vertices[1].y=5;b.vertices[1].v=16;b.state.scanmsk=2;b.state.context.scissor={0,63,0,63};}
    if(mode>=13){b.state.context.frame.fbp=511;
        if(mode==14){b.state.prim.fst=false;b.state.textureWidth=b.state.textureHeight=1024;b.state.context.tex0.tw=b.state.context.tex0.th=10;b.vertices[1].s=b.vertices[1].t=8.f/1024;}
        if(mode==15)b.state.prim.tme=false;
    }
    if(mode==9){auto &t=b.state.context.tex0;t.tw=(psm==GS_PSM_T8||psm==GS_PSM_T4)?7:6;t.th=psm==GS_PSM_T4?7:psm==GS_PSM_CT32?5:6;b.state.textureWidth=1u<<t.tw;b.state.textureHeight=1u<<t.th;b.state.context.frame.psm=1;}
    Fill(oracle,b,mode==2||mode==6);std::memcpy(actual,expected,Size);
    auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
    GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
    GSTexClutReg clut;clut.cbw=1;hybrid.LoadClut(b.state.context.tex0,clut);oracle.LoadClut(b.state.context.tex0,clut);
    hybrid.Submit(b);oracle.Submit(b);auto counts=hybrid.GetCounters();
    Check(fallback?counts.softwareDraws==1:counts.nativeDraws==1,"wrong texture routing");
    if(!fallback)Check(std::memcmp(actual,expected,Size)!=0,"textured draw mirrored on CPU");
    Compare(hybrid);probe_result[10]=probe_result[10]+counts.nativeDraws;probe_result[11]=probe_result[11]+counts.softwareDraws;
    probe_result[12]=probe_result[12]+native->uploads;probe_result[13]=probe_result[13]+native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
}
void Retained()
{
    std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);auto b=Batch(GS_PSM_CT32,0);Fill(oracle,b);std::memcpy(actual,expected,Size);
    auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
    auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
    GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
    hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);
    hybrid.WriteVram(0,0,1,0,0,0x8000ff00);oracle.WriteVram(0,0,1,0,0,0x8000ff00);
    hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);Check(hybrid.ReadVram(0,64*32,1,4,4)==0x80000000,"native decode lost retained texels");
    hybrid.TextureFlush();oracle.TextureFlush();hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);
    Check(hybrid.ReadVram(0,64*32,1,4,4)==0x8000ff00,"native TEXFLUSH ignored");
    // Switch native -> unsupported textured CPU draw using the same guest cache.
    b.state.linearFilter=true;hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);
    auto counts=hybrid.GetCounters();probe_result[10]+=counts.nativeDraws;probe_result[11]+=counts.softwareDraws;
    probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
}
void ProducerConsumer()
{
    std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
    auto first=Batch(GS_PSM_CT32,0);first.vertices[0].x=first.vertices[0].y=0;first.vertices[1].x=first.vertices[1].y=8;
    Fill(oracle,first);std::memcpy(actual,expected,Size);
    auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
    GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
    hybrid.Submit(first);oracle.Submit(first);Check(std::memcmp(actual,expected,Size)!=0,"producer mirrored on CPU");
    auto second=Batch(GS_PSM_CT32,0,128);second.state.context.tex0.tbp0=64*32;
    hybrid.Submit(second);oracle.Submit(second);Check(hybrid.GetCounters().nativeDraws==2,"producer-consumer not native");Compare(hybrid);
    auto counts=hybrid.GetCounters();probe_result[10]+=counts.nativeDraws;probe_result[11]+=counts.softwareDraws;
    probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
}
void Triangles()
{
    const unsigned formats[]={GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH};
    for(unsigned psm:formats)for(unsigned variant=0;variant<8;++variant){
        probe_result[20]=46+psm*8+variant;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto b=Batch(psm,0);b.vertexCount=3;b.state.prim.type=static_cast<GSPrimType>(GS_PRIM_TRIANGLE+(variant%3));
        b.vertices[0].x=4;b.vertices[0].y=4;b.vertices[0].u=0;b.vertices[0].v=0;
        b.vertices[1].x=20;b.vertices[1].y=4;b.vertices[1].u=128;b.vertices[1].v=0;
        b.vertices[2]=b.vertices[1];b.vertices[2].x=4;b.vertices[2].y=20;b.vertices[2].u=0;b.vertices[2].v=128;
        if(variant&1)std::swap(b.vertices[1],b.vertices[2]);
        if(variant&2)for(auto &vertex:b.vertices)std::swap(vertex.u,vertex.v);
        if(variant&4){b.state.context.scissor={6,16,5,17};b.state.scanmsk=3;b.state.context.frame.psm=1;}
        Fill(oracle,b);std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
        auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        GSTexClutReg clut;clut.cbw=1;hybrid.LoadClut(b.state.context.tex0,clut);oracle.LoadClut(b.state.context.tex0,clut);
        // Two identical draws verify source upload reuse with real GX rendering.
        for(unsigned repeat=0;repeat<2;++repeat){hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);}
        const auto counts=hybrid.GetCounters();
        Check(counts.nativeDraws==2&&counts.softwareDraws==0,"triangle routing");
        Check(native->uploads==1&&native->reuses==1&&native->triangles==2,"triangle upload reuse");
        probe_result[10]+=counts.nativeDraws;probe_result[11]+=counts.softwareDraws;
        probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;
        probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
    }
}
void FlatCombineAndBlend()
{
    for(unsigned shape=0;shape<2;++shape)for(unsigned tfx=0;tfx<4;++tfx)for(unsigned mode=0;mode<4;++mode)for(unsigned filter=0;filter<2;++filter){
        probe_result[20]=500+shape*16+tfx*4+mode;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto b=Batch(mode&1?GS_PSM_T8:GS_PSM_CT32,0);
        b.state.linearFilter=filter;b.state.context.clamp=filter?5:0;
        b.state.context.tex0.tfx=tfx;b.state.context.tex0.tcc=!(mode&1);b.state.context.frame.psm=mode&1;
        b.state.prim.abe=mode&2;b.state.context.alpha=(uint64_t(128)<<32)|0x68;
        b.vertices[1].r=67;b.vertices[1].g=149;b.vertices[1].b=231;b.vertices[1].a=73;
        if(shape){b.vertexCount=3;b.state.prim.type=GS_PRIM_TRIANGLE;
            b.vertices[0].x=b.vertices[0].y=4;b.vertices[1].x=20;b.vertices[1].y=4;b.vertices[1].u=128;b.vertices[1].v=0;
            b.vertices[2]=b.vertices[1];b.vertices[2].x=4;b.vertices[2].y=20;b.vertices[2].u=0;b.vertices[2].v=128;}
        Fill(oracle,b);std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        GSTexClutReg clut;clut.cbw=1;hybrid.LoadClut(b.state.context.tex0,clut);oracle.LoadClut(b.state.context.tex0,clut);
        // Repeated blending must consume the previous GPU destination.
        for(unsigned repeat=0;repeat<2;++repeat){hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);}
        auto counts=hybrid.GetCounters();Check(counts.nativeDraws==2,"combine/additive routing");
        probe_result[10]+=counts.nativeDraws;probe_result[11]+=counts.softwareDraws;probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
    }
}
void BatchedTextures()
{
    probe_result[20]=600;
    std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);auto b=Batch(GS_PSM_CT32,0);Fill(oracle,b);std::memcpy(actual,expected,Size);
    auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
    GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
    for(unsigned i=0;i<16;++i){hybrid.Submit(b);oracle.Submit(b);}
    Check(hybrid.GetCounters().resolves==0,"repeated source forced per-draw readback");
    Check(native->uploads==1&&native->reuses==15&&native->decodes==1&&native->decodeReuses==15,"resident upload reuse failed");
    Check(std::memcmp(actual,expected,Size)!=0,"resident textured batch mirrored on CPU");
    Compare(hybrid);Check(hybrid.GetCounters().resolves==1,"resident batch did not resolve once");
    hybrid.Submit(b);oracle.Submit(b);
    b.state.context.tex0.tfx=0;b.vertices[1].r=87;b.vertices[1].g=101;b.vertices[1].b=63;b.vertices[1].a=128;
    // Changed source-space combine must not overwrite a live upload buffer.
    hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);
    Check(hybrid.GetCounters().softwareDraws==1,"live upload overwrite was not rejected");
    auto counts=hybrid.GetCounters();probe_result[10]+=counts.nativeDraws;probe_result[11]+=counts.softwareDraws;probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
    probe_result[18]=counts.resolves;
}
void Bilinear()
{
    for(unsigned shape=0;shape<2;++shape)for(unsigned scale=0;scale<3;++scale)for(unsigned pattern=0;pattern<8;++pattern){
        probe_result[20]=650+shape*24+scale*8+pattern;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto b=Batch(GS_PSM_CT32,scale);b.state.linearFilter=true;b.state.context.clamp=5;
        if(shape){b.vertexCount=3;b.state.prim.type=GS_PRIM_TRIANGLE;
            b.vertices[1].x=20;b.vertices[1].y=4;b.vertices[1].u=128;b.vertices[1].v=0;
            b.vertices[2]=b.vertices[1];b.vertices[2].x=4;b.vertices[2].y=20;b.vertices[2].u=0;b.vertices[2].v=128;
            if(scale==1)std::swap(b.vertices[1],b.vertices[2]);if(scale==2)b.state.scanmsk=2;
        }
        uint32_t random=0x12345678u+pattern;
        for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x){
            random=random*1664525u+1013904223u;
            uint32_t value=pattern?0x80000000|(random&0x00f0f0f0u):0x80000000|(x*16)|(y*16<<8)|((x+y)*16<<16);
            if(pattern==7)value|=0x00010101;
            oracle.WriteVram(0,0,1,x,y,value);
        }
        std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);Check(hybrid.GetCounters().nativeDraws==1,"bilinear routing");
        auto counts=hybrid.GetCounters();probe_result[10]+=counts.nativeDraws;probe_result[11]+=counts.softwareDraws;probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
    }
}
void MirroredPointSprites()
{
    const float slopes[]={-2,-1,-.5f,-.25f,0,.25f,.5f,1,2};
    unsigned n=0;
    for(float du:slopes)for(float dv:slopes){
        probe_result[20]=750+n++;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);auto b=Batch(GS_PSM_CT32,0);
        const unsigned w=std::fabs(du)==2?2:std::fabs(du)==1?4:8,h=std::fabs(dv)==2?2:std::fabs(dv)==1?4:8;
        b.vertices[1].x=4+w;b.vertices[1].y=4+h;
        const float u=du<0?7:du==0?3:0,v=dv<0?7:dv==0?3:0;
        b.vertices[0].u=u*16;b.vertices[0].v=v*16;b.vertices[1].u=(u+w*du)*16;b.vertices[1].v=(v+h*dv)*16;
        Fill(oracle,b);std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);Check(hybrid.GetCounters().nativeDraws==1,"mirrored point routing");
        auto counts=hybrid.GetCounters();probe_result[10]+=counts.nativeDraws;probe_result[11]+=counts.softwareDraws;probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
    }
}
void TriangleFallbacks()
{
    for(unsigned mode=0;mode<4;++mode){
        probe_result[20]=850+mode;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);auto b=Batch(GS_PSM_CT32,0);
        b.vertexCount=3;b.state.prim.type=GS_PRIM_TRIANGLE;
        b.vertices[1].x=20;b.vertices[1].y=4;b.vertices[1].u=128;b.vertices[1].v=0;
        b.vertices[2]=b.vertices[1];b.vertices[2].x=4;b.vertices[2].y=20;b.vertices[2].u=0;b.vertices[2].v=128;
        if(mode==0)b.vertices[1].x=19;
        if(mode==1)b.vertices[1].u=96;
        if(mode==2){b.state.prim.iip=true;b.state.context.tex0.tfx=0;b.vertices[1].r=127;}
        if(mode==3){b.state.prim.fst=false;b.vertices[1].s=1;b.vertices[2].t=1;b.vertices[1].q=-1;}
        Fill(oracle,b);std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);Check(hybrid.GetCounters().softwareDraws==1&&hybrid.GetCounters().nativeDraws==0,"triangle fallback routing");
        probe_result[11]+=hybrid.GetCounters().softwareDraws;
    }
}
void FlatSprites()
{
    for(unsigned psm=0;psm<2;++psm)for(unsigned scan=0;scan<4;++scan)for(unsigned place=0;place<2;++place){
        probe_result[20]=900+psm*8+scan*2+place;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);auto b=Batch(GS_PSM_CT32,0);
        b.state.prim.tme=false;b.state.context.frame.psm=psm;b.state.scanmsk=scan;
        b.vertices[0].x=place?20:4;b.vertices[0].y=place?32:4;
        b.vertices[1].x=b.vertices[0].x+8;b.vertices[1].y=b.vertices[0].y+8;
        b.vertices[1].r=0x74;b.vertices[1].g=0xab;b.vertices[1].b=0x23;b.vertices[1].a=0xff;
        std::memcpy(actual,expected,Size);auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);Check(hybrid.GetCounters().nativeDraws==1&&native->flats==1,"native flat routing");
        probe_result[10]+=1;probe_result[26]+=native->flats;
    }
}
void FlatFades()
{
    const unsigned alphas[]={0,1,63,127,128,129,249,255};
    for(unsigned psm=0;psm<2;++psm)for(unsigned scan=0;scan<4;++scan)
    for(unsigned alpha:alphas)for(unsigned variant=0;variant<2;++variant){
        probe_result[20]=0x2000+psm*1024+scan*256+alpha;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto b=Batch(GS_PSM_CT32,0);b.state.prim.tme=false;b.state.prim.abe=true;
        b.state.context.alpha=0x42;b.state.context.frame.psm=psm;b.state.scanmsk=scan;
        b.state.context.scissor={5,58,7,57};
        b.vertices[0].x=b.vertices[0].y=0;b.vertices[1].x=b.vertices[1].y=64;
        auto &v=b.vertices[1];v.r=variant?1:0;v.g=variant?127:128;v.b=variant?249:255;v.a=alpha;
        if(variant)b.state.context.test|=1u|(1u<<1); // ATE with ALWAYS passing.
        for(unsigned y=0;y<64;++y)for(unsigned x=0;x<64;++x)
            oracle.WriteVram(psm,64*32,1,x,y,((x+y)&255)<<24|(x*17+y*11)&255|(((x*3+y*29)&255)<<8)|(((x*31+y*7)&255)<<16));
        std::memcpy(actual,expected,Size);auto software=std::make_unique<GSCpuBackend>();
        auto driver=std::make_unique<TextureDriver>(software.get());auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        for(unsigned repeat=0;repeat<2;++repeat){hybrid.Submit(b);oracle.Submit(b);}
        Check(hybrid.GetCounters().resolves==0,"flat fade forced intermediate readback");
        Check(hybrid.GetCounters().nativeDraws==2&&hybrid.GetCounters().softwareDraws==0&&native->flats==2&&native->flatSubtractions==2,"flat fade did not use GX");
        Check(native->uploads==0&&native->decodes==0,"flat fade prepared an unnecessary image");
        Compare(hybrid);probe_result[10]+=2;probe_result[26]+=2;
    }
    // Full loading-screen size, with an existing native background retained
    // in EFB and two subtractive passes before the first VRAM resolve.
    for(unsigned psm=0;psm<2;++psm)for(unsigned variant=0;variant<2;++variant){
        probe_result[20]=0x3000+psm*2+variant;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto b=Batch(GS_PSM_CT32,0);b.state.prim.tme=false;b.state.context.frame={64,10,uint8_t(psm),0};
        b.state.context.scissor={0,639,0,223};b.vertices[0].x=b.vertices[0].y=0;b.vertices[1].x=640;b.vertices[1].y=224;
        auto &v=b.vertices[1];v.r=200;v.g=129;v.b=70;v.a=93;
        std::memcpy(actual,expected,Size);auto software=std::make_unique<GSCpuBackend>();
        auto driver=std::make_unique<TextureDriver>(software.get());
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        hybrid.Submit(b);oracle.Submit(b);
        b.state.prim.abe=true;b.state.context.alpha=0x42;
        b.state.context.test=0x337fb; // Real loading fade: alpha >= 127.
        v.r=1;v.g=127;v.b=249;v.a=variant?128:127;
        for(unsigned repeat=0;repeat<2;++repeat){hybrid.Submit(b);oracle.Submit(b);}
        Check(hybrid.GetCounters().resolves==0&&hybrid.GetCounters().nativeDraws==3,"full-size fade lost resident RGB");
        Compare(hybrid);probe_result[10]+=3;probe_result[26]+=3;
    }
}
void CompactSurfaces()
{
    for(unsigned mode=0;mode<5;++mode){
        probe_result[20]=940+mode;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);auto b=Batch(GS_PSM_CT32,0);
        b.state.context.frame.fbw=10;b.state.context.scissor={0,639,0,447};
        b.state.prim.tme=mode>=3;b.state.prim.abe=mode==3;b.state.context.alpha=(uint64_t(128)<<32)|0x68;
        b.state.context.frame.psm=mode==1?1:0;b.state.scanmsk=mode==2?2:0;
        b.vertices[0].x=mode==1?3:0;b.vertices[0].y=mode==1?5:0;b.vertices[1].x=mode==1?637:640;b.vertices[1].y=mode==1?443:448;
        b.vertices[1].r=0xab;b.vertices[1].g=0xcd;b.vertices[1].b=0xef;b.vertices[1].a=0x77;
        b.vertices[0].u=b.vertices[1].u=48;b.vertices[0].v=b.vertices[1].v=48;
        if(b.state.prim.tme)Fill(oracle,b);std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        const unsigned repeats=mode==4?16:1;
        for(unsigned i=0;i<repeats;++i){
            if(mode==4){b.vertices[0].x=3+i*16;b.vertices[0].y=5+(i%4)*16;b.vertices[1].x=b.vertices[0].x+6;b.vertices[1].y=b.vertices[0].y+6;}
            hybrid.Submit(b);oracle.Submit(b);
        }
        Check(hybrid.GetCounters().nativeDraws==repeats,"compact full-surface routing");Compare(hybrid);
        auto counts=hybrid.GetCounters();probe_result[10]+=counts.nativeDraws;probe_result[11]+=counts.softwareDraws;probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;probe_result[26]+=native->flats;
    }
}
// Exercise actual GX sampling of cropped STQ images, not a CPU frame upload.
void CroppedSTQ()
{
    const unsigned formats[]={GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH,GS_PSM_Z32,GS_PSM_Z24,GS_PSM_Z16,GS_PSM_Z16S};
    for(unsigned psm:formats)for(unsigned variant=0;variant<8;++variant){
        probe_result[20]=500+psm*8+variant;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto b=Batch(psm,0);Fill(oracle,b,true);
        auto &c=b.state.context;
        if(variant&4){
            const auto &t=c.tex0;
            for(unsigned y=0;y<8;++y)for(unsigned x=0;x<8;++x)
                oracle.WriteVram(t.psm,t.tbp0,t.tbw,512+x,256+y,oracle.ReadVram(t.psm,t.tbp0,t.tbw,x,y));
        }
        b.state.prim.fst=false;b.state.prim.iip=true;
        c.tex0.tw=c.tex0.th=10;b.state.textureWidth=b.state.textureHeight=1024;c.clamp=5;
        c.tex1=uint64_t(0xffffffa6)<<32; // K without a mip level.
        b.vertices[0].x=4.25f;b.vertices[0].y=4.125f;
        b.vertices[1].x=20.25f;b.vertices[1].y=20.125f;
        b.vertices[0].q=3;b.vertices[1].q=.5f;
        b.vertices[0].s=b.vertices[0].t=0;
        b.vertices[1].s=b.vertices[1].t=8.f/2048;
        if(variant&4){b.vertices[0].s+=.25f;b.vertices[1].s+=.25f;b.vertices[0].t+=.125f;b.vertices[1].t+=.125f;}
        if(variant&2){
            b.state.prim.fst=true;
            for(unsigned v=0;v<2;++v){b.vertices[v].u=b.vertices[v].s*32768;b.vertices[v].v=b.vertices[v].t*32768;}
        }
        b.vertices[1].r=96;b.vertices[1].g=128;b.vertices[1].b=160;b.vertices[1].a=64;
        c.tex0.tfx=variant&3;
        if(variant&4){std::swap(b.vertices[0].x,b.vertices[1].x);std::swap(b.vertices[0].y,b.vertices[1].y);c.frame.psm=1;}
        // Alpha fail still writes framebuffer when depth writes are masked.
        c.test|=1|(uint64_t(5)<<1)|(uint64_t(127)<<4)|(uint64_t(1)<<12);
        std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
        auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        GSTexClutReg clut;clut.cbw=1;hybrid.LoadClut(c.tex0,clut);oracle.LoadClut(c.tex0,clut);
        // Keep multiple source variants in flight. Each old source must be
        // consumed before its storage is reused; no framebuffer readback here.
        const unsigned repeats=3;
        for(unsigned draw=0;draw<repeats;++draw){
            b.vertices[1].r=96+draw*8;
            b.vertices[0].x+=8;b.vertices[1].x+=8;
            c.scissor.x1=unsigned(std::ceil(std::max(b.vertices[0].x,b.vertices[1].x)))-3;
            c.scissor.y1=18; // Non-multiple-of-four covered area and empty padded rows.
            if(draw==1){b.state.prim.abe=true;c.alpha=10;} // Copy-equivalent GS equation.
            if(draw==2){b.state.prim.abe=true;c.alpha=(uint64_t(128)<<32)|0x68|0x5a5a5a00a5a5a500ull;}
            hybrid.Submit(b);oracle.Submit(b);
        }
        Check(hybrid.GetCounters().nativeDraws==repeats&&native->croppedSprites==repeats,"STQ crop not native");
        Check(std::memcmp(actual,expected,Size)!=0,"STQ crop mirrored on CPU");Compare(hybrid);
        probe_result[10]+=repeats;probe_result[12]+=native->uploads;probe_result[19]+=native->decodes;
        probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[25]+=native->decodeReuses;
    }
}
void CroppedRingLifetime()
{
    probe_result[20]=900;
    std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
    auto b=Batch(GS_PSM_CT32,0);Fill(oracle,b,true);b.state.prim.fst=false;
    b.state.context.tex0.tfx=0;b.state.context.clamp=5;
    b.vertices[0].q=b.vertices[1].q=1;b.vertices[1].s=b.vertices[1].t=1;
    b.vertices[1].g=b.vertices[1].b=b.vertices[1].a=128;
    std::memcpy(actual,expected,Size);
    auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
    auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
    GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
    for(unsigned i=0;i<600;++i){
        b.vertices[0].x=4+(i%4)*12;b.vertices[1].x=b.vertices[0].x+8;
        b.vertices[0].y=4+((i/4)%4)*12;b.vertices[1].y=b.vertices[0].y+8;
        b.vertices[1].r=i&255;b.vertices[1].g=128+i/256;
        hybrid.Submit(b);oracle.Submit(b);
        if(i%16==0){hybrid.Submit(b);oracle.Submit(b);}
    }
    probe_result[27]=native->sourceFences;probe_result[28]=native->reuses;
    Check(native->sourceFences>0&&native->reuses>0,"crop ring not exercised");
    Check(hybrid.GetCounters().softwareDraws==0,"crop ring software fallback");Compare(hybrid);
    probe_result[10]+=hybrid.GetCounters().nativeDraws;probe_result[12]+=native->uploads;probe_result[14]+=native->reuses;
    probe_result[13]+=native->uploadedTexels;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;
}
void ProjectiveTriangles()
{
    const unsigned formats[]={GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH,GS_PSM_Z32,GS_PSM_Z24,GS_PSM_Z16,GS_PSM_Z16S};
    uint32_t random=0x7505900;auto next=[&]{random=random*1664525u+1013904223u;return random;};
    for(unsigned psm:formats)for(unsigned variant=0;variant<4;++variant){
        probe_result[20]=1200+psm*4+variant;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto b=Batch(psm,0);b.vertexCount=3;b.state.prim.type=GSPrimType(GS_PRIM_TRIANGLE+variant%3);b.state.prim.fst=false;
        b.state.textureWidth=b.state.textureHeight=128;b.state.context.tex0.tw=b.state.context.tex0.th=7;b.state.context.tex0.tbw=2;
        b.state.context.tex0.tfx=variant;b.state.context.clamp=variant&1?5:0;b.state.scanmsk=variant;
        b.state.context.frame.psm=variant&1;
        const bool indexed=psm==GS_PSM_T8||psm==GS_PSM_T4||psm==GS_PSM_T8H||psm==GS_PSM_T4HL||psm==GS_PSM_T4HH;
        const bool small=psm==GS_PSM_CT16||psm==GS_PSM_CT16S||psm==GS_PSM_Z16||psm==GS_PSM_Z16S;
        Fill(oracle,b);b.state.context.tex0.cbp=512;
        for(unsigned i=0;i<256;++i)oracle.WriteVram(0,512,1,i,0,0x80000000|((i*17&255)<<16)|((i*31&255)<<8)|(i*7&255));
        for(unsigned y=0;y<128;++y)for(unsigned x=0;x<128;++x){
            const uint32_t pixel=indexed?(x+y)%16:small?0x8000|(x&31)|((y&31)<<5):0x80000000|(x*2)|(y*2<<8)|((x+y)<<16);
            oracle.WriteVram(psm,0,2,x,y,pixel);
        }
        bool admitted=false;
        for(unsigned attempt=0;attempt<128&&!admitted;++attempt){
            for(unsigned v=0;v<3;++v){auto &z=b.vertices[v];
                z.x=4+(v==1?16:0)+(next()%16)/16.f;z.y=4+(v==2?16:0)+(next()%16)/16.f;
                z.q=.5f+(next()%9)/4.f;const float offset=variant==0?-128.f:variant==1?128.f:0;z.s=((48+(next()%1024)/32.f+offset)/128)*z.q;z.t=((32+(next()%1024)/32.f+offset)/128)*z.q;
                z.r=96;z.g=128;z.b=160;z.a=128;
            }
            if(variant&2)std::swap(b.vertices[1],b.vertices[2]);
            GSNativeProjectivePlan p;admitted=GSNativeProjectivePlan::Prepare(b,p);
        }
        Check(admitted,"could not construct a safe projective fixture");
        if(variant==2){b.state.prim.abe=true;b.state.context.alpha=10;}
        if(variant==3){b.state.prim.abe=true;b.state.context.alpha=(uint64_t(128)<<32)|0x68|0x5a5a5a00a5a5a500ull;}
        std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
        auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        GSTexClutReg clut;clut.cbw=1;hybrid.LoadClut(b.state.context.tex0,clut);oracle.LoadClut(b.state.context.tex0,clut);
        for(unsigned repeat=0;repeat<3;++repeat){hybrid.Submit(b);oracle.Submit(b);}
        Check(hybrid.GetCounters().nativeDraws==3&&native->projectiveTriangles==3,"projective triangle not native");
        Check(native->uploads==1&&native->reuses==2,"projective source did not stay resident");
        Check(std::memcmp(actual,expected,Size)!=0,"projective draw mirrored on CPU");Compare(hybrid);
        probe_result[10]+=3;probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;probe_result[25]+=native->decodeReuses;
        probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[29]+=native->projectiveTriangles;
    }
}
void ProjectiveOwnership()
{
    for(unsigned mode=0;mode<2;++mode){
        probe_result[20]=1600+mode;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto b=Batch(GS_PSM_CT32,0);Fill(oracle,b);b.vertexCount=3;b.state.prim.fst=false;b.state.prim.type=GS_PRIM_TRIANGLE;
        b.state.context.frame.psm=1;
        for(unsigned v=0;v<3;++v){auto &z=b.vertices[v];z.x=v==1?20.125f:4.125f;z.y=v==2?20.25f:4.25f;
            z.q=1+v;z.s=(6.25f/8)*z.q;z.t=(6.25f/8)*z.q;}
        std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
        auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        hybrid.Submit(b);oracle.Submit(b);
        Check(hybrid.GetCounters().nativeDraws==1,"initial projective ownership draw not native");
        if(mode==0){
            // New source is the still-pending old native target. Resolve must
            // happen BEFORE source materialization, not merely before drawing.
            b.state.context.tex0.tbp0=64*32;b.state.context.frame.fbp=128;
            hybrid.Submit(b);oracle.Submit(b);
            Check(hybrid.GetCounters().nativeDraws==2,"projective producer-consumer not native");
            // Current-target feedback remains unsupported and must fall back.
            b.state.context.tex0.tbp0=128*32;
            hybrid.Submit(b);oracle.Submit(b);
            Check(hybrid.GetCounters().softwareDraws==1&&hybrid.GetCounters().resolves>=2,"projective feedback bypassed resolve/fallback");
        }else{
            // A software source write does not flush the guest-latched page.
            hybrid.WriteVram(0,0,1,6,6,0x80112233);oracle.WriteVram(0,0,1,6,6,0x80112233);
            hybrid.Submit(b);oracle.Submit(b);
            Check(hybrid.GetCounters().softwareDraws==1,"stale retained source authorized native snapshot");
            hybrid.TextureFlush();oracle.TextureFlush();hybrid.Submit(b);oracle.Submit(b);
            Check(hybrid.GetCounters().nativeDraws==2,"TEXFLUSH did not re-enable coherent projective source");
        }
        Compare(hybrid);auto c=hybrid.GetCounters();probe_result[10]+=c.nativeDraws;probe_result[11]+=c.softwareDraws;
        probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;
        probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;probe_result[29]+=native->projectiveTriangles;probe_result[30]+=1;
    }
}
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
void CachedProjectiveSources()
{
    for(unsigned psm:{GS_PSM_CT32,GS_PSM_CT16,GS_PSM_T8}){
        probe_result[20]=1800+psm;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto a=Batch(psm,0);a.vertexCount=3;a.state.prim.fst=false;a.state.prim.type=GS_PRIM_TRIANGLE;a.state.context.frame.psm=1;
        for(unsigned v=0;v<3;++v){auto &z=a.vertices[v];z.x=v==1?20.125f:4.125f;z.y=v==2?20.25f:4.25f;
            z.q=1+v;z.s=(6.25f/8)*z.q;z.t=(6.25f/8)*z.q;}
        auto b=a;b.state.context.tex0.tbp0=32;Fill(oracle,a);Fill(oracle,b);
        oracle.WriteVram(psm,32,b.state.context.tex0.tbw,6,6,psm==GS_PSM_T8?1:psm==GS_PSM_CT16?0x8ce3:0x806b4512);
        std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
        auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        GSTexClutReg clut;clut.cbw=1;hybrid.LoadClut(a.state.context.tex0,clut);oracle.LoadClut(a.state.context.tex0,clut);
        auto draw=[&](const GSPrimitiveBatch &batch){hybrid.Submit(batch);oracle.Submit(batch);Compare(hybrid);};
        draw(a);draw(b);Check(native->decodes==2,"distinct source images were not decoded");
        hybrid.WriteVram(0,1024,1,0,0,0x80998877);oracle.WriteVram(0,1024,1,0,0,0x80998877);
        draw(a);Check(native->decodes==2&&native->decodeReuses==1,"unrelated CPU write discarded reusable source");
        const uint32_t changed=psm==GS_PSM_T8?3:psm==GS_PSM_CT16?0x8c33:0x80775533;
        hybrid.WriteVram(psm,0,a.state.context.tex0.tbw,6,6,changed);oracle.WriteVram(psm,0,a.state.context.tex0.tbw,6,6,changed);
        draw(a);Check(hybrid.GetCounters().softwareDraws==1,"decoded image bypassed stale guest texture latch");
        hybrid.TextureFlush();oracle.TextureFlush();draw(a);
        Check(native->decodes==3,"changed raw source reused stale decoded pixels");
        a.state.context.tex0.tfx=0;
        for(auto &z:a.vertices){z.r=83;z.g=101;z.b=71;z.a=128;}
        draw(a);Check(native->decodes==3&&native->decodeReuses==2,"raw source cache mixed vertex-color combination");
        if(psm==GS_PSM_T8){
            hybrid.LoadClut(a.state.context.tex0,clut);oracle.LoadClut(a.state.context.tex0,clut);
            draw(a);Check(native->decodes==3&&native->decodeReuses==3,"identical CLUT reload discarded decoded source");
            hybrid.WriteVram(0,128,1,3,0,0x80eeddcc);oracle.WriteVram(0,128,1,3,0,0x80eeddcc);
            hybrid.LoadClut(a.state.context.tex0,clut);oracle.LoadClut(a.state.context.tex0,clut);
            draw(a);Check(native->decodes==4,"changed CLUT reused stale decoded pixels");
            hybrid.WriteVram(0,128,1,3,0,0x80335d15);oracle.WriteVram(0,128,1,3,0,0x80335d15);
            hybrid.LoadClut(a.state.context.tex0,clut);oracle.LoadClut(a.state.context.tex0,clut);
            draw(a);Check(native->decodes==4&&native->decodeReuses==4,"restored exact palette did not reuse prior decoded source");
        }
        auto c=hybrid.GetCounters();probe_result[10]+=c.nativeDraws;probe_result[11]+=c.softwareDraws;
        probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;
        probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;probe_result[29]+=native->projectiveTriangles;
    }
}
void CachedSourceBudgetAndRing()
{
    for(unsigned large=0;large<2;++large){
        probe_result[20]=1900+large;
        std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
        auto a=Batch(GS_PSM_CT32,0,256);a.vertexCount=3;a.state.prim.fst=false;a.state.prim.type=GS_PRIM_TRIANGLE;a.state.context.frame.psm=1;
        if(large){a.state.textureWidth=a.state.textureHeight=128;a.state.context.tex0.tw=a.state.context.tex0.th=7;a.state.context.tex0.tbw=2;}
        for(unsigned v=0;v<3;++v){auto &z=a.vertices[v];z.x=v==1?20.125f:4.125f;z.y=v==2?20.25f:4.25f;
            z.q=1+v;z.s=(6.25f/a.state.textureWidth)*z.q;z.t=(6.25f/a.state.textureHeight)*z.q;}
        const unsigned count=large?5:17;
        for(unsigned i=0;i<count;++i){auto b=a;b.state.context.tex0.tbp0=i*(large?256:32);Fill(oracle,b);}
        std::memcpy(actual,expected,Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
        auto driver=std::make_unique<TextureDriver>(canonical);auto *native=driver.get();
        GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
        for(unsigned i=0;i<=count;++i){auto b=a;b.state.context.tex0.tbp0=(i%count)*(large?256:32);
            hybrid.Submit(b);oracle.Submit(b);Compare(hybrid);
            Check(native->SourceCacheBytes()<=512u*1024u,"decoded source cache exceeded retained allocation budget");
        }
        Check(hybrid.GetCounters().nativeDraws==count+1&&hybrid.GetCounters().softwareDraws==0,"source ring draw did not use GX");
        Check(native->decodes==count+1,"source cache did not evict the oldest image");
        auto c=hybrid.GetCounters();probe_result[10]+=c.nativeDraws;probe_result[11]+=c.softwareDraws;
        probe_result[12]+=native->uploads;probe_result[13]+=native->uploadedTexels;probe_result[14]+=native->reuses;
        probe_result[17]+=native->triangles;probe_result[19]+=native->decodes;probe_result[25]+=native->decodeReuses;probe_result[29]+=native->projectiveTriangles;
    }
}
#endif
void Run()
{
    const unsigned formats[]={GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH};
    unsigned n=0;
    for(unsigned psm:formats)for(unsigned scale=0;scale<3;++scale){probe_result[20]=n;One(psm,scale,n++);}
    for(unsigned mode:{1u,2u,3u,4u,5u,6u,7u,8u,11u,12u,13u,14u,15u}){probe_result[20]=n;One(GS_PSM_CT32,0,n++,mode);}
    Retained();ProducerConsumer();
    for(unsigned psm:{GS_PSM_CT32,GS_PSM_CT16,GS_PSM_T8,GS_PSM_T4}){probe_result[20]=n;One(psm,0,n++,9);}
    Triangles();
    FlatCombineAndBlend();
    BatchedTextures();
    Bilinear();
    MirroredPointSprites();
    TriangleFallbacks();
    FlatSprites();
    FlatFades();
    CompactSurfaces();
    CroppedSTQ();
    CroppedRingLifetime();
    ProjectiveTriangles();
    ProjectiveOwnership();
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
    CachedProjectiveSources();
    CachedSourceBudgetAndRing();
#endif
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
    probe_result[2]=813;
#else
    probe_result[2]=768;
#endif
}
}
int main()
{
    probe_result[0]=1;VIDEO_Init();auto *mode=VIDEO_GetPreferredMode(nullptr);void *xfb=SYS_AllocateFramebuffer(mode);VIDEO_Configure(mode);VIDEO_SetNextFramebuffer(xfb);VIDEO_SetBlack(FALSE);VIDEO_Flush();
    try{Run();probe_result[0]=0x600d;}catch(const std::exception&){probe_result[3]=probe_result[20]+1;probe_result[4]=1;probe_result[0]=0xe5;}
    while(true)usleep(10000);
}
