// SPDX-License-Identifier: GPL-3.0-or-later
// Hardware RGB filtering/TFX/Gouraud prototype, explicitly NOT byte-exact RGB.
#include <gccore.h>
#include <unistd.h>
#include <malloc.h>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <vector>
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_native_linear_plan.h"
#include "ps2_wii_gx_driver.h"
#include "ps2_wii_gx_owner_hooks.h"
#include "runtime/gs/ps2_gs_memory.h"
extern "C" {
#include "core/hw/gs_gx.h"
#include "core/hw/gs_mem.h"
int ps2x_gx_bind(uint8_t*,uint32_t);int ps2x_gx_init(void);int ps2x_gx_unbind(void);
int ps2x_gx_draw_linear_rgb(const gs_gx_flat_draw*,const void*,uint32_t,uint32_t,const float*,uint32_t,uint32_t,uint32_t,uint32_t,int,int);
uint32_t gs_scanout_read_rgb(uint32_t bp,uint32_t bw,uint32_t x,uint32_t y,uint32_t psm){if(psm>1)std::abort();return gs_mem_read_psmct32(bp,bw,x,y);}
extern volatile uint32_t PS2WiiGXWholeTriangles[8];
volatile uint32_t probe_result[64];
}
namespace {
constexpr unsigned Size=4*1024*1024;
alignas(32) uint8_t actual[Size],expected[Size];
void Check(bool b,const char *why){if(!b)throw std::runtime_error(why);}
void One(unsigned zpsm,unsigned tfx,unsigned variant,bool wide=false,bool occluded=false,bool flat=false,bool needle=false,unsigned whole=0,bool resident=false)
{
    const unsigned psm=GS_PSM_CT32;
    probe_result[20]=psm*64+tfx*8+variant;
    Check(gs_gx_reset_boot_state(),"previous GPU owner did not drain");
    std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
    GSPrimitiveBatch b;b.vertexCount=3;auto &s=b.state;auto &t=s.context.tex0;
    s.prim.type=GSPrimType(GS_PRIM_TRIANGLE+variant%3);s.prim.tme=variant!=7;s.prim.iip=variant!=0;s.prim.abe=variant>=4;s.colclamp=1;
    s.textureWidth=s.textureHeight=128;s.linearFilter=s.prim.tme;
    s.context.frame={64,1,uint8_t(variant&1?GS_PSM_CT32:GS_PSM_CT24),0};s.context.scissor={0,63,0,63};
    s.context.zbuf={uint16_t(wide?256:192),uint8_t(zpsm),bool(variant&2)};
    if(wide){s.context.frame.fbw=10;s.context.scissor={0,639,0,479};}
    s.context.test=1u|((variant%8)<<1)|(64u<<4)|((variant%4)<<12)|((variant%4)<<17);
    if(occluded){s.context.test=uint64_t(2)<<17;s.context.zbuf.zmask=true;}
    s.context.fba=variant&1;s.pabe=variant&1;
    s.context.alpha=(uint64_t(variant==5?64:128)<<32)|(variant==4?0x44:variant==5?0x64:0x68);s.context.tex1=1u<<5;s.context.clamp=variant&1?5:0;s.scanmsk=variant%4;
    t.psm=psm;t.tw=t.th=7;t.tbw=2;t.tfx=tfx;t.tcc=1;t.cpsm=GS_PSM_CT32;t.cbp=512;t.csm=1;t.cld=1;
    s.texa.ta0=s.texa.ta1=128;
    const bool indexed=psm==GS_PSM_T8||psm==GS_PSM_T4||psm==GS_PSM_T8H||psm==GS_PSM_T4HL||psm==GS_PSM_T4HH;
    const bool small=psm==GS_PSM_CT16||psm==GS_PSM_CT16S||psm==GS_PSM_Z16||psm==GS_PSM_Z16S;
    uint32_t random=0x7505900;auto next=[&]{random=random*1664525u+1013904223u;return random;};
    for(unsigned i=0;i<256;++i)oracle.WriteVram(0,512,1,i,0,((next()%65)<<24)|(next()&0xffffff));
    for(unsigned y=0;y<128;++y)for(unsigned x=0;x<128;++x){
        const uint32_t pixel=indexed?next()&255:small?0x8000|(next()&0x7fff):((next()%65)<<24)|(next()&0xffffff);
        oracle.WriteVram(psm,0,2,x,y,pixel);
    }
    for(unsigned i=0;i<3;++i){auto &v=b.vertices[i];v.x=5.125f+(i==1?26:0)+(i==2?3.25f:0);v.y=4.375f+(i==2?25:0)+(i==1?1.125f:0);
        v.q=.5f+i*.5f;const float offset=variant==1?-128.f:variant==2?128.f:0;
        v.s=((16+i*23+offset)/128)*v.q;v.t=((24+i*31+offset)/128)*v.q;
        v.r=32+i*83;v.g=200-i*61;v.b=17+i*57;v.a=12+i*12;v.z=100000;
    }
    if(wide)for(auto &v:b.vertices){v.x=90+v.x*12;v.y=120+v.y*7;}
    if(variant&2)std::swap(b.vertices[1],b.vertices[2]);
    if(needle){
        b.vertices[0].x=b.vertices[2].x=12.125f;b.vertices[1].x=20.125f;
        b.vertices[0].y=b.vertices[1].y=4.375f;b.vertices[2].y=wide?474.375f:60.375f;
        s.context.test=uint64_t(1)<<17;s.context.zbuf.zmask=true;s.prim.abe=false;s.pabe=false;s.scanmsk=0;
    }
#if PS2X_GX_WHOLE_TRIANGLES
    if(needle)s.scanmsk=1; // No field rejection, but exercise the row route.
#endif
    if(whole){
        const float shapes[6][6]={{5,4,31,5,8,29},{4,4,36,4,4,36},{4,4,36,36,4,36},
          {5,4,6,44,7,5},{0,0,63,0,0,63},{0,63,63,0,63,63}};
        for(unsigned i=0;i<3;++i){b.vertices[i].x=shapes[(whole-1)%6][i*2];b.vertices[i].y=shapes[(whole-1)%6][i*2+1];}
        if(whole&1)std::swap(b.vertices[0],b.vertices[1]);
        s.context.test=uint64_t(1)<<17;s.context.zbuf.zmask=true;s.prim.abe=variant==5||variant==6;s.pabe=false;s.scanmsk=0;
        if(whole>=7){
            unsigned seed=whole*0x9e3779b9u;int area=0;
            do{for(unsigned i=0;i<3;++i){seed=seed*1664525u+1013904223u;b.vertices[i].x=1+(seed>>16)%61;seed=seed*1664525u+1013904223u;b.vertices[i].y=1+(seed>>16)%61;}
             area=int((b.vertices[1].x-b.vertices[0].x)*(b.vertices[2].y-b.vertices[0].y)-(b.vertices[2].x-b.vertices[0].x)*(b.vertices[1].y-b.vertices[0].y));
            }while(std::abs(area)<4);
        }
        if(whole>=31)for(unsigned i=0;i<3;++i){b.vertices[i].x+=((whole+i*3)%16)/16.f;b.vertices[i].y+=((whole*3+i*5)%16)/16.f;}
        if(wide)for(auto &v:b.vertices){v.x*=10;v.y*=7;}
        if(whole&2){s.context.xyoffset.ofx=8;s.context.xyoffset.ofy=24;for(auto &v:b.vertices){v.x+=.5f;v.y+=1.5f;}}
    }
    if(resident){s.prim.tme=false;s.prim.abe=false;s.pabe=false;s.scanmsk=0;s.context.test=uint64_t(2)<<17;s.context.zbuf.zmask=false;}
    if(flat)s.prim.iip=false;
    GSNativeLinearPlan p;Check(GSNativeLinearPlan::Prepare(b,p),"linear geometry rejected");
    for(unsigned y=0;y<(wide?480u:64u);++y)for(unsigned x=0;x<(wide?640u:64u);++x)
        oracle.WriteVram(zpsm,s.context.zbuf.zbp*32,s.context.frame.fbw,x,y,occluded?200000:100000+((x+y)%3-1)*50);
    std::memcpy(actual,expected,Size);
    auto software=std::make_unique<GSCpuBackend>();auto *sampler=software.get();
    auto driver=std::make_unique<PS2WiiGXTextureDriver>(sampler);auto *native=driver.get();
    GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
    GSTexClutReg clut;clut.cbw=1;hybrid.LoadClut(t,clut);oracle.LoadClut(t,clut);
    oracle.Submit(b);
    const auto depthBefore=PS2WiiGXDepth24Stats[0];
    const auto wholeBefore=PS2WiiGXWholeTriangles[0];
    hybrid.Submit(b);
    if(resident)Check(PS2WiiGXDepth24Stats[0]>depthBefore,"resident Z24 path was not used");
    if(whole)Check(PS2WiiGXWholeTriangles[0]>wholeBefore,"whole triangle was not submitted");
    const bool sequence=!resident&&!whole&&!occluded&&variant==1&&tfx==1&&zpsm==GS_PSM_Z32;
    if(sequence){
        auto depthOnly=b;depthOnly.state.context.test=1u|(2u<<12)|(1u<<17);
        const unsigned beforeDecode=native->decodes,beforeUpload=native->uploads;
        hybrid.Submit(depthOnly);oracle.Submit(depthOnly);
        Check(native->metadataWithoutImage==1&&native->decodes==beforeDecode&&native->uploads==beforeUpload,"depth-only pass prepared an unused image");
        hybrid.Submit(b);oracle.Submit(b);
        const auto queued=hybrid.GetCounters();
        Check(queued.resolves==0&&queued.metadataDraws==1&&queued.nativeDraws==2,"metadata-only sequence broke pending RGB ownership");
    }
    hybrid.Sync(GSSyncReason::Finish);
    const auto counters=hybrid.GetCounters();
    Check(counters.softwareDraws==0&&(resident||native->linearOperations==(sequence?3u:1u)),"connected path fell back to software");
    if(variant==0||occluded)Check(native->metadataWithoutImage==1&&native->decodes==0&&native->uploads==0,"NEVER depth test decoded/uploaded a texture");
    probe_result[31]+=native->metadataWithoutImage;
    probe_result[25]+=counters.nativeDraws;probe_result[26]+=counters.metadataDraws;
    probe_result[27]+=native->depthTested;probe_result[28]+=native->depthRejected;probe_result[29]+=native->depthWritten;
    gs_gx_flat_draw d{};d.x=p.x;d.y=p.y;d.width=p.width;d.height=p.height;
    for(unsigned y=0;y<d.height;++y){d.left[y]=p.left[y];d.right[y]=p.right[y];}
    // Only covered RGB bytes may differ, and only within the explicit rounding
    // budget. Alpha, source memory, uncovered pixels and all other VRAM are exact.
    const unsigned budget=!p.textured?2:tfx==1?5:8;
    for(unsigned row=0;row<d.height;++row)for(unsigned x=d.left[row];x<d.right[row];++x){uint32_t address=0;
        Check(GSMem::TextureByteAddress(GS_PSM_CT32,64*32,s.context.frame.fbw,d.x+x,d.y+row,address),"target address");
        for(unsigned channel=0;channel<3;++channel){const unsigned i=address+channel;
            const unsigned error=std::abs(int(actual[i])-int(expected[i]));
            if(error>budget){probe_result[7]=i;probe_result[15]=actual[i];probe_result[16]=expected[i];probe_result[17]=budget;probe_result[18]=1;
                throw std::runtime_error("hardware RGB exceeded explicit rounding budget");}
            if(error){probe_result[21]=probe_result[21]+1;probe_result[22]=probe_result[22]+error;}
            probe_result[23]=std::max(unsigned(probe_result[23]),error);
            // Normalize ONLY already-checked covered RGB in this completed
            // one-draw oracle result, then verify all remaining bytes exactly.
            // These bytes never feed a later draw or the native renderer.
            expected[i]=actual[i];
        }
    }
    if(std::memcmp(actual,expected,Size)){
        for(unsigned i=0;i<Size;++i)if(actual[i]!=expected[i]){probe_result[7]=i;probe_result[15]=actual[i];probe_result[16]=expected[i];break;}
        throw std::runtime_error("native draw changed alpha/uncovered/source VRAM");
    }
    Check(gs_gx_reset_boot_state(),"GPU drain");
    probe_result[1]=probe_result[1]+1;probe_result[10]=probe_result[10]+1;
}
#if PS2X_GX_WHOLE_TRIANGLES
struct AuxProbe {unsigned calls=0,address=0;bool oldVramSeen=false;};
AuxProbe auxProbe;
int AuxResolve(void *opaque){auto &p=*static_cast<AuxProbe*>(opaque);if(!p.calls)p.oldVramSeen=actual[p.address]==0;++p.calls;return 1;}
int AuxDisjoint(void*,uint32_t lo,uint32_t hi){return hi<=0x300000||lo>=0x310000;}
void WholeSequence(unsigned psm){
    probe_result[20]=0x500+psm;
    Check(gs_gx_reset_boot_state(),"whole sequence previous owner");
    std::memset(expected,0,Size);std::memcpy(actual,expected,Size);
    GSCpuBackend oracle;oracle.Initialize(expected,Size);
    auto sw=std::make_unique<GSCpuBackend>();auto native=std::make_unique<PS2WiiGXTextureDriver>(sw.get());
    GSHybridBackend hybrid(std::move(sw),std::move(native));hybrid.Initialize(actual,Size);
    GSPrimitiveBatch b;b.vertexCount=3;auto &s=b.state;s.prim.type=GS_PRIM_TRIANGLE;s.prim.abe=true;s.colclamp=1;
    s.context.frame={64,1,uint8_t(psm),0};s.context.zbuf={192,GS_PSM_Z32,true};s.context.scissor={0,63,0,63};
    s.context.test=uint64_t(1)<<17;s.context.alpha=(uint64_t(128)<<32)|0x68;
    const float xy[2][6]={{4,4,36,4,36,36},{4,4,36,36,4,36}};
    auxProbe={};Check(GSMem::TextureByteAddress(GS_PSM_CT32,64*32,1,8,8,auxProbe.address),"auxiliary ordering pixel");
    Check(!ps2x_gx_set_aux_hooks(nullptr,AuxDisjoint,&auxProbe),"alias owner registered without a resolver");
    Check(ps2x_gx_set_aux_hooks(AuxResolve,AuxDisjoint,&auxProbe),"auxiliary hooks registration");
    Check(!ps2x_gx_source_disjoint(0x300000,0x300004),"auxiliary Z alias was ignored");
    const unsigned before=PS2WiiGXWholeTriangles[0];
    for(unsigned step=0;step<6;++step){
        s.prim.fge=step==2;
        for(unsigned i=0;i<3;++i){auto &v=b.vertices[i];v.x=xy[step%2][i*2];v.y=xy[step%2][i*2+1];
            if(step>=4){v.x+=1.f/16;v.y+=3.f/16;}
            v.r=17;v.g=31;v.b=63;v.a=64;v.fog=255;v.q=1;}
        oracle.Submit(b);hybrid.Submit(b);
        if(step==0)Check(!ps2x_gx_set_aux_hooks(nullptr,nullptr,nullptr),"pending owner hooks changed without a fence");
    }
    hybrid.Sync(GSSyncReason::Finish);
    Check(auxProbe.calls>=2&&auxProbe.oldVramSeen,"auxiliary owner did not resolve before RGB import");
    Check(ps2x_gx_set_aux_hooks(nullptr,nullptr,nullptr),"auxiliary hooks did not drain");
    Check(PS2WiiGXWholeTriangles[0]-before==5,"whole sequence did not use both renderers");
    Check(hybrid.GetCounters().softwareDraws==1,"whole sequence software transition missing");
    if(std::memcmp(actual,expected,Size)){
        for(unsigned i=0;i<Size;++i)if(actual[i]!=expected[i]){probe_result[7]=i;probe_result[15]=actual[i];probe_result[16]=expected[i];break;}
        throw std::runtime_error("whole shared edges/blending/mixed ownership differ from reference");
    }
    Check(gs_gx_reset_boot_state(),"whole sequence GPU drain");++probe_result[1];
}
#endif
#if defined(PS2X_WII_GX_DEPTH24)
void ResidentSequence(){
    probe_result[20]=0x700;Check(gs_gx_reset_boot_state(),"resident sequence previous owner");
    std::memset(actual,0,Size);std::memset(expected,0,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
    auto sw=std::make_unique<GSCpuBackend>();auto driver=std::make_unique<PS2WiiGXTextureDriver>(sw.get());
    GSHybridBackend hybrid(std::move(sw),std::move(driver));hybrid.Initialize(actual,Size);
    GSPrimitiveBatch b;b.vertexCount=3;auto &s=b.state;s.prim.type=GS_PRIM_TRIANGLE;s.colclamp=1;
    s.context.frame={64,1,GS_PSM_CT32,0};s.context.zbuf={192,GS_PSM_Z24,false};s.context.scissor={0,63,0,63};s.context.test=uint64_t(2)<<17;
    for(unsigned step=0;step<168;++step){s.prim.fge=step==17;s.context.fba=step&1;
        for(unsigned i=0;i<3;++i){auto &v=b.vertices[i];v.x=i==1?60:4;v.y=i==2?60:4;v.z=100000+(step%13)*5;v.r=17;v.g=31;v.b=63;v.a=(step*19)&255;v.fog=255;}
        oracle.Submit(b);hybrid.Submit(b);
        if(step==8){Check(!ps2x_gx_source_disjoint(192*8192,192*8192+4),"resident Z source alias was not protected");
            Check(hybrid.ReadVram(GS_PSM_Z24,192*32,1,8,8)==oracle.ReadVram(GS_PSM_Z24,192*32,1,8,8),"CPU Z read did not materialize resident depth");}
        if(step==24){hybrid.TextureFlush();oracle.TextureFlush();}
    }
    hybrid.Sync(GSSyncReason::Finish);
    Check(hybrid.GetCounters().softwareDraws==1,"resident transition forced extra CPU fallback");
    Check(PS2WiiGXDepth24Stats[0]==167,"resident sequence did not stay native");
    Check(PS2WiiGXDepth24Stats[2]>0,"canonical upload arena did not exercise a wrap fence");
    Check(!std::memcmp(actual,expected,Size),"resident mixed sequence alpha/Z/source bytes differ");
    Check(gs_gx_reset_boot_state(),"resident sequence shutdown");++probe_result[1];
}
#endif
void Reject(unsigned kind){
    probe_result[20]=0x100+kind;
    Check(gs_gx_reset_boot_state(),"negative case drain");std::memset(expected,0x5a,Size);std::memcpy(actual,expected,Size);
    GSPrimitiveBatch b;b.vertexCount=3;auto&s=b.state;s.prim.type=GS_PRIM_TRIANGLE;s.colclamp=1;
    s.context.frame={64,1,GS_PSM_CT32,0};s.context.zbuf={192,GS_PSM_Z32,false};s.context.scissor={0,63,0,63};s.context.test=1u<<17;
    for(unsigned n=0;n<3;++n){auto&v=b.vertices[n];v.x=n==1?28:4;v.y=n==2?28:4;v.r=31;v.g=79;v.b=123;v.a=200;v.q=1;v.z=100000;}
    if(kind==0)s.context.zbuf.zbp=64; // CPU depth would overwrite the RGB target.
    if(kind==1){s.prim.tme=true;s.linearFilter=true;s.textureWidth=s.textureHeight=4;
      s.context.tex0={64*32,1,GS_PSM_CT32,2,2,1,1,0,0,0,0,0};s.context.clamp=5;}
    if(kind==2){s.prim.abe=true;s.context.alpha=0x44;} // As > 128 is not an ordinary GX coefficient.
    if(kind==3)s.context.frame.fbmsk=0x00ff0000; // Partial RGB mask is not supported.
    GSCpuBackend oracle;oracle.Initialize(expected,Size);auto sw=std::make_unique<GSCpuBackend>();auto native=std::make_unique<PS2WiiGXTextureDriver>(sw.get());
    GSHybridBackend hybrid(std::move(sw),std::move(native));hybrid.Initialize(actual,Size);
    oracle.Submit(b);hybrid.Submit(b);hybrid.Sync(GSSyncReason::Finish);
    Check(hybrid.GetCounters().softwareDraws==1&&hybrid.GetCounters().nativeDraws==0,"unsafe state was accepted natively");
    Check(!std::memcmp(actual,expected,Size),"rejected native state partially mutated VRAM");
    ++probe_result[1];++probe_result[30];
}
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
void ImmutableSources(unsigned mode)
{
    probe_result[20]=3000+mode;Check(gs_gx_reset_boot_state(),"previous GPU owner did not drain");
    std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
    const unsigned count=mode==0?2:mode==1?17:5,width=mode==2?128:8;
    GSPrimitiveBatch b;b.vertexCount=3;auto &s=b.state;auto &t=s.context.tex0;
    s.prim.type=GS_PRIM_TRIANGLE;s.prim.tme=true;s.prim.fst=false;s.colclamp=1;s.linearFilter=true;
    s.context.frame={256,1,GS_PSM_CT24,0};s.context.scissor={0,63,0,63};s.context.test=uint64_t(1)<<17;s.context.zbuf.zmask=true;
    t.psm=GS_PSM_CT32;t.tw=t.th=mode==2?7:3;t.tbw=mode==2?2:1;t.tcc=1;t.tfx=1;
    s.textureWidth=s.textureHeight=width;
    for(unsigned i=0;i<count;++i){const uint32_t color=0x80000000|((17+i*11)&255)|(((33+i*7)&255)<<8)|(((91+i*13)&255)<<16);
        for(unsigned y=0;y<width;++y)for(unsigned x=0;x<width;++x)oracle.WriteVram(0,i*(mode==2?256:32),t.tbw,x,y,color);}
    std::memcpy(actual,expected,Size);
    auto software=std::make_unique<GSCpuBackend>();auto *sampler=software.get();
    auto driver=std::make_unique<PS2WiiGXTextureDriver>(sampler);auto *native=driver.get();
    GSHybridBackend hybrid(std::move(software),std::move(driver));hybrid.Initialize(actual,Size);
    const unsigned draws=count+1;
    for(unsigned i=0;i<draws;++i){t.tbp0=(i%count)*(mode==2?256:32);
        for(unsigned v=0;v<3;++v){auto &z=b.vertices[v];z.x=2+(i%4)*14+(v==1?10:0)+.125f;z.y=2+(i/4)*10+(v==2?8:0)+.25f;
            z.q=1+v;z.s=(6.25f/width)*z.q;z.t=(6.25f/width)*z.q;}
        hybrid.Submit(b);oracle.Submit(b);
        Check(native->SourceCacheBytes()<=512u*1024u,"GPU source cache exceeded retained storage budget");
    }
    Check(hybrid.GetCounters().resolves==0,"immutable source switch forced framebuffer import");
    Check(hybrid.GetCounters().nativeDraws==draws&&hybrid.GetCounters().softwareDraws==0,"immutable source batch fell back");
    if(mode==0)Check(native->uploads==2&&native->reuses==1&&native->sourceTileFences==0,"A/B/A did not reuse immutable upload without a fence");
    else Check(native->sourceTileFences>0,"in-flight source eviction did not fence");
    hybrid.Sync(GSSyncReason::Finish);
    std::vector<uint8_t> snapshot;hybrid.SnapshotVram(snapshot);
    Check(snapshot.size()==Size&&std::memcmp(snapshot.data(),expected,Size)==0,"immutable source batch changed exact uniform RGB/alpha/depth/source bytes");
    ++probe_result[1];probe_result[25]+=draws;
}
#endif
#if defined(PS2X_GX_CONSTANT_STAGES)
extern "C" volatile uint32_t PS2WiiGXConstantStages;
#endif
#if defined(PS2X_GX_BATCH_LINEAR_RUNS)
extern "C" volatile uint32_t PS2WiiGXRunBatches[4];
#endif
void Run(){
#if defined(PS2X_WII_GX_DEPTH24)
    for(bool wide:{false,true})for(unsigned variant:{1u,2u})One(GS_PSM_Z24,0,variant,wide,false,false,false,0,true);
    ResidentSequence();
#endif
    const unsigned formats[]={GS_PSM_Z32,GS_PSM_Z24,GS_PSM_Z16,GS_PSM_Z16S};
    for(unsigned psm:formats)for(unsigned tfx=0;tfx<4;++tfx)for(unsigned v=0;v<8;++v)One(psm,tfx,v);
#if defined(PS2X_GX_CONSTANT_STAGES)
    for(unsigned tfx=0;tfx<4;++tfx)for(unsigned variant:{3u,5u,6u,7u})One(GS_PSM_Z32,tfx,variant,false,false,true);
    Check(PS2WiiGXConstantStages>0,"constant GX stages were not used");
#endif
#if defined(PS2X_GX_BATCH_LINEAR_RUNS)
    for(unsigned tfx=0;tfx<4;++tfx)for(bool wide:{false,true})One(GS_PSM_Z32,tfx,3,wide,false,false,true);
    Check(PS2WiiGXRunBatches[2]>0&&PS2WiiGXRunBatches[1]<PS2WiiGXRunBatches[0],"GX rows were not combined");
#endif
#if PS2X_GX_WHOLE_TRIANGLES
    for(unsigned shape=1;shape<=6;++shape)for(unsigned tfx=0;tfx<4;++tfx)for(unsigned variant:{1u,2u,5u,6u,7u})One(GS_PSM_Z32,tfx,variant,false,false,false,false,shape);
    for(unsigned shape=7;shape<=62;++shape)One(GS_PSM_Z32,shape%4,shape%2?2:7,false,false,false,false,shape);
    for(unsigned shape=1;shape<=6;++shape)for(unsigned variant:{2u,5u,6u})One(GS_PSM_Z32,shape%4,variant,true,false,false,false,shape);
    WholeSequence(GS_PSM_CT24);WholeSequence(GS_PSM_CT32);
    Check(PS2WiiGXWholeTriangles[3]>0,"CT24 whole triangles did not bypass CPU fragment permissions");
#endif
    One(GS_PSM_Z32,1,1,true);One(GS_PSM_Z24,0,3,true);
    One(GS_PSM_Z32,1,1,false,true);
    for(unsigned n=0;n<4;++n)Reject(n);
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
    for(unsigned mode=0;mode<3;++mode)ImmutableSources(mode);
    probe_result[2]=138;
#else
    probe_result[2]=135;
#endif
#if defined(PS2X_GX_CONSTANT_STAGES)
    probe_result[2]+=16;
#endif
#if defined(PS2X_GX_BATCH_LINEAR_RUNS)
    probe_result[2]+=8;
#endif
#if PS2X_GX_WHOLE_TRIANGLES
    probe_result[2]+=196;
#endif
#if defined(PS2X_WII_GX_DEPTH24)
    probe_result[2]+=5;
#endif
}
}
int main(){
    probe_result[0]=1;probe_result[63]=1; // Different RGB precision contract.
    VIDEO_Init();auto *mode=VIDEO_GetPreferredMode(nullptr);void *xfb=SYS_AllocateFramebuffer(mode);VIDEO_Configure(mode);VIDEO_SetNextFramebuffer(xfb);VIDEO_SetBlack(FALSE);VIDEO_Flush();
    try{Run();probe_result[0]=0x600d;}catch(const std::exception&){probe_result[3]=probe_result[20]+1;probe_result[4]=1;probe_result[0]=0xe5;}
    while(true)usleep(10000);
}
