// SPDX-License-Identifier: GPL-3.0-or-later
// Independent Z24 precision/edge experiment. Not connected to the game driver.
#include <gccore.h>
#include <malloc.h>
#include <unistd.h>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <stdexcept>
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_native_linear_plan.h"
#include "runtime/gs/gs_native_depth24_plan.h"
#include "runtime/gs/gs_native_depth24_ledger.h"
#include <memory>
extern "C" {
volatile uint32_t probe_result[64];
uint32_t gs_scanout_read_rgb(uint32_t,uint32_t,uint32_t,uint32_t,uint32_t){return 0;}
}
#ifndef PS2X_GX_DEPTH_STAGE
#define PS2X_GX_DEPTH_STAGE 3
#endif
namespace {
constexpr unsigned Size=4*1024*1024,W=64,H=64;
alignas(32) uint8_t actual[Size],expected[Size],seed[W*H*4],copy[W*H*4];
void Check(bool b,const char *s){if(!b)throw std::runtime_error(s);}
unsigned Tile(unsigned x,unsigned y){return ((y/4)*(W/4)+x/4)*64+(y&3)*8+(x&3)*2;}
void Transform(bool depth){
 GX_SetViewport(0,0,W,H,depth?1:0,depth?0:1);GX_SetScissor(0,0,W,H);
 Mtx model;Mtx44 projection;guMtxIdentity(model);guOrtho(projection,0,H,0,W,depth?0:-1,depth?float(GX_MAX_Z24):1);
 if(depth)projection[2][3]=0; // guOrtho otherwise translates by -far/(far-near).
 GX_LoadPosMtxImm(model,GX_PNMTX0);GX_SetCurrentMtx(GX_PNMTX0);GX_LoadProjectionMtx(projection,GX_ORTHOGRAPHIC);
}
void Base(){
 GX_SetPixelFmt(GX_PF_RGB8_Z24,GX_ZC_LINEAR);GX_SetDither(GX_FALSE);GX_SetCullMode(GX_CULL_NONE);GX_SetFieldMode(GX_FALSE,GX_FALSE);
 GX_SetBlendMode(GX_BM_NONE,GX_BL_ONE,GX_BL_ZERO,GX_LO_COPY);GX_SetAlphaUpdate(GX_FALSE);
 GX_SetAlphaCompare(GX_ALWAYS,0,GX_AOP_AND,GX_ALWAYS,0);GX_SetZTexture(GX_ZT_DISABLE,GX_TF_Z24X8,0);
 GX_SetNumTevStages(1);GX_ClearVtxDesc();GX_SetVtxDesc(GX_VA_POS,GX_DIRECT);GX_SetVtxAttrFmt(GX_VTXFMT0,GX_VA_POS,GX_POS_XYZ,GX_F32,0);
}
void SeedDepth(){
 Base();Transform(false);GX_SetColorUpdate(GX_FALSE);GX_SetZCompLoc(GX_FALSE);GX_SetZMode(GX_TRUE,GX_ALWAYS,GX_TRUE);
 GX_SetNumChans(0);GX_SetNumTexGens(1);GX_SetTexCoordGen(GX_TEXCOORD0,GX_TG_MTX2x4,GX_TG_TEX0,GX_IDENTITY);
 GX_SetVtxDesc(GX_VA_TEX0,GX_DIRECT);GX_SetVtxAttrFmt(GX_VTXFMT0,GX_VA_TEX0,GX_TEX_ST,GX_F32,0);
 GXTexObj tex;GX_InitTexObj(&tex,seed,W,H,GX_TF_RGBA8,GX_CLAMP,GX_CLAMP,GX_FALSE);
 GX_InitTexObjLOD(&tex,GX_NEAR,GX_NEAR,0,0,0,GX_FALSE,GX_FALSE,GX_ANISO_1);
 DCFlushRange(seed,sizeof(seed));GX_InvalidateTexAll();GX_LoadTexObj(&tex,GX_TEXMAP0);
 GX_SetTevOrder(0,GX_TEXCOORD0,GX_TEXMAP0,GX_COLORNULL);GX_SetTevOp(0,GX_REPLACE);
 GX_SetZTexture(GX_ZT_REPLACE,GX_TF_Z24X8,0);
 GX_Begin(GX_QUADS,GX_VTXFMT0,4);
 for(unsigned i:{0u,1u,3u,2u}){GX_Position3f32((i&1)?W:0,(i&2)?H:0,0);GX_TexCoord2f32((i&1)?1:0,(i&2)?1:0);}GX_End();GX_DrawDone();
}
void Triangle(const GSPrimitiveBatch &b,unsigned method){
 Base();Transform(true);GX_SetColorUpdate(GX_TRUE);GX_SetZCompLoc(GX_TRUE);
 GX_SetZMode(GX_TRUE,method==1?GX_ALWAYS:method==2?GX_GEQUAL:GX_GREATER,GX_TRUE);
 GX_SetNumTexGens(0);GX_SetNumChans(1);GX_SetVtxDesc(GX_VA_CLR0,GX_DIRECT);GX_SetVtxAttrFmt(GX_VTXFMT0,GX_VA_CLR0,GX_CLR_RGBA,GX_RGBA8,0);
 GX_SetChanCtrl(GX_COLOR0A0,GX_DISABLE,GX_SRC_REG,GX_SRC_VTX,GX_LIGHTNULL,GX_DF_NONE,GX_AF_NONE);
 GX_SetTevOrder(0,GX_TEXCOORDNULL,GX_TEXMAP_NULL,GX_COLOR0A0);GX_SetTevOp(0,GX_PASSCLR);
 GX_Begin(GX_TRIANGLES,GX_VTXFMT0,3);
 for(unsigned i=0;i<3;++i){const auto &v=b.vertices[i];GX_Position3f32(v.x+1.f/12,v.y+1.f/12,float(v.z+.5));GX_Color4u8(17,31,63,64);}GX_End();GX_DrawDone();
}
void CanonicalTriangle(const GSPrimitiveBatch &b,const GSNativeLinearPlan &p,unsigned method){
 // No old depth is read or compared here. GX owns the decision and Z write.
 std::memset(seed,0,sizeof(seed));
 for(int row=0;row<p.height;++row)for(unsigned x=p.left[row];x<p.right[row];++x){
  const unsigned z=GSNativeDepth24Plan::Depth(b,p,x,row),k=Tile(p.x+x,p.y+row);
  Check(z<=GX_MAX_Z24,"canonical source Z is outside exact Z24 family");
  seed[k]=255;seed[k+1]=z>>16;seed[k+32]=z>>8;seed[k+33]=z;
 }
 Base();Transform(false);GX_SetColorUpdate(GX_TRUE);GX_SetZCompLoc(GX_FALSE);
 GX_SetZMode(GX_TRUE,method==2?GX_GEQUAL:GX_GREATER,GX_TRUE);
 GX_SetNumChans(0);GX_SetNumTexGens(1);GX_SetTexCoordGen(GX_TEXCOORD0,GX_TG_MTX2x4,GX_TG_POS,GX_TEXMTX0);
 Mtx tm={{1.f/W,0,0,0},{0,1.f/H,0,0},{0,0,1,0}};GX_LoadTexMtxImm(tm,GX_TEXMTX0,GX_MTX2x4);
 GXTexObj tex;GX_InitTexObj(&tex,seed,W,H,GX_TF_RGBA8,GX_CLAMP,GX_CLAMP,GX_FALSE);
 GX_InitTexObjLOD(&tex,GX_NEAR,GX_NEAR,0,0,0,GX_FALSE,GX_FALSE,GX_ANISO_1);
 DCFlushRange(seed,sizeof(seed));GX_InvalidateTexAll();GX_LoadTexObj(&tex,GX_TEXMAP0);
 GX_SetTevColor(GX_TEVREG0,GXColor{17,31,63,64});GX_SetTevOrder(0,GX_TEXCOORD0,GX_TEXMAP0,GX_COLORNULL);
 GX_SetTevColorIn(0,GX_CC_ZERO,GX_CC_ZERO,GX_CC_ZERO,GX_CC_C0);GX_SetTevColorOp(0,GX_TEV_ADD,GX_TB_ZERO,GX_CS_SCALE_1,GX_TRUE,GX_TEVPREV);
 GX_SetTevAlphaIn(0,GX_CA_ZERO,GX_CA_ZERO,GX_CA_ZERO,GX_CA_A0);GX_SetTevAlphaOp(0,GX_TEV_ADD,GX_TB_ZERO,GX_CS_SCALE_1,GX_TRUE,GX_TEVPREV);
 GX_SetZTexture(GX_ZT_REPLACE,GX_TF_Z24X8,0);
 GX_Begin(GX_TRIANGLES,GX_VTXFMT0,3);for(unsigned i=0;i<3;++i)GX_Position3f32(b.vertices[i].x+1.f/12,b.vertices[i].y+1.f/12,0);GX_End();GX_DrawDone();
}
void Read(GSCpuBackend &out,bool depth){
 GX_SetTexCopySrc(0,0,W,H);GX_SetTexCopyDst(W,H,depth?GX_TF_Z24X8:GX_TF_RGBA8,GX_FALSE);
 GX_CopyTex(copy,GX_FALSE);GX_DrawDone();DCInvalidateRange(copy,sizeof(copy));
 for(unsigned y=0;y<H;++y)for(unsigned x=0;x<W;++x){const unsigned k=Tile(x,y);
  const uint32_t v=depth?(uint32_t(copy[k+1])<<16)|(uint32_t(copy[k+32])<<8)|copy[k+33]:uint32_t(copy[k+1])|(uint32_t(copy[k+32])<<8)|(uint32_t(copy[k+33])<<16);
  out.WriteVram(depth?GS_PSM_Z24:GS_PSM_CT24,depth?192*32:64*32,1,x,y,v);
 }
}
void LedgerCases(void *xfb,GXRModeObj *mode){
 for(unsigned n=0;n<16;++n){
  probe_result[20]=32+n;std::memset(actual,0x5a,Size);std::memset(expected,0x5a,Size);
  GSCpuBackend reference,result;reference.Initialize(expected,Size);result.Initialize(actual,Size);
  std::array<GSPrimitiveBatch,3> ledger;
  for(unsigned draw=0;draw<3;++draw){auto &b=ledger[draw];b.vertexCount=3;auto &s=b.state;
   s.prim.type=GS_PRIM_TRIANGLE;s.colclamp=1;s.context.frame={64,1,GS_PSM_CT32,0};
   s.context.zbuf={192,GS_PSM_Z24,false};s.context.scissor={0,63,0,63};s.context.test=uint64_t(2)<<17;s.context.fba=(n+draw)&1;
   for(unsigned i=0;i<3;++i){auto &v=b.vertices[i];v.x=i==1?53:5+(i==2?3:0);v.y=i==2?55:4+(i==1?1:0);
    if(n&1){v.x+=(i+1)/16.f;v.y+=(3-i)/16.f;}
    v.z=(i==0?100000:i==1?100200:100400)+(draw==2?(i==1?90:-90):0);
    v.r=17;v.g=31;v.b=63;v.a=32+draw*53;}
  }
  GSNativeLinearPlan first;Check(GSNativeLinearPlan::Prepare(ledger[0],first),"ledger initial geometry");
  for(unsigned y=0;y<H;++y)for(unsigned x=0;x<W;++x){
   unsigned z=0;if(n&2){float w[3];first.weights(int(x)-first.x,int(y)-first.y,w);
    const auto &b=ledger[0];const double value=b.vertices[0].z*w[0]+b.vertices[1].z*w[1]+b.vertices[2].z*w[2];
    z=unsigned(std::clamp(value+.5+int((x+y)%3)-1,0.,double(GX_MAX_Z24)));}
   reference.WriteVram(GS_PSM_Z24,192*32,1,x,y,z);const unsigned k=Tile(x,y);seed[k]=255;seed[k+1]=z>>16;seed[k+32]=z>>8;seed[k+33]=z;
  }
  Base();Transform(false);GX_SetColorUpdate(GX_TRUE);GX_SetZMode(GX_TRUE,GX_ALWAYS,GX_TRUE);
  GX_SetDispCopySrc(0,0,W,H);GX_SetDispCopyDst(W,H);GX_SetDispCopyYScale(1);
  GX_SetCopyFilter(GX_FALSE,mode->sample_pattern,GX_FALSE,mode->vfilter);GX_SetCopyClear(GXColor{0x5a,0x5a,0x5a,0x5a},0);
  GX_CopyDisp(xfb,GX_TRUE);GX_DrawDone();SeedDepth();
  auto owner=std::make_unique<GSNativeDepth24Ledger>();
  for(auto &b:ledger){GSNativeLinearPlan p;float xy[6];Check(GSNativeDepth24Plan::Prepare(b,xy)&&GSNativeLinearPlan::Prepare(b,p),"ledger family rejected");
   Check(owner->Append(b,true,0),"bounded Z owner rejected ledger");CanonicalTriangle(b,p,2);reference.Submit(b);}
  Read(result,false);Read(result,true);
  std::array<uint8_t,W*H> assigned{};
  // GEQUAL + writes is monotonic: the last source matching final Z owns alpha.
  const int sourceRounding=std::fegetround(),uiRounding=sourceRounding==FE_TOWARDZERO?FE_TONEAREST:FE_TOWARDZERO;
  Check(std::fesetround(uiRounding)==0,"UI rounding setup");
  Check(owner->BeginResolve(),"depth owner resolve state");
  Check(owner->ReplayBand(0,0,W,H,[&](unsigned x,unsigned y){return !assigned[y*W+x];},
   [&](unsigned x,unsigned y){return result.ReadVram(GS_PSM_Z24,192*32,1,x,y);},
   [&](unsigned x,unsigned y,uint8_t alpha){const auto rgb=result.ReadVram(GS_PSM_CT32,64*32,1,x,y)&0xffffff;
    result.WriteVram(GS_PSM_CT32,64*32,1,x,y,rgb|(uint32_t(alpha)<<24));assigned[y*W+x]=1;}),"depth alpha replay failed");
  Check(std::fegetround()==uiRounding,"depth replay leaked producer rounding into UI");
  Check(owner->EndResolve(true),"depth owner resolve completion");
  Check(std::fesetround(sourceRounding)==0,"producer rounding restore");
  if(std::memcmp(actual,expected,Size)){
   ++probe_result[4];++probe_result[29];
   for(unsigned i=0;i<Size;++i)if(actual[i]!=expected[i]){++probe_result[5];if((i&3)==3)++probe_result[28];if(probe_result[5]==1){probe_result[6]=32+n;probe_result[7]=i;probe_result[15]=actual[i];probe_result[16]=expected[i];}}
  }else{++probe_result[1];++probe_result[30];}
 }
}
void Run(void *xfb,GXRModeObj *mode){
 for(unsigned n=0;n<32;++n){
  probe_result[20]=n;std::memset(actual,0x5a,Size);std::memset(expected,0x5a,Size);
  GSCpuBackend reference,result;reference.Initialize(expected,Size);result.Initialize(actual,Size);
  GSPrimitiveBatch b;b.vertexCount=3;auto &s=b.state;s.prim.type=GS_PRIM_TRIANGLE;s.colclamp=1;
  s.context.frame={64,1,GS_PSM_CT24,0};s.context.zbuf={192,GS_PSM_Z24,false};s.context.scissor={0,W-1,0,H-1};
  const unsigned method=PS2X_GX_DEPTH_STAGE==1?1:n&1?3:2;s.context.test=uint64_t(method)<<17;
  const double z[4][3]={{100000,100200,100400},{1,3,7},{340000,0,280000},{16777000,16776000,16775000}};
  for(unsigned i=0;i<3;++i){auto &v=b.vertices[i];v.x=i==1?53:5+(i==2?3:0);v.y=i==2?55:4+(i==1?1:0);
   if(n&4){v.x+=(i+1)/16.f;v.y+=(3-i)/16.f;}v.z=z[(n/8)%4][i];v.r=17;v.g=31;v.b=63;v.a=64;}
  GSNativeLinearPlan p;Check(GSNativeLinearPlan::Prepare(b,p),"depth geometry plan");
  for(unsigned y=0;y<H;++y)for(unsigned x=0;x<W;++x){
   uint32_t old=0;
   if((n/2)%2){float w[3];p.weights(int(x)-p.x,int(y)-p.y,w);const double zz=b.vertices[0].z*w[0]+b.vertices[1].z*w[1]+b.vertices[2].z*w[2];
    const int offset=int((x+y)%3)-1;old=uint32_t(std::clamp(zz+.5+offset,0.,double(GX_MAX_Z24)));}
   reference.WriteVram(GS_PSM_Z24,192*32,1,x,y,old);const unsigned k=Tile(x,y);
   seed[k]=255;seed[k+1]=old>>16;seed[k+32]=old>>8;seed[k+33]=old;
  }
  Base();Transform(false);GX_SetColorUpdate(GX_TRUE);GX_SetZMode(GX_TRUE,GX_ALWAYS,GX_TRUE);
  GX_SetDispCopySrc(0,0,W,H);GX_SetDispCopyDst(W,H);GX_SetDispCopyYScale(1);
  GX_SetCopyFilter(GX_FALSE,mode->sample_pattern,GX_FALSE,mode->vfilter);GX_SetCopyClear(GXColor{0x5a,0x5a,0x5a,0x5a},0);
  GX_CopyDisp(xfb,GX_TRUE);GX_DrawDone();SeedDepth();
  if(PS2X_GX_DEPTH_STAGE==3)CanonicalTriangle(b,p,method);
  else if(PS2X_GX_DEPTH_STAGE!=0)Triangle(b,method);
  Read(result,false);Read(result,true);
  if(PS2X_GX_DEPTH_STAGE!=0)reference.Submit(b);
  // Sparse independent PE reads distinguish Z copy conversion from EFB Z.
  for(unsigned y=0;y<H;y+=8)for(unsigned x=0;x<W;x+=8){
   uint32_t peek=0;GX_PeekZ(x,y,&peek);
   const auto want=reference.ReadVram(GS_PSM_Z24,192*32,1,x,y),got=result.ReadVram(GS_PSM_Z24,192*32,1,x,y);
   probe_result[10]+=peek!=want;probe_result[11]+=peek!=got;
   probe_result[12]=std::max(uint32_t(probe_result[12]),uint32_t(std::abs(int64_t(got)-want)));
   probe_result[13]=std::max(uint32_t(probe_result[13]),uint32_t(std::abs(int64_t(peek)-want)));
  }
  if(std::memcmp(actual,expected,Size)){
   for(unsigned i=0;i<Size;++i)if(actual[i]!=expected[i]){++probe_result[5];if(i>=64*8192&&i<66*8192){++probe_result[8];probe_result[32+n]+=1u<<16;}else{++probe_result[9];++probe_result[32+n];}if(probe_result[5]==1){probe_result[6]=n;probe_result[7]=i;probe_result[15]=actual[i];probe_result[16]=expected[i];}}
   ++probe_result[4]; // Continue: distinguish precision failures from seed failures.
  }else ++probe_result[1];
 }
 if(PS2X_GX_DEPTH_STAGE==3)LedgerCases(xfb,mode);
 probe_result[2]=PS2X_GX_DEPTH_STAGE==3?48:32;probe_result[0]=0x600d;
}
}
int main(){
 probe_result[0]=1;VIDEO_Init();auto *mode=VIDEO_GetPreferredMode(nullptr);void *xfb=SYS_AllocateFramebuffer(mode);
 VIDEO_Configure(mode);VIDEO_SetNextFramebuffer(xfb);VIDEO_SetBlack(FALSE);VIDEO_Flush();
 void *fifo=memalign(32,64*1024);if(!fifo){probe_result[0]=0xe1;while(true)usleep(10000);}std::memset(fifo,0,64*1024);GX_Init(fifo,64*1024);
#if defined(PS2X_GX_DEPTH_RTZ)
 asm volatile("mtfsfi 7,1");probe_result[14]=1;
#endif
 try{Run(xfb,mode);}catch(const std::exception&){probe_result[0]=0xe5;probe_result[3]=probe_result[20]+1;}
 while(true)usleep(10000);
}
