// SPDX-License-Identifier: GPL-3.0-or-later
// Hardware RGB filtering/TFX/Gouraud prototype, explicitly NOT byte-exact RGB.
#include <gccore.h>
#include <unistd.h>
#include <malloc.h>
#include <algorithm>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <stdexcept>
#include <vector>
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_native_linear_plan.h"
#include "runtime/gs/ps2_gs_memory.h"
extern "C" {
#include "core/hw/gs_gx.h"
#include "core/hw/gs_mem.h"
int ps2x_gx_bind(uint8_t*,uint32_t);int ps2x_gx_init(void);int ps2x_gx_unbind(void);
int ps2x_gx_draw_linear_rgb(const gs_gx_flat_draw*,const void*,uint32_t,uint32_t,const float*,uint32_t,uint32_t,uint32_t,uint32_t,int,int);
uint32_t gs_scanout_read_rgb(uint32_t bp,uint32_t bw,uint32_t x,uint32_t y,uint32_t psm){if(psm>1)std::abort();return gs_mem_read_psmct32(bp,bw,x,y);}
volatile uint32_t probe_result[64];
}
namespace {
constexpr unsigned Size=4*1024*1024;
alignas(32) uint8_t actual[Size],expected[Size];
void Check(bool b,const char *why){if(!b)throw std::runtime_error(why);}
void One(unsigned psm,unsigned tfx,unsigned variant)
{
    probe_result[20]=psm*64+tfx*8+variant;
    Check(gs_gx_reset_boot_state(),"previous GPU owner did not drain");
    std::memset(expected,0x5a,Size);GSCpuBackend oracle;oracle.Initialize(expected,Size);
    GSPrimitiveBatch b;b.vertexCount=3;auto &s=b.state;auto &t=s.context.tex0;
    s.prim.type=GSPrimType(GS_PRIM_TRIANGLE+variant%3);s.prim.tme=variant!=4;s.prim.iip=variant!=0;s.prim.abe=variant==3;s.colclamp=1;
    s.textureWidth=s.textureHeight=128;s.linearFilter=s.prim.tme;
    s.context.frame={64,1,GS_PSM_CT24,0};s.context.scissor={0,63,0,63};s.context.zbuf.zmask=true;s.context.test=uint64_t(1)<<17;
    s.context.alpha=(uint64_t(128)<<32)|0x68;s.context.tex1=1u<<5;s.context.clamp=variant&1?5:0;s.scanmsk=variant%4;
    t.psm=psm;t.tw=t.th=7;t.tbw=2;t.tfx=tfx;t.tcc=variant&1;t.cpsm=GS_PSM_CT32;t.cbp=512;t.csm=1;t.cld=1;
    s.texa.ta0=s.texa.ta1=128;
    const bool indexed=psm==GS_PSM_T8||psm==GS_PSM_T4||psm==GS_PSM_T8H||psm==GS_PSM_T4HL||psm==GS_PSM_T4HH;
    const bool small=psm==GS_PSM_CT16||psm==GS_PSM_CT16S||psm==GS_PSM_Z16||psm==GS_PSM_Z16S;
    uint32_t random=0x7505900;auto next=[&]{random=random*1664525u+1013904223u;return random;};
    for(unsigned i=0;i<256;++i)oracle.WriteVram(0,512,1,i,0,0x80000000|(next()&0xffffff));
    for(unsigned y=0;y<128;++y)for(unsigned x=0;x<128;++x){
        const uint32_t pixel=indexed?next()&255:small?0x8000|(next()&0x7fff):0x80000000|(next()&0xffffff);
        oracle.WriteVram(psm,0,2,x,y,pixel);
    }
    for(unsigned i=0;i<3;++i){auto &v=b.vertices[i];v.x=5.125f+(i==1?26:0)+(i==2?3.25f:0);v.y=4.375f+(i==2?25:0)+(i==1?1.125f:0);
        v.q=.5f+i*.5f;const float offset=variant==1?-128.f:variant==2?128.f:0;
        v.s=((16+i*23+offset)/128)*v.q;v.t=((24+i*31+offset)/128)*v.q;
        v.r=32+i*83;v.g=200-i*61;v.b=17+i*57;v.a=24+i*37;
    }
    if(variant&2)std::swap(b.vertices[1],b.vertices[2]);
    GSNativeLinearPlan p;Check(GSNativeLinearPlan::Prepare(b,p),"linear geometry rejected");
    std::memcpy(actual,expected,Size);GSCpuBackend sampler;sampler.Initialize(actual,Size);
    GSTexClutReg clut;clut.cbw=1;sampler.LoadClut(t,clut);oracle.LoadClut(t,clut);
    std::vector<uint32_t> image;
    uint8_t *tiles=nullptr;
    if(s.prim.tme){
        Check(sampler.SnapshotCoherentNativeImage(s,image),"coherent source rejected");
        tiles=static_cast<uint8_t*>(memalign(32,128*128*4));Check(tiles,"source allocation");
        for(unsigned y=0;y<128;++y)for(unsigned x=0;x<128;++x){const uint32_t c=image[y*128+x];unsigned k=((y/4)*32+x/4)*64+(y&3)*8+(x&3)*2;
            tiles[k]=c>>24;tiles[k+1]=c;tiles[k+32]=c>>8;tiles[k+33]=c>>16;}
    }
    oracle.Submit(b);
    Check(ps2x_gx_bind(actual,Size)&&ps2x_gx_init(),"GPU init/bind");gs_gx_set_render_enabled(1);
    gs_gx_flat_draw d{};d.bp=64*2048;d.bw=64;d.x=p.x;d.y=p.y;d.width=p.width;d.height=p.height;d.psm=1;
    for(unsigned y=0;y<d.height;++y){d.left[y]=p.left[y];d.right[y]=p.right[y];}
    if(p.textured)Check(sampler.CommitCoherentNativeSample(s,p.firstSample[0],p.firstSample[1],p.firstSample[2]),"first sample commit");
    Check(ps2x_gx_draw_linear_rgb(&d,tiles,128,128,p.matrices.data(),s.context.clamp&3,(s.context.clamp>>2)&3,tfx,p.textured,1,s.prim.abe),"native RGB draw");
    Check(gs_mem_sync(),"GPU resolve");
    if(p.textured)Check(sampler.CommitCoherentNativeSample(s,p.lastSample[0],p.lastSample[1],p.lastSample[2]),"last sample commit");
    // Only covered RGB bytes may differ, and only within the explicit rounding
    // budget. Alpha, source memory, uncovered pixels and all other VRAM are exact.
    const unsigned budget=!p.textured?1:tfx==1?4:tfx>=2?7:6;
    for(unsigned row=0;row<d.height;++row)for(unsigned x=d.left[row];x<d.right[row];++x){uint32_t address=0;
        Check(GSMem::TextureByteAddress(GS_PSM_CT32,64*32,1,d.x+x,d.y+row,address),"target address");
        for(unsigned channel=0;channel<3;++channel){const unsigned i=address+channel;
            const unsigned error=std::abs(int(actual[i])-int(expected[i]));
            if(error>budget){probe_result[7]=i;probe_result[15]=actual[i];probe_result[16]=expected[i];probe_result[17]=budget;probe_result[18]=1;
                throw std::runtime_error("hardware RGB exceeded explicit rounding budget");}
            if(error){probe_result[21]=probe_result[21]+1;probe_result[22]=probe_result[22]+error;}
            probe_result[23]=std::max(unsigned(probe_result[23]),error);
            // Normalize ONLY already-checked covered RGB in this completed
            // one-draw oracle result, then verify all remaining bytes exactly.
            // These bytes never feed a later draw or the native renderer.
            expected[i]=actual[i];
        }
    }
    if(std::memcmp(actual,expected,Size)){
        for(unsigned i=0;i<Size;++i)if(actual[i]!=expected[i]){probe_result[7]=i;probe_result[15]=actual[i];probe_result[16]=expected[i];break;}
        throw std::runtime_error("native draw changed alpha/uncovered/source VRAM");
    }
    Check(gs_gx_reset_boot_state()&&ps2x_gx_unbind(),"GPU drain/unbind");std::free(tiles);
    probe_result[1]=probe_result[1]+1;probe_result[10]=probe_result[10]+1;
}
void Run(){
    const unsigned formats[]={GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH,GS_PSM_Z32,GS_PSM_Z24,GS_PSM_Z16,GS_PSM_Z16S};
    for(unsigned psm:formats)for(unsigned tfx=0;tfx<4;++tfx)for(unsigned v=0;v<4;++v)One(psm,tfx,v);
    for(unsigned tfx=0;tfx<4;++tfx)One(GS_PSM_CT32,tfx,4);
    probe_result[2]=212;
}
}
int main(){
    probe_result[0]=1;probe_result[63]=1; // Different RGB precision contract.
    VIDEO_Init();auto *mode=VIDEO_GetPreferredMode(nullptr);void *xfb=SYS_AllocateFramebuffer(mode);VIDEO_Configure(mode);VIDEO_SetNextFramebuffer(xfb);VIDEO_SetBlack(FALSE);VIDEO_Flush();
    try{Run();probe_result[0]=0x600d;}catch(const std::exception&){probe_result[3]=probe_result[20]+1;probe_result[4]=1;probe_result[0]=0xe5;}
    while(true)usleep(10000);
}
