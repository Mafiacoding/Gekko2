// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic integration probe. This restricted driver is NOT a production backend.
#include <gccore.h>
#include <unistd.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <stdexcept>
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_hybrid_backend.h"
extern "C" {
#include "core/hw/gs_gx.h"
#include "core/hw/gs_mem.h"
int probe_bind(uint8_t *, uint32_t);
int probe_unbind(void);
int probe_gx_init(void);
uint32_t gs_scanout_read_rgb(uint32_t bp,uint32_t bw,uint32_t x,uint32_t y,uint32_t psm)
{
    if (psm > 1) std::abort();
    return gs_mem_read_psmct32(bp,bw,x,y);
}
volatile uint32_t probe_result[64];
}
namespace {
constexpr unsigned Size=4*1024*1024;
alignas(32) uint8_t actual[Size],expected[Size];

class FlatDriver final : public GSNativeDrawDriver
{
    bool bound=false;
    bool Invalidate()
    {
        if (!gs_gx_reset_boot_state() || !probe_gx_init()) return false;
        gs_gx_set_render_enabled(1);
        return true;
    }
public:
    bool Initialize(uint8_t *vram,uint32_t size) override
    {
        if (!probe_bind(vram,size)) return false;
        bound=true;
        if (!Invalidate()) throw std::runtime_error("GX initialization failed");
        return true;
    }
    Result TrySubmit(const GSPrimitiveBatch &b) override
    {
        const auto &s=b.state;const auto &c=s.context;
        if (b.vertexCount!=2 || s.prim.type!=GS_PRIM_SPRITE || s.prim.tme ||
            s.prim.abe || s.prim.fge || s.prim.aa1 || c.frame.psm>1 ||
            c.frame.fbmsk || c.fba || !c.zbuf.zmask || (c.test&0x4001) ||
            ((c.test>>17)&3)!=1 || !c.frame.fbw || c.frame.fbw>10 || !s.colclamp)
            return Result::Unsupported;
        float x[2],y[2];
        for(unsigned i=0;i<2;++i)
        {
            x[i]=b.vertices[i].x-float(c.xyoffset.ofx)/16;
            y[i]=b.vertices[i].y-float(c.xyoffset.ofy)/16;
            if(!std::isfinite(x[i])||!std::isfinite(y[i])||x[i]<0||y[i]<0||
               x[i]>2047||y[i]>2047||std::floor(x[i])!=x[i]||std::floor(y[i])!=y[i])
                return Result::Unsupported;
        }
        const int x0=std::max(int(std::min(x[0],x[1])),int(c.scissor.x0));
        const int y0=std::max(int(std::min(y[0],y[1])),int(c.scissor.y0));
        const int x1=std::min(int(std::max(x[0],x[1])),int(c.scissor.x1)+1);
        const int y1=std::min(int(std::max(y[0],y[1])),int(c.scissor.y1)+1);
        if(x1<=x0||y1<=y0)return Result::Unsupported;
        const auto &v=b.vertices[1];
        const uint32_t rgba=v.r|(uint32_t(v.g)<<8)|(uint32_t(v.b)<<16)|(uint32_t(v.a)<<24);
        const int32_t xy[6]={x0,y0,x1,y1,0,0};gs_gx_flat_draw prepared;
        if(!gs_gx_prepare_flat(&prepared,6,c.frame.fbp*2048,c.frame.fbw*64,
                              x0,y0,x1,y1,xy,rgba,s.scanmsk&3))
            return Result::Unsupported; // Pure validation, no GPU side effects.
        // Once eligible work is attempted, any error is terminal. A legacy GX
        // failure may have submitted work and is never safe to call unsupported.
        return gs_gx_draw_flat_psm(c.frame.psm,6,c.frame.fbp*2048,c.frame.fbw*64,
                                   x0,y0,x1,y1,xy,rgba,s.scanmsk&3)
                   ? Result::Submitted : Result::Fault;
    }
    bool Resolve() override { return gs_mem_sync()!=0; }
    // Conservative integration prototype: reset host GX caches after software
    // writes. This preserves CPU guest texels but is NOT a fast final policy.
    bool CpuWroteVram() override { return Invalidate(); }
    bool LoadClut(const GSTex0Reg &,const GSTexClutReg &) override { return true; }
    bool TextureFlush() override { return Invalidate(); }
    bool Flush() override { GX_Flush();return !gs_gx_faulted(); }
    bool Reset() override { return Invalidate(); }
    bool Shutdown() noexcept override
    {
        if(!bound)return true;
        if(!gs_gx_reset_boot_state()||!probe_unbind())return false;
        bound=false;return true;
    }
};
GSPrimitiveBatch Sprite(uint32_t rgba,uint32_t page=0)
{
    GSPrimitiveBatch b;b.vertexCount=2;b.state.prim.type=GS_PRIM_SPRITE;
    b.state.context.frame={page,1,GS_PSM_CT32,0};
    b.state.context.scissor={0,63,0,63};b.state.context.zbuf.zmask=true;
    b.state.context.test=uint64_t(1)<<17;b.state.colclamp=1;
    b.vertices[1].x=4;b.vertices[1].y=4;
    for(auto &v:b.vertices){v.r=rgba;v.g=rgba>>8;v.b=rgba>>16;v.a=rgba>>24;}
    return b;
}
GSPrimitiveBatch Textured()
{
    auto b=Sprite(0x80808080,1);b.state.prim.tme=true;b.state.prim.fst=true;
    b.state.context.tex0={0,1,GS_PSM_CT32,2,2,1,1,0,0,0,0,0};
    b.state.textureWidth=4;b.state.textureHeight=4;b.vertices[1].u=64;b.vertices[1].v=64;
    return b;
}
void Check(bool condition,const char *message)
{
    if(!condition)throw std::runtime_error(message);
}
void Equal(GSHybridBackend &hybrid)
{
    std::vector<uint8_t> bytes;hybrid.SnapshotVram(bytes);
    Check(bytes.size()==Size&&!std::memcmp(bytes.data(),expected,Size),"full VRAM differs");
    probe_result[1]=probe_result[1]+1;
}
void Run()
{
    GSCpuBackend oracle;oracle.Initialize(expected,Size);
    GSHybridBackend hybrid(std::make_unique<GSCpuBackend>(),std::make_unique<FlatDriver>());
    hybrid.Initialize(actual,Size);probe_result[0]=2;
    auto blue=Sprite(0x80ff0000),red=Sprite(0x800000ff),sample=Textured();
    hybrid.Submit(blue);oracle.Submit(blue);
    Check(std::memcmp(actual,expected,Size)!=0,"accepted GX draw mirrored on CPU");
    auto counts=hybrid.GetCounters();Check(counts.nativeDraws==1&&counts.softwareDraws==0,"native routing failed");
    hybrid.Submit(sample);oracle.Submit(sample);Equal(hybrid); // Resolve, then CPU caches blue texels.
    probe_result[0]=3;
    hybrid.Submit(red);oracle.Submit(red);
    hybrid.Submit(sample);oracle.Submit(sample);Equal(hybrid);
    Check(hybrid.ReadVram(0,32,1,0,0)==0x80ff0000,"ownership change flushed guest texels");
    hybrid.TextureFlush();oracle.TextureFlush();
    hybrid.Submit(sample);oracle.Submit(sample);Equal(hybrid);
    Check(hybrid.ReadVram(0,32,1,0,0)==0x800000ff,"TEXFLUSH did not expose new texels");
    probe_result[0]=4;
    auto unsupported=Sprite(0x80805511,2);unsupported.state.prim.abe=true;
    unsupported.state.context.alpha=0x44;
    hybrid.Submit(blue);oracle.Submit(blue);
    hybrid.Submit(unsupported);oracle.Submit(unsupported);Equal(hybrid);
    hybrid.Submit(red);oracle.Submit(red);
    hybrid.WriteVram(0,0,1,0,0,0x80010203);oracle.WriteVram(0,0,1,0,0,0x80010203);Equal(hybrid);
    hybrid.Submit(blue);oracle.Submit(blue);
    hybrid.ClearFramebuffer(blue.state.context,0x80446688);
    oracle.ClearFramebuffer(blue.state.context,0x80446688);Equal(hybrid);
    probe_result[0]=5;
    GSTransferCommand transfer;transfer.direction=0;transfer.bitbltbuf.dbp=64;
    transfer.bitbltbuf.dbw=1;transfer.trxreg={2,2};
    hybrid.Submit(red);oracle.Submit(red);
    hybrid.BeginTransfer(transfer);oracle.BeginTransfer(transfer);
    const uint8_t pixels[16]={1,2,3,128,4,5,6,128,7,8,9,128,10,11,12,128};
    hybrid.UploadImage(pixels,sizeof pixels);oracle.UploadImage(pixels,sizeof pixels);Equal(hybrid);
    counts=hybrid.GetCounters();probe_result[10]=counts.nativeDraws;
    probe_result[11]=counts.softwareDraws;probe_result[12]=counts.resolves;
    Check(counts.nativeDraws>=6&&counts.softwareDraws>=4&&counts.resolves>=5,"missing mixed execution");
    probe_result[2]=7;
}
}
int main()
{
    probe_result[0]=1;VIDEO_Init();auto *mode=VIDEO_GetPreferredMode(nullptr);
    void *xfb=SYS_AllocateFramebuffer(mode);VIDEO_Configure(mode);VIDEO_SetNextFramebuffer(xfb);
    VIDEO_SetBlack(FALSE);VIDEO_Flush();
    try{Run();probe_result[0]=0x600d;}
    catch(const std::exception &){probe_result[4]=1;probe_result[3]=probe_result[0];probe_result[0]=0xe5;}
    while(true)usleep(10000);
}
