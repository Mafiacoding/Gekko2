#!/usr/bin/env python3
"""Build a synthetic ELF only. Never mutates Gekko2 or creates a game DOL."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import importlib.util


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gekko-root', type=Path, required=True)
    parser.add_argument('--devkitpro', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--probe', choices=['raster', 'hybrid', 'texture', 'linear', 'connected', 'depth'], default='raster')
    parser.add_argument('--runtime-adapter', action='store_true', help='Test the game-sized staging adapter')
    parser.add_argument('--source-image-cache', action='store_true', help='Exercise exact-byte native source image reuse')
    parser.add_argument('--immutable-source-tiles', action='store_true', help='Exercise fenced immutable GX source uploads (requires source image cache)')
    parser.add_argument('--constant-stages', '--decal-single-stage', dest='constant_stages', action='store_true', help='Elide GX color ramps for constant planes and DECAL')
    parser.add_argument('--batch-linear-runs', action='store_true', help='Batch compatible native GX row runs')
    parser.add_argument('--fixed-run-vertices', action='store_true', help='Submit exact pixel-aligned run corners as S16 XY')
    parser.add_argument("--whole-triangles", action="store_true", help="Exercise experimental whole 12.4 GX triangles")
    parser.add_argument("--depth-stage", choices=["seed", "interpolation", "full", "canonical"], default=None, help="Isolate Z24 seed/readback, interpolation, or comparison")
    parser.add_argument("--depth-rounding", choices=["nearest", "zero"], default="nearest", help="CPU rounding mode for the depth reference and source samples")
    parser.add_argument("--resident-depth24", action="store_true", help="Enable the connected resident Z24 engine")
    args = parser.parse_args()
    if args.probe != 'depth' and args.depth_stage is not None:parser.error('--depth-stage requires --probe depth')
    if args.probe != 'depth' and args.depth_rounding != 'nearest':parser.error('--depth-rounding requires --probe depth')
    args.depth_stage = args.depth_stage or ('canonical' if args.probe == 'depth' else 'full')
    if args.immutable_source_tiles and not args.source_image_cache:parser.error('immutable source tiles require --source-image-cache')
    probe_names={'raster':'native_gx_probe','hybrid':'native_hybrid_probe','texture':'native_texture_probe','linear':'native_linear_probe','connected':'native_connected_probe','depth':'native_depth_probe'}
    probe_name=probe_names[args.probe]
    here = Path(__file__).resolve().parent
    root = here.parents[2]
    gekko = args.gekko_root.resolve()
    output = args.output.resolve()
    # Keep generated GPL copies/objects out of both source trees.
    if output.is_relative_to(root) or output.is_relative_to(gekko):
        parser.error('Use a separate output directory outside both source trees')
    spec = importlib.util.spec_from_file_location('gx_adapter', root / 'tools/wii/prepare_gx_adapter.py')
    adapter = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(adapter)
    manifest = adapter.prepare(gekko, output, limited=args.runtime_adapter, textures=args.probe in ('texture','linear','connected'))
    toolchain = args.devkitpro.resolve()
    cc = toolchain / 'devkitPPC/bin/powerpc-eabi-gcc'
    cxx = toolchain / 'devkitPPC/bin/powerpc-eabi-g++'
    abi = ['-Os', '-G0', '-ffp-contract=off', '-ffunction-sections', '-fdata-sections',
           '-DGEKKO', '-DHW_RVL', '-mrvl', '-mcpu=750', '-meabi', '-mhard-float']
    includes = ['-I' + str(gekko / 'include'),
                '-I' + str(toolchain / 'libogc/include'),
                '-I' + str(root / 'ps2xRuntime/include'),
                '-I' + str(root / 'ps2xIOP/include'),
                '-I' + str(root / 'ps2xRuntime/platform/wii')]
    sources = [('shared_mem', output / 'shared_mem.c', False),
               ('gx_probe', output / 'gx_probe.c', False),
               ('surface', gekko / 'source/hw/gs_gx_surface.c', False),
               ('additive', gekko / 'source/hw/gs_gx_additive.c', False),
               ('profile', gekko / 'source/core/runtime_profile.c', False),
               ('oracle', root / 'ps2xRuntime/src/lib/gs/gs_cpu_backend.cpp', True),
               ('memory', root / 'ps2xRuntime/src/lib/gs/ps2_gs_memory.cpp', True),
               ('probe', here / (probe_name+'.cpp'), True)]
    if args.probe in ('hybrid', 'texture', 'connected'):
        sources.append(('hybrid', root / 'ps2xRuntime/src/lib/gs/gs_hybrid_backend.cpp', True))
    objects = []
    for name, path, cpp in sources:
        obj = output / (name + '.o')
        extra = ['-DPS2X_GX_FAST_LINEAR='+('1' if args.probe=='connected' else '0'), '-DPS2X_GX_FAST_UNTEXTURED='+('1' if args.probe=='connected' else '0'), '-DPS2X_WII_SCALAR_SIMD', '-DPS2_RUNTIME_LOGS=0', '-DAGRESSIVE_LOGS=0'] if cpp else []
        if (name == 'gx_probe' or cpp) and args.constant_stages:extra.append('-DPS2X_GX_CONSTANT_STAGES')
        if (name == 'gx_probe' or cpp) and args.batch_linear_runs:extra.append('-DPS2X_GX_BATCH_LINEAR_RUNS')
        if (name == 'gx_probe' or cpp) and args.fixed_run_vertices:extra.append('-DPS2X_GX_FIXED_RUN_VERTICES')
        if name == 'probe' and args.probe == 'depth':extra.append('-DPS2X_GX_DEPTH_STAGE='+str(['seed','interpolation','full','canonical'].index(args.depth_stage)))
        if name == 'probe' and args.probe == 'depth' and args.depth_rounding == 'zero':extra.append('-DPS2X_GX_DEPTH_RTZ=1')
        if cpp and args.whole_triangles:extra.append('-DPS2X_GX_WHOLE_TRIANGLES=1')
        if cpp and args.resident_depth24:extra.append('-DPS2X_WII_GX_DEPTH24')
        if cpp and args.source_image_cache:extra.append('-DPS2X_WII_SOURCE_IMAGE_CACHE')
        if cpp and args.immutable_source_tiles:extra.append('-DPS2X_WII_IMMUTABLE_SOURCE_TILES')
        subprocess.run([str(cxx if cpp else cc), '-std=c++20' if cpp else '-std=gnu11',
                        *abi, *includes, *extra, '-c', str(path), '-o', str(obj)], check=True)
        objects.append(str(obj))
    elf = output / (probe_name+'.elf')
    subprocess.run([str(cxx), '-mrvl', '-mcpu=750', '-meabi', '-mhard-float',
                    '-Wl,--gc-sections', *objects, '-L' + str(toolchain / 'libogc/lib/wii'),
                    '-logc', '-lm', '-o', str(elf)], check=True)
    manifest['compiler'] = subprocess.check_output([str(cxx), '--version'], text=True).splitlines()[0]
    manifest['abi_flags'] = abi
    manifest['fast_linear_enabled'] = args.probe == 'connected'
    manifest['fast_untextured_enabled'] = args.probe == 'connected'
    manifest['source_image_cache_enabled'] = args.source_image_cache
    manifest['immutable_source_tiles_enabled'] = args.immutable_source_tiles
    manifest['constant_stages_enabled'] = args.constant_stages
    manifest['batch_linear_runs_enabled'] = args.batch_linear_runs
    manifest['fixed_run_vertices_enabled'] = args.fixed_run_vertices
    manifest['whole_triangles_enabled'] = args.whole_triangles
    if args.probe == 'depth':
        manifest['depth_stage'] = args.depth_stage
        manifest['depth_rounding'] = args.depth_rounding
    manifest.update(probe=args.probe, elf_sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),
                    probe_source_sha256=hashlib.sha256((here / (probe_name+'.cpp')).read_bytes()).hexdigest(),
                    scope=('independent GX Z24 interpolation/comparison/readback experiment; not game integration' if args.probe == 'depth' else 'synthetic CT32/CT24 GX sprites' if args.probe == 'raster' else 'restricted real-GX/coordinator integration including texture cache' if args.probe == 'texture' else 'hardware-linear/Gouraud GX RGB with bounded error and exact structural VRAM' if args.probe in ('linear','connected') else 'restricted real-GX/coordinator integration') + '; no game or hardware speed claim')
    manifest['runtime_sources_sha256'] = {
        str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in [root / 'ps2xRuntime/src/lib/gs/gs_cpu_backend.cpp',
                     root / 'ps2xRuntime/src/lib/gs/gs_hybrid_backend.cpp',
                     root / 'ps2xRuntime/include/runtime/gs/gs_cpu_backend.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_hybrid_backend.h',
                     root / 'ps2xRuntime/src/lib/gs/ps2_gs_memory.cpp',
                     root / 'ps2xRuntime/include/runtime/gs/ps2_gs_memory.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_texture_page_cache.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_triangle_coverage.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_native_sprite_plan.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_native_projective_plan.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_native_linear_plan.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_native_fragment_plan.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_native_whole_triangle.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_native_depth24_plan.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_native_depth24_ledger.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_texture_coordinates.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_types.h',
                     root / 'ps2xRuntime/include/runtime/gs/gs_backend.h']}
    if args.probe in ('texture','linear','connected'):
        manifest['driver_sha256'] = hashlib.sha256((root / 'ps2xRuntime/platform/wii/ps2_wii_gx_driver.h').read_bytes()).hexdigest()
        manifest['wii_bridge_sha256'] = hashlib.sha256((root / 'ps2xRuntime/platform/wii/ps2_wii_gx_bridge.inc').read_bytes()).hexdigest()
        manifest['texture_bridge_sha256'] = hashlib.sha256((here / 'probe_texture_bridge.inc').read_bytes()).hexdigest()
    (output / 'build.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(elf)


if __name__ == '__main__':
    main()
