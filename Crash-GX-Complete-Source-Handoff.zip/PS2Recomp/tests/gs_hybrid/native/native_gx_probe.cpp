// SPDX-License-Identifier: GPL-3.0-or-later
// Synthetic native GX differential probe; no game assets or game code.
#include <gccore.h>
#include <unistd.h>
#include <cstring>
#include <algorithm>
#include <cstdlib>
#include "runtime/gs/gs_cpu_backend.h"
extern "C" {
#include "core/hw/gs_gx.h"
#include "core/hw/gs_mem.h"
int probe_bind(uint8_t*,uint32_t);
int probe_gx_init(void);
uint32_t gs_scanout_read_rgb(uint32_t bp,uint32_t bw,uint32_t x,uint32_t y,uint32_t psm){if(psm>1)std::abort();return gs_mem_read_psmct32(bp,bw,x,y);}
volatile uint32_t probe_result[64];
}
alignas(32) static uint8_t actual[4*1024*1024],expected[4*1024*1024];
int main(){
 probe_result[0]=1;probe_result[2]=64;VIDEO_Init();auto *mode=VIDEO_GetPreferredMode(nullptr);void *xfb=SYS_AllocateFramebuffer(mode);VIDEO_Configure(mode);VIDEO_SetNextFramebuffer(xfb);VIDEO_SetBlack(FALSE);VIDEO_Flush();GSCpuBackend oracle;oracle.Initialize(expected,sizeof expected);
 if(!probe_bind(actual,sizeof actual)){probe_result[0]=0xe1;goto stop;}
 for(unsigned n=0;n<64;++n){
  probe_result[0]=0x100+n;
  if(!gs_gx_reset_boot_state()||!probe_gx_init()){probe_result[0]=0xe2;goto stop;}
  bool resident=(n&2)==0;unsigned psm=n>=32?1:0;
  gs_gx_set_residency_enabled(resident);
  memset(actual,0x5a,sizeof actual);memset(expected,0x5a,sizeof expected);oracle.Reset();gs_gx_set_render_enabled(1);
  GSPrimitiveBatch b;b.vertexCount=2;b.state.prim.type=GS_PRIM_SPRITE;
  b.state.context.frame={n%3,1+n%2,uint8_t(psm),0};
  b.state.context.scissor={uint16_t(n%5==0?3:0),uint16_t(n%7==0?14:63),uint16_t(n%3==0?3:0),uint16_t(n%11==0?10:63)};
  b.state.context.zbuf.zmask=true;b.state.context.test=uint64_t(1)<<17;b.state.colclamp=1;
  b.vertices[0].x=n%8;b.vertices[0].y=n%4;b.vertices[1].x=n%8+4+(n%4)*4;b.vertices[1].y=n%4+4+(n%3)*4;
  uint32_t color=n==0?0:n==1?0xffffffffu:0x80012345u+n*0x9e3779b9u;
  for(auto&v:b.vertices){v.r=color;v.g=color>>8;v.b=color>>16;v.a=color>>24;}
  b.state.scanmsk=n%4;oracle.Submit(b);
  int x0=std::max(int(b.vertices[0].x),int(b.state.context.scissor.x0)),y0=std::max(int(b.vertices[0].y),int(b.state.context.scissor.y0));
  int x1=std::min(int(b.vertices[1].x),int(b.state.context.scissor.x1)+1),y1=std::min(int(b.vertices[1].y),int(b.state.context.scissor.y1)+1);
  int32_t xy[6]={x0,y0,x1,y1,0,0};
  if(!gs_gx_draw_flat_psm(psm,6,b.state.context.frame.fbp*2048,b.state.context.frame.fbw*64,x0,y0,x1,y1,xy,color,b.state.scanmsk)){probe_result[0]=0xe3;probe_result[3]=n+1;goto stop;}
  if(!gs_mem_sync()){probe_result[0]=0xe4;probe_result[3]=n+1;goto stop;}
  if(memcmp(actual,expected,sizeof actual)){
   probe_result[4]=probe_result[4]+1;
   for(unsigned i=0;i<sizeof actual;++i)if(actual[i]!=expected[i]){probe_result[5]=probe_result[5]+1;if(!probe_result[3]){probe_result[3]=n+1;probe_result[7]=i;probe_result[10]=actual[i];probe_result[11]=expected[i];probe_result[12]=color;probe_result[13]=psm;probe_result[14]=resident;}}
  }else probe_result[1]=probe_result[1]+1;
 }
 probe_result[0]=0x600d;
 stop:while(true)usleep(10000);
}
