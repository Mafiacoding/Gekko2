# Native GX differential probe (experimental)

This synthetic test submits actual GX draws and compares the complete 4 MiB
VRAM allocation against PS2Recomp's software renderer after every case. It does
not use the deferred test double in the parent directory. It contains no game
code, assets, BIOS, screenshots or private traces. It is not a speed benchmark.

Build using devkitPro/devkitPPC/libogc and a separate Gekko2 checkout:

```
python3 tests/gs_hybrid/native/build_probe.py \
  --gekko-root /path/to/Gekko2 \
  --devkitpro /path/to/devkitpro \
  --output /tmp/native-gx-probe
```

The validated core Gekko2 C sources are pinned by SHA-256 in `gekko_sources.json`.
The script creates GPL source copies and objects only in the output directory;
it changes neither checkout. Gekko2's license is copied alongside those files.
A test-only adapter binds its memory accessors to the external VRAM and exposes
bounded GX initialization. An independent oracle allocation is test data, not a
production CPU mirror. No DOL or game executable is produced.

Run the resulting `native_gx_probe.elf` under Dolphin with a functioning graphics
backend. For Dolphin 2503, relevant command-line settings are:

```
-v OGL
-C Graphics.Hacks.EFBAccessEnable=True
-C Graphics.Hacks.EFBToTextureEnable=False
-C Graphics.Hacks.DeferEFBCopies=False
```

**Use `Graphics`, not `GFX`:** Dolphin 2503 silently ignores an unknown system
name. Without these settings, GPU-only EFB copies and disabled CPU EFB access
can make a correct draw appear black on CPU readback. Null video is unsuitable
for this test. Local validation used X11/Xvfb and OpenGL Mesa llvmpipe; results
are not physical Wii evidence.

The ELF leaves `probe_result` available for a debugger after completion. It
contains 64 big-endian 32-bit words:

- `[0]`: `0x600d` completed; `0xe1..0xe4` initialization/draw/resolve failure.
- `[1]`: passing cases; `[2]`: expected case count (64).
- `[3]`: first failed case plus one, or zero; `[4]`: failing comparisons.
- `[5]`: differing byte count; `[7]`: first differing VRAM offset.
- `[10..14]`: first mismatch's actual byte, oracle byte, color, PSM and residency.

Success requires `[0]=0x600d`, `[1]=[2]=64`, `[3]=[4]=[5]=0`. The main loop
sleeps after completion so a debugger can read the report. A successful boot or
GX fence alone is not success.

Cases combine CT32/CT24, resident/direct execution, 64/128-pixel buffer widths,
different framebuffer bases, non-aligned bounds, scissor clipping, scan masks
and varying RGBA values. Initial VRAM bytes are `0x5a`, so comparisons also check
preserved alpha and untouched bytes. Every comparison covers all 4 MiB, not
just visible RGB. Textures, blends, depth writes/tests, triangles, and integration
with `GSHybridBackend` remain outside this probe's acceptance scope.

## Real coordinator integration probe

Add `--probe hybrid` to build `native_hybrid_probe.elf`. This links the real
`GSHybridBackend` coordinator with a deliberately restricted GX driver, using
the same shared-VRAM adapter. It compares seven full-VRAM checkpoints around
actual GPU/CPU transitions, retained texels before TEXFLUSH, updated texels after
TEXFLUSH, unsupported blend fallback, direct CPU writes, clears and uploads.
A check before the first resolve verifies the accepted native draw was not
also drawn into VRAM by the CPU. The separate oracle still renders its own
allocation for comparison; it is not the production path's CPU mirror.

For this probe, success is `[0]=0x600d`, `[1]=[2]=7`, `[3]=[4]=0`.
Words `[10..12]` contain coordinator native/software/resolve counters. Native
drawing is restricted to a small opaque, untextured, integer-coordinate sprite
subset. Other operations fall back; errors after a native attempt are terminal.
The CPU texel cache remains authoritative for textured draws. This driver
conservatively resets host GX caches after software writes: correct ownership
is the goal, and the resulting cost prevents a speed claim. It does not support
concurrent Gekko2 GPU ownership, general native textures or direct presentation.
Neither ELF is selected by the game runtime or intended as an owner Wii update.

## Native source texture probe

Use `--probe texture` to build `native_texture_probe.elf`. This adds actual GX
point-textured sprites and opts in only with the exact canonical software
texel/CLUT cache. Source textures are RGBA8 uploads decoded from CT32/CT24,
CT16/CT16S or P8/P4/high-plane indexed formats; GX samples texels per fragment.
It is not a CPU-rendered screen-image upload. The appended test-only GX bridge
is in `probe_texture_bridge.inc` and upstream core source hashes stay pinned.

Success: `[0]=0x600d`, `[1]=[2]=453`, `[3]=[4]=0`. `[10..14]` report
native draws, software draws, uploads, uploaded atlas/source texels and upload
reuses: 455, 15, 301, 126528 and 154. `[17]` is 232 native triangles, `[19]`
is 304 source decodes and `[25]` is 153 decode reuses. Counts include rejected
source preparations, which do not submit GPU work. `[18]=2` is the separate
resident-batch scenario's total resolves: one after 16 identical draws and one
before changed-source software fallback.

The extended probe includes affine triangle coverage, constant-color source-space
TFX, exact additive blending, quarter-phase bilinear source preprocessing,
random textures and mirrored point sprites. Filtered sources are resampled once
into a bounded atlas; this is not general GX hardware bilinear filtering.
Unsupported states remain software. No game or physical Wii speed is measured.

In addition to the EFB settings above, use:

```
-C Graphics.Settings.SafeTextureCacheColorSamples=0
```

Without full texture hashing Dolphin can reuse stale seed tiles after partial
uploads into the large staging texture, causing false blending failures.
Keep using `Graphics.Hacks`; `GFX.Hacks` is silently ignored in Dolphin 2503.

Limits, test configuration findings and remaining release gates are documented
in `docs/wii/NATIVE-TEXTURES.md`. Production backend selection is unchanged.

## Wii-sized adapter

Add `--runtime-adapter` to build the same shared driver/bridge with compact
staging used by the opt-in game target. Success is now 474/474 checkpoints:
491 native draws (including 19 flat sprites), 15 software draws, 303 uploads
and 169 upload reuses. Word 26 records flat submissions. The additional cases
cover full 640x448 surfaces, partial CT24 writes, scan masks, additive reads and
new tiles while prior native work is pending. Compact staging totals 174080
bytes, separate from source, FIFO and surface metadata allocations.

See `docs/wii/GX1-EXPERIMENTAL-BUILD.md` for actual game-target wiring and limits.

## STQ extension (unreleased)

The shared-driver texture probe now expects 579/579 full-VRAM checkpoints.
The new cases cover thirteen source formats, cropped high-coordinate STQ
textures, fractional/reversed geometry, flat TFX, copy-equivalent/additive
blending, varying alpha metadata and a bounded immutable-image ring. Words
27 and 28 expose wrap fences and cache reuse in the dedicated ring stress.
Both must be nonzero. This extension is not full native 3D or a Wii speed result;
see `docs/wii/GX-STQ-PROGRESS.md` before treating a build as an owner update.

## Projective extension (unreleased)

The extended texture probe expects 636 full-VRAM checkpoints. Word 29 counts
projective native triangles and word 30 counts the two dedicated ownership
sequences. The additional 52 format/state cases each keep three accepted draws
pending and require one source upload plus two reuses. Producer-consumer, stale
page, TEXFLUSH and current-target feedback remain differential checks. Large
cropped sources now exercise both FST and STQ. See
`docs/wii/GX-PROJECTIVE-PROGRESS.md`; this is not general native depth/filtering
or a performance result.

The optional `--probe depth` experiment compares actual GX Z24 seeding,
interpolated triangles, GEQUAL/GREATER, and RGB/Z readback against the CPU
reference. It deliberately includes near-equal depths and high values that can
expose precision failures. It is **not** an accepted native depth implementation;
check the completed case count and exact comparison result, not completion alone.
Per-case result words 32–63 encode differing RGB bytes in the high half and
other differing VRAM bytes in the low half. Words 8/9 aggregate these categories.
The depth prototype is never selected by the Wii runtime.

Use `--probe depth --depth-stage seed` to test only texture-to-EFB Z seeding and
readback. `--depth-stage interpolation` uses depth ALWAYS to remove comparison
from the experiment; `--depth-stage full` also tests GEQUAL/GREATER. Sparse
`GX_PeekZ` reads independently check the copy path: word 10 counts PE/reference
differences, word 11 PE/copy differences, and words 12/13 the largest sampled
copy/reference and PE/reference depth errors. These are probe diagnostics only.

`--depth-stage canonical` supplies canonical source-Z texels and makes GX perform
the comparison/write. It also exercises 16 overlapping CT32 alpha-reconstruction
batches using the bounded shared ledger (48 total cases). It does not read old
CPU Z to choose which fragments pass. `--depth-rounding zero` verifies source
arithmetic under the Wii runtime's truncation rounding mode.

The depth probe now defaults to `canonical`; request `--depth-stage full` or
`interpolation` explicitly to reproduce the unsuccessful direct-interpolation
control. Ledger records retain the source CPU rounding mode and restore the
resolving thread’s mode after replay. The GPU test intentionally changes rounding
between submission and resolution.
