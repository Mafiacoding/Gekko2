// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_native_projective_plan.h"
#include <cstdio>
#include <stdexcept>
int main(){try{
 std::vector<uint8_t> vram(4*1024*1024);GSCpuBackend oracle;oracle.Initialize(vram.data(),vram.size());
 for(unsigned y=0;y<128;++y)for(unsigned x=0;x<128;++x)oracle.WriteVram(0,0,2,x,y,0x80000000|x|(y<<8));
 uint32_t random=0x7505900;auto next=[&]{random=random*1664525u+1013904223u;return random;};
 unsigned admitted=0,pixels=0;
 for(unsigned n=0;n<256;++n){
  GSPrimitiveBatch b;b.vertexCount=3;auto&s=b.state;s.prim.type=GS_PRIM_TRIANGLE;s.prim.tme=true;s.prim.iip=n&1;s.colclamp=1;
  s.context.frame={128,1,GS_PSM_CT32,0};s.context.scissor={0,63,0,63};s.context.zbuf.zmask=true;s.context.test=uint64_t(1)<<17;
  s.textureWidth=s.textureHeight=128;auto&t=s.context.tex0;t.tw=t.th=7;t.tbw=2;t.psm=GS_PSM_CT32;t.tfx=t.tcc=1;s.context.clamp=n&1?5:0;s.scanmsk=n%4;
  for(unsigned i=0;i<3;++i){auto&v=b.vertices[i];v.r=(n+i*71)&255;v.g=(n+i*23)&255;v.b=(n+i*53)&255;v.a=(n+i*37)&255;v.x=4+(i==1?16:0)+(next()%16)/16.f;v.y=4+(i==2?16:0)+(next()%16)/16.f;
   v.q=(.5f+(next()%9)/4.f)*(n%3==0?.00001f:n%3==1?1.f:128.f);v.s=((16+(next()%1024)/64.f+(n%4==0?-128.f:n%4==1?128.f:0))/128)*v.q;v.t=((24+(next()%1024)/64.f+(n%4==0?-128.f:n%4==1?128.f:0))/128)*v.q;}
  if(n&2)std::swap(b.vertices[1],b.vertices[2]);
  GSNativeProjectivePlan p;if(!GSNativeProjectivePlan::Prepare(b,p))continue;++admitted;
  oracle.ClearFramebuffer(s.context,0);oracle.Submit(b);
  for(int y=0;y<p.height;++y)for(int x=p.left[y];x<p.right[y];++x){
   const float gx=p.x+x+7.f/12,gy=p.y+y+7.f/12;auto plane=[&](unsigned k){return p.matrix[k*4]*gx+p.matrix[k*4+1]*gy+p.matrix[k*4+3];};
   const int u=GSWrapTextureCoordinate(int(std::floor(plane(0)/plane(2)*128)),128,s.context.clamp&3,0,0);
   const int v=GSWrapTextureCoordinate(int(std::floor(plane(1)/plane(2)*128)),128,(s.context.clamp>>2)&3,0,0);
   if(oracle.ReadVram(0,128*32,1,p.x+x,p.y+y)!=(0x80000000|unsigned(u)|(unsigned(v)<<8)))throw std::runtime_error("projective matrix differs from canonical triangle");++pixels;
  }
 }
 std::printf("admitted=%u compared_pixels=%u\n",admitted,pixels);
 if(admitted<32)throw std::runtime_error("too few actual perspective plans admitted");
 std::puts("PASS: projective GX point matrices match canonical STQ triangles, reversed winding/scissor/scan masks");return 0;
}catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
