#include "runtime/gs/gs_hybrid_backend.h"
#include "runtime/gs/gs_cpu_backend.h"
#include <cstdio>
#include <stdexcept>
#include <vector>

static void check(bool condition, const char *message)
{
    if (!condition) throw std::runtime_error(message);
}
// Test double, NOT a GPU implementation. Defer real software draws until the
// coordinator resolves ownership. This tests ordering/equality, never GX speed.
class DeferredDriver final : public GSNativeDrawDriver
{
public:
    GSCpuBackend executor;
    std::vector<GSPrimitiveBatch> queue;
    uint8_t *bound = nullptr;
    unsigned resolves = 0, invalidations = 0, cluts = 0, flushes = 0, resets = 0;
    bool available = true, failResolve = false, failSubmit = false, failInvalidate = false;
    const GSRasterBackend *sharedCache = nullptr;
    bool throwPreparation = false, allowPreparation = false;
    mutable unsigned preparations = 0;
    bool SharesTextureCacheWith(const GSRasterBackend *cache) const noexcept override { return cache==sharedCache; }
    bool CanPrepareTextureWithoutResolve(const GSPrimitiveBatch &) const override {
        ++preparations;
        if(throwPreparation)throw std::runtime_error("injected preparation exception");
        return allowPreparation;
    }
    bool resolveBefore = false, throwResolveDecision = false;
    mutable unsigned resolveDecisions = 0;
    bool NeedsResolveBeforeSubmit(const GSPrimitiveBatch &) const override {
        ++resolveDecisions;
        if(throwResolveDecision)throw std::runtime_error("injected owner query failure");
        return resolveBefore;
    }
    bool metadataOnly = false;
    bool throwSubmit = false;
    bool throwInitialize = false;
    unsigned *shutdownCounter = nullptr;
    bool Initialize(uint8_t *vram, uint32_t size) override
    {
        if (!available) return false;
        bound = vram;
        if (throwInitialize) throw std::runtime_error("injected initialization failure");
        executor.Initialize(vram, size); return true;
    }
    Result TrySubmit(const GSPrimitiveBatch &batch) override
    {
        if (resolveBefore&&!queue.empty())throw std::runtime_error("old owner was not resolved before native preparation");
        if (metadataOnly) return Result::MetadataOnly;
        if (throwSubmit) throw std::runtime_error("injected driver exception");
        if (failSubmit) return Result::Fault;
        if (batch.state.prim.tme || batch.state.prim.type != GS_PRIM_SPRITE)
            return Result::Unsupported;
        queue.push_back(batch); return Result::Submitted;
    }
    bool Resolve() override
    {
        ++resolves;
        if (failResolve) return false;
        for (const auto &batch : queue) executor.Submit(batch);
        queue.clear(); return true;
    }
    bool CpuWroteVram() override { ++invalidations; executor.TextureFlush(); return !failInvalidate; }
    bool LoadClut(const GSTex0Reg &t, const GSTexClutReg &c) override
    { ++cluts; executor.LoadClut(t,c); return true; }
    bool TextureFlush() override { executor.TextureFlush(); return true; }
    bool Flush() override { ++flushes; return true; }
    bool Reset() override { ++resets; executor.Reset(); return true; }
    bool Shutdown() noexcept override { if(shutdownCounter)++*shutdownCounter;queue.clear(); bound = nullptr; return true; }
};
static constexpr uint32_t Size = 4u * 1024u * 1024u;
struct Fixture
{
    std::vector<uint8_t> actual = std::vector<uint8_t>(Size);
    std::vector<uint8_t> expected = std::vector<uint8_t>(Size);
    GSCpuBackend oracle;
    DeferredDriver *driver;
    GSHybridBackend hybrid;
    explicit Fixture(bool enabled = true)
      : driver(new DeferredDriver),
        hybrid(std::make_unique<GSCpuBackend>(), std::unique_ptr<DeferredDriver>(driver))
    {
        driver->available = enabled;
        hybrid.Initialize(actual.data(), Size); oracle.Initialize(expected.data(), Size);
    }
    void equal()
    {
        std::vector<uint8_t> snapshot; hybrid.SnapshotVram(snapshot);
        if(snapshot != expected || actual != expected) { for(size_t i=0;i<expected.size();++i) if(snapshot[i]!=expected[i]) { std::fprintf(stderr,"VRAM offset=%zu actual=%u oracle=%u\n",i,snapshot[i],expected[i]);break;} throw std::runtime_error("full VRAM mismatch"); }
    }
};
static GSPrimitiveBatch sprite(uint32_t rgba, uint32_t page = 0)
{
    GSPrimitiveBatch b; b.vertexCount = 2; b.state.prim.type = GS_PRIM_SPRITE;
    b.state.context.frame = {page,1,GS_PSM_CT32,0};
    b.state.context.scissor = {0,63,0,63}; b.state.context.zbuf.zmask = true;
    b.state.context.test = uint64_t(1) << 17; b.state.colclamp = 1;
    b.vertices[1].x = 4; b.vertices[1].y = 4;
    for (auto &v : b.vertices) { v.r=rgba;v.g=rgba>>8;v.b=rgba>>16;v.a=rgba>>24; }
    return b;
}
static GSPrimitiveBatch textured()
{
    auto b=sprite(0x80808080,1); b.state.prim.tme=true; b.state.prim.fst=true;
    b.state.context.tex0={0,1,GS_PSM_CT32,2,2,1,1,0,0,0,0,0};
    b.state.textureWidth=4;b.state.textureHeight=4;
    b.vertices[1].u=64;b.vertices[1].v=64; return b;
}
static void deferredAndFallback()
{
    Fixture f;check(f.driver->bound==f.actual.data(),"native must share external VRAM");
    auto a=sprite(0x80112233),b=sprite(0x80776655),c=textured();
    f.hybrid.Submit(a);f.oracle.Submit(a);f.hybrid.Submit(b);f.oracle.Submit(b);
    check(f.actual != f.expected,"accepted draw was mirrored eagerly on CPU");
    check(f.driver->queue.size()==2,"native batching lost");
    f.hybrid.Flush();check(f.driver->resolves==0,"flush forced unnecessary readback");
    f.hybrid.Submit(c);f.oracle.Submit(c);f.equal();
    auto counts=f.hybrid.GetCounters();
    check(counts.nativeDraws==2&&counts.softwareDraws==1&&counts.resolves==1,"draw routing counts wrong");
    check(f.hybrid.ReadVram(0,32,1,0,0)==f.oracle.ReadVram(0,32,1,0,0),"fallback texture differs");
}
static void metadataPreservesOwnership()
{
    Fixture f;auto b=sprite(0x80112233);f.hybrid.Submit(b);f.oracle.Submit(b);
    f.driver->metadataOnly=true;f.hybrid.Submit(b);
    check(f.driver->resolves==0&&f.driver->queue.size()==1,"metadata-only work resolved/lost GPU RGB");
    auto c=f.hybrid.GetCounters();check(c.nativeDraws==1&&c.metadataDraws==1&&c.softwareDraws==0,"metadata-only counts wrong");
    f.driver->metadataOnly=false;f.equal();
}
static void staleTextureCache()
{
    Fixture f;auto sample=textured();
    for(unsigned y=0;y<4;++y)for(unsigned x=0;x<4;++x){f.hybrid.WriteVram(0,0,1,x,y,0x80ff0000);f.oracle.WriteVram(0,0,1,x,y,0x80ff0000);}
    f.hybrid.Submit(sample);f.oracle.Submit(sample); // Prime CPU decoded cache.
    auto red=sprite(0x800000ff);f.hybrid.Submit(red);f.oracle.Submit(red);
    f.hybrid.Submit(sample);f.oracle.Submit(sample);f.equal();
    check(f.hybrid.ReadVram(0,32,1,0,0)==0x80ff0000,"ownership change incorrectly flushed guest texels");
    f.hybrid.TextureFlush();f.oracle.TextureFlush();
    f.hybrid.Submit(sample);f.oracle.Submit(sample);f.equal();
    check(f.hybrid.ReadVram(0,32,1,0,0)==0x800000ff,"guest TEXFLUSH did not expose native render result");
}
static void cpuAccessAndTransfers()
{
    Fixture f;auto b=sprite(0x80123456);f.hybrid.Submit(b);f.oracle.Submit(b);
    check(f.hybrid.ReadVram(0,0,1,0,0)==0x80123456,"read did not resolve");
    f.hybrid.Sync(GSSyncReason::DebugReadback);check(f.driver->resolves==1,"redundant resolve");
    f.hybrid.Submit(b);f.oracle.Submit(b);
    f.hybrid.WriteVram(0,0,1,0,0,0x80abcdef);f.oracle.WriteVram(0,0,1,0,0,0x80abcdef);
    GSTransferCommand transfer;transfer.direction=0;transfer.bitbltbuf.dbp=32;
    transfer.bitbltbuf.dbw=1;transfer.trxreg={2,2};
    f.hybrid.BeginTransfer(transfer);f.oracle.BeginTransfer(transfer);
    uint32_t pixels[]={0x80110000,0x80220000,0x80330000,0x80440000};
    f.hybrid.UploadImage(reinterpret_cast<uint8_t*>(pixels),sizeof pixels);
    f.oracle.UploadImage(reinterpret_cast<uint8_t*>(pixels),sizeof pixels);f.equal();
    transfer.direction=2;transfer.bitbltbuf.sbp=32;transfer.bitbltbuf.sbw=1;transfer.bitbltbuf.dbp=64;
    f.hybrid.BeginTransfer(transfer);f.oracle.BeginTransfer(transfer);f.equal();
    transfer.direction=1;transfer.bitbltbuf.sbp=64;
    f.hybrid.BeginTransfer(transfer);f.oracle.BeginTransfer(transfer);
    uint8_t a[32]{},e[32]{};auto an=f.hybrid.ConsumeLocalToHostBytes(a,sizeof a),en=f.oracle.ConsumeLocalToHostBytes(e,sizeof e);
    check(an==en&&std::vector<uint8_t>(a,a+an)==std::vector<uint8_t>(e,e+en),"transfer readback differs");
    check(f.hybrid.GetTransferSnapshot().direction==f.oracle.GetTransferSnapshot().direction,"transfer metadata differs");
    f.hybrid.LoadClut({},{});check(f.driver->cluts==1,"CLUT state not forwarded");
    f.hybrid.TextureFlush();f.hybrid.Reset();f.oracle.Reset();f.equal();
}
static void cleanFallbackAndRebinding()
{
    Fixture f(false);auto a=sprite(0x80112233);f.hybrid.Submit(a);f.oracle.Submit(a);f.equal();
    check(f.hybrid.GetCounters().nativeDraws==0,"unavailable native driver used");
    Fixture bound;bound.hybrid.Submit(a);bound.oracle.Submit(a);
    std::vector<uint8_t> replacement(Size);bound.hybrid.Initialize(replacement.data(),Size);
    check(bound.actual==bound.expected,"rebind abandoned old GPU result");
    check(bound.driver->bound==replacement.data(),"rebind retained old VRAM");
    // Destroy the backend before replacement's storage goes out of scope.
    bound.hybrid.Initialize(bound.actual.data(),Size);
}
static void faultsRemainTerminal()
{
    Fixture f;auto b=sprite(0x80123456);f.hybrid.Submit(b);f.driver->failResolve=true;
    bool failed=false;try{f.hybrid.WriteVram(0,0,1,0,0,42);}catch(const std::runtime_error&){failed=true;}
    check(failed,"failed fence treated as successful fallback");
    check(f.actual==std::vector<uint8_t>(Size),"CPU wrote after failed GPU resolve");
    f.driver->failResolve=false;failed=false;
    try{f.hybrid.Submit(b);}catch(const std::runtime_error&){failed=true;}
    check(failed&&f.hybrid.GetCounters().softwareDraws==0,"fault silently recovered with stale state");
    Fixture s;s.driver->failSubmit=true;failed=false;
    try{s.hybrid.Submit(b);}catch(const std::runtime_error&){failed=true;}
    check(failed&&s.hybrid.GetCounters().softwareDraws==0,"partial native submission fell back");
    Fixture w;w.driver->failInvalidate=true;failed=false;
    try{w.hybrid.WriteVram(0,0,1,0,0,1);}catch(const std::runtime_error&){failed=true;}
    check(failed,"native invalidation failure ignored");
    Fixture t;t.driver->throwSubmit=true;failed=false;
    try{t.hybrid.Submit(b);}catch(const std::runtime_error&){failed=true;}
    check(failed,"driver exception ignored");t.driver->throwSubmit=false;failed=false;
    try{t.hybrid.Submit(b);}catch(const std::runtime_error&){failed=true;}
    check(failed,"driver exception did not retain terminal fault state");
    unsigned shutdowns=0;
    {
        auto driver=std::make_unique<DeferredDriver>();driver->throwInitialize=true;driver->shutdownCounter=&shutdowns;
        std::vector<uint8_t> vram(Size);
        GSHybridBackend backend(std::make_unique<GSCpuBackend>(),std::move(driver));
        failed=false;try{backend.Initialize(vram.data(),Size);}catch(const std::runtime_error&){failed=true;}
        check(failed,"initialization exception ignored");
    }
    check(shutdowns==1,"partial native initialization leaked external VRAM references");
}
static void cachedPreparationContract()
{
    for(unsigned mode=0;mode<3;++mode){
        std::vector<uint8_t> actual(Size),expected(Size);GSCpuBackend oracle;oracle.Initialize(expected.data(),Size);
        auto software=std::make_unique<GSCpuBackend>();auto *canonical=software.get();
        auto owned=std::make_unique<DeferredDriver>();auto *driver=owned.get();
        driver->sharedCache=canonical;driver->allowPreparation=mode==1;driver->throwPreparation=mode==2;
        GSHybridBackend hybrid(std::move(software),std::move(owned));hybrid.Initialize(actual.data(),Size);
        auto plain=sprite(0x80123456),texture=textured();hybrid.Submit(plain);oracle.Submit(plain);
        bool failed=false;try{hybrid.Submit(texture);}catch(const std::runtime_error&){failed=true;}
        check(driver->preparations==1,"pending texture bypassed preparation contract");
        if(mode==2){
            check(failed,"preparation exception ignored");
            failed=false;try{hybrid.Sync(GSSyncReason::DebugReadback);}catch(const std::runtime_error&){failed=true;}
            check(failed,"preparation exception was not terminal");
            continue;
        }
        check(!failed&&driver->resolves==1,"unsupported prepared texture did not resolve before fallback");
        oracle.Submit(texture);std::vector<uint8_t> snapshot;hybrid.SnapshotVram(snapshot);
        check(snapshot==expected,"prepared fallback differs from oracle");
    }
}
static void auxiliaryOwnerBoundary()
{
    {Fixture f;f.driver->resolveBefore=true;auto a=sprite(0x80112233),b=sprite(0x80556677);
     f.hybrid.Submit(a);f.oracle.Submit(a);check(f.driver->resolveDecisions==0,"empty owner queried");
     f.hybrid.Submit(b);f.oracle.Submit(b);
     check(f.driver->resolves==1&&f.driver->queue.size()==1,"auxiliary owner did not materialize before the next native draw");
     const auto c=f.hybrid.GetCounters();check(c.nativeDraws==2&&c.softwareDraws==0,"owner boundary incorrectly forced software fallback");f.equal();}
    {Fixture f;auto b=sprite(0x80112233);f.hybrid.Submit(b);f.driver->throwResolveDecision=true;
     bool failed=false;try{f.hybrid.Submit(b);}catch(const std::runtime_error&){failed=true;}
     check(failed&&f.driver->queue.size()==1,"owner query failure replayed a draw");
     failed=false;try{f.hybrid.Flush();}catch(const std::runtime_error&){failed=true;}check(failed,"owner query failure was not terminal");}
}
static void mixedDrawsClearAndPresent()
{
    Fixture f;uint32_t random=0x193ad17u;
    auto next=[&](){random=random*1664525u+1013904223u;return random;};
    for(unsigned i=0;i<256;++i)
    {
        auto b=(i%3==0)?textured():sprite(next(),i%2);
        b.state.prim.abe=(next()&1)!=0;
        b.state.context.alpha=uint64_t(0x44)|(uint64_t(next()&255)<<32);
        b.state.context.frame.fbmsk=(i%5==0)?next():0;
        b.state.context.test=(uint64_t(1+(next()%3))<<17)|(i%7==0?1:0);
        b.state.context.zbuf={128,GS_PSM_Z24,(i%2)!=0};
        b.vertices[1].z=next()&0xffffff;
        f.hybrid.Submit(b);f.oracle.Submit(b);
        if(i%17==0)f.equal();
    }
    auto b=sprite(0x803412ab);f.hybrid.Submit(b);f.oracle.Submit(b);
    check(f.hybrid.ClearFramebuffer(b.state.context,0x80556677)==
          f.oracle.ClearFramebuffer(b.state.context,0x80556677),"clear return differs");
    f.equal();
    f.hybrid.Submit(b);f.oracle.Submit(b);
    GSPresentationRequest request;request.contextFrames[0]=b.state.context.frame;
    auto actual=f.hybrid.Present(request),expected=f.oracle.Present(request);
    check(bool(actual)==bool(expected)&&actual.width==expected.width&&actual.height==expected.height&&
          actual.pixels==expected.pixels,"CPU presentation boundary differs");
    f.equal();
}
int main()
{
    try{auxiliaryOwnerBoundary();cachedPreparationContract();std::puts("deferredAndFallback");deferredAndFallback(); metadataPreservesOwnership();std::puts("staleTextureCache");staleTextureCache();std::puts("cpuAccessAndTransfers");cpuAccessAndTransfers();std::puts("cleanFallbackAndRebinding");cleanFallbackAndRebinding();std::puts("faultsRemainTerminal");faultsRemainTerminal();std::puts("mixedDrawsClearAndPresent");mixedDrawsClearAndPresent();
        std::puts("PASS: shared VRAM, deferred native draws, CPU fallback, caches, transfers, rebinding and terminal faults");return 0;}
    catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}
}
