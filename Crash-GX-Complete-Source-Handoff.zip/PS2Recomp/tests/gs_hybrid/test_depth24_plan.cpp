// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_native_depth24_plan.h"
#include "runtime/gs/gs_native_depth24_ledger.h"
#include "runtime/gs/gs_cpu_backend.h"
#include <array>
#include <cstdio>
#include <cstdlib>
#include <memory>
static void Check(bool b){if(!b)std::abort();}
int main(){
 constexpr unsigned W=64,H=64,Size=4*1024*1024;
 auto memory=std::make_unique<uint8_t[]>(Size);GSCpuBackend reference;
 std::array<uint32_t,W*H> finalZ{};std::array<uint8_t,W*H> alpha{},done{};
 unsigned seed=0x2415900,samples=0;auto next=[&]{seed=seed*1664525u+1013904223u;return seed;};
 const int originalRounding=std::fegetround();
 for(unsigned test=0;test<64;++test){
  Check(std::fesetround(FE_TONEAREST)==0);
  std::fill_n(memory.get(),Size,uint8_t(0x5a));reference.Initialize(memory.get(),Size);
  for(unsigned y=0;y<H;++y)for(unsigned x=0;x<W;++x){const unsigned k=y*W+x;finalZ[k]=next()%300000;alpha[k]=next()&255;done[k]=0;
   reference.WriteVram(GS_PSM_Z24,192*32,1,x,y,finalZ[k]);reference.WriteVram(GS_PSM_CT32,64*32,1,x,y,uint32_t(alpha[k])<<24);}
  const unsigned textureAlpha=(test*13)&255;
  for(unsigned y=0;y<4;++y)for(unsigned x=0;x<4;++x)reference.WriteVram(GS_PSM_CT32,0,1,x,y,(textureAlpha<<24)|0x808080);
  std::array<GSPrimitiveBatch,16> ledger{};auto owner=std::make_unique<GSNativeDepth24Ledger>();
  for(unsigned d=0;d<ledger.size();++d){Check(std::fesetround(d%2?FE_TOWARDZERO:FE_TONEAREST)==0);auto &b=ledger[d];b.vertexCount=3;auto &s=b.state;
   s.prim.tme=test&2;
   if(s.prim.tme){s.linearFilter=true;s.textureWidth=s.textureHeight=4;auto &t=s.context.tex0;t.tbw=1;t.psm=GS_PSM_CT32;t.tw=t.th=2;t.tcc=1;t.tfx=(test/4)%4;}
   s.prim.type=GS_PRIM_TRIANGLE;s.prim.iip=test&1;s.colclamp=1;s.context.frame={64,1,GS_PSM_CT32,0};
   s.context.zbuf={192,GS_PSM_Z24,false};s.context.scissor={0,63,0,63};s.context.test=uint64_t(2)<<17;s.context.fba=(test+d)%2;
   for(unsigned i=0;i<3;++i){auto &v=b.vertices[i];v.x=2+(next()%56)+(test%16)/16.f;v.y=2+(next()%56)+(d%16)/16.f;
    v.z=next()%500000;v.a=next()&255;v.q=1;}
   // Coplanar duplicates with different alpha exercise GEQUAL last-writer ties.
   if(d%4==3){for(unsigned i=0;i<3;++i){b.vertices[i].x=ledger[d-1].vertices[i].x;b.vertices[i].y=ledger[d-1].vertices[i].y;b.vertices[i].z=ledger[d-1].vertices[i].z;}}
   GSNativeLinearPlan p;if(!GSNativeLinearPlan::Prepare(b,p)){b=ledger[0];if(!GSNativeLinearPlan::Prepare(b,p))continue;}
   float xy[6];Check(GSNativeDepth24Plan::Prepare(b,xy));
   Check(owner->Append(b,true,textureAlpha));reference.Submit(b);
   // Model the GPU's already-validated exact canonical-Z GEQUAL writes.
   for(int y=0;y<p.height;++y)for(unsigned x=p.left[y];x<p.right[y];++x){const unsigned k=(p.y+y)*W+p.x+x;finalZ[k]=std::max(finalZ[k],GSNativeDepth24Plan::Depth(b,p,x,y));}
  }
  Check(std::fesetround(FE_UPWARD)==0);
  Check(owner->BeginResolve());
  Check(owner->ReplayBand(0,0,W,H,[&](unsigned x,unsigned y){return !done[y*W+x];},
   [&](unsigned x,unsigned y){return finalZ[y*W+x];},
   [&](unsigned x,unsigned y,uint8_t a){const unsigned k=y*W+x;alpha[k]=a;done[k]=1;}));
  Check(std::fegetround()==FE_UPWARD);
  Check(owner->EndResolve(true));Check(!owner->Pending());
  for(unsigned y=0;y<H;++y)for(unsigned x=0;x<W;++x){const unsigned k=y*W+x;
   Check(reference.ReadVram(GS_PSM_Z24,192*32,1,x,y)==finalZ[k]);
   Check(reference.ReadVram(GS_PSM_CT32,64*32,1,x,y)>>24==alpha[k]);++samples;}
 }
 Check(std::fesetround(originalRounding)==0);
 // Queue bounds, target changes, source ownership and fault lifecycle.
 GSPrimitiveBatch b;b.vertexCount=3;b.state.prim.type=GS_PRIM_TRIANGLE;b.state.colclamp=1;
 b.state.context.frame={64,1,GS_PSM_CT32,0};b.state.context.zbuf={192,GS_PSM_Z24,false};b.state.context.test=uint64_t(2)<<17;b.state.context.scissor={0,63,0,63};
 b.vertices[0].x=b.vertices[0].y=4;b.vertices[1].x=36;b.vertices[1].y=4;b.vertices[2].x=4;b.vertices[2].y=36;
 auto owner=std::make_unique<GSNativeDepth24Ledger>();
 for(unsigned i=0;i<GSNativeDepth24Ledger::Capacity;++i)Check(owner->Append(b,true,0));
 Check(!owner->Append(b,true,0));Check(owner->Size()==128);
 Check(!owner->SourceDisjoint(192*8192,192*8192+4));Check(owner->SourceDisjoint(0,1024));
 Check(owner->BeginResolve());Check(!owner->CanAppend(b,true));Check(!owner->EndResolve(false));Check(owner->Faulted());Check(!owner->BeginResolve());
 auto target=std::make_unique<GSNativeDepth24Ledger>();Check(target->Append(b,true,0));
 b.state.context.frame.psm=GS_PSM_CT24;Check(!target->CanAppend(b,true));
 b.state.context.frame.psm=GS_PSM_CT32;b.state.context.zbuf.zbp=193;Check(!target->CanAppend(b,true));
 b.state.context.zbuf.zbp=192;
 auto empty=std::make_unique<GSNativeDepth24Ledger>();Check(empty->CanAppend(b,true));
 b.state.prim.tme=true;b.state.context.tex0.tcc=1;Check(!empty->CanAppend(b,false));
 b.state.prim.tme=false;b.state.context.test=uint64_t(3)<<17;Check(!empty->CanAppend(b,true));
 b.state.context.test=uint64_t(2)<<17;b.state.context.zbuf.zmask=true;Check(!empty->CanAppend(b,true));
 b.state.context.zbuf.zmask=false;b.state.context.zbuf.zbp=64;Check(!empty->CanAppend(b,true));
 b.state.context.zbuf.zbp=192;b.state.context.scissor.x1=127;b.vertices[1].x=100;Check(!empty->CanAppend(b,true));
 Check(!empty->ReplayBand(0,0,1,1,[](unsigned,unsigned){return true;},[](unsigned,unsigned){return 0u;},[](unsigned,unsigned,uint8_t){std::abort();}));
 std::printf("Z24 reverse alpha replay: %u independent reference pixels passed; metadata bytes=%zu\n",samples,sizeof(GSNativeDepth24Ledger));
}
