// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_cpu_backend.h"
#include <algorithm>
#include <cstdio>
#include <stdexcept>
#include <vector>
static void Check(bool value,const char *message){if(!value)throw std::runtime_error(message);}
static GSDrawState State(unsigned psm,unsigned tw=2,unsigned th=2)
{
    GSDrawState s;s.prim.tme=true;s.prim.fst=true;
    s.context.tex0.psm=psm;s.context.tex0.tw=tw;s.context.tex0.th=th;
    s.context.tex0.tbw=(psm==GS_PSM_T8||psm==GS_PSM_T4)?2:1;
    s.textureWidth=1u<<tw;s.textureHeight=1u<<th;s.texa.ta0=0x44;s.texa.ta1=0xa0;
    return s;
}
static void DirectFormats()
{
    std::vector<uint8_t> vram(4*1024*1024);GSCpuBackend backend;backend.Initialize(vram.data(),vram.size());
    for(unsigned psm:{GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S})
    {
        backend.Reset();auto s=State(psm);uint32_t raw=psm==GS_PSM_CT32?0x80123456:psm==GS_PSM_CT24?0x00123456:0x801f;
        for(unsigned y=0;y<4;++y)for(unsigned x=0;x<4;++x)backend.WriteVram(psm,0,1,x,y,raw);
        std::vector<uint32_t> pixels;Check(backend.DecodeNativeTexturePage(s,pixels),"direct decode rejected");
        uint32_t expected=psm==GS_PSM_CT32?raw:psm==GS_PSM_CT24?0x44123456:0xa00000f8;
        Check(pixels==std::vector<uint32_t>(16,expected),"TEXA or 16-bit expansion differs");
    }
}
static void CacheLifetimeAndRejection()
{
    std::vector<uint8_t> vram(4*1024*1024);GSCpuBackend backend;backend.Initialize(vram.data(),vram.size());
    auto s=State(GS_PSM_CT32);backend.WriteVram(0,0,1,0,0,0x800000ff);
    std::vector<uint32_t> pixels;Check(backend.DecodeNativeTexturePage(s,pixels),"initial decode failed");
    Check(backend.CanDecodeNativeTexturePageWithoutVramRead(s),"latched page not recognized");
    GSCpuBackend::NativeTextureStamp before,after;
    Check(backend.GetNativeTextureStamp(s,before),"resident stamp missing");
    backend.WriteVram(0,0,1,0,0,0x8000ff00);
    Check(backend.CanDecodeNativeTexturePageWithoutVramRead(s),"ordinary write changed latched-page proof");
    Check(backend.GetNativeTextureStamp(s,after)&&before.texels==after.texels&&before.clut==after.clut,"ordinary write changed canonical stamp");
    auto other=s;other.context.tex0.tbp0=32;
    Check(!backend.CanDecodeNativeTexturePageWithoutVramRead(other),"uncached page admitted without resolve");
    auto invalid=s;invalid.context.tex0.tbp0=1;
    Check(!backend.CanDecodeNativeTexturePageWithoutVramRead(invalid),"unaligned page admitted");
    auto bad=s;bad.context.tex0.tbp0=1;std::vector<uint32_t> sentinel{0xdeadbeef};
    Check(!backend.DecodeNativeTexturePage(bad,sentinel)&&sentinel==std::vector<uint32_t>{0xdeadbeef},"rejection modified output");
    bad=s;bad.context.clamp=2;Check(!backend.DecodeNativeTexturePage(bad,sentinel),"region clamp accepted");
    bad=s;bad.textureHeight=64;bad.context.tex0.th=6;Check(!backend.DecodeNativeTexturePage(bad,sentinel),"multi-page CT32 accepted");
    Check(backend.DecodeNativeTexturePage(s,pixels)&&pixels[0]==0x800000ff,"decode or rejected call evicted guest texels");
    backend.TextureFlush();Check(!backend.CanDecodeNativeTexturePageWithoutVramRead(s),"TEXFLUSH retained no-read proof");Check(backend.DecodeNativeTexturePage(s,pixels)&&pixels[0]==0x8000ff00,"TEXFLUSH did not refresh native texels");
    Check(backend.DecodeNativeTexturePage(other,pixels),"second page decode failed");
    Check(!backend.CanDecodeNativeTexturePageWithoutVramRead(s),"evicted page kept no-read permission");
    Check(backend.CanDecodeNativeTexturePageWithoutVramRead(other),"new resident page lost permission");
    backend.Reset();Check(!backend.CanDecodeNativeTexturePageWithoutVramRead(other),"reset retained no-read permission");
    backend.Initialize(nullptr,0);Check(!backend.CanDecodeNativeTexturePageWithoutVramRead(other),"unbound backend admitted decode");
}
static void IndexedFormats()
{
    std::vector<uint8_t> vram(4*1024*1024);GSCpuBackend backend;backend.Initialize(vram.data(),vram.size());
    for(unsigned psm:{GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH})
    {
        backend.Reset();auto s=State(psm);s.context.tex0.csm=1;s.context.tex0.cbp=128;
        s.context.tex0.cpsm=GS_PSM_CT32;s.context.tex0.cld=1;GSTexClutReg clut;clut.cbw=1;
        const unsigned entries=(psm==GS_PSM_T4||psm==GS_PSM_T4HL||psm==GS_PSM_T4HH)?16:256;
        for(unsigned i=0;i<entries;++i)backend.WriteVram(0,128,1,i,0,0x80000000|(i*0x010101));
        for(unsigned y=0;y<4;++y)for(unsigned x=0;x<4;++x)backend.WriteVram(psm,0,s.context.tex0.tbw,x,y,x+y*4);
        backend.LoadClut(s.context.tex0,clut);std::vector<uint32_t> pixels;
        Check(backend.DecodeNativeTexturePage(s,pixels),"indexed decode rejected");
        for(unsigned i=0;i<16;++i)Check(pixels[i]==(0x80000000|(i*0x010101)),"native CLUT lookup differs");
        auto bad=s;bad.context.tex0.cpsm=63;std::vector<uint32_t> sentinel{0xdeadbeef};
        Check(!backend.DecodeNativeTexturePage(bad,sentinel)&&sentinel==std::vector<uint32_t>{0xdeadbeef},"unsupported palette format accepted or changed output");
        backend.WriteVram(0,128,1,0,0,0x800000ff);backend.TextureFlush();
        Check(backend.DecodeNativeTexturePage(s,pixels)&&pixels[0]==0x80000000,"TEXFLUSH incorrectly reloaded CLUT");
        GSCpuBackend::NativeTextureStamp before,after;Check(backend.GetNativeTextureStamp(s,before),"palette pre-reload stamp missing");
        backend.LoadClut(s.context.tex0,clut);
        Check(backend.DecodeNativeTexturePage(s,pixels)&&backend.GetNativeTextureStamp(s,after)&&before.clut!=after.clut,"palette reload did not change stamp");
        Check(backend.DecodeNativeTexturePage(s,pixels)&&pixels[0]==0x800000ff,"explicit CLUT load not visible");
    }
}
static void MaximumPageLifetime()
{
    std::vector<uint8_t> vram(4*1024*1024);GSCpuBackend backend;backend.Initialize(vram.data(),vram.size());
    for(unsigned psm:{GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH})
    {
        backend.Reset();unsigned tw=(psm==GS_PSM_T8||psm==GS_PSM_T4)?7:6;
        unsigned th=psm==GS_PSM_T4?7:(psm==GS_PSM_T8||psm==GS_PSM_CT16||psm==GS_PSM_CT16S)?6:5;
        auto s=State(psm,tw,th);s.context.tex0.cbp=128;s.context.tex0.cpsm=GS_PSM_CT32;s.context.tex0.csm=1;s.context.tex0.cld=1;
        bool indexed=psm==GS_PSM_T8||psm==GS_PSM_T4||psm==GS_PSM_T8H||psm==GS_PSM_T4HL||psm==GS_PSM_T4HH;
        unsigned raw=indexed?1:psm==GS_PSM_CT16||psm==GS_PSM_CT16S?0x801f:0x80123456;
        for(unsigned i=0;i<256;++i)backend.WriteVram(0,128,1,i,0,0x80000000|i);
        for(unsigned y=0;y<s.textureHeight;++y)for(unsigned x=0;x<s.textureWidth;++x)backend.WriteVram(psm,0,s.context.tex0.tbw,x,y,raw);
        GSTexClutReg clut;clut.cbw=1;backend.LoadClut(s.context.tex0,clut);
        std::vector<uint32_t> pixels;Check(backend.DecodeNativeTexturePage(s,pixels),"maximum page rejected");
        auto first=pixels[0];uint32_t expected=indexed?0x80000001:psm==GS_PSM_CT32?0x80123456:psm==GS_PSM_CT24?0x44123456:0xa00000f8;
        Check(first==expected&&std::all_of(pixels.begin(),pixels.end(),[&](auto pixel){return pixel==expected;}),"maximum page decode incomplete");
        backend.WriteVram(psm,0,s.context.tex0.tbw,0,0,indexed?2:0x83e0);
        Check(backend.DecodeNativeTexturePage(s,pixels)&&pixels[0]==first,"maximum decode crossed/evicted physical page");
        Check(backend.DecodeNativeTexturePage(s,pixels)&&pixels[0]==first,"maximum decode transiently evicted/reloaded source page");
        backend.TextureFlush();Check(backend.DecodeNativeTexturePage(s,pixels)&&pixels[0]!=first,"maximum page TEXFLUSH failed");
    }
}
int main()
{
    try{DirectFormats();CacheLifetimeAndRejection();IndexedFormats();MaximumPageLifetime();std::puts("PASS: canonical native texture decode, maximum pages, TEXA, palette retention and TEXFLUSH");return 0;}
    catch(const std::exception &e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}
}
