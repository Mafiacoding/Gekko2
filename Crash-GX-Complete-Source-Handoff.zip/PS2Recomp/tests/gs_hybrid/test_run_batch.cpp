// SPDX-License-Identifier: GPL-3.0-or-later
#include "ps2_wii_gx_run_batch.h"
#include <algorithm>
#include <cstdio>
#include <stdexcept>
#include <vector>
static void check(bool ok,const char*why){if(!ok)throw std::runtime_error(why);}
static void shade(std::vector<unsigned>&image,const ps2x_gx_run&r){
 check(r.left<r.right&&r.right<=64&&r.top<r.bottom&&r.bottom<=480,"invalid emitted rectangle");
 for(unsigned y=r.top;y<r.bottom;++y)for(unsigned x=r.left;x<r.right;++x){
  unsigned &d=image[y*64+x],s=(x*7+y*13)&255;
  d=r.blend==3?std::min(255u,d+s):r.blend?((128-r.factor)*d+r.factor*s)>>7:s;
 }
}
int main(){try{
 uint32_t random=0x7505900;auto next=[&]{random=random*1664525u+1013904223u;return random;};
 unsigned long long logical=0,draws=0;unsigned joined=0;
 for(unsigned trial=0;trial<1024;++trial){
  std::vector<unsigned> expected(64*480,90),actual(expected);ps2x_gx_run_batch batch{};ps2x_gx_run emit;
  for(unsigned i=0;i<640;++i){
   const unsigned y=i%480,l=trial==0?4:next()%32;
   ps2x_gx_run r{l,trial==0?28:l+1+next()%(64-l),y,y+1,trial==0?2:next()%4,trial==0?64:next()%129};
   // Include long compatible runs, row gaps, holes, coefficient changes and
   // repeated visits to earlier pixels. Metadata differs independently of RGB.
   if(trial%4==0){r.left=4;r.right=28;r.blend=2;r.factor=64;}
   shade(expected,r);++logical;
   const int had=batch.valid;
   if(ps2x_gx_run_offer(&batch,&r,&emit)){shade(actual,emit);++draws;}
   else if(had)++joined;
   if((i+1)%256==0&&ps2x_gx_run_drain(&batch,&emit)){shade(actual,emit);++draws;}
  }
  if(ps2x_gx_run_drain(&batch,&emit)){shade(actual,emit);++draws;}
  check(!ps2x_gx_run_drain(&batch,&emit),"empty drain emitted a draw");
  check(actual==expected,"batch changed coverage, ordering or blend factor");
 }
 check(joined>0&&draws<logical,"compatible runs were not combined");
 std::printf("PASS: 1024 synthetic streams / %llu runs -> %llu quads; exact coverage/blending and 256-run barrier drains\n",logical,draws);
 return 0;
}catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
