// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_cpu_backend.h"
#include <array>
#include <cstdio>
#include <cstring>
#include <stdexcept>
static void check(bool b,const char*w){if(!b)throw std::runtime_error(w);}
int main(){try{
 constexpr unsigned N=16,Size=4*1024*1024;std::vector<uint8_t>a(Size,0x5a),b=a;
 GSCpuBackend native,oracle;native.Initialize(a.data(),Size);oracle.Initialize(b.data(),Size);
 std::array<uint8_t,N> alpha{},actions{},stored{};std::array<uint32_t,N> z{};
 unsigned rows=0,pixels=0;
 for(unsigned zpsm:{GS_PSM_Z32,GS_PSM_Z24,GS_PSM_Z16,GS_PSM_Z16S})for(unsigned fpsm:{GS_PSM_CT32,GS_PSM_CT24})
 for(unsigned atst=0;atst<8;++atst)for(unsigned afail=0;afail<4;++afail)for(unsigned ztest=0;ztest<4;++ztest)
 for(unsigned zmask=0;zmask<2;++zmask)for(unsigned flags=0;flags<4;++flags)for(unsigned alphaMode=0;alphaMode<5;++alphaMode){
  if(alphaMode&&(ztest!=1||!zmask))continue;
  GSDrawState s;s.context.frame={64,1,uint8_t(fpsm),0};s.context.zbuf={192,uint8_t(zpsm),bool(zmask)};
  s.context.scissor={0,63,0,63};s.context.test=1|(atst<<1)|(128u<<4)|(afail<<12)|(ztest<<17);s.colclamp=1;
  s.prim.type=GS_PRIM_SPRITE;s.prim.abe=flags&1;s.pabe=flags&1;s.context.fba=(flags>>1)&1;
  s.context.alpha=(uint64_t(128)<<32)|0x68;
  for(unsigned i=0;i<N;++i){
   constexpr uint8_t edges[]={0,127,128,255};
   const uint32_t old=0x8000+i*7;alpha[i]=alphaMode?edges[alphaMode-1]:(i*17+atst*3)&255;z[i]=old+(i%3==0?uint32_t(-1):i%3==1?0:1);
   native.WriteVram(0,64*32,1,i,5,0x5a5a5a5a);oracle.WriteVram(0,64*32,1,i,5,0x5a5a5a5a);
   native.WriteVram(zpsm,192*32,1,i,5,old);oracle.WriteVram(zpsm,192*32,1,i,5,old);
  }
  GSCpuBackend::NativeDepthCounts counts;
  check(native.ProcessNativeFragmentRow(s,0,5,N,alpha.data(),z.data(),actions.data(),stored.data(),counts),"native permissions rejected");
  for(unsigned i=0;i<N;++i){
   GSPrimitiveBatch one;one.vertexCount=2;one.state=s;
   one.vertices[0].x=i;one.vertices[0].y=5;one.vertices[1].x=i+1;one.vertices[1].y=6;
   one.vertices[1].z=z[i];one.vertices[1].r=18;one.vertices[1].g=52;one.vertices[1].b=86;one.vertices[1].a=alpha[i];oracle.Submit(one);
   const uint32_t color=oracle.ReadVram(0,64*32,1,i,5);
   if(actions[i]&GSCpuBackend::NativeRgb){
    const unsigned red=actions[i]&GSCpuBackend::NativeBlend?108:18;
    check((color&255)==red,"RGB/blend permission differs from real raster");
   }else check((color&0xffffff)==0x5a5a5a,"discarded fragment changed oracle RGB");
   check((color>>24)==((actions[i]&GSCpuBackend::NativeAlpha)?stored[i]:0x5a),"alpha/FBA/RGB-only permission differs");
   check(native.ReadVram(0,64*32,1,i,5)==0x5a5a5a5a,"permission pass shaded or wrote framebuffer");
   // Remove independently verified oracle framebuffer writes. All remaining
   // VRAM, including swizzled depth stores and preserved bits, must be exact.
   oracle.WriteVram(0,64*32,1,i,5,0x5a5a5a5a);++pixels;
  }
  check(!std::memcmp(a.data(),b.data(),Size),"native depth shadow differs from canonical raster");++rows;
 }
 GSDrawState invalid;invalid.context.frame={64,1,GS_PSM_CT32,0};invalid.context.scissor={0,63,0,63};invalid.context.zbuf={192,GS_PSM_Z24,false};invalid.context.test=uint64_t(1)<<17;
 const auto before=a;actions.fill(0xcd);GSCpuBackend::NativeDepthCounts counts;
 invalid.context.test|=1u<<14;
 check(!native.ProcessNativeFragmentRow(invalid,0,5,N,alpha.data(),z.data(),actions.data(),stored.data(),counts),"DATE without framebuffer ownership accepted");
 check(a==before&&actions[0]==0xcd,"rejected permission pass mutated state/output");
 // Overlapping scratch and partial scissor retain the original scalar order.
 for(unsigned mode=0;mode<3;++mode){
  GSDrawState s=invalid;s.context.test=uint64_t(1)<<17;s.context.zbuf.zmask=true;s.context.fba=1;
  if(mode==2)s.context.scissor={3,12,0,63};
  std::array<uint8_t,64> whole{},single{};whole.fill(128);single=whole;
  const unsigned actionOffset=mode==0?8:16,storedOffset=mode==1?16:32;
  GSCpuBackend::NativeDepthCounts bulkCounts,scalarCounts;
  check(native.ProcessNativeFragmentRow(s,0,5,N,whole.data(),z.data(),whole.data()+actionOffset,whole.data()+storedOffset,bulkCounts),"bulk overlap/scissor rejected");
  for(unsigned i=0;i<N;++i)check(oracle.ProcessNativeFragmentRow(s,i,5,1,single.data()+i,z.data()+i,single.data()+actionOffset+i,single.data()+storedOffset+i,scalarCounts),"scalar overlap/scissor rejected");
  check(whole==single,"bulk classification changed scratch alias/scissor semantics");
 }
 // Depth writes must retain the GS's stale texture-page semantics. A native
 // metadata update may not silently flush a page previously sampled as texture.
 GSDrawState latched;latched.context.frame={64,1,GS_PSM_CT32,0};
 latched.context.zbuf={192,GS_PSM_Z32,false};latched.context.scissor={0,63,0,63};
 latched.context.test=uint64_t(1)<<17;latched.textureWidth=latched.textureHeight=4;
 latched.context.tex0.tbp0=192*32;latched.context.tex0.tbw=1;
 latched.context.tex0.psm=GS_PSM_Z32;latched.context.tex0.tw=latched.context.tex0.th=2;
 native.TextureFlush();native.WriteVram(GS_PSM_Z32,192*32,1,0,0,0x12345678);
 std::vector<uint32_t> texel;GSCpuBackend::NativeTextureStamp stampBefore,stampAfter;
 check(native.DecodeNativeTextureRect(latched,{0,0,1,1},texel),"cannot latch depth texture");
 const uint32_t retained=texel[0];
 check(native.GetNativeTextureRectStamp(latched,{0,0,1,1},stampBefore),"depth latch missing");
 alpha[0]=128;z[0]=0x87654321;
 check(native.ProcessNativeFragmentRow(latched,0,0,1,alpha.data(),z.data(),actions.data(),stored.data(),counts),"depth metadata update rejected");
 check(native.ReadVram(GS_PSM_Z32,192*32,1,0,0)==z[0],"depth backing store not updated");
 check(native.GetNativeTextureRectStamp(latched,{0,0,1,1},stampAfter)&&stampBefore.texels==stampAfter.texels,"metadata update changed texture revision");
 check(native.DecodeNativeTextureRect(latched,{0,0,1,1},texel)&&texel[0]==retained,"metadata update implicitly flushed retained texture");
 native.TextureFlush();
 check(native.DecodeNativeTextureRect(latched,{0,0,1,1},texel)&&texel[0]==z[0],"explicit flush did not expose new depth texture");
 std::printf("PASS: %u exact permission rows / %u real raster pixels, four Z formats, alpha/depth/PABE/FBA; no RGB writes\n",rows,pixels);return 0;
}catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
