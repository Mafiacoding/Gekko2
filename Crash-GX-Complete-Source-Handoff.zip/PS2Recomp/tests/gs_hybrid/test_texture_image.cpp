// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_cpu_backend.h"
#include <algorithm>
#include <cstdio>
#include <limits>
#include <stdexcept>
static void check(bool yes,const char *why){if(!yes)throw std::runtime_error(why);}
int main(){try{
 const unsigned formats[]={GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,GS_PSM_T8,GS_PSM_T4,GS_PSM_T8H,GS_PSM_T4HL,GS_PSM_T4HH,GS_PSM_Z32,GS_PSM_Z24,GS_PSM_Z16,GS_PSM_Z16S};
 for(unsigned psm:formats){
  std::vector<uint8_t> a(4*1024*1024),b(a.size());GSCpuBackend native,oracle;
  native.Initialize(a.data(),a.size());oracle.Initialize(b.data(),b.size());
  GSPrimitiveBatch batch;batch.vertexCount=2;auto &s=batch.state;auto &t=s.context.tex0;
  s.prim.type=GS_PRIM_SPRITE;s.prim.tme=true;s.prim.fst=true;s.colclamp=1;
  s.textureWidth=s.textureHeight=128;t.tw=t.th=7;t.psm=psm;t.tbw=2;t.tbp0=16352;
  t.tfx=1;t.tcc=1;t.cpsm=GS_PSM_CT32;t.cbp=1024;t.csm=1;t.cld=1;
  s.texa.ta0=32;s.texa.ta1=128;s.context.clamp=5;s.context.frame={256,2,GS_PSM_CT32,0};
  s.context.scissor={0,127,0,127};s.context.zbuf.zmask=true;s.context.test=uint64_t(1)<<17;
  batch.vertices[1].x=batch.vertices[1].y=128;batch.vertices[1].u=batch.vertices[1].v=128*16;
  const bool indexed=psm==GS_PSM_T8||psm==GS_PSM_T4||psm==GS_PSM_T8H||psm==GS_PSM_T4HL||psm==GS_PSM_T4HH;
  const bool small=psm==GS_PSM_CT16||psm==GS_PSM_CT16S||psm==GS_PSM_Z16||psm==GS_PSM_Z16S;
  for(unsigned y=0;y<128;++y)for(unsigned x=0;x<128;++x){
   const uint32_t raw=indexed?(x+y)%16:small?0x8000|((x&31)<<5)|(y&31):0x80000000|(x*2)|(y*2<<8)|((x+y)<<16);
   native.WriteVram(psm,t.tbp0,t.tbw,x,y,raw);oracle.WriteVram(psm,t.tbp0,t.tbw,x,y,raw);
  }
  GSTexClutReg clut;clut.cbw=1;
  for(unsigned x=0;x<256;++x){native.WriteVram(0,1024,1,x,0,0x80000000|x*0x010307);oracle.WriteVram(0,1024,1,x,0,0x80000000|x*0x010307);}
  native.LoadClut(t,clut);oracle.LoadClut(t,clut);
  std::vector<uint32_t> image;uint64_t stamp;
  check(native.GetCoherentNativeImageStamp(s,stamp),"fresh coherent source rejected");
  check(native.SnapshotCoherentNativeImage(s,image)&&image.size()==128*128,"multi-page snapshot rejected");
  GSCpuBackend::NativeTextureStamp page;
  check(!native.GetNativeTextureRectStamp(s,{0,0,1,1},page),"snapshot changed canonical latch");
  oracle.Submit(batch);
  for(unsigned y=0;y<128;++y)for(unsigned x=0;x<128;++x)
   check(image[y*128+x]==oracle.ReadVram(0,256*32,2,x,y),"coherent source differs from canonical raster");
  s.prim.fst=false;
  check(!native.CommitCoherentNativeSample(s,std::numeric_limits<float>::max(),0,1),"overflowing final sample accepted");
  check(!native.CommitCoherentNativeSample(s,0,0,std::numeric_limits<float>::quiet_NaN()),"NaN final Q accepted");
  check(!native.GetNativeTextureRectStamp(s,{0,0,1,1},page),"invalid final sample changed latch");
  const float end=127.f/128;
  check(native.CommitCoherentNativeSample(s,end,end,1),"final sample commit rejected");
  check(native.GetNativeTextureRectStamp(s,{127,127,1,1},page),"final actual sample not latched");
  GSCpuBackend::NativeTextureStamp old=page;
  std::vector<uint32_t> one;
  check(native.DecodeNativeTextureRect(s,{127,127,1,1},one)&&one[0]==image.back(),"committed final texel differs");
  native.WriteVram(psm,t.tbp0,t.tbw,127,127,0);
  const auto before=image;
  check(!native.GetCoherentNativeImageStamp(s,stamp),"stale retained page authorized snapshot");
  check(!native.SnapshotCoherentNativeImage(s,image)&&image==before,"stale rejection changed output");
  check(native.GetNativeTextureRectStamp(s,{127,127,1,1},page)&&page.texels==old.texels,"rejected snapshot changed retained state");
  check(native.DecodeNativeTextureRect(s,{127,127,1,1},one)&&one[0]==before.back(),"retained source implicitly flushed");
  native.TextureFlush();check(native.SnapshotCoherentNativeImage(s,image),"explicit TEXFLUSH failed to enable current snapshot");
 }
 std::puts("PASS: thirteen multi-page/wrapped formats match raster; snapshots preserve latch; stale bytes reject; final sample/explicit flush retained");return 0;
}catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
