// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_cpu_backend.h"
#include <algorithm>
#include <cstdio>
#include <stdexcept>
#include <vector>
static void check(bool ok,const char*why){if(!ok)throw std::runtime_error(why);}
int main(){try {
 const unsigned formats[]={GS_PSM_CT32,GS_PSM_CT24,GS_PSM_CT16,GS_PSM_CT16S,
  GS_PSM_Z32,GS_PSM_Z24,GS_PSM_Z16,GS_PSM_Z16S,GS_PSM_T8,GS_PSM_T8H,
  GS_PSM_T4,GS_PSM_T4HL,GS_PSM_T4HH};
 const unsigned widths[]={0,1,2,3,31,32,33,63,64,65,127};
 const unsigned chunks[]={1,2,3,7,16,31,64,257};
 std::vector<uint8_t> actual(4*1024*1024),expected(actual.size());
 GSCpuBackend candidate,oracle;candidate.Initialize(actual.data(),actual.size());oracle.Initialize(expected.data(),expected.size());
 unsigned cases=0,comparisons=0;
 for(unsigned format:formats)for(unsigned width:widths)for(unsigned kind=0;kind<2;++kind) {
  candidate.Reset();oracle.Reset();uint32_t random=0x7505900+cases;
  for(auto &v:actual){random=random*1664525u+1013904223u;v=random>>24;}expected=actual;
  GSTransferCommand command;command.direction=0;command.bitbltbuf.dbp=kind?16380:64;
  command.bitbltbuf.dbw=kind?2:1;command.bitbltbuf.dpsm=format;
  command.trxpos.dsax=kind?63:0;command.trxpos.dsay=kind?127:0;command.trxreg={uint16_t(width),5};
  candidate.BeginTransfer(command);
  const bool nibble=format==GS_PSM_T4||format==GS_PSM_T4HL||format==GS_PSM_T4HH;
  const unsigned bytes=(format==GS_PSM_CT32||format==GS_PSM_Z32)?4:
   (format==GS_PSM_CT24||format==GS_PSM_Z24)?3:
   (format==GS_PSM_CT16||format==GS_PSM_CT16S||format==GS_PSM_Z16||format==GS_PSM_Z16S)?2:1;
  std::vector<uint8_t> input(width*5*4+1024);for(auto &v:input){random=random*1664525u+1013904223u;v=random>>24;}
  unsigned copied=0,total=width*5,x=command.trxpos.dsax,y=command.trxpos.dsay,direction=0;
  auto equal=[&]{
   check(actual==expected,"upload changed full VRAM");const auto state=candidate.GetTransferSnapshot();
   check(state.x==x&&state.y==y&&state.copiedPixels==copied&&state.totalPixels==total&&state.direction==direction&&state.localToHostPendingBytes==0,"upload cursor/snapshot changed");++comparisons;
  };
  candidate.UploadImage(nullptr,32);candidate.UploadImage(input.data(),0);equal();
  unsigned offset=0,chunkIndex=0;
  while(offset<input.size()) {
   const unsigned count=std::min<unsigned>(chunks[chunkIndex++%8],input.size()-offset);
   candidate.UploadImage(input.data()+offset,count);
   for(unsigned at=0;at+bytes<=count&&direction==0&&width!=0;at+=bytes) {
    uint32_t packed=0;for(unsigned b=0;b<bytes;++b)packed|=uint32_t(input[offset+at+b])<<(8*b);
    const unsigned step=std::min(nibble?2u:1u,total-copied);
    for(unsigned p=0;p<step;++p) {
     const unsigned index=copied+p;
     oracle.WriteVram(format,command.bitbltbuf.dbp,command.bitbltbuf.dbw,
      command.trxpos.dsax+index%width,command.trxpos.dsay+index/width,
      nibble?(packed>>(p*4))&15u:packed);
    }
    copied+=step;
    if(copied>=total){direction=3;total=0;}
    else{x=command.trxpos.dsax+copied%width;y=command.trxpos.dsay+copied/width;}
   }
   equal();offset+=count;
  }
  if(width)check(direction==3,"nonempty upload did not finish");++cases;
 }
 std::printf("PASS: %u uploads / %u full-VRAM and cursor comparisons; 13 formats, split/truncated packets, odd nibbles, wrap and zero width\n",cases,comparisons);
 return 0;
}catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
