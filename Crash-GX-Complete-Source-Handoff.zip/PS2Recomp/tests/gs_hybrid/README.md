# Experimental hybrid GS ownership checks

Build this standalone suite without a game, GUI or GPU:

```
cmake -S tests/gs_hybrid -B /tmp/ps2-hybrid-tests -DPS2X_HYBRID_SANITIZERS=ON
cmake --build /tmp/ps2-hybrid-tests
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir /tmp/ps2-hybrid-tests --output-on-failure
```

The coordinator is not selected by the production frontend or linked into the
released Wii build. The deferred driver is a test double: it queues batches and
executes them through the real software backend only when resolved. It is not
GX emulation and cannot measure GPU speed. Both sides use one external 4 MiB
VRAM allocation; compare all bytes against an independent software oracle.

Checks cover deferred batches without a CPU mirror, fallback ordering, retained
texture-cache contents until guest TEXFLUSH, readback, host/local transfers,
CLUT forwarding, 256 deterministic mixed draws, masks/depth/blend state, clears,
CPU presentation, rebinding, clean native unavailability, and terminal driver
errors/exceptions. Partial initialization must release native VRAM references.
ASan/UBSan are enabled by the option; leak scanning is separately disabled in
the command above because the local execution environment uses ptrace.

Default drivers still exclude textured native draws. An opt-in driver must
identify the exact canonical software cache it uses. By default the coordinator
resolves older GPU writes before native source materialization. A driver can
opt in to preparation without resolving only if its source reads exclusively
latched texel/CLUT bytes and it preserves buffers that GX still samples.
Rejections still resolve before software fallback; preparation exceptions are
terminal. The canonical backend supplies saturating texel/palette revisions for
safe decoded-source reuse. Ordinary VRAM writes preserve latched stamps;
cache misses, TEXFLUSH/reset and palette loads invalidate the corresponding
reuse proof. Revisions never wrap into an old key. The native texture
probe covers this restricted path. Silently invalidating texels at an ownership
transition changes rendering semantics. Host-derived
source caches and guest-latched texels are different things. Callers must not
write external VRAM behind this coordinator while GPU ownership is active.
Native drivers must not call back into the coordinator while it holds its lock.
Direct native presentation remains open: current Present resolves to CPU RGBA.

`gs_native_texture_page` checks canonical point-source decoding, TEXA, palette
retention/reload, maximum page dimensions and rejection without cache mutation.
See `docs/wii/NATIVE-TEXTURES.md` for actual-GX coverage and remaining limits.

`gs_native_triangle_spans`, `gs_native_texture_rect` and
`gs_native_sprite_plan` cover analytic canonical edge spans, bounded crops from
large textures, and STQ/FST point-sprite coordinates against actual software
raster results. They do not require a GPU. The corresponding real GX extension
and its remaining release gates are in `docs/wii/GX-STQ-PROGRESS.md`.

`gs_native_texture_image` verifies coherent, non-mutating multi-page snapshots
against real raster output and the final guest-cache sample. `gs_native_projective_plan`
checks homogeneous point matrices, winding/scan masks, negative/clamped coordinates
and Q scaling. GPU execution and remaining limits are recorded in
`docs/wii/GX-PROJECTIVE-PROGRESS.md`.
