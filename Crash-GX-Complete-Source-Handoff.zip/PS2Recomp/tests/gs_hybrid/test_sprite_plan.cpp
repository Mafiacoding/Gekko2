// SPDX-License-Identifier: GPL-3.0-or-later
#include "runtime/gs/gs_native_sprite_plan.h"
#include <cstdio>
#include <stdexcept>
int main(){try{
 std::vector<uint8_t> vram(4*1024*1024);GSCpuBackend oracle;oracle.Initialize(vram.data(),vram.size());
 for(unsigned y=256;y<288;++y)for(unsigned x=512;x<576;++x)oracle.WriteVram(0,0,16,x,y,0x80000000|(x&255)|((y&255)<<8)|((x>>8)<<16));
 uint32_t random=0x750128;auto next=[&]{random=random*1664525+1013904223;return random;};unsigned accepted=0,pixels=0;
 for(unsigned n=0;n<1024;++n){
  oracle.Reset();GSPrimitiveBatch b;b.vertexCount=2;b.state.prim.type=GS_PRIM_SPRITE;b.state.prim.tme=true;b.state.prim.fst=n%3==0;
  b.state.colclamp=1;b.state.context.frame={128,1,GS_PSM_CT32,0};b.state.context.scissor={0,63,0,63};b.state.context.zbuf.zmask=true;b.state.context.test=uint64_t(1)<<17;
  b.state.context.tex0.psm=0;b.state.context.tex0.tbw=16;b.state.context.tex0.tw=b.state.context.tex0.th=10;b.state.context.tex0.tfx=1;b.state.context.tex0.tcc=1;b.state.textureWidth=b.state.textureHeight=1024;b.state.context.clamp=5;
  auto&a=b.vertices[0];auto&z=b.vertices[1];a.x=4+(next()%16)/16.f;a.y=4+(next()%16)/16.f;z.x=a.x+4+(next()%12)/4.f;z.y=a.y+4+(next()%12)/4.f;
  float u0=516+next()%8,v0=260+next()%8,u1=u0+(z.x-a.x)*.5f,v1=v0+(z.y-a.y)*.5f;
  a.q=-7;z.q=n%5==0?1.e-10f:n%5==1?.5f:n%5==2?1:n%5==3?2:4;const float q=std::fabs(z.q)>1.e-8f?z.q:1;
  a.s=(u0/1024)*q;z.s=(u1/1024)*q;a.t=(v0/1024)*q;z.t=(v1/1024)*q;
  a.u=u0*16;z.u=u1*16;a.v=v0*16;z.v=v1*16;
  if(n&1){std::swap(a.x,z.x);std::swap(a.s,z.s);std::swap(a.u,z.u);}
  GSNativeSpritePlan plan;if(!GSNativeSpritePlan::Prepare(b,plan))continue;++accepted;
  oracle.ClearFramebuffer(b.state.context,0);oracle.Submit(b);
  for(int y=0;y<plan.height;y++)for(int x=0;x<plan.width;x++){
   const int u=plan.columns[x],v=plan.rows[y];const uint32_t expected=0x80000000|(u&255)|((v&255)<<8)|((u>>8)<<16);
   if(oracle.ReadVram(0,128*32,1,plan.x+x,plan.y+y)!=expected)throw std::runtime_error("planned STQ/FST point differs from real DrawSprite");
   const int gu=std::clamp(int(std::floor(plan.u+plan.du*(x+7.f/12))),0,int(plan.source.width)-1)+plan.source.x;
   const int gv=std::clamp(int(std::floor(plan.v+plan.dv*(y+7.f/12))),0,int(plan.source.height)-1)+plan.source.y;
   if(gu!=u||gv!=v)throw std::runtime_error("fitted nearest ramp differs from canonical sample");++pixels;
  }
 }
 std::printf("admitted=%u compared=%u\n",accepted,pixels);
 if(accepted<800)throw std::runtime_error("too few coordinate cases admitted");
 std::printf("PASS: %u STQ/FST fractional/reversed sprites, %u actual software-raster pixel comparisons\n",accepted,pixels);return 0;
 }catch(const std::exception&e){std::fprintf(stderr,"FAIL: %s\n",e.what());return 1;}}
