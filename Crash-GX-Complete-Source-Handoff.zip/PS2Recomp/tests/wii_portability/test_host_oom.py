#!/usr/bin/env python3
"""Host allocation failures must not become guest address exceptions."""
from pathlib import Path
import subprocess,tempfile,re,os
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/ps2_runtime.cpp').read_text();start=s.index('uint8_t PS2Runtime::Load8(');end=s.index('void PS2Runtime::kickGifDmaChainFromMMIO(',start);body=s[start:end]
source=r'''
#include <cstdint>
#include <new>
#include <stdexcept>
#include <cassert>
#include <smmintrin.h>
struct R5900Context{};
constexpr int EXCEPTION_ADDRESS_ERROR_LOAD=1,EXCEPTION_ADDRESS_ERROR_STORE=2;
template<class...T>void ps2TraceGuestWrite(T...){}
struct Memory {
 int mode=0;void check(){if(mode==1)throw std::bad_alloc();if(mode==2)throw std::runtime_error("guest address");}
 uint8_t read8(uint32_t){check();return 7;}uint16_t read16(uint32_t){check();return 7;}
 uint32_t read32(uint32_t){check();return 7;}uint64_t read64(uint32_t){check();return 7;}
 __m128i read128(uint32_t){check();return _mm_set1_epi32(7);}
 void write8(uint32_t,uint8_t){check();}void write16(uint32_t,uint16_t){check();}
 void write32(uint32_t,uint32_t){check();}void write64(uint32_t,uint64_t){check();}void write128(uint32_t,__m128i){check();}
};
struct PS2Runtime {
 Memory m_memory;int faults=0,drained=0;
 void SignalException(R5900Context*,int){++faults;}void drainCompletedDmacHandlers(uint8_t*){++drained;}
 uint8_t Load8(uint8_t*,R5900Context*,uint32_t);uint16_t Load16(uint8_t*,R5900Context*,uint32_t);
 uint32_t Load32(uint8_t*,R5900Context*,uint32_t);uint64_t Load64(uint8_t*,R5900Context*,uint32_t);__m128i Load128(uint8_t*,R5900Context*,uint32_t);
 void Store8(uint8_t*,R5900Context*,uint32_t,uint8_t);void Store16(uint8_t*,R5900Context*,uint32_t,uint16_t);
 void Store32(uint8_t*,R5900Context*,uint32_t,uint32_t);void Store64(uint8_t*,R5900Context*,uint32_t,uint64_t);void Store128(uint8_t*,R5900Context*,uint32_t,__m128i);
};
BODY
int main(){PS2Runtime r;R5900Context c;
 for(int operation=0;operation<10;++operation)for(int mode=0;mode<3;++mode){r.m_memory.mode=mode;r.faults=r.drained=0;bool oom=false;
 try{switch(operation){
 case 0:r.Load8(nullptr,&c,0);break;case 1:r.Load16(nullptr,&c,0);break;case 2:r.Load32(nullptr,&c,0);break;case 3:r.Load64(nullptr,&c,0);break;case 4:r.Load128(nullptr,&c,0);break;
 case 5:r.Store8(nullptr,&c,0,1);break;case 6:r.Store16(nullptr,&c,0,1);break;case 7:r.Store32(nullptr,&c,0,1);break;case 8:r.Store64(nullptr,&c,0,1);break;case 9:r.Store128(nullptr,&c,0,_mm_setzero_si128());break;
 }}catch(const std::bad_alloc&){oom=true;}
 assert(oom==(mode==1));assert(r.faults==(mode==2));assert(r.drained==int(operation==7&&mode==0));
 }
}
'''.replace('BODY',body)
with tempfile.TemporaryDirectory() as td:
 p=Path(td);(p/'test.cpp').write_text(source)
 subprocess.run(['c++','-std=c++20','-O1','-msse4.1','-fsanitize=address,undefined',str(p/'test.cpp'),'-o',str(p/'test')],check=True);subprocess.run([str(p/'test')],check=True,env={**os.environ,"ASAN_OPTIONS":os.environ.get("ASAN_OPTIONS","")+":detect_leaks=0"})
print('PASS: 30 production load/store cases; host OOM escapes, guest address faults retained, no fake DMA completion')
