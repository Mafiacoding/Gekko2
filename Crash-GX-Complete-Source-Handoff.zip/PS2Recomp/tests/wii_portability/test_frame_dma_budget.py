#!/usr/bin/env python3
"""Exercise production presentation with the DMA allocation size from owner logs."""
from pathlib import Path
import argparse,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--backend',type=Path);p.add_argument('--expect-failure',action='store_true');a=p.parse_args()
root=Path(__file__).resolve().parents[2]
source=r'''
#include "runtime/gs/gs_cpu_backend.h"
#include <new>
#include <cstdlib>
#include <cstddef>
#include <cassert>
#include <cstdio>
static bool tracking=false;static size_t live=0,peak=0;
struct alignas(std::max_align_t) Header{size_t bytes;bool tracked;};
void*operator new(size_t n){bool tracked=tracking&&n>=65536;if(tracked&&n>2600000-live)throw std::bad_alloc();
 auto*h=static_cast<Header*>(std::malloc(n+sizeof(Header)));if(!h)throw std::bad_alloc();*h={n,tracked};if(tracked){live+=n;if(live>peak)peak=live;}return h+1;}
void operator delete(void*p)noexcept{if(!p)return;auto*h=static_cast<Header*>(p)-1;if(h->tracked)live-=h->bytes;std::free(h);}
void operator delete(void*p,size_t)noexcept{operator delete(p);}
int main(){
 try{
 std::vector<uint8_t>vram(4*1024*1024,0);GSCpuBackend gs;gs.Initialize(vram.data(),vram.size());
 gs.WriteVram(GS_PSM_CT32,0,10,0,0,0x80302010);
 GSPresentationRequest req{};req.pmode=1;req.dispfb1=10ull<<9;req.display1=(639ull<<32)|(223ull<<44);
 tracking=true;
 {auto frame=gs.Present(req);assert(frame&&frame.width==640&&frame.height==224);
 std::vector<uint8_t>dma(1890440,0xa5);assert(dma.front()==0xa5&&dma.back()==0xa5);
 assert(frame.pixels[0]==0x10&&frame.pixels[1]==0x20&&frame.pixels[2]==0x30);}
 tracking=false;assert(live==0);std::printf("PASS: 640x224 GS frame plus 1,890,440-byte DMA snapshot, peak tracked bytes=%zu under 2,600,000-byte budget\\n",peak);
 }catch(const std::bad_alloc&){return 2;}
}
'''
with tempfile.TemporaryDirectory(prefix='gs-dma-budget-') as td:
 d=Path(td);(d/'test.cpp').write_text(source)
 cmd=['c++','-std=c++20','-O1','-msse4.1','-pthread','-DPS2X_WII_SERIAL_PRESENT','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),str(d/'test.cpp'),str(a.backend or root/'ps2xRuntime/src/lib/gs/gs_cpu_backend.cpp'),str(root/'ps2xRuntime/src/lib/gs/ps2_gs_memory.cpp'),'-o',str(d/'test')]
 subprocess.run(cmd,check=True);r=subprocess.run([str(d/'test')])
 assert r.returncode==(2 if a.expect_failure else 0),r.returncode
 if a.expect_failure:print('PASS negative control: old production frame allocation cannot fit observed DMA snapshot under the same budget')
