#!/usr/bin/env python3
"""Owned DMA snapshots across fragmented allocations, using the real buffer/reader."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[2]
code=r'''
#include "runtime/ps2_dma_buffer.h"
#include <cassert>
#include <cstdlib>
#include <cstddef>
#include <new>
static bool tracking=false;static size_t limit=65536,calls=0,live=0,largest=0,failAfter=~size_t(0);
struct alignas(std::max_align_t) Header{bool tracked;};
void*operator new(size_t n){if(tracking&&(n>limit||calls==failAfter))throw std::bad_alloc();
 auto*h=static_cast<Header*>(std::malloc(sizeof(Header)+std::max(n,size_t(1))));if(!h)throw std::bad_alloc();h->tracked=tracking;
 if(tracking){++calls;++live;largest=std::max(largest,n);}return h+1;}
void operator delete(void*p)noexcept{if(p){auto*h=static_cast<Header*>(p)-1;if(h->tracked)--live;std::free(h);}}
void operator delete(void*p,size_t)noexcept{operator delete(p);}
void*operator new[](size_t n){return operator new(n);}void operator delete[](void*p)noexcept{operator delete(p);}void operator delete[](void*p,size_t)noexcept{operator delete(p);}
int main(){
 constexpr size_t size=2861248;std::vector<uint8_t>source(size);for(size_t i=0;i<size;++i)source[i]=uint8_t(i*31+(i>>16));
 tracking=true;
 {bool failed=false;try{Ps2DmaBuffer old;old.reserve(size);}catch(const std::bad_alloc&){failed=true;}assert(failed);}
 {Ps2DmaBuffer b(true);b.reserve(size);const auto allocated=calls;size_t pos=0;
 while(pos<size){auto n=std::min(size-pos,size_t(137));b.append(source.data()+pos,source.data()+pos+n);pos+=n;}
 assert(calls==allocated&&b.size()==size&&largest<=65536);
 for(size_t offset : {size_t(0),size_t(65534),size_t(65536),size-16}){
  Ps2DmaInput input(b);auto*p=input.span(offset,16);assert(!std::memcmp(p,source.data()+offset,16));
  assert(input.read<uint32_t>(offset)==Ps2GuestRead<uint32_t>(source.data()+offset));
 }
 for(size_t i=0;i<size;i+=97)assert(b[i]==source[i]);
 bool bounds=false;try{b.copy(size-1,source.data(),2);}catch(const std::out_of_range&){bounds=true;}assert(bounds);
 auto moved=std::move(b);assert(b.empty()&&moved.size()==size);
 std::fill(source.begin(),source.end(),0);assert(moved[65534]!=0); // immutable snapshot
 bool failed=false;try{Ps2DmaInput input(moved);input.span(0,size);}catch(const std::bad_alloc&){failed=true;}assert(failed);
 limit=1048576;{Ps2DmaInput input(moved);auto*p=input.span(100,1048576);assert(p[0]==moved[100]&&p[1048575]==moved[1048675]);}
 }
 assert(live==0);
 // A partial reserve failure frees every block; no partial owner escapes.
 limit=65536;failAfter=calls+7;bool failed=false;
 try{Ps2DmaBuffer b(true);b.reserve(size);}catch(const std::bad_alloc&){failed=true;}assert(failed&&live==0);
 tracking=false;
}
'''
with tempfile.TemporaryDirectory() as td:
 p=Path(td);(p/'test.cpp').write_text(code)
 subprocess.run(['c++','-std=c++20','-O1','-msse4.1','-fsanitize=address,undefined','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: exact 2,861,248-byte snapshot under 64 KiB allocation limit, byte/word boundary reads, owned moves, 1 MiB command view, bounds and failure cleanup; contiguous negative control fails')
