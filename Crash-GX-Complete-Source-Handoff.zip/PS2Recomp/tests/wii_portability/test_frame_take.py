#!/usr/bin/env python3
"""Execute the actual GS frame-consumer method, including allocation failure."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/gs/gs_frontend.cpp').read_text();a=s.index('bool GS::takeLatchedHostPresentationFrame');b=s.index('\nbool GS::',a+10);body=s[a:b]
prefix=r'''
#include <cstdint>
#include <vector>
#include <mutex>
#include <cstdlib>
#include <new>
#include <cassert>
static bool deny=false;
void*operator new(std::size_t n){if(deny)throw std::bad_alloc();if(auto*p=std::malloc(n))return p;throw std::bad_alloc();}
void operator delete(void*p)noexcept{std::free(p);}void operator delete(void*p,std::size_t)noexcept{std::free(p);}
struct GS{
 std::mutex m_presentationMutex;bool m_hasHostPresentationFrame=true,m_hostPresentationUsedPreferred=true;
 uint32_t m_hostPresentationWidth=640,m_hostPresentationHeight=224,m_hostPresentationDisplayFbp=1,m_hostPresentationSourceFbp=2;
 std::vector<uint8_t>m_hostPresentationFrame;
 bool takeLatchedHostPresentationFrame(std::vector<uint8_t>&,uint32_t&,uint32_t&,uint32_t*,uint32_t*,bool*);
};
'''
main=r'''
int main(){GS gs;gs.m_hostPresentationFrame.assign(640*224*4,0xa5);auto*p=gs.m_hostPresentationFrame.data();std::vector<uint8_t>out(100);uint32_t w=0,h=0,d=0,s=0;bool pref=false;
 deny=true;bool ok=gs.takeLatchedHostPresentationFrame(out,w,h,&d,&s,&pref);deny=false;
 assert(ok&&out.data()==p&&out.size()==640*224*4&&w==640&&h==224&&d==1&&s==2&&pref);
 assert(gs.m_hostPresentationFrame.empty()&&!gs.m_hasHostPresentationFrame);for(auto b:out)assert(b==0xa5);
 assert(!gs.takeLatchedHostPresentationFrame(out,w,h,&d,&s,&pref));assert(out.empty()&&w==0&&h==0&&!pref);
 gs.m_hasHostPresentationFrame=true;gs.m_hostPresentationWidth=641;gs.m_hostPresentationFrame.resize(640*512*4);
 assert(!gs.takeLatchedHostPresentationFrame(out,w,h,nullptr,nullptr,nullptr));
 gs.m_hostPresentationWidth=640;gs.m_hostPresentationFrame.resize(16);assert(!gs.takeLatchedHostPresentationFrame(out,w,h,nullptr,nullptr,nullptr));
}
'''
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'test.cpp').write_text(prefix+body+main)
 subprocess.run(['c++','-std=c++20','-O1','-pthread','-fsanitize=address,undefined',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: actual GS consume method, ownership transfer without allocations, no stale reuse, invalid layout rejection')
