#!/usr/bin/env python3
import importlib.util,unittest
from pathlib import Path
p=Path(__file__).resolve().parents[2]/'tools/wii/analyze_phase_profile.py'
spec=importlib.util.spec_from_file_location('profile',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def fixture():
 return 'profile_hz=100 profile_samples=10\nwall_ee_phase_samples='+''.join(f' {i}:{10 if i==10 else 0}' for i in range(16))+'\nwall_ui_phase_samples='+''.join(f' {i}:{10 if i==3 else 0}' for i in range(32))+'\n'
class Tests(unittest.TestCase):
 def test_overlap_is_separate(self):
  r=m.analyze(fixture());self.assertEqual(r['ee'][0]['name'],'VU execution');self.assertEqual(r['ee'][0]['percent'],100);self.assertEqual(r['ui'][0]['percent'],100)
 def test_upload_phase_is_separate(self):
  text=fixture().replace(" 10:10", " 10:0").replace(" 14:0", " 14:10",1)
  row=m.analyze(text)["ee"][0]
  self.assertEqual(row["name"], "GS image upload / swizzle");self.assertEqual(row["percent"],100)
 def test_incomplete_and_malformed(self):
  for bad in [fixture().replace(' 15:0',''),fixture().replace(' 15:0',' 15:1'),fixture().replace(' 15:0',' 10:0'),fixture().replace(' 15:0',' 99:0'),fixture().replace(' 15:0',' 15:-1'),fixture().replace('samples=10','samples=0'),fixture()+'profile_hz=100 profile_samples=10\n']:
   with self.assertRaises(ValueError):m.analyze(bad)
 def test_old_progress_is_not_a_profile(self):
  with self.assertRaises(ValueError):m.analyze('seconds=100 ee_phase=10\n')
unittest.main()
