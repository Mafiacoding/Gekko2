#!/usr/bin/env python3
"""Check compatibility IOP storage lifecycle without a duplicate eager reserve."""
from pathlib import Path
import subprocess,tempfile,os
root=Path(__file__).resolve().parents[2];s=(root/'ps2xRuntime/src/lib/ps2_memory.cpp').read_text()
a=s.index('uint8_t *PS2Memory::getIOPRAM()');b=s.index('bool PS2Memory::initialize(',a);body=s[a:b]
init=s[b:s.index('void PS2Memory::resetEeTimers()',b)]
assert 'iop_ram = new' not in init,'initialization must not eagerly reserve compatibility RAM'
source=r'''
#include <cstdint>
#include <mutex>
#include <thread>
#include <cassert>
struct PS2Memory {uint8_t*m_rdram=nullptr,*iop_ram=nullptr;std::mutex m_legacyIopMutex;uint8_t*getIOPRAM();~PS2Memory(){delete[] iop_ram;}};
BODY
int main(){PS2Memory m;assert(!m.getIOPRAM()&&!m.iop_ram);uint8_t dummy;m.m_rdram=&dummy;
 uint8_t*a=nullptr,*b=nullptr;std::thread t1([&]{a=m.getIOPRAM();}),t2([&]{b=m.getIOPRAM();});t1.join();t2.join();assert(a&&a==b);
 for(unsigned i=0;i<2*1024*1024;++i)assert(a[i]==0);a[0]=7;a[2*1024*1024-1]=9;
 assert(m.getIOPRAM()[0]==7&&m.getIOPRAM()[2*1024*1024-1]==9);
}
'''.replace('BODY',body)
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'test.cpp').write_text(source)
 subprocess.run(['c++','-std=c++20','-O1','-pthread','-fsanitize=address,undefined',str(d/'test.cpp'),'-o',str(d/'test')],check=True)
 subprocess.run([str(d/'test')],check=True,env={**os.environ,'ASAN_OPTIONS':os.environ.get('ASAN_OPTIONS','')+':detect_leaks=0'})
print('PASS: no eager compatibility allocation, uninitialized null, zero-filled 2 MiB on demand, stable concurrent pointer and persistent bytes')
