#!/usr/bin/env python3
"""Compile production allocator with bounded MEM2 and failing MEM1 fixtures."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'ogc').mkdir()
 (p/'gccore.h').write_text('''#pragma once
#include <cstddef>
extern void* arenaLo;extern void*arenaHi;
inline void*SYS_GetArena2Lo(){return arenaLo;}inline void*SYS_GetArena2Hi(){return arenaHi;}inline void SYS_SetArena2Lo(void*p){arenaLo=p;}
''')
 (p/'ogc/mutex.h').write_text('''#pragma once
using mutex_t=int;inline int LWP_MutexInit(mutex_t*,bool){return 0;}inline void LWP_MutexLock(mutex_t){}inline void LWP_MutexUnlock(mutex_t){}
''')
 (p/'ogc/lwp_heap.h').write_text('''#pragma once
#include <cstdint>
#include <cstddef>
struct heap_cntrl{unsigned char*base;std::size_t size,pos;};
inline bool __lwp_heap_init(heap_cntrl*h,void*b,uint32_t n,int){*h={(unsigned char*)b,n,0};return true;}
inline void*__lwp_heap_allocate(heap_cntrl*h,uint32_t n){auto off=(h->pos+31)&~std::size_t(31);if(off+n>h->size)return nullptr;h->pos=off+n;return h->base+off;}
inline void __lwp_heap_free(heap_cntrl*,void*){}
''')
 (p/'test.cpp').write_text('''#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <cerrno>
alignas(32) unsigned char mem2[2*1024*1024];void*arenaLo=mem2;void*arenaHi=mem2+sizeof mem2;bool fail=false,preferFast=false;
extern "C" bool PS2WiiPreferFastHeap(){return preferFast;}
extern "C" void*__real_malloc(size_t n){return fail?nullptr:std::malloc(n);}
extern "C" void*__real_memalign(size_t a,size_t n){void*p=nullptr;if(!fail)posix_memalign(&p,a,n);return p;}
extern "C" void*__real_realloc(void*p,size_t n){return fail?nullptr:std::realloc(p,n);}
extern "C" void*__real_calloc(size_t a,size_t b){return fail?nullptr:std::calloc(a,b);}
extern "C" void __real_free(void*p){std::free(p);}
unsigned PS2WiiHeapInventory(uint32_t*,unsigned);
void PS2WiiHeapInit();void PS2WiiHeapSnapshot(uint32_t*);
extern "C" void*__wrap_malloc(size_t);extern "C" void*__wrap_memalign(size_t,size_t);extern "C" void*__wrap_calloc(size_t,size_t);extern "C" void*__wrap_realloc(void*,size_t);extern "C" void __wrap_free(void*);
bool inMem2(void*p){return uintptr_t(p)>=uintptr_t(mem2)&&uintptr_t(p)<uintptr_t(mem2+sizeof mem2);}
int main(){PS2WiiHeapInit();auto*p=__wrap_malloc(32);assert(p&&!inMem2(p));__wrap_free(p);
 preferFast=true;p=__wrap_malloc(70000);assert(p&&!inMem2(p));__wrap_free(p);
 p=__wrap_memalign(128,70000);assert(p&&!inMem2(p)&&uintptr_t(p)%128==0);__wrap_free(p);
 fail=true;p=__wrap_malloc(70000);assert(p&&inMem2(p));__wrap_free(p);preferFast=false;
 fail=true;p=__wrap_malloc(32);assert(p&&inMem2(p));std::memset(p,0x5a,32);
 auto*q=__wrap_realloc(p,128);assert(q&&inMem2(q));for(int i=0;i<32;++i)assert(((unsigned char*)q)[i]==0x5a);__wrap_free(q);
 p=__wrap_memalign(128,64);assert(p&&inMem2(p)&&uintptr_t(p)%128==0);__wrap_free(p);
 p=__wrap_calloc(16,4);assert(p&&inMem2(p));for(int i=0;i<64;++i)assert(((unsigned char*)p)[i]==0);__wrap_free(p);
 assert(!__wrap_calloc(SIZE_MAX,2)&&errno==ENOMEM);
 assert(!__wrap_memalign(3,64)&&errno==EINVAL);
 p=__wrap_malloc(70000);assert(p);uint32_t records[9]{};auto count=PS2WiiHeapInventory(records,3);assert(count==1&&records[1]==70000);__wrap_free(p);assert(PS2WiiHeapInventory(records,3)==0);
 assert(!__wrap_malloc(4*1024*1024));uint32_t stats[3];PS2WiiHeapSnapshot(stats);assert(stats[0]==0&&stats[1]>=160&&stats[2]==4*1024*1024);
}
''')
 subprocess.run(['c++','-std=c++20','-fsanitize=address,undefined','-I'+str(p),str(p/'test.cpp'),str(root/'ps2xRuntime/platform/wii/ps2_wii_heap.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: production MEM1-to-MEM2 fallback, alignment, calloc, realloc preservation and failure telemetry')
