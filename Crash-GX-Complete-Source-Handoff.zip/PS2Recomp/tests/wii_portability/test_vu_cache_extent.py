#!/usr/bin/env python3
"""Run production cache rebuild/lookup methods at VU0/VU1 hardware extents."""
from pathlib import Path
import subprocess,tempfile,os
root=Path(__file__).resolve().parents[2];s=(root/'ps2xRuntime/src/lib/vu/ps2_vu1_core.cpp').read_text()
a=s.index('void VU1Interpreter::rebuildDecodedCodeCache(');b=s.index('void VU1Interpreter::reportReservedInstruction(',a);body=s[a:b]
source=r'''
#include <array>
#include <vector>
#include <algorithm>
#include <cstdint>
#include <cassert>
struct PS2Memory {uint8_t code0[4096]{},code1[16384]{};uint64_t gen0=1,gen1=1;
 uint8_t*getVU0Code(){return code0;}uint8_t*getVU1Code(){return code1;}
 uint64_t getVU0CodeGeneration(){return gen0;}uint64_t getVU1CodeGeneration(){return gen1;}};
template<typename T>T Ps2GuestRead(const uint8_t*p){T value=0;for(unsigned i=0;i<sizeof(T);++i)value|=T(p[i])<<(i*8);return value;}
struct VU1Interpreter {
 enum class Unit{VU0,VU1};enum Pipeline{PipelineNone,PipelineUndecoded=255};
 struct Usage{Pipeline pipeline=PipelineUndecoded;};
 struct DecodedInstructionPair{uint32_t value=0,lower=0,upper=0;Usage upperUsage{};bool requiresValidation=true;uint8_t padding[60]{};};
 static constexpr uint32_t kMaxDecodedPairs=2048;
 Unit m_unit;std::vector<DecodedInstructionPair> m_decodedCodeCache;
 const uint8_t*m_cachedVuCode=nullptr;const PS2Memory*m_cachedMemory=nullptr;
 uint32_t m_cachedCodeSize=0;uint64_t m_cachedCodeGeneration=0;bool m_decodedCodeCacheValid=false;unsigned decoded=0;
 DecodedInstructionPair decodeInstructionPair(const uint8_t*p,uint32_t pc){++decoded;DecodedInstructionPair out;out.value=p[pc];out.lower=Ps2GuestRead<uint32_t>(p+pc);out.upper=Ps2GuestRead<uint32_t>(p+pc+4);out.upperUsage.pipeline=PipelineNone;out.requiresValidation=false;return out;}
 void rebuildDecodedCodeCache(const uint8_t*,uint32_t,const PS2Memory*,uint64_t);
 DecodedInstructionPair getDecodedInstructionPairForPc(const uint8_t*,uint32_t,PS2Memory*,uint32_t);
};
BODY
#if defined(PS2X_VU_LAZY_DECODE)
constexpr unsigned count(unsigned eager,unsigned lazy){return lazy;}
#else
constexpr unsigned count(unsigned eager,unsigned lazy){return eager;}
#endif
int main(){PS2Memory memory;memory.code0[4088]=27;memory.code1[16376]=91;
 VU1Interpreter zero{VU1Interpreter::Unit::VU0};auto x=zero.getDecodedInstructionPairForPc(memory.code0,4096,&memory,4088);
 assert(x.value==27&&zero.m_decodedCodeCache.size()==512&&zero.decoded==count(512,1));
 memory.code0[4088]=32;++memory.gen0;x=zero.getDecodedInstructionPairForPc(memory.code0,4096,&memory,4088);
 assert(x.value==32&&zero.decoded==count(1024,2)&&zero.m_decodedCodeCache.size()==512);
 zero.getDecodedInstructionPairForPc(memory.code0,4096,&memory,4088);assert(zero.decoded==count(1024,2));
 zero.getDecodedInstructionPairForPc(memory.code0,512,&memory,504);assert(zero.m_decodedCodeCache.size()==64&&zero.decoded==count(1088,3));
 zero.getDecodedInstructionPairForPc(memory.code0,4096,&memory,4088);assert(zero.m_decodedCodeCache.size()==512&&zero.decoded==count(1600,4));
 uint8_t external[16]{};external[8]=7;x=zero.getDecodedInstructionPairForPc(external,16,&memory,8);assert(x.value==7&&zero.decoded==count(1601,5));
 VU1Interpreter one{VU1Interpreter::Unit::VU1};x=one.getDecodedInstructionPairForPc(memory.code1,16384,&memory,16376);
 assert(x.value==91&&one.m_decodedCodeCache.size()==2048&&one.decoded==count(2048,1));
 memory.code1[16376]=92;++memory.gen1;x=one.getDecodedInstructionPairForPc(memory.code1,16384,&memory,16376);
 assert(x.value==92&&one.decoded==count(4096,2));
 // An upload changing an unexecuted pair must preserve the fetched pair's
 // validated metadata. A changed upper half must still trigger re-decode.
 auto before=one.decoded;memory.code1[0]=3;++memory.gen1;
 x=one.getDecodedInstructionPairForPc(memory.code1,16384,&memory,16376);
 assert(x.value==92&&one.decoded==before+count(2048,0));
 before=one.decoded;memory.code1[16380]=0x71;++memory.gen1;
 x=one.getDecodedInstructionPairForPc(memory.code1,16384,&memory,16376);
 assert(x.upper==0x71&&one.decoded==before+count(2048,1));
 // Fresh zero/zero code is a real instruction pair, not a cache hit on defaults.
 before=zero.decoded;x=zero.getDecodedInstructionPairForPc(memory.code0,4096,&memory,0);
 assert(x.lower==0&&x.upper==0&&zero.decoded==before+count(0,1));
}
'''.replace('BODY',body)
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'test.cpp').write_text(source)
 for defines in ([],['-DPS2X_VU_LAZY_DECODE']):
  subprocess.run(['c++','-std=c++20','-O1','-fsanitize=address,undefined',*defines,str(d/'test.cpp'),'-o',str(d/'test')],check=True)
  subprocess.run([str(d/'test')],check=True,env={**os.environ,'ASAN_OPTIONS':os.environ.get('ASAN_OPTIONS','')+':detect_leaks=0'})
print('PASS: production VU cache extents, highest PCs, generation invalidation, resize and untracked-code fallback')
