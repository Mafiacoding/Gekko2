#!/usr/bin/env python3
"""Run the actual observer with mock timebase/LWP, real threads and file IO."""
from pathlib import Path
import tempfile,subprocess,argparse
p=argparse.ArgumentParser();p.add_argument("--profile",action="store_true");args=p.parse_args()
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'ogc').mkdir();(p/'sd:/ps2recomp').mkdir(parents=True)
 (p/'gccore.h').write_text('''#pragma once
#include <chrono>
#include <cstdint>
inline constexpr unsigned LWP_PRIO_HIGHEST=127;
inline unsigned LWP_GetSelf(){return 0;}
inline void LWP_SetThreadPriority(unsigned,unsigned){}
inline uint64_t gettime(){return std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
inline uint64_t ticks_to_microsecs(uint64_t x){return x;}
''')
 (p/'ogc/lwp_watchdog.h').write_text('#pragma once\n')
 (p/'test.cpp').write_text('''#include "ps2_wii_progress.h"
#include <cassert>
#include <fstream>
#include <string>
#include <thread>
#include <chrono>
unsigned PS2WiiHeapInventory(uint32_t*,unsigned){return 0;}
uint32_t PS2WiiHeapFailureSite(){return 0x1234;}
void PS2WiiHeapSnapshot(uint32_t*p){p[0]=1;p[1]=2;p[2]=3;}
static bool closed=false;
bool WindowShouldClose(){return closed;}
int main(){
 PS2WiiProgressStart();
 for(unsigned i=0;i<1024;++i)PS2WiiProgressPoint(0x100000+i*4,0x1234,0x5678,i,0);
#if defined(PS2X_WII_SAMPLE_PROFILE)
 PS2WiiProgressPhase(99);PS2WiiProgressUi(99);
 std::this_thread::sleep_for(std::chrono::milliseconds(60));
#endif
 PS2WiiProgressPhase(5);
 try{PS2WiiProgressScope scope(10);throw 1;}catch(int){}
#if defined(PS2X_WII_SAMPLE_PROFILE)
 PS2WiiProgressUi(24);
#else
 PS2WiiProgressUi(2);
#endif
 // No producer activity: observer must still create its next durable sample.
 bool periodicObserved=false;
 const auto deadline=std::chrono::steady_clock::now()+std::chrono::seconds(20);
 while(std::chrono::steady_clock::now()<deadline){
  std::ifstream f("sd:/ps2recomp/progress.txt");std::string periodic((std::istreambuf_iterator<char>(f)),{});
  if(periodic.find("seconds=5 ")!=periodic.npos){periodicObserved=true;break;}
  std::this_thread::sleep_for(std::chrono::milliseconds(50));
 }
 assert(periodicObserved);
 PS2WiiProgressDmaSnapshot(0x10009000,2861248);
 PS2WiiProgressDmaDrained(0x10009000,2861248);
 PS2WiiProgressDmaDrained(0x10009000,16);
 PS2WiiProgressDmaDrained(0x10008000,2048);
 PS2WiiProgressStop();
 std::ifstream file("sd:/ps2recomp/progress.txt");std::string s((std::istreambuf_iterator<char>(file)),{});
 assert(s.find("state=STOPPED")!=s.npos);
 assert(s.find("failed_alloc_bytes=3")!=s.npos);
 assert(s.find("dma_snapshot_channel=10009000 dma_snapshot_bytes=2861248")!=s.npos);
 assert(s.find("max_vif0_snapshot_drained=2048 max_vif1_snapshot_drained=2861248")!=s.npos);
 assert(s.find("ee_points=1024")!=s.npos);
 assert(s.find("pc=00100ffc")!=s.npos);
#if defined(PS2X_WII_SAMPLE_PROFILE)
 assert(s.find("ee_phase=5 ui_phase=24")!=s.npos);
#else
 assert(s.find("ee_phase=5 ui_phase=2")!=s.npos);
#endif
#if defined(PS2X_WII_SAMPLE_PROFILE)
 assert(s.find("profile_hz=100")!=s.npos);
 auto readNumber=[&](const std::string&key){auto pos=s.find(key);assert(pos!=s.npos);return std::stoul(s.substr(pos+key.size()));};
 auto total=readNumber("profile_samples=");assert(total>=100&&total<800);
 assert(readNumber(" 5:")>total*9/10);
 assert(readNumber(" 15:")>0); // unknown phase is bounded into its bucket
 assert(readNumber(" 24:")>total*9/10); // retain existing RGBA conversion stage
 assert(readNumber(" 31:")>0);
 assert(s.find("profile_unknown_ui_last=00000063")!=s.npos);
#else
 assert(s.find("profile_hz=")==s.npos);
#endif
 closed=true;assert(PS2WiiProgressStopRequested());assert(PS2WiiServicePoll());
 PS2WiiProgressStart();PS2WiiProgressStop(); // repeat lifecycle joins safely
 std::ifstream resetFile("sd:/ps2recomp/progress.txt");std::string reset((std::istreambuf_iterator<char>(resetFile)),{});
 assert(reset.find("max_vif0_snapshot_drained=0 max_vif1_snapshot_drained=0")!=reset.npos);
}
''')
 subprocess.run(['c++',*(['-DPS2X_WII_SAMPLE_PROFILE'] if args.profile else []),'-std=c++20','-pthread','-fsanitize=address,undefined','-I'+str(p),'-I'+str(root/'ps2xRuntime/platform/wii'),'-I'+str(root/'ps2xRuntime/include'),str(p/'test.cpp'),str(root/'ps2xRuntime/platform/wii/ps2_wii_progress.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],cwd=p,check=True)
 print('PASS: independent observer, durable idle sample, bounded stop/restart, stop flag')
