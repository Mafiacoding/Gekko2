#!/usr/bin/env python3
import unittest
from run_scene_probe import inspect

PROFILE={'milestones':[{'name':'hub','pattern':r'E3HUB.GSC success=1'}], 'minimum_nonblack_pixels':1000}
FRAME='[GS_CAPTURE] seconds=4 width=640 height=224 nonblack=5000 hash=1\n'
INPUT='[HEADLESS_INPUT] poll=3 key=S\n[PAD_PACKET] bytes=f7,ff\n'
LOAD='[VFS_OPEN] path=/private/E3HUB.GSC success=1\n'
END='[HEADLESS_SUMMARY] valid_gs_frames=10 nonblack_frames=9\n'
class SceneProbeTests(unittest.TestCase):
 def test_requires_frames_after_load(self):
  self.assertFalse(inspect(INPUT+FRAME+LOAD+END,PROFILE)['matched'])
 def test_generated_input_is_not_delivery(self):
  self.assertFalse(inspect('[HEADLESS_INPUT] poll=3 key=S\n'+LOAD+FRAME+END,PROFILE)['matched'])
 def test_failed_open_is_not_milestone(self):
  self.assertFalse(inspect(INPUT+LOAD.replace('success=1','success=0')+FRAME+END,PROFILE)['matched'])
 def test_timeout_or_crash_without_summary_fails(self):
  self.assertFalse(inspect(INPUT+LOAD+FRAME,PROFILE)['matched'])
 def test_sanitizer_failure_fails(self):
  self.assertFalse(inspect(INPUT+LOAD+FRAME+END+'ERROR: AddressSanitizer: overflow',PROFILE)['matched'])
 def test_late_worker_failure_rejects_even_after_all_milestones(self):
  for error in ('Error during program execution: std::bad_alloc','[main] fatal exception: unknown','[terminate] std::exception: test'):
   result=inspect(INPUT+LOAD+FRAME+END+error,PROFILE)
   self.assertFalse(result['matched']);self.assertFalse(result['completed_normally']);self.assertTrue(result['runtime_error'])
 def test_valid_probe_preserves_visual_limit(self):
  result=inspect(INPUT+LOAD+FRAME+END,PROFILE)
  self.assertTrue(result['matched']);self.assertFalse(result['visible_image_correctness_verified'])
if __name__=='__main__':unittest.main()
