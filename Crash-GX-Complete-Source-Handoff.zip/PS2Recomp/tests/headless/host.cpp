#include "ps2_wii_host.h"
#include "gs_replay_trace.h"
#include <chrono>
#include <thread>
#include <map>
#include <vector>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <stdexcept>
#include <atomic>
#include <cmath>
#ifndef PS2_HEADLESS_BUILD_ID
#define PS2_HEADLESS_BUILD_ID "unversioned"
#endif
namespace {
 unsigned gsFrames=0,gsNonblack=0;double firstFrame=-1;
 using Clock=std::chrono::steady_clock;
 auto started=Clock::now();bool ready=false;std::atomic<bool>closed{false};double limit=240;
 struct Tex{unsigned w,h;std::vector<uint8_t>pixels;const uint8_t*view=nullptr;};std::map<unsigned,Tex> textures;unsigned next=1;
}
void PS2WiiBootstrap(){}
void PS2WiiCheckpoint(const char*s){std::fprintf(stderr,"[CHECKPOINT] %s\n",s);}
void InitWindow(int,int,const char*){started=Clock::now();ready=true;std::fprintf(stderr,"[HEADLESS] source=%s native_capture=1\n",PS2_HEADLESS_BUILD_ID);if(auto*s=std::getenv("PS2_HEADLESS_SECONDS"))limit=std::strtod(s,nullptr);}
void CloseWindow(){Ps2GsTrace::finish();closed=true;std::fprintf(stderr,"[HEADLESS_SUMMARY] valid_gs_frames=%u nonblack_frames=%u first_frame_seconds=%.3f\n",gsFrames,gsNonblack,firstFrame);}bool IsWindowReady(){return ready;}void SetConfigFlags(unsigned){}void SetTargetFPS(int){}
double GetTime(){return std::chrono::duration<double>(Clock::now()-started).count();}
bool WindowShouldClose(){bool stop=closed||GetTime()>=limit;if(stop)Ps2GsTrace::finish();return stop;}
float PS2WiiDisplayAspect(){return 4.0f/3.0f;}
int GetScreenWidth(){return 640;}int GetScreenHeight(){return 480;}float GetFrameTime(){return .02f;}
void BeginDrawing(){}void ClearBackground(Color){}void EndDrawing(){std::this_thread::sleep_for(std::chrono::milliseconds(20));}
Image GenImageColor(int w,int h,Color c){auto*p=static_cast<Color*>(std::malloc(size_t(w)*h*4));if(!p)throw std::bad_alloc();for(int i=0;i<w*h;++i)p[i]=c;return{p,w,h,1,7};}
void UnloadImage(Image i){std::free(i.data);}Texture2D LoadTextureFromImage(Image i){auto id=next++;Tex t{unsigned(i.width),unsigned(i.height),std::vector<uint8_t>(size_t(i.width)*i.height*4)};std::memcpy(t.pixels.data(),i.data,t.pixels.size());textures.emplace(id,std::move(t));return{id,i.width,i.height,1,7};}
void UnloadTexture(Texture2D t){textures.erase(t.id);}void UpdateTexture(Texture2D t,const void*p){auto&tgt=textures.at(t.id);auto&v=tgt.pixels;v.resize(size_t(tgt.w)*tgt.h*4);std::memcpy(v.data(),p,v.size());tgt.view=nullptr;}
void PS2WiiTextureView(Texture2D &t,const void*p,unsigned storageHeight){auto&v=textures.at(t.id);if(p){if(!storageHeight||storageHeight>512)throw std::runtime_error("Invalid borrowed frame height");v.h=storageHeight;t.height=int(storageHeight);}std::vector<uint8_t>().swap(v.pixels);v.view=static_cast<const uint8_t*>(p);}
void DrawTexturePro(Texture2D t,Rectangle,Rectangle,Vector2,float,Color){auto&v=textures.at(t.id);if(!v.view&&v.pixels.empty())throw std::runtime_error("Detached headless texture view");if(v.view){volatile auto byte=v.view[size_t(v.w)*v.h*4-1];(void)byte;}}
bool IsGamepadAvailable(int n){return n==0&&(std::getenv("PS2_HEADLESS_AUTO_START")||std::getenv("PS2_HEADLESS_BUTTON_POLLS")||std::getenv("PS2_HEADLESS_BUTTON_SCRIPT"));}
bool IsGamepadButtonDown(int n,int b){
 if(!IsGamepadAvailable(n))return false;
 static uint64_t poll=0;
 if(b==GAMEPAD_BUTTON_LEFT_FACE_UP)++poll;
 auto scripted=[&](const char*events,double position){
  for(const char*p=events;*p;){double begin=0,end=0;char key=0;int consumed=0;
   if(std::sscanf(p,"%lf:%lf:%c%n",&begin,&end,&key,&consumed)!=3||consumed<=0)break;
   if(position>=begin&&position<end&&((key=='S'&&b==GAMEPAD_BUTTON_MIDDLE_RIGHT)||(key=='X'&&b==GAMEPAD_BUTTON_RIGHT_FACE_DOWN))){
    std::fprintf(stderr,"[HEADLESS_INPUT] poll=%llu seconds=%.3f key=%c\n",(unsigned long long)poll,GetTime(),key);return true;
   }
   p+=consumed;if(*p==',')++p;else break;
  }return false;
 };
 if(auto*events=std::getenv("PS2_HEADLESS_BUTTON_POLLS"))return scripted(events,double(poll));
 if(auto*events=std::getenv("PS2_HEADLESS_BUTTON_SCRIPT"))return scripted(events,GetTime());
 if(std::getenv("PS2_HEADLESS_SINGLE_START"))return b==GAMEPAD_BUTTON_MIDDLE_RIGHT&&GetTime()>=8.0&&GetTime()<8.2;
 double phase=std::fmod(GetTime(),10.0);
 return (b==GAMEPAD_BUTTON_RIGHT_FACE_DOWN&&phase>=5.0&&phase<5.2)||(b==GAMEPAD_BUTTON_MIDDLE_RIGHT&&phase>=8.0&&phase<8.2);
}
float GetGamepadAxisMovement(int,int){return 0;}bool IsKeyDown(int){return false;}
void InitAudioDevice(){}void CloseAudioDevice(){}bool IsAudioDeviceReady(){return false;}
Wave LoadWaveFromMemory(const char*,const unsigned char*,int){throw std::runtime_error("Headless audio unavailable");}Sound LoadSoundFromWave(Wave){throw std::runtime_error("Headless audio unavailable");}
void UnloadWave(Wave){}void UnloadSound(Sound){}void PlaySound(Sound){}void StopSound(Sound){}bool IsSoundPlaying(Sound){return false;}void SetSoundPitch(Sound,float){}void SetSoundVolume(Sound,float){}
void PS2HeadlessCapture(const uint8_t*p,unsigned w,unsigned h){
 static uint64_t lastHash=0;static unsigned saved=0;static double lastSaved=-10;uint64_t hash=1469598103934665603ull;unsigned nonblack=0;
 for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x){auto*q=p+(size_t(y)*640+x)*4;nonblack+=bool(q[0]|q[1]|q[2]);for(unsigned i=0;i<3;++i){hash^=q[i];hash*=1099511628211ull;}}
 ++gsFrames;gsNonblack+=nonblack!=0;if(firstFrame<0)firstFrame=GetTime();
 if(hash==lastHash)return;lastHash=hash;std::fprintf(stderr,"[GS_CAPTURE] seconds=%.2f width=%u height=%u nonblack=%u hash=%016llx\n",GetTime(),w,h,nonblack,(unsigned long long)hash);
 if(!nonblack&&std::getenv("PS2_HEADLESS_CAPTURE_NONBLACK"))return;
 auto*output=std::getenv("PS2_HEADLESS_OUTPUT");if(!output||saved>=(std::getenv("PS2_HEADLESS_CAPTURE_LIMIT")?unsigned(std::strtoul(std::getenv("PS2_HEADLESS_CAPTURE_LIMIT"),nullptr,10)):32u)||(saved>=8&&GetTime()-lastSaved<2.0))return;lastSaved=GetTime();
 std::filesystem::create_directories(output);char name[64];std::snprintf(name,sizeof name,"/frame-%04u.ppm",saved++);auto path=std::string(output)+name;
 FILE*f=std::fopen(path.c_str(),"wb");if(!f)return;std::fprintf(f,"P6\n%u %u\n255\n",w,h);
 for(unsigned y=0;y<h;++y)for(unsigned x=0;x<w;++x)std::fwrite(p+(size_t(y)*640+x)*4,1,3,f);std::fclose(f);
}
