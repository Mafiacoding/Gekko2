#include "ps2_wii_host.h"
#include <atomic>
#include <cstdio>
extern "C" [[noreturn]] void __real_abort(void);
extern "C" [[noreturn]] void __real__Exit(int);
#if defined(PS2X_WII_NATIVE_GX)
extern "C" int PS2WiiGXDrain();
#endif
namespace {
 std::atomic_flag reporting=ATOMIC_FLAG_INIT;
 void record(const char *kind,int status){
  if(reporting.test_and_set())return;
  char text[80];std::snprintf(text,sizeof text,"process-%s status=%d",kind,status);
  PS2WiiCheckpoint(text);
 }
}
extern "C" [[noreturn]] void __wrap_abort(){record("abort",-1);__real_abort();}
extern "C" [[noreturn]] void __wrap__Exit(int status){
#if defined(PS2X_WII_NATIVE_GX)
 if(!PS2WiiGXDrain()){record("gx-drain-failed",status);__real_abort();}
#endif
 record("_Exit",status);__real__Exit(status);
}
