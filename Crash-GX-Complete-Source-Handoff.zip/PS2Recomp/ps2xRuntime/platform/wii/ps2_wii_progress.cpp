#include "ps2_wii_progress.h"
#include "ps2_wii_host.h"
#include "runtime/ps2_progress_policy.h"
#include <gccore.h>
#include <ogc/lwp_watchdog.h>
#include <atomic>
#include <cstdio>
#include <thread>
#include <unistd.h>
namespace {
 static_assert(std::atomic<uint32_t>::is_always_lock_free);
 std::atomic<uint32_t> pc{},ra{},sp{},cycles{},waitReason{},phase{},uiPhase{},eeCount{},uiCount{};
 std::atomic<uint32_t> frameWidth{},frameHeight{},frameBytes{};
 std::atomic<uint32_t> dmaSnapshotChannel{},dmaSnapshotBytes{};
 std::atomic<uint32_t> maxVif0Drained{},maxVif1Drained{};
 std::atomic<uint32_t> history[32]{};
 std::atomic<bool> stopping{false};
 std::thread observer;
 // Only the EE executor touches these throttle fields.
 uint32_t throttle=0;uint64_t lastYield=0;
 uint64_t startedAt=0;
#if defined(PS2X_WII_SAMPLE_PROFILE)
 // Only the observer writes these; the final read occurs after joining it.
 uint32_t phaseSamples[16]{},uiSamples[32]{},sampleCount=0,lastUnknownUi=0;
 void samplePhases(){
  const auto ee=phase.load(std::memory_order_relaxed);
  const auto ui=uiPhase.load(std::memory_order_relaxed);
  ++phaseSamples[ee<16?ee:15];++uiSamples[ui<32?ui:31];++sampleCount;
  if(ui>=32)lastUnknownUi=ui;
 }
#endif
 void writeSnapshot(unsigned seconds,const Ps2ProgressPolicy&policy,bool finalSnapshot=false){
    FILE*f=std::fopen("sd:/ps2recomp/progress.txt","w");
    if(f){
     uint32_t heap[3];PS2WiiHeapSnapshot(heap);
     uint32_t allocations[96];unsigned count=PS2WiiHeapInventory(allocations,32);
     for(unsigned i=0;i<count;++i)std::fprintf(f,"allocation ptr=%08lx bytes=%lu new_site=%08lx\n",(unsigned long)allocations[i*3],(unsigned long)allocations[i*3+1],(unsigned long)allocations[i*3+2]);
     std::fprintf(f,"failed_new_site=%08lx frame_width=%lu frame_height=%lu frame_bytes=%lu\n",(unsigned long)PS2WiiHeapFailureSite(),(unsigned long)frameWidth.load(),(unsigned long)frameHeight.load(),(unsigned long)frameBytes.load());
     std::fprintf(f,"dma_snapshot_channel=%08lx dma_snapshot_bytes=%lu\n",(unsigned long)dmaSnapshotChannel.load(),(unsigned long)dmaSnapshotBytes.load());
     std::fprintf(f,"max_vif0_snapshot_drained=%lu max_vif1_snapshot_drained=%lu\n",(unsigned long)maxVif0Drained.load(),(unsigned long)maxVif1Drained.load());
     std::fprintf(f,"mem2_payload=%lu mem2_peak=%lu failed_alloc_bytes=%lu\n",(unsigned long)heap[0],(unsigned long)heap[1],(unsigned long)heap[2]);
     std::fprintf(f,"seconds=%u state=%s ee_points=%lu ui_frames=%lu ee_quiet=%lu ui_quiet=%lu\npc=%08lx ra=%08lx sp=%08lx cycles_low=%lu wait=%lu ee_phase=%lu ui_phase=%lu\nrecent_pcs=",seconds,finalSnapshot?"STOPPED":policy.state(),(unsigned long)eeCount.load(),(unsigned long)uiCount.load(),(unsigned long)policy.eeQuiet,(unsigned long)policy.uiQuiet,(unsigned long)pc.load(),(unsigned long)ra.load(),(unsigned long)sp.load(),(unsigned long)cycles.load(),(unsigned long)waitReason.load(),(unsigned long)phase.load(),(unsigned long)uiPhase.load());
     uint32_t n=eeCount.load();for(unsigned i=0;i<32;++i)std::fprintf(f," %08lx",(unsigned long)history[(n+i)%32].load());
     std::fprintf(f,"\nSamples are independent; not a coherent guest snapshot.\n");
#if defined(PS2X_WII_SAMPLE_PROFILE)
     std::fprintf(f,"profile_hz=100 profile_samples=%lu\nwall_ee_phase_samples=",(unsigned long)sampleCount);
     for(unsigned i=0;i<16;++i)std::fprintf(f," %u:%lu",i,(unsigned long)phaseSamples[i]);
     std::fprintf(f,"\nwall_ui_phase_samples=");
     for(unsigned i=0;i<32;++i)std::fprintf(f," %u:%lu",i,(unsigned long)uiSamples[i]);
     std::fprintf(f,"\nprofile_unknown_ui_last=%08lx\n",(unsigned long)lastUnknownUi);
     std::fprintf(f,"Profile samples are wall-time phase occupancy, not CPU time or physical FPS. EE and UI overlap; do not add them.\n");
#endif
     std::fflush(f);std::fclose(f);
    }
 }
 void monitor(){
  // Wake briefly above the guest worker; sleep between samples. No guest/GS
  // locks, live-context reads or rendering in this thread.
  LWP_SetThreadPriority(LWP_GetSelf(),LWP_PRIO_HIGHEST);
  Ps2ProgressPolicy policy;
  for(unsigned seconds=0;!stopping.load();++seconds){
   if(seconds%5==0){
    writeSnapshot(seconds,policy);
   }
#if defined(PS2X_WII_SAMPLE_PROFILE)
   for(unsigned i=0;i<100&&!stopping.load();++i){samplePhases();usleep(10000);}
#else
   for(unsigned i=0;i<4&&!stopping.load();++i)usleep(250000);
#endif
   policy.observe(eeCount.load(),uiCount.load());
  }
 }
}
void PS2WiiProgressStart(){
#if defined(PS2X_WII_SAMPLE_PROFILE)
 for(auto &v:phaseSamples)v=0;for(auto &v:uiSamples)v=0;sampleCount=0;lastUnknownUi=0;
#endif
 dmaSnapshotChannel=0;dmaSnapshotBytes=0;maxVif0Drained=0;maxVif1Drained=0;startedAt=gettime();stopping=false;eeCount=0;uiCount=0;pc=0;ra=0;sp=0;cycles=0;waitReason=0;phase=0;uiPhase=0;for(auto &v:history)v=0;throttle=0;lastYield=gettime();observer=std::thread(monitor);}
void PS2WiiProgressStop(){stopping=true;if(observer.joinable())observer.join();Ps2ProgressPolicy finalPolicy;finalPolicy.observe(eeCount.load(),uiCount.load());writeSnapshot(unsigned(ticks_to_microsecs(gettime()-startedAt)/1000000),finalPolicy,true);}
bool PS2WiiProgressStopRequested(){return WindowShouldClose();}
void PS2WiiProgressPhase(uint32_t p){phase.store(p,std::memory_order_relaxed);}
void PS2WiiProgressUi(uint32_t p){uiPhase.store(p,std::memory_order_relaxed);if(p==1)uiCount.fetch_add(1,std::memory_order_relaxed);}
void PS2WiiProgressPoint(uint32_t p,uint32_t r,uint32_t s,uint32_t c,uint32_t w){
 pc.store(p,std::memory_order_relaxed);ra.store(r,std::memory_order_relaxed);sp.store(s,std::memory_order_relaxed);cycles.store(c,std::memory_order_relaxed);waitReason.store(w,std::memory_order_relaxed);
 auto n=eeCount.fetch_add(1,std::memory_order_relaxed);history[n%32].store(p,std::memory_order_relaxed);
 (void)PS2WiiServicePoll();
}

uint32_t PS2WiiProgressEnter(uint32_t p){return phase.exchange(p,std::memory_order_relaxed);}

bool PS2WiiServicePoll(){
 if((++throttle&127)==0){auto now=gettime();if(ticks_to_microsecs(now-lastYield)>=2000){lastYield=now;usleep(1000);}}
 return WindowShouldClose();
}

void PS2WiiProgressFrame(uint32_t w,uint32_t h,uint32_t b){frameWidth=w;frameHeight=h;frameBytes=b;}

void PS2WiiProgressDmaSnapshot(uint32_t channel,uint32_t bytes){dmaSnapshotChannel=channel;dmaSnapshotBytes=bytes;}

void PS2WiiProgressDmaDrained(uint32_t channel,uint32_t bytes){
 auto&maximum=channel==0x10008000u?maxVif0Drained:maxVif1Drained;
 auto old=maximum.load(std::memory_order_relaxed);
 while(old<bytes&&!maximum.compare_exchange_weak(old,bytes,std::memory_order_relaxed)){}
}
