#include <gccore.h>
#include <ogc/lwp_heap.h>
#include <ogc/mutex.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cerrno>
#include <atomic>
extern "C" __attribute__((weak)) uint32_t PS2WiiCurrentNewSite(){return 0;}
extern "C" __attribute__((weak)) void PS2WiiNewSitesEnable(){}
extern "C" __attribute__((weak)) bool PS2WiiPreferFastHeap(){return false;}
extern "C" void *__real_malloc(size_t);
extern "C" void *__real_calloc(size_t,size_t);
extern "C" void *__real_memalign(size_t,size_t);
extern "C" void *__real_realloc(void*,size_t);
extern "C" void __real_free(void*);
namespace {std::atomic<uint32_t> used{0},peak{0},failed{0},failedSite{0};heap_cntrl heap;mutex_t mutex;uintptr_t begin=0,end=0;bool ready=false;struct Header {void *base;size_t bytes;};
 bool owns(void *p){return ready&&uintptr_t(p)>=begin&&uintptr_t(p)<end;}
 void *allocate(size_t alignment,size_t bytes){
  if(!ready||alignment<sizeof(void*)||(alignment&(alignment-1))||bytes>SIZE_MAX-alignment-sizeof(Header))return nullptr;
  LWP_MutexLock(mutex);void *base=__lwp_heap_allocate(&heap,uint32_t(bytes+alignment+sizeof(Header)));LWP_MutexUnlock(mutex);if(!base)return nullptr;
  uintptr_t value=(uintptr_t(base)+sizeof(Header)+alignment-1)&~(alignment-1);auto *h=reinterpret_cast<Header*>(value)-1;h->base=base;h->bytes=bytes;auto current=used.fetch_add(uint32_t(bytes))+uint32_t(bytes);auto old=peak.load();while(current>old&&!peak.compare_exchange_weak(old,current)){}return reinterpret_cast<void*>(value);
 }
}
void PS2WiiHeapInit(){
 if(ready)return;begin=(uintptr_t(SYS_GetArena2Lo())+31)&~uintptr_t(31);end=uintptr_t(SYS_GetArena2Hi())&~uintptr_t(31);
 if(end<=begin+1024*1024)return;end-=256*1024;
 if(LWP_MutexInit(&mutex,false)!=0)return;
 if(!__lwp_heap_init(&heap,reinterpret_cast<void*>(begin),uint32_t(end-begin),32))return;
 SYS_SetArena2Lo(reinterpret_cast<void*>(end));ready=true;PS2WiiNewSitesEnable();
}
namespace {
 struct AllocationRecord{std::atomic<uintptr_t>ptr{0};std::atomic<uint32_t>bytes{0},site{0};};
 AllocationRecord records[64];
 void forget(void*p){if(!p)return;for(auto&r:records)if(r.ptr.load()==uintptr_t(p)){r.bytes=0;r.site=0;r.ptr=0;return;}}
 void*record(void*p,size_t n,uint32_t caller){
  const auto site=PS2WiiCurrentNewSite();if(site)caller=site;
  if(p&&n>=65536)for(auto&r:records){uintptr_t empty=0;if(r.ptr.compare_exchange_strong(empty,uintptr_t(p))){r.site=caller;r.bytes=uint32_t(n);break;}}
  if(!p){failed=uint32_t(n);failedSite=caller;}
  return p;
 }
}
extern "C" void *__wrap_malloc(size_t n){
 void*p=nullptr;
 if(n>=65536&&!PS2WiiPreferFastHeap()){p=allocate(32,n);if(!p)p=__real_malloc(n);}
 else{p=__real_malloc(n);if(!p)p=allocate(32,n);}
 return record(p,n,uint32_t(uintptr_t(__builtin_return_address(0))));
}
extern "C" void *__wrap_memalign(size_t a,size_t n){
 if(a<sizeof(void*)||(a&(a-1))){errno=EINVAL;return nullptr;}
 void*p=nullptr;
 if(n>=65536&&!PS2WiiPreferFastHeap()){p=allocate(std::max<size_t>(32,a),n);if(!p)p=__real_memalign(a,n);}
 else{p=__real_memalign(a,n);if(!p)p=allocate(std::max<size_t>(32,a),n);}
 return record(p,n,uint32_t(uintptr_t(__builtin_return_address(0))));
}
extern "C" void __wrap_free(void *p){forget(p);if(owns(p)){auto *h=static_cast<Header*>(p)-1;used.fetch_sub(uint32_t(h->bytes));LWP_MutexLock(mutex);__lwp_heap_free(&heap,h->base);LWP_MutexUnlock(mutex);}else __real_free(p);}
extern "C" void *__wrap_calloc(size_t n,size_t bytes){if(bytes&&n>SIZE_MAX/bytes){errno=ENOMEM;return nullptr;}size_t total=n*bytes;void*p=__wrap_malloc(total);if(p)std::memset(p,0,total);return p;}
extern "C" void *__wrap_realloc(void *p,size_t n){
 if(!p)return __wrap_malloc(n);if(!n){__wrap_free(p);return nullptr;}
 if(!owns(p)){void*q=__real_realloc(p,n);if(q){forget(p);return record(q,n,uint32_t(uintptr_t(__builtin_return_address(0))));}return record(nullptr,n,uint32_t(uintptr_t(__builtin_return_address(0))));}
 auto*h=static_cast<Header*>(p)-1;void*q=__wrap_malloc(n);if(q){std::memcpy(q,p,std::min(n,h->bytes));__wrap_free(p);}return q;
}
unsigned PS2WiiHeapInventory(uint32_t*out,unsigned cap){
 unsigned n=0;for(auto&r:records){auto p=r.ptr.load();auto b=r.bytes.load();auto c=r.site.load();if(p&&b&&r.ptr.load()==p&&n<cap){out[n*3]=uint32_t(p);out[n*3+1]=b;out[n*3+2]=c;++n;}}return n;
}

void PS2WiiHeapSnapshot(uint32_t*out){out[0]=used.load();out[1]=peak.load();out[2]=failed.load();}

uint32_t PS2WiiHeapFailureSite(){return failedSite.load();}
