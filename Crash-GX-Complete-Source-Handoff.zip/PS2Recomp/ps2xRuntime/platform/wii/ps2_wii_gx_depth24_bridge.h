// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
#include "core/hw/gs_gx.h"
int ps2x_gx_depth24_prepare(const gs_gx_flat_draw*);
int ps2x_gx_depth24_seed(const void*,uint32_t,uint32_t,uint32_t,uint32_t);
int ps2x_gx_depth24_draw(const gs_gx_flat_draw*,const void*,uint32_t,uint32_t,uint32_t,uint32_t,const float*,const float*);
const uint8_t *ps2x_gx_depth24_read(uint32_t,uint32_t,uint32_t,uint32_t);
int ps2x_gx_depth24_metadata(uint8_t**,uint8_t**,uint32_t*,uint32_t*);
#ifdef __cplusplus
}
#endif
