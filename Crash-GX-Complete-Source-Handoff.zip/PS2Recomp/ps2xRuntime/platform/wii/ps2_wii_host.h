#pragma once
#include <cstdint>
struct Color {uint8_t r,g,b,a;};
struct Vector2 {float x,y;};
struct Rectangle {float x,y,width,height;};
struct Image {void *data;int width,height,mipmaps,format;};
struct Texture2D {unsigned id;int width,height,mipmaps,format;};
struct Wave {unsigned frameCount,sampleRate,sampleSize,channels;void *data;};
struct Sound {unsigned id;};
inline constexpr Color BLACK{0,0,0,255},WHITE{255,255,255,255},BLANK{0,0,0,0},MAGENTA{255,0,255,255};
inline constexpr int FLAG_WINDOW_RESIZABLE=0;
enum {GAMEPAD_BUTTON_LEFT_FACE_UP=1,GAMEPAD_BUTTON_LEFT_FACE_DOWN,GAMEPAD_BUTTON_LEFT_FACE_LEFT,GAMEPAD_BUTTON_LEFT_FACE_RIGHT,GAMEPAD_BUTTON_RIGHT_FACE_DOWN,GAMEPAD_BUTTON_RIGHT_FACE_RIGHT,GAMEPAD_BUTTON_RIGHT_FACE_LEFT,GAMEPAD_BUTTON_RIGHT_FACE_UP,GAMEPAD_BUTTON_LEFT_TRIGGER_1,GAMEPAD_BUTTON_RIGHT_TRIGGER_1,GAMEPAD_BUTTON_LEFT_TRIGGER_2,GAMEPAD_BUTTON_RIGHT_TRIGGER_2,GAMEPAD_BUTTON_MIDDLE_LEFT,GAMEPAD_BUTTON_MIDDLE_RIGHT,GAMEPAD_BUTTON_LEFT_THUMB,GAMEPAD_BUTTON_RIGHT_THUMB};
enum {GAMEPAD_AXIS_LEFT_X,GAMEPAD_AXIS_LEFT_Y,GAMEPAD_AXIS_RIGHT_X,GAMEPAD_AXIS_RIGHT_Y};
enum {KEY_ONE=101,KEY_THREE,KEY_LEFT_CONTROL,KEY_RIGHT_CONTROL,KEY_A=1,KEY_C,KEY_D,KEY_DOWN,KEY_E,KEY_ENTER,KEY_ESCAPE,KEY_KP_0,KEY_KP_1,KEY_LEFT,KEY_LEFT_SHIFT,KEY_Q,KEY_RIGHT,KEY_RIGHT_SHIFT,KEY_S,KEY_SPACE,KEY_TAB,KEY_UP,KEY_V,KEY_W,KEY_X,KEY_Z};
void PS2WiiBootstrap();
void PS2WiiCheckpoint(const char *stage);
void InitWindow(int,int,const char*);void CloseWindow();bool IsWindowReady();
void SetConfigFlags(unsigned);void SetTargetFPS(int);bool WindowShouldClose();
float PS2WiiDisplayAspect();
int GetScreenWidth();int GetScreenHeight();double GetTime();float GetFrameTime();
void BeginDrawing();void ClearBackground(Color);void EndDrawing();
Image GenImageColor(int,int,Color);void UnloadImage(Image);
Texture2D LoadTextureFromImage(Image);void UnloadTexture(Texture2D);void UpdateTexture(Texture2D,const void*);
// Borrowed upload: caller keeps 640-pixel-stride RGBA storage alive until
// the next call. storageHeight is the number of backed rows for non-null data.
// nullptr detaches it; only the single host/UI thread may use this API.
void PS2WiiTextureView(Texture2D&,const void*,unsigned storageHeight=0);
void DrawTexturePro(Texture2D,Rectangle,Rectangle,Vector2,float,Color);
bool IsGamepadAvailable(int);bool IsGamepadButtonDown(int,int);float GetGamepadAxisMovement(int,int);bool IsKeyDown(int);
void InitAudioDevice();void CloseAudioDevice();bool IsAudioDeviceReady();
Wave LoadWaveFromMemory(const char*,const unsigned char*,int);Sound LoadSoundFromWave(Wave);
void UnloadWave(Wave);void UnloadSound(Sound);void PlaySound(Sound);void StopSound(Sound);
bool IsSoundPlaying(Sound);void SetSoundPitch(Sound,float);void SetSoundVolume(Sound,float);
