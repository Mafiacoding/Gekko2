// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <gccore.h>
#include <malloc.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <stdexcept>
#if defined(PS2X_WII)
#include "ps2_wii_progress.h"
#endif
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_hybrid_backend.h"
#include "runtime/gs/gs_triangle_coverage.h"
#include "runtime/gs/gs_native_sprite_plan.h"
#include "runtime/gs/gs_native_projective_plan.h"
#include "runtime/gs/gs_native_fragment_plan.h"
#include "runtime/gs/gs_native_whole_triangle.h"
#include "runtime/gs/ps2_gs_memory.h"
#if defined(PS2X_WII_GX_DEPTH24)
#include "ps2_wii_gx_depth24_engine.h"
#endif
extern "C" {
#include "core/hw/gs_gx.h"
#include "core/hw/gs_mem.h"
extern volatile uint32_t PS2WiiGXWholeTriangles[8];
extern volatile uint32_t PS2WiiGXStateFamilies[64];
extern volatile uint32_t PS2WiiGXDepth24Stats[4];
int ps2x_gx_bind(uint8_t*,uint32_t);int ps2x_gx_unbind(void);int ps2x_gx_init(void);
int ps2x_gx_source_barrier(void);
int ps2x_gx_source_disjoint(uint32_t,uint32_t);
int ps2x_gx_linear_ready(void);
int ps2x_gx_draw_linear_fragments(const gs_gx_flat_draw*,const void*,uint32_t,uint32_t,const float*,uint32_t,uint32_t,uint32_t,uint32_t,int,uint32_t,uint32_t,
 int(*)(void*,uint32_t,uint32_t,uint32_t,uint8_t*,uint8_t*,uint8_t*),void*,int*,const float*);
int ps2x_gx_draw_projective(const gs_gx_flat_draw*,const void*,uint32_t,uint32_t,const float*,uint32_t,uint32_t,int,int);
int ps2x_gx_source_alpha(const gs_gx_flat_draw*,const uint8_t*,uint32_t,uint32_t,const int32_t*,const int32_t*,int32_t,int32_t);
int ps2x_gx_draw_native_flat(const gs_gx_flat_draw*);
int ps2x_gx_draw_native_texture(const gs_gx_flat_draw*,const void*,uint32_t,uint32_t,float,float,float,float,float,float,int,int);
int ps2x_gx_draw_native_subtract_flat(const gs_gx_flat_draw*);
}
#ifndef PS2X_GX_BOOT
#define PS2X_GX_BOOT(message) ((void)0)
#endif
#ifndef PS2X_GX_STATUS
#define PS2X_GX_STATUS(a,b,c,d,e,f,g) ((void)0)
#endif
#ifndef PS2X_GX_SUBTRACTED
#define PS2X_GX_SUBTRACTED(n) ((void)0)
#endif
#ifndef PS2X_GX_UNTEXTURED
#define PS2X_GX_UNTEXTURED(total,constant) ((void)0)
#endif
#ifndef PS2X_GX_SOURCE_TILES
#define PS2X_GX_SOURCE_TILES(bytes,fences) ((void)0)
#endif
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES) && !defined(PS2X_WII_SOURCE_IMAGE_CACHE)
#error Immutable source tiles require the exact source image cache
#endif
#ifndef PS2X_GX_ADMISSION
#define PS2X_GX_ADMISSION(p) ((void)0)
#endif
#ifndef PS2X_GX_SKIPPED
#define PS2X_GX_SKIPPED(n) ((void)0)
#endif
#ifndef PS2X_GX_LINEAR
#define PS2X_GX_LINEAR(p) ((void)0)
#endif
#ifndef PS2X_GX_FAST_UNTEXTURED
#define PS2X_GX_FAST_UNTEXTURED 0
#endif
#ifndef PS2X_GX_CONSTANT_UNTEXTURED
#define PS2X_GX_CONSTANT_UNTEXTURED 0
#endif
#ifndef PS2X_GX_WHOLE_TRIANGLES
#define PS2X_GX_WHOLE_TRIANGLES 0
#endif
#ifndef PS2X_GX_FAST_LINEAR
#define PS2X_GX_FAST_LINEAR 0
#endif
// Same driver for synthetic GX differential tests and the opt-in Wii build.
class PS2WiiGXTextureDriver final:public GSNativeDrawDriver
{
    // Immutable images remain alive until the ring wraps and its GX consumer
    // fence completes. Source changes do not require a framebuffer readback.
    struct CropImage {
        std::array<uint64_t,6> key{};
        unsigned offset=0,width=0,height=0,alpha=0;
        bool valid=false,uniform=false;
    };
    std::array<CropImage,256> cropImages{};
    unsigned cropCursor=0;
    uint8_t *cropTiles=nullptr;
#if defined(PS2X_WII_GX_DEPTH24)
    std::unique_ptr<PS2WiiGXDepth24Engine> depth24;
    void DepthStats(){if(depth24){PS2WiiGXDepth24Stats[0]=depth24->submissions;PS2WiiGXDepth24Stats[1]=depth24->resolutions;PS2WiiGXDepth24Stats[2]=depth24->fences;PS2WiiGXDepth24Stats[3]=depth24->tiles;}}
#endif
    GSCpuBackend *sampler;uint8_t *tiles=nullptr;bool bound=false,hostDirty=false;
    std::array<uint64_t,6> previousKey{};bool previousKeyValid=false;
    std::vector<uint32_t> previous;unsigned previousWidth=0,previousHeight=0,sourceKind=0;
    uint8_t *projectiveTiles=nullptr;
    uint64_t imageEpoch=0;
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
    struct SourceSpan { uint32_t offset,size; };
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
    struct SourceTileFree { void operator()(uint8_t *p)const noexcept{std::free(p);} };
#endif
    struct SourceImage {
        std::array<uint64_t,6> key{};
        std::vector<uint8_t> source;
        std::vector<uint32_t> rgba;
        std::vector<uint16_t> palette;
        std::vector<SourceSpan> spans;
        unsigned retainedBytes=0;
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        std::unique_ptr<uint8_t,SourceTileFree> tiles;
        uint64_t lastUse=0;
        bool uploaded=false;
#endif
        bool valid=false;
    };
    std::array<SourceImage,16> sourceImages{};
    unsigned sourceCursor=0,sourceRetainedBytes=0;
    const uint8_t *sourceVram=nullptr;
    uint64_t sourcePaletteRevision=UINT64_MAX;
    std::vector<uint16_t> sourcePalette;
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
    SourceImage *decodedSourceImage=nullptr,*activeLinearImage=nullptr;
    uint64_t sourceUses=0,sourceCompleted=0;
    void FenceSourceImages(){
        if(sourceUses==sourceCompleted)return;
        if(!ps2x_gx_source_barrier())throw std::runtime_error("GX source image lifetime fence failed");
        sourceCompleted=sourceUses;++sourceTileFences;
    }
    void MarkSourceUse(SourceImage &image){
        if(sourceUses==UINT64_MAX){FenceSourceImages();for(auto &entry:sourceImages)entry.lastUse=0;sourceUses=sourceCompleted=0;}
        image.lastUse=++sourceUses;
    }
    uint8_t *SourceTilePixels(SourceImage &image,unsigned width,unsigned height){
        if(image.tiles)return image.tiles.get();
        const unsigned bytes=width*height*4u;
        if(image.rgba.size()!=size_t(width)*height||image.retainedBytes+bytes+sourcePalette.capacity()*2u>512u*1024u)return nullptr;
        while(sourceRetainedBytes+bytes+sourcePalette.capacity()*2u>512u*1024u){
            auto &victim=sourceImages[sourceCursor++%sourceImages.size()];if(&victim!=&image)EvictSourceImage(victim);
        }
        auto *pixels=static_cast<uint8_t*>(memalign(32,bytes));if(!pixels)throw std::bad_alloc();
        image.tiles.reset(pixels);
        for(unsigned y=0;y<height;++y)for(unsigned x=0;x<width;++x){
            const uint32_t pixel=image.rgba[size_t(y)*width+x];
            const unsigned k=((y/4)*(width/4)+x/4)*64+(y&3)*8+(x&3)*2;
            pixels[k]=pixel>>24;pixels[k+1]=pixel;pixels[k+32]=pixel>>8;pixels[k+33]=pixel>>16;
        }
        image.retainedBytes+=bytes;sourceRetainedBytes+=bytes;return pixels;
    }
#endif
    void ClearSourceImages(){
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        FenceSourceImages();sourceUses=sourceCompleted=0;decodedSourceImage=activeLinearImage=nullptr;
#endif
        for(auto &image:sourceImages)image=SourceImage{};sourceCursor=0;sourceRetainedBytes=0;sourcePaletteRevision=UINT64_MAX;std::vector<uint16_t>().swap(sourcePalette);
    }
    void EvictSourceImage(SourceImage &image){
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        if(image.lastUse>sourceCompleted)FenceSourceImages();
#endif
        sourceRetainedBytes-=image.retainedBytes;image=SourceImage{};
    }
#endif
    std::array<uint64_t,6> projectiveKey{};
    bool projectiveValid=false;
    unsigned projectiveAlpha=0;bool projectiveUniform=false;
    unsigned linearAlpha=0,linearMaxAlpha=0;bool linearUniform=false;
    mutable uint64_t rangeKey=0;mutable bool rangeValid=false;
    mutable uint32_t rangeLo=0,rangeHi=0;
    static bool ResidentTarget(const GSFrameReg &f){
        // The resident owner uses a complete 480-row surface. A small valid
        // primitive near VRAM's end does not make that surface representable.
        // Reject before submission rather than turning a layout miss into Fault.
        return f.fbw&&f.fbw<=10&&f.fbp<512&&unsigned(f.fbp)+unsigned(f.fbw)*15u<=512;
    }
    void InvalidateImages(){if(imageEpoch!=UINT64_MAX)++imageEpoch;projectiveValid=false;previousKeyValid=false;}
    bool DecodeImage(const GSDrawState &s,uint64_t clut,uint32_t lo,uint32_t hi,std::vector<uint32_t> &rgba){
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        decodedSourceImage=nullptr;
#endif
        // Called only after the canonical sampler proves its retained page
        // coherent and the native path excludes every pending RGB/Z source
        // overlap. Compare exact backing bytes across unrelated CPU writes or
        // resolves; an epoch alone must never authorize reuse.
        const auto &t=s.context.tex0;
        const bool indexed=t.psm==GS_PSM_T8||t.psm==GS_PSM_T4||t.psm==GS_PSM_T8H||t.psm==GS_PSM_T4HL||t.psm==GS_PSM_T4HH;
        if(indexed&&sourcePaletteRevision!=clut){
            if(!sampler->SnapshotNativeClut(sourcePalette))return false;sourcePaletteRevision=clut;
            while(sourceRetainedBytes+sourcePalette.capacity()*2u>512u*1024u)EvictSourceImage(sourceImages[sourceCursor++%sourceImages.size()]);
        }
        const std::array<uint64_t,6> key={0,rangeKey,
            uint64_t(t.cpsm)|(uint64_t(t.csm)<<8)|(uint64_t(t.csa)<<16),
            uint64_t(s.texa.ta0)|(uint64_t(s.texa.ta1)<<8)|(uint64_t(s.texa.aem)<<16),0,0};
        const bool bounded=sourceVram&&lo<hi&&hi<=4u*1024u*1024u;
        if(bounded)for(auto &image:sourceImages){
            if(!image.valid||image.key!=key||(indexed&&image.palette!=sourcePalette))continue;
            size_t cursor=0;bool equal=true;
            for(const auto &span:image.spans){
                if(std::memcmp(image.source.data()+cursor,sourceVram+span.offset,span.size)!=0){equal=false;break;}
                cursor+=span.size;
            }
            if(equal){
                rgba=image.rgba;++decodeReuses;
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
                decodedSourceImage=&image;
#endif
                return true;
            }
        }
#endif
        if(!sampler->SnapshotCoherentNativeImage(s,rgba))return false;
        ++decodes;
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
        if(bounded){
            // Compare only touched physical 256-byte blocks, not padding in
            // their 8-KiB page envelopes. Merge adjacent blocks for fast copies.
            const unsigned blockW=t.psm==GS_PSM_T4?32:t.psm==GS_PSM_T8||t.psm==GS_PSM_CT16||t.psm==GS_PSM_CT16S||t.psm==GS_PSM_Z16||t.psm==GS_PSM_Z16S?16:8;
            const unsigned blockH=t.psm==GS_PSM_T4||t.psm==GS_PSM_T8?16:8;
            std::vector<uint32_t> blocks;
            for(unsigned y=0;y<s.textureHeight;y+=blockH)for(unsigned x=0;x<s.textureWidth;x+=blockW){
                uint32_t address=0;if(!GSMem::TextureByteAddress(t.psm,t.tbp0,t.tbw,x,y,address))return true;
                blocks.push_back(address&~255u);
            }
            std::sort(blocks.begin(),blocks.end());blocks.erase(std::unique(blocks.begin(),blocks.end()),blocks.end());
            std::vector<SourceSpan> spans;
            for(auto address:blocks){
                if(!spans.empty()&&spans.back().offset+spans.back().size==address)spans.back().size+=256;
                else spans.push_back({address,256});
            }
            const unsigned rawBytes=blocks.size()*256u;
            const unsigned needed=rawBytes+rgba.size()*4u+spans.capacity()*sizeof(SourceSpan)+(indexed?sourcePalette.size()*2u:0u);
            const unsigned budget=512u*1024u-sourcePalette.capacity()*2u;
            if(needed>budget)return true;
            auto &image=sourceImages[sourceCursor++%sourceImages.size()];EvictSourceImage(image);
            while(sourceRetainedBytes+needed>budget)EvictSourceImage(sourceImages[sourceCursor++%sourceImages.size()]);
            image.source.resize(rawBytes);image.rgba=rgba;image.spans=std::move(spans);image.key=key;
            if(indexed)image.palette=sourcePalette;
            size_t cursor=0;for(const auto &span:image.spans){std::memcpy(image.source.data()+cursor,sourceVram+span.offset,span.size);cursor+=span.size;}
            image.retainedBytes=image.source.capacity()+image.rgba.capacity()*4u+image.spans.capacity()*sizeof(SourceSpan)+image.palette.capacity()*2u;
            sourceRetainedBytes+=image.retainedBytes;image.valid=true;
            while(sourceRetainedBytes>budget)EvictSourceImage(sourceImages[sourceCursor++%sourceImages.size()]);
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
            if(image.valid)decodedSourceImage=&image;
#endif
        }
#endif
        return true;
    }
    bool ImageRange(const GSDrawState &s,uint32_t &lo,uint32_t &hi)const{
        const auto &t=s.context.tex0;
        if(t.tw>7||t.th>7||s.textureWidth!=(1u<<t.tw)||s.textureHeight!=(1u<<t.th)||t.tbp0>=16384||t.tbw>63)return false;
        const uint64_t key=uint64_t(t.tbp0)|(uint64_t(t.tbw)<<14)|(uint64_t(t.psm)<<20)|(uint64_t(t.tw)<<26)|(uint64_t(t.th)<<30);
        if(!rangeValid||rangeKey!=key){
            uint32_t low=UINT32_MAX,high=0;
            // Each logical block occupies one contiguous physical 256-byte
            // block, even with a non-page-aligned TBP and VRAM wrapping.
            const unsigned blockW=t.psm==GS_PSM_T4?32:t.psm==GS_PSM_T8||t.psm==GS_PSM_CT16||t.psm==GS_PSM_CT16S||t.psm==GS_PSM_Z16||t.psm==GS_PSM_Z16S?16:8;
            const unsigned blockH=t.psm==GS_PSM_T4||t.psm==GS_PSM_T8?16:8;
            for(unsigned y=0;y<s.textureHeight;y+=blockH)for(unsigned x=0;x<s.textureWidth;x+=blockW){
                uint32_t a=0;if(!GSMem::TextureByteAddress(t.psm,t.tbp0,t.tbw,x,y,a))return false;
                a&=~8191u;low=std::min(low,a);high=std::max(high,a+8192);
            }
            rangeLo=low;rangeHi=high;rangeKey=key;rangeValid=true;
        }
        lo=rangeLo;hi=rangeHi;return true;
    }
    static int FragmentRow(void *opaque,uint32_t row,uint32_t left,uint32_t right,uint8_t *actions,uint8_t *alpha,uint8_t *stored){
#if defined(PS2X_WII_GX_PROFILE_FAMILIES) && defined(PS2X_WII)
        PS2WiiProgressScope permissionsScope(15);
#endif
        return GSNativeFragmentPlan::Row(opaque,row,left,right,actions,alpha,stored);
    }
    unsigned linearStage=1;
    Result TryLinear(const GSPrimitiveBatch &b){
        linearStage=1;
        const auto &s=b.state;const auto &c=s.context;const auto &t=c.tex0;
        if(s.prim.fge||s.prim.aa1||c.frame.psm>1||c.frame.fbmsk||(c.test&0x4000)||
           !(s.colclamp&1)||!ResidentTarget(c.frame)||((c.tex1>>2)&7)||t.tfx>3||t.tcc>1)return Result::Unsupported;
        const unsigned ztest=(c.test>>17)&3;
        const bool needZ=ztest>=2||(!c.zbuf.zmask&&ztest==1);
        if(c.zbuf.zbp>=512||(needZ&&c.zbuf.psm!=GS_PSM_Z32&&c.zbuf.psm!=GS_PSM_Z24&&c.zbuf.psm!=GS_PSM_Z16&&c.zbuf.psm!=GS_PSM_Z16S))return Result::Unsupported;
        for(unsigned i=0;i<3;++i)if(!std::isfinite(b.vertices[i].z)||b.vertices[i].z<0||b.vertices[i].z>4294963200.)return Result::Unsupported;
        const uint64_t equation=c.alpha&((uint64_t(255)<<32)|255);
        const bool copy=(c.alpha&3)==((c.alpha>>2)&3)&&((c.alpha>>6)&3)==0;
        unsigned blend=0,fix=(c.alpha>>32)&255;
        if(s.prim.abe&&!copy){
            if((equation&255)==0x44)blend=2;
            else if((equation&255)==0x64&&fix<=128)blend=1;
            else if(equation==((uint64_t(128)<<32)|0x68))blend=3;
            else return Result::Unsupported;
        }
        linearStage=2;
        GSNativeLinearPlan plan;if(!GSNativeLinearPlan::Prepare(b,plan))return Result::Unsupported;
        linearStage=3;
        if(unsigned(plan.x+plan.width)>c.frame.fbw*64u||
           !gs_gx_target_valid(4*1024*1024,c.frame.fbp*2048,c.frame.fbw*64,plan.x,plan.y,plan.width,plan.height))return Result::Unsupported;
        // Physical 8 KiB envelopes include padded/seeded color tiles. No CPU Z
        // access may overlap current color or an older resident target.
        const unsigned colorLo=c.frame.fbp+(plan.y/32)*c.frame.fbw+plan.x/64;
        const unsigned colorHi=c.frame.fbp+((plan.y+plan.height-1)/32)*c.frame.fbw+(plan.x+plan.width-1)/64+1;
        if(colorHi>512)return Result::Unsupported;
        uint32_t lo=0,hi=0;
        if(s.prim.tme&&(!ImageRange(s,lo,hi)||!(hi<=colorLo*8192||lo>=colorHi*8192)||!ps2x_gx_source_disjoint(lo,hi)))return Result::Unsupported;
        if(needZ){
            uint32_t low=UINT32_MAX,high=0;
            // Logical Z pages are 64x32 for 32/24 and 64x64 for 16 bit.
            const unsigned pageHeight=(c.zbuf.psm==GS_PSM_Z16||c.zbuf.psm==GS_PSM_Z16S)?64:32;
            for(unsigned y=plan.y/pageHeight;y<=unsigned(plan.y+plan.height-1)/pageHeight;++y)
             for(unsigned x=plan.x/64;x<=unsigned(plan.x+plan.width-1)/64;++x){
              const unsigned page=c.zbuf.zbp+y*c.frame.fbw+x;
              if(page>=512)return Result::Unsupported;low=std::min(low,page*8192);high=std::max(high,(page+1)*8192);
             }
            if(!(high<=colorLo*8192||low>=colorHi*8192)||!ps2x_gx_source_disjoint(low,high)||
               (s.prim.tme&&!(high<=lo||low>=hi)))return Result::Unsupported;
        }
        linearStage=4;
        const bool rawReuse=s.prim.tme&&sourceKind==2&&previousKeyValid;
        uint64_t clut=0;
        if(s.prim.tme&&!sampler->GetCoherentNativeImageStamp(s,clut))return Result::Unsupported;
        const std::array<uint64_t,6> key={imageEpoch,clut,rangeKey,
         uint64_t(t.cpsm)|(uint64_t(t.csm)<<6)|(uint64_t(t.csa)<<7),
         uint64_t(s.texa.ta0)|(uint64_t(s.texa.ta1)<<8)|(uint64_t(s.texa.aem)<<16),0};
        const bool reuse=rawReuse&&previousKey==key;
        // These register states exclude every RGB/alpha write independently
        // of sampled texture alpha. Preserve guest sampling and required Z work,
        // but never decode/tile/upload an image that GX cannot consume.
        const bool alphaNever=(c.test&1)&&((c.test>>1)&7)==0;
        const unsigned alphaFail=(c.test>>12)&3;
        const bool registerDiscard=ztest==0||(alphaNever&&(alphaFail==0||alphaFail==2));
        bool depthDiscard=false;
        if(!registerDiscard&&!reuse&&s.prim.tme&&ztest>=2&&unsigned(s.textureWidth)*s.textureHeight>=1024){
            // Small hidden triangles need no complete texture image. Probe only
            // current CPU Z, with alpha disabled and every write suppressed.
            // Stop at the first passing row; never change guest depth or RGB.
            auto probeBatch=b;probeBatch.state.prim.tme=false;probeBatch.state.context.zbuf.zmask=true;
            probeBatch.state.context.test&=~uint64_t(1);
            GSNativeFragmentPlan probe;probe.batch=&probeBatch;probe.plan=&plan;probe.sampler=sampler;
            uint8_t actions[640],alpha[640],stored[640];depthDiscard=true;
            for(unsigned row=0;row<unsigned(plan.height)&&depthDiscard;++row)if(plan.left[row]<plan.right[row]){
                if(!FragmentRow(&probe,row,plan.left[row],plan.right[row],actions,alpha,stored))return Result::Fault;
                for(unsigned x=plan.left[row];x<plan.right[row];++x)if(actions[x]&GSCpuBackend::NativeRgb){depthDiscard=false;break;}
            }
        }
        if(registerDiscard||depthDiscard){
            if(s.prim.tme&&!sampler->CommitCoherentNativeSample(s,plan.firstSample[0],plan.firstSample[1],plan.firstSample[2]))return Result::Fault;
            if(!depthDiscard&&ztest!=0&&alphaNever&&alphaFail==2){
                auto depthBatch=b;depthBatch.state.prim.tme=false;
                GSNativeFragmentPlan depth;depth.batch=&depthBatch;depth.plan=&plan;depth.sampler=sampler;
                uint8_t actions[640],alpha[640],stored[640];
                for(unsigned row=0;row<unsigned(plan.height);++row)if(plan.left[row]<plan.right[row]){
                    if(!FragmentRow(&depth,row,plan.left[row],plan.right[row],actions,alpha,stored))return Result::Fault;
                }
                depthTested+=depth.depth.tested;depthRejected+=depth.depth.rejected;depthWritten+=depth.depth.written;
            }
            if(s.prim.tme&&!sampler->CommitCoherentNativeSample(s,plan.lastSample[0],plan.lastSample[1],plan.lastSample[2]))return Result::Fault;
            // Z may have changed a source cached by a previous primitive.
            projectiveValid=false;previousKeyValid=false;
            ++linearOperations;++metadataOperations;++metadataWithoutImage;PS2X_GX_SKIPPED(metadataWithoutImage);
            return Result::MetadataOnly;
        }
        if(s.prim.tme&&!reuse){
            if(!DecodeImage(s,clut,lo,hi,previous))return Result::Unsupported;
        }
        GSNativeFragmentPlan fragments;fragments.batch=&b;fragments.plan=&plan;fragments.sampler=sampler;fragments.image=&previous;
        if(s.prim.tme){
            if(!reuse){linearAlpha=previous[0]>>24;linearMaxAlpha=0;linearUniform=true;
                for(auto pixel:previous){const unsigned a=pixel>>24;linearUniform&=a==linearAlpha;linearMaxAlpha=std::max(linearMaxAlpha,a);}}
            fragments.uniformAlpha=linearAlpha;fragments.uniform=linearUniform;
        }
        // GX's ordinary blend coefficients cannot represent As > 128. Prove a
        // conservative primitive-wide alpha bound before any Z/cache mutation.
        linearStage=5;
        if(blend==2){
            unsigned va=s.prim.iip?std::max({b.vertices[0].a,b.vertices[1].a,b.vertices[2].a}):b.vertices[2].a;
            if(s.prim.iip)va=std::min(255u,va+1);unsigned ta=0;
            if(s.prim.tme&&t.tcc)ta=linearMaxAlpha;
            const unsigned maxAlpha=!s.prim.tme||!t.tcc?va:t.tfx==0?std::min(255u,(ta*va)>>7):t.tfx==2?std::min(255u,ta+va):ta;
            if(maxAlpha>128)return Result::Unsupported;
        }
        linearStage=6;
        gs_gx_flat_draw d{};d.bp=c.frame.fbp*2048;d.bw=c.frame.fbw*64;d.psm=c.frame.psm;
        d.x=plan.x;d.y=plan.y;d.width=plan.width;d.height=plan.height;
        for(unsigned y=0;y<d.height;++y){d.left[y]=plan.left[y];d.right[y]=plan.right[y];}
        if(d.x+d.width>d.bw||!gs_gx_target_valid(4*1024*1024,d.bp,d.bw,d.x,d.y,d.width,d.height))return Result::Unsupported;
        if(!ps2x_gx_linear_ready())return Result::Unsupported;
        const uint8_t *drawPixels=tiles;bool sourceUpload=!reuse;
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        SourceImage *drawImage=s.prim.tme?(reuse?activeLinearImage:decodedSourceImage):nullptr;
        if(drawImage){
            if(!drawImage->valid)return Result::Fault;
            if(auto *pixels=SourceTilePixels(*drawImage,s.textureWidth,s.textureHeight)){drawPixels=pixels;sourceUpload=!drawImage->uploaded;}
            else drawImage=nullptr;
        }
        const bool immutableSource=drawImage!=nullptr;
#else
        constexpr bool immutableSource=false;
#endif
        if(s.prim.tme&&!reuse&&!immutableSource){
            if(gs_mem_gpu_pending()&&!ps2x_gx_source_barrier())return Result::Fault;
            for(unsigned y=0;y<s.textureHeight;++y)for(unsigned x=0;x<s.textureWidth;++x){
             const uint32_t pixel=previous[size_t(y)*s.textureWidth+x];
             const unsigned k=((y/4)*(s.textureWidth/4)+x/4)*64+(y&3)*8+(x&3)*2;
             tiles[k]=pixel>>24;tiles[k+1]=pixel;tiles[k+32]=pixel>>8;tiles[k+33]=pixel>>16;
            }
        }
        if(hostDirty){if(!Invalidate())return Result::Fault;hostDirty=false;}

        // From here onward failure is terminal, never software replay over Z.
        if(s.prim.tme&&!sampler->CommitCoherentNativeSample(s,plan.firstSample[0],plan.firstSample[1],plan.firstSample[2]))return Result::Fault;
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        if(drawImage)MarkSourceUse(*drawImage);
#endif
        float wholeXY[6];
        const bool whole=PS2X_GX_WHOLE_TRIANGLES&&blend!=2&&GSNativeWholeTriangle::Prepare(b,wholeXY);
        if(PS2X_GX_WHOLE_TRIANGLES&&!whole&&GSNativeWholeTriangle::StateEligible(b))++PS2WiiGXWholeTriangles[7];
        int submitted=0;
        if(!ps2x_gx_draw_linear_fragments(&d,drawPixels,s.textureWidth,s.textureHeight,plan.matrices.data(),s.prim.tme?(c.clamp&3):0,s.prim.tme?((c.clamp>>2)&3):0,
          t.tfx,s.prim.tme,sourceUpload,blend,blend==1?fix:128,
          whole&&c.frame.psm==GS_PSM_CT24?nullptr:FragmentRow,&fragments,&submitted,whole?wholeXY:nullptr))return Result::Fault;
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        if(drawImage&&submitted)drawImage->uploaded=true;
        activeLinearImage=submitted?drawImage:nullptr;
#endif
        if(s.prim.tme&&!sampler->CommitCoherentNativeSample(s,plan.lastSample[0],plan.lastSample[1],plan.lastSample[2]))return Result::Fault;
        projectiveValid=false;previousKeyValid=s.prim.tme&&submitted;sourceKind=2;previousKey=key;
        ++linearOperations;depthTested+=fragments.depth.tested;depthRejected+=fragments.depth.rejected;depthWritten+=fragments.depth.written;
        if(!submitted){++metadataOperations;return Result::MetadataOnly;}
        if(s.prim.tme){if(reuse)++decodeReuses;if(sourceUpload){++uploads;uploadedTexels+=previous.size();}else ++reuses;}
        else ++flats;
        ++triangles;++linearTriangles;return Result::Submitted;
    }
    Result TryProjective(const GSPrimitiveBatch &b){
        ++admission[7];
        const auto &s=b.state;const auto &c=s.context;const auto &t=c.tex0;const auto &z=b.vertices[2];
        if(s.prim.fge||s.prim.aa1||c.frame.psm>1||c.frame.fbmsk||c.fba||!c.zbuf.zmask||
           (c.test&0x4000)||((c.test>>17)&3)!=1||!(s.colclamp&1)||!c.frame.fbw||c.frame.fbw>10||
           !ResidentTarget(c.frame)||((c.tex1>>2)&7)||t.tfx>3||t.tcc>1){++admission[8];return Result::Unsupported;}
        const bool copy=(c.alpha&3)==((c.alpha>>2)&3)&&((c.alpha>>6)&3)==0;
        const bool additive=s.prim.abe&&!copy;
        if(additive&&(s.pabe||(c.alpha&((uint64_t(255)<<32)|255))!=((uint64_t(128)<<32)|0x68)))return Result::Unsupported;
        GSNativeProjectivePlan plan;if(!GSNativeProjectivePlan::Prepare(b,plan)){++admission[9];return Result::Unsupported;}
        uint32_t lo=0,hi=0;if(!ImageRange(s,lo,hi))return Result::Unsupported;
        const uint32_t targetLo=c.frame.fbp*8192u,targetHi=targetLo+c.frame.fbw*15u*8192u;
        if(targetHi>4*1024*1024||!(hi<=targetLo||lo>=targetHi)||!ps2x_gx_source_disjoint(lo,hi))return Result::Unsupported;
        uint64_t clut=0;if(!sampler->GetCoherentNativeImageStamp(s,clut))return Result::Unsupported;
        const uint64_t color=(t.tfx==1&&t.tcc)?0:uint64_t(z.r)|(uint64_t(z.g)<<8)|(uint64_t(z.b)<<16)|(uint64_t(z.a)<<24);
        const std::array<uint64_t,6> key={imageEpoch,clut,rangeKey,
            uint64_t(t.cpsm)|(uint64_t(t.csm)<<6)|(uint64_t(t.csa)<<7),
            uint64_t(s.texa.ta0)|(uint64_t(s.texa.ta1)<<8)|(uint64_t(s.texa.aem)<<16)|(uint64_t(t.tcc)<<17)|(uint64_t(t.tfx)<<18),color};
        const bool reuse=projectiveValid&&imageEpoch!=UINT64_MAX&&key==projectiveKey;
        std::vector<uint32_t> image;
        unsigned alpha=projectiveAlpha;bool uniform=projectiveUniform;
        if(!reuse){
            if(!DecodeImage(s,clut,lo,hi,image))return Result::Unsupported;
            Combine(image,t,z);alpha=t.tcc?image[0]>>24:z.a;uniform=true;
            if(t.tcc)for(auto texel:image)uniform&=(texel>>24)==alpha;
        }
        if(c.frame.psm==0&&!uniform)return Result::Unsupported;
        bool writeAlpha=c.frame.psm==0;
        if((c.test&1)&&((c.test>>12)&3)!=1){
            if(!uniform)return Result::Unsupported;
            if(!AlphaPass(c.test,alpha)){if(((c.test>>12)&3)!=3)return Result::Unsupported;writeAlpha=false;}
        }
        gs_gx_flat_draw d{};d.bp=c.frame.fbp*2048;d.bw=c.frame.fbw*64;
        d.x=plan.x;d.y=plan.y;d.width=plan.width;d.height=plan.height;d.psm=writeAlpha?0:1;d.rgba=alpha<<24;
        for(unsigned y=0;y<d.height;++y){d.left[y]=plan.left[y];d.right[y]=plan.right[y];}
        if(!gs_gx_target_valid(4*1024*1024,d.bp,d.bw,d.x,d.y,d.width,d.height))return Result::Unsupported;
        if(!reuse){
            if(!projectiveTiles){projectiveTiles=static_cast<uint8_t*>(memalign(32,128*128*4));if(!projectiveTiles)throw std::bad_alloc();}
            else if(gs_mem_gpu_pending()&&!ps2x_gx_source_barrier())return Result::Fault;
            for(unsigned y=0;y<s.textureHeight;++y)for(unsigned x=0;x<s.textureWidth;++x){
                const uint32_t pixel=image[size_t(y)*s.textureWidth+x];
                const unsigned off=((y/4)*(s.textureWidth/4)+x/4)*64+(y&3)*8+(x&3)*2;
                projectiveTiles[off]=pixel>>24;projectiveTiles[off+1]=pixel;projectiveTiles[off+32]=pixel>>8;projectiveTiles[off+33]=pixel>>16;
            }
        }
        if(hostDirty){if(!Invalidate())return Result::Fault;hostDirty=false;}
        if(!sampler->CommitCoherentNativeSample(s,plan.finalS,plan.finalT,plan.finalQ))return Result::Fault;
        if(!ps2x_gx_draw_projective(&d,projectiveTiles,s.textureWidth,s.textureHeight,plan.matrix.data(),c.clamp&3,(c.clamp>>2)&3,!reuse,additive))return Result::Fault;
        projectiveKey=key;projectiveAlpha=alpha;projectiveUniform=uniform;projectiveValid=true;
        if(reuse){++reuses;++decodeReuses;}else{++uploads;uploadedTexels+=image.size();}
        ++triangles;++projectiveTriangles;projectiveProofPixels+=plan.checkedPixels;return Result::Submitted;
    }
    bool Invalidate(){if(!gs_gx_reset_boot_state()||!ps2x_gx_init())return false;gs_gx_set_render_enabled(1);return true;}
    static int64_t FloorDiv(int64_t value,int64_t divisor){
        const int64_t quotient=value/divisor,remainder=value%divisor;
        return quotient-((remainder!=0)&&((remainder<0)!=(divisor<0)));
    }
    static bool Step(float v){v=std::fabs(v);return v==0||v==.25f||v==.5f||v==1||v==2;}
    static void Combine(std::vector<uint32_t> &pixels,const GSTex0Reg &t,const GSVertex &z){
        if(t.tfx==1)return;
        for(auto &pixel:pixels){
            const unsigned tr=pixel&255,tg=(pixel>>8)&255,tb=(pixel>>16)&255,ta=pixel>>24;
            const unsigned add=t.tfx>=2?z.a:0;
            const unsigned r=std::min(255u,((tr*z.r)>>7)+add),g=std::min(255u,((tg*z.g)>>7)+add),bl=std::min(255u,((tb*z.b)>>7)+add);
            const unsigned alpha=!t.tcc?z.a:t.tfx==0?std::min(255u,(ta*z.a)>>7):t.tfx==2?std::min(255u,ta+z.a):ta;
            pixel=r|(g<<8)|(bl<<16)|(alpha<<24);
        }
    }
    static bool AlphaPass(uint64_t test,unsigned alpha){
        const unsigned ref=(test>>4)&255;
        switch((test>>1)&7){case 0:return false;case 1:return true;case 2:return alpha<ref;case 3:return alpha<=ref;case 4:return alpha==ref;case 5:return alpha>=ref;case 6:return alpha>ref;default:return alpha!=ref;}
    }
    static bool CroppedCandidate(const GSPrimitiveBatch &b){
        return b.vertexCount==2&&b.state.prim.type==GS_PRIM_SPRITE&&
            (!b.state.prim.fst||b.state.textureWidth>128||b.state.textureHeight>128||b.state.context.tex1!=0);
    }
    Result TryCroppedSprite(const GSPrimitiveBatch &b){
        ++admission[0];
        const auto &s=b.state;const auto &c=s.context;const auto &t=c.tex0;const auto &z=b.vertices[1];
        if(s.prim.fge||s.prim.aa1||c.frame.psm>1||c.frame.fbmsk||c.fba||!c.zbuf.zmask||(c.test&0x4000)||((c.test>>17)&3)!=1||!(s.colclamp&1)||!c.frame.fbw||c.frame.fbw>10||!ResidentTarget(c.frame)||((c.tex1>>2)&7)||t.tfx>3||t.tcc>1){++admission[1];return Result::Unsupported;}
        // (A-A)*C + Cs is a source copy for every alpha, including PABE.
        const bool sourceCopy=(c.alpha&3)==((c.alpha>>2)&3)&&((c.alpha>>6)&3)==0;
        const bool additive=s.prim.abe&&!sourceCopy;
        if(additive&&(s.pabe||(c.alpha&((uint64_t(255)<<32)|255))!=((uint64_t(128)<<32)|0x68))){++admission[2];return Result::Unsupported;}
        GSNativeSpritePlan plan;if(!GSNativeSpritePlan::Prepare(b,plan)){++admission[3];return Result::Unsupported;}
        uint32_t address=0;if(!GSMem::TextureByteAddress(t.psm,t.tbp0,t.tbw,plan.source.x,plan.source.y,address))return Result::Unsupported;
        const unsigned page=address/8192,lo=c.frame.fbp+(plan.y/32)*c.frame.fbw+plan.x/64;
        const unsigned hi=c.frame.fbp+((plan.y+plan.height-1)/32)*c.frame.fbw+(plan.x+plan.width-1)/64;
        if(hi>=512||(page>=lo&&page<=hi)){++admission[4];return Result::Unsupported;}
        int32_t xy[6]={plan.x,plan.y,plan.x+plan.width,plan.y+plan.height,0,0};gs_gx_flat_draw prepared;
        if(!gs_gx_prepare_flat(&prepared,6,c.frame.fbp*2048,c.frame.fbw*64,plan.x,plan.y,plan.x+plan.width,plan.y+plan.height,xy,0,s.scanmsk&3)||unsigned(plan.y)+prepared.height>480)return Result::Unsupported;
        bool covered=false;for(unsigned row=0;row<prepared.height;++row)covered|=prepared.right[row]>prepared.left[row];if(!covered)return Result::Unsupported;
        GSCpuBackend::NativeTextureStamp stamp;
        auto keyFor=[&]{return std::array<uint64_t,6>{stamp.texels,stamp.clut,
            uint64_t(t.tbp0)|(uint64_t(t.tbw)<<14)|(uint64_t(t.psm)<<20)|(uint64_t(t.cpsm)<<26)|(uint64_t(t.csm)<<32)|(uint64_t(t.csa)<<33),
            uint64_t(plan.source.x)|(uint64_t(plan.source.y)<<10)|(uint64_t(plan.source.width)<<20)|(uint64_t(plan.source.height)<<28),
            uint64_t(s.texa.ta0)|(uint64_t(s.texa.ta1)<<8)|(uint64_t(s.texa.aem)<<16)|(uint64_t(t.tcc)<<17)|(uint64_t(t.tfx)<<18),
            uint64_t(z.r)|(uint64_t(z.g)<<8)|(uint64_t(z.b)<<16)|(uint64_t(z.a)<<24)};};
        const bool latched=sampler->GetNativeTextureRectStamp(s,plan.source,stamp);
        if(gs_mem_gpu_pending()&&!latched)return Result::Fault;
        auto sourceKey=keyFor();
        auto hashKey=[](const std::array<uint64_t,6> &key){
            uint64_t hash=1469598103934665603ull;
            for(auto word:key){hash^=word;hash*=1099511628211ull;}
            return unsigned(hash&255);
        };
        CropImage *image=&cropImages[hashKey(sourceKey)];
        const bool reuse=latched&&image->valid&&image->key==sourceKey;
        std::vector<uint32_t> decoded;
        unsigned alpha=0;bool uniform=true;
        if(!reuse){
            if(!sampler->DecodeNativeTextureRect(s,plan.source,decoded)){++admission[5];return Result::Unsupported;}
            Combine(decoded,t,z);++decodes;
            alpha=t.tcc?decoded[0]>>24:z.a;
            if(t.tcc)for(auto pixel:decoded)uniform&=(pixel>>24)==alpha;
        }else {++decodeReuses;alpha=image->alpha;uniform=image->uniform;}
        bool writeAlpha=c.frame.psm==0;
        if((c.test&1)&&((c.test>>12)&3)!=1){
            if(!uniform){++admission[6];return Result::Unsupported;}
            if(!AlphaPass(c.test,alpha)){
                if(((c.test>>12)&3)!=3)return Result::Unsupported;
                writeAlpha=false;
            }
        }
        unsigned width=4,height=4;while(width<plan.source.width)width*=2;while(height<plan.source.height)height*=2;
        const bool upload=!reuse;
        if(upload){
            const unsigned bytes=width*height*4;
            if(cropCursor+bytes>128*128*4){
                if(gs_mem_gpu_pending()&&!ps2x_gx_source_barrier())return Result::Fault;
                for(auto &entry:cropImages)entry.valid=false;
                cropCursor=0;++sourceFences;
            }
            if(!sampler->GetNativeTextureRectStamp(s,plan.source,stamp))return Result::Fault;
            sourceKey=keyFor();image=&cropImages[hashKey(sourceKey)];
            image->offset=cropCursor;cropCursor+=bytes;
            auto *target=cropTiles+image->offset;
            for(unsigned y=0;y<height;++y)for(unsigned x=0;x<width;++x){
                const auto pixel=decoded[size_t(std::min(y,unsigned(plan.source.height)-1))*plan.source.width+std::min(x,unsigned(plan.source.width)-1)];
                const unsigned offset=((y/4)*(width/4)+x/4)*64+(y&3)*8+(x&3)*2;
                target[offset]=pixel>>24;target[offset+1]=pixel;target[offset+32]=pixel>>8;target[offset+33]=pixel>>16;
            }
            image->key=sourceKey;image->width=width;image->height=height;image->alpha=alpha;image->uniform=uniform;image->valid=true;
        }
        if(hostDirty){if(!Invalidate())return Result::Fault;hostDirty=false;}
        prepared.psm=writeAlpha?0:1;prepared.rgba=alpha<<24;
        if(!ps2x_gx_draw_native_texture(&prepared,cropTiles+image->offset,width,height,plan.u,plan.v,plan.du,0,0,plan.dv,upload,additive))return Result::Fault;
        if(writeAlpha&&!uniform&&!ps2x_gx_source_alpha(&prepared,cropTiles+image->offset,width,height,plan.columns.data(),plan.rows.data(),plan.source.x,plan.source.y))return Result::Fault;
        if(upload){++uploads;uploadedTexels+=width*height;}else ++reuses;
        ++croppedSprites;return Result::Submitted;
    }
    Result TryFlat(const GSPrimitiveBatch &b){
        const auto &s=b.state;const auto &c=s.context;
        const bool subtract=s.prim.abe&&!s.pabe&&(c.alpha&255u)==0x42u;
        if(b.vertexCount!=2||s.prim.type!=GS_PRIM_SPRITE||(s.prim.abe&&!subtract)||s.prim.fge||s.prim.aa1||c.frame.psm>1||!ResidentTarget(c.frame)||c.frame.fbmsk||c.fba||!c.zbuf.zmask||(c.test&0x4000)||((c.test>>17)&3)!=1||!(s.colclamp&1)||!c.frame.fbw||c.frame.fbw>10)return Result::Unsupported;
        // An untextured sprite has constant source alpha. A passing alpha
        // test is therefore a whole-draw proof; failed tests keep the fallback.
        if((c.test&1)&&!AlphaPass(c.test,b.vertices[1].a))return Result::Unsupported;
        float x[2],y[2];
        for(unsigned i=0;i<2;++i){x[i]=b.vertices[i].x-float(c.xyoffset.ofx)/16;y[i]=b.vertices[i].y-float(c.xyoffset.ofy)/16;
            if(!std::isfinite(x[i])||!std::isfinite(y[i])||x[i]<0||y[i]<0||x[i]>2047||y[i]>2047||std::floor(x[i])!=x[i]||std::floor(y[i])!=y[i])return Result::Unsupported;}
        const int x0=std::max(int(std::min(x[0],x[1])),int(c.scissor.x0)),y0=std::max(int(std::min(y[0],y[1])),int(c.scissor.y0));
        const int x1=std::min(int(std::max(x[0],x[1])),int(c.scissor.x1)+1),y1=std::min(int(std::max(y[0],y[1])),int(c.scissor.y1)+1);
        if(x1<=x0||y1<=y0)return Result::Unsupported;
        const auto &v=b.vertices[1];
        // GS (0-Cs)*As/128+Cd floors the negative product: subtract its
        // positive ceiling. Values above 255 always clamp any 8-bit Cd to 0.
        const auto channel=[&](uint8_t value){return subtract?std::min(255u,(unsigned(value)*v.a+127u)/128u):unsigned(value);};
        const uint32_t rgba=channel(v.r)|(channel(v.g)<<8)|(channel(v.b)<<16)|(uint32_t(v.a)<<24);
        const int32_t xy[6]={x0,y0,x1,y1,0,0};gs_gx_flat_draw prepared;
        if(!gs_gx_prepare_flat(&prepared,6,c.frame.fbp*2048,c.frame.fbw*64,x0,y0,x1,y1,xy,rgba,s.scanmsk&3)||unsigned(y0)+prepared.height>480)return Result::Unsupported;
        bool covered=false;for(unsigned row=0;row<prepared.height;++row)covered|=prepared.right[row]>prepared.left[row];
        if(!covered)return Result::Unsupported;
        if(hostDirty){if(!Invalidate())return Result::Fault;hostDirty=false;}
        prepared.psm=c.frame.psm;
        if(!(subtract?ps2x_gx_draw_native_subtract_flat(&prepared):ps2x_gx_draw_native_flat(&prepared)))return Result::Fault;
        if(subtract){++flatSubtractions;PS2X_GX_SUBTRACTED(flatSubtractions);}
        ++flats;return Result::Submitted;
    }

public:
    unsigned SourceCacheBytes()const noexcept{
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
        return sourceRetainedBytes+sourcePalette.capacity()*2u;
#else
        return 0;
#endif
    }
    std::array<unsigned,11> admission{};
    std::array<unsigned,8> linearAdmission{};
    unsigned linearOperations=0,linearTriangles=0,metadataOperations=0,metadataWithoutImage=0;uint64_t depthTested=0,depthRejected=0,depthWritten=0;
    unsigned projectiveTriangles=0,projectiveProofPixels=0,sourceFences=0,croppedSprites=0,flats=0,flatSubtractions=0,attempts=0,uploads=0,uploadedTexels=0,reuses=0,triangles=0,decodes=0,decodeReuses=0;
    unsigned untexturedTriangles=0,constantTriangles=0;
    unsigned sourceTileFences=0;
    explicit PS2WiiGXTextureDriver(GSCpuBackend *s):sampler(s){
        tiles=static_cast<uint8_t*>(memalign(32,128*128*4));
        cropTiles=static_cast<uint8_t*>(memalign(32,128*128*4));
        if(!tiles||!cropTiles){std::free(tiles);std::free(cropTiles);throw std::bad_alloc();}
    }
    ~PS2WiiGXTextureDriver() override{std::free(tiles);std::free(cropTiles);std::free(projectiveTiles);}
    bool NeedsResolveBeforeSubmit(const GSPrimitiveBatch &b)const override{
#if defined(PS2X_WII_GX_DEPTH24)
        return depth24&&depth24->Pending()&&!depth24->CanSubmit(b);
#else
        (void)b;return false;
#endif
    }
    bool SharesTextureCacheWith(const GSRasterBackend *s)const noexcept override{return s==sampler;}
    bool CanPrepareTextureWithoutResolve(const GSPrimitiveBatch &batch)const override{
        if(batch.vertexCount==3&&!batch.state.prim.fst){
            // Reject the common unsupported depth/filter states BEFORE walking
            // a source image merely to decide whether a resolve is needed.
            if((!PS2X_GX_FAST_LINEAR||!batch.state.linearFilter)&&(!batch.state.context.zbuf.zmask||((batch.state.context.test>>17)&3)!=1||
               batch.state.prim.fge||batch.state.prim.aa1||
               batch.state.textureWidth>128||batch.state.textureHeight>128))return false;
            uint32_t lo=0,hi=0;uint64_t clut=0;
            return ImageRange(batch.state,lo,hi)&&ps2x_gx_source_disjoint(lo,hi)&&sampler->GetCoherentNativeImageStamp(batch.state,clut);
        }
        if(CroppedCandidate(batch)){
            GSNativeSpritePlan plan;GSCpuBackend::NativeTextureStamp stamp;
            return GSNativeSpritePlan::Prepare(batch,plan)&&sampler->GetNativeTextureRectStamp(batch.state,plan.source,stamp);
        }
        return sampler->CanDecodeNativeTexturePageWithoutVramRead(batch.state);
    }
    bool Initialize(uint8_t *vram,uint32_t size)override{
        if(!ps2x_gx_bind(vram,size))return false;bound=true;
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
        sourceVram=vram;ClearSourceImages();
#endif
        if(!Invalidate()){if(!ps2x_gx_unbind())throw std::runtime_error("GX init cleanup");bound=false;return false;}
#if defined(PS2X_WII_GX_DEPTH24)
        depth24=std::make_unique<PS2WiiGXDepth24Engine>();
        if(!depth24->Initialize(vram))depth24.reset();
        DepthStats();
#endif
        hostDirty=false;PS2X_GX_BOOT("gx-native-ready shared_vram=1 fallback=software");return true;
    }
    Result TrySubmit(const GSPrimitiveBatch &b)override
    {
#if defined(PS2X_WII_GIF_TRACE)
        if (PS2WiiGXDiagnosticSoftwareOnly) return Result::Unsupported;
#endif
#if defined(PS2X_WII)
        PS2WiiProgressScope nativeScope(13); // Producer-side preparation/submission, including its GX waits.
#endif
        ++attempts;
#if defined(PS2X_WII_GX_DEPTH24)
        if(depth24&&depth24->CanSubmit(b)){
            const int result=depth24->Submit(b);DepthStats();
            if(result<0)return Result::Fault;
            if(result>0)return Result::Submitted;
            if(depth24->Pending())return Result::Unsupported;
        }
#endif
#if defined(PS2X_WII_GX_PROFILE_FAMILIES)
        if(b.vertexCount==3&&(attempts&63u)==0){
            const auto &s=b.state;const auto &c=s.context;const unsigned z=(c.test>>17)&3;
            const bool always=(!(c.test&1)||((c.test>>1)&7)==1)&&!(c.test&0x4000)&&!s.scanmsk;
            ++PS2WiiGXStateFamilies[31];++PS2WiiGXStateFamilies[z];
            const unsigned zp=c.zbuf.psm==GS_PSM_Z32?32:c.zbuf.psm==GS_PSM_Z24?33:c.zbuf.psm==GS_PSM_Z16?34:c.zbuf.psm==GS_PSM_Z16S?35:36;
            ++PS2WiiGXStateFamilies[zp];
            if(PS2WiiGXStateFamilies[31]==1){PS2WiiGXStateFamilies[40]=UINT32_MAX;PS2WiiGXStateFamilies[43]=UINT32_MAX;}
            for(unsigned i=0;i<3;++i)if(std::isfinite(b.vertices[i].z)&&b.vertices[i].z>=0&&b.vertices[i].z<=4294963200.){
                const uint32_t v=uint32_t(b.vertices[i].z);
                if(v<PS2WiiGXStateFamilies[40])PS2WiiGXStateFamilies[40]=v;
                if(v>PS2WiiGXStateFamilies[41])PS2WiiGXStateFamilies[41]=v;
                PS2WiiGXStateFamilies[42]|=v;PS2WiiGXStateFamilies[43]&=v;
            }
            if(always)++PS2WiiGXStateFamilies[4+z];
            if(c.zbuf.zmask)++PS2WiiGXStateFamilies[8+z];
            if(always&&c.zbuf.zmask)++PS2WiiGXStateFamilies[12+z];
            PS2WiiGXStateFamilies[16]+=(c.test&1)&&((c.test>>1)&7)!=1;
            PS2WiiGXStateFamilies[17]+=!!(c.test&0x4000);
            PS2WiiGXStateFamilies[18]+=s.pabe&&s.prim.abe;
            PS2WiiGXStateFamilies[19]+=!!c.frame.fbmsk;
            PS2WiiGXStateFamilies[20]+=s.prim.fge;
            PS2WiiGXStateFamilies[21]+=s.prim.aa1;
            PS2WiiGXStateFamilies[22]+=!(s.colclamp&1);
            PS2WiiGXStateFamilies[23]+=c.frame.psm>1;
            PS2WiiGXStateFamilies[24]+=s.prim.abe;
            PS2WiiGXStateFamilies[25]+=s.prim.tme;
            PS2WiiGXStateFamilies[26]+=c.zbuf.zmask;
            PS2WiiGXStateFamilies[27]+=b.vertices[0].z==b.vertices[1].z&&b.vertices[1].z==b.vertices[2].z;
            PS2WiiGXStateFamilies[28]+=b.vertices[0].a==b.vertices[1].a&&b.vertices[1].a==b.vertices[2].a;
            PS2WiiGXStateFamilies[29]+=c.frame.psm==GS_PSM_CT24;
            PS2WiiGXStateFamilies[30]+=!!s.scanmsk;
        }
#endif
        bool constantUntextured=false;
        if(!b.state.prim.tme&&b.vertexCount==3){
            ++untexturedTriangles;bool constant=!b.state.prim.iip;
            if(!constant){constant=true;for(unsigned v=0;v<2;++v){const auto &a=b.vertices[v],&z=b.vertices[2];constant&=a.r==z.r&&a.g==z.g&&a.b==z.b&&a.a==z.a;}}
            constantTriangles+=constant;constantUntextured=constant;
        }
        if((attempts&4095u)==0)PS2X_GX_UNTEXTURED(untexturedTriangles,constantTriangles);
        if((attempts&4095u)==0)PS2X_GX_SOURCE_TILES(SourceCacheBytes(),sourceTileFences);
        if((attempts&4095u)==0){PS2X_GX_STATUS(attempts,uploads,reuses,triangles,decodes,decodeReuses,flats);PS2X_GX_ADMISSION(admission.data());PS2X_GX_LINEAR(linearAdmission.data());}
        float candidateXY[6];
        const bool wholeCandidate=PS2X_GX_WHOLE_TRIANGLES&&GSNativeWholeTriangle::Prepare(b,candidateXY);
        if(PS2X_GX_WHOLE_TRIANGLES){++PS2WiiGXWholeTriangles[4];PS2WiiGXWholeTriangles[5]+=GSNativeWholeTriangle::StateEligible(b);PS2WiiGXWholeTriangles[6]+=wholeCandidate;}
        if(PS2X_GX_FAST_LINEAR&&b.vertexCount==3&&((wholeCandidate||(PS2X_GX_FAST_UNTEXTURED||(PS2X_GX_CONSTANT_UNTEXTURED&&constantUntextured))&&!b.state.prim.tme)||(!b.state.prim.fst&&b.state.linearFilter&&b.state.prim.tme))){
            ++linearAdmission[0];const auto fast=TryLinear(b);
            if(fast!=Result::Unsupported){++linearAdmission[7];return fast;}
            ++linearAdmission[linearStage];
        }
        if(sourceKind==2)previousKeyValid=false;
        if(!b.state.prim.tme)return TryFlat(b);
        if(b.vertexCount==3&&!b.state.prim.fst)return TryProjective(b);
        if(b.vertexCount==2&&b.state.prim.type==GS_PRIM_SPRITE&&b.state.prim.fst)++admission[10];
        if(CroppedCandidate(b))return TryCroppedSprite(b);
        const auto &s=b.state;const auto &c=s.context;const auto &t=c.tex0;
        const bool triangle=b.vertexCount==3&&(s.prim.type==GS_PRIM_TRIANGLE||s.prim.type==GS_PRIM_TRISTRIP||s.prim.type==GS_PRIM_TRIFAN);
        if((!triangle&&(b.vertexCount!=2||s.prim.type!=GS_PRIM_SPRITE))||!s.prim.tme||!s.prim.fst||
           s.prim.fge||s.prim.aa1||c.frame.psm>1||c.frame.fbmsk||c.fba||
           !c.zbuf.zmask||(c.test&0x4001)||((c.test>>17)&3)!=1||!(s.colclamp&1)||
           !c.frame.fbw||c.frame.fbw>10||!ResidentTarget(c.frame)||c.tex1||t.tfx>3||t.tcc>1||
           s.textureWidth<4||s.textureHeight<4||s.textureWidth>128||s.textureHeight>128)
            return Result::Unsupported;
        // Exact additive equation: (Cs-0)*128/128+Cd. Other equations
        // need a destination/alpha precision contract and remain software.
        const bool additive=s.prim.abe;
        // GX bilinear rounding differs from the software GS. Precompute exact
        // quarter-texel source phases once; GX point-samples that source atlas.
        // This is source preprocessing, never a screen-sized shaded image.
        if(s.linearFilter&&((c.clamp&15)!=5||s.textureWidth>32||s.textureHeight>32))return Result::Unsupported;
        const unsigned textureWidth=s.textureWidth*(s.linearFilter?4:1),textureHeight=s.textureHeight*(s.linearFilter?4:1);
        if(additive&&(s.pabe||(c.alpha&((uint64_t(255)<<32)|255))!=((uint64_t(128)<<32)|0x68)))return Result::Unsupported;
        if(triangle&&s.prim.iip&&t.tfx!=1){
            for(unsigned i=0;i<2;++i){const auto &a=b.vertices[i],&z=b.vertices[2];
                if(a.r!=z.r||a.g!=z.g||a.b!=z.b||a.a!=z.a)return Result::Unsupported;}
        }
        float x[3],y[3];
        for(unsigned i=0;i<b.vertexCount;++i){x[i]=b.vertices[i].x-float(c.xyoffset.ofx)/16;y[i]=b.vertices[i].y-float(c.xyoffset.ofy)/16;
            if(!std::isfinite(x[i])||!std::isfinite(y[i])||x[i]<0||y[i]<0||x[i]>2047||y[i]>2047||std::floor(x[i])!=x[i]||std::floor(y[i])!=y[i]||
               ((b.vertices[i].u|b.vertices[i].v)&15))return Result::Unsupported;}
        int left=std::min(x[0],x[1]),top=std::min(y[0],y[1]);
        int right=std::max(x[0],x[1]),bottom=std::max(y[0],y[1]);
        float du=0,dv=0,duy=0,dvx=0,u0=0,v0=0;
        const auto &a=b.vertices[0];const auto &z=b.vertices[b.vertexCount-1];
        if(triangle){
            left=std::min(left,int(x[2]));top=std::min(top,int(y[2]));right=std::max(right,int(x[2]));bottom=std::max(bottom,int(y[2]));
            const float dx1=x[1]-x[0],dy1=y[1]-y[0],dx2=x[2]-x[0],dy2=y[2]-y[0];
            const int area=int(dx1*dy2-dx2*dy1);const unsigned magnitude=std::abs(area);
            // Power-of-two area and one nonzero power-of-two UV endpoint
            // level per axis make canonical barycentric UV sums exact. General
            // endpoints/areas/STQ need a separately validated sampling fitter.
            const unsigned uBits=a.u|b.vertices[1].u|z.u,vBits=a.v|b.vertices[1].v|z.v;
            if(!magnitude||(magnitude&(magnitude-1))||(uBits&&(uBits&(uBits-1)))||(vBits&&(vBits&(vBits-1))))return Result::Unsupported;
            const float u1=(int(b.vertices[1].u)-a.u)/16.f,u2=(int(z.u)-a.u)/16.f;
            const float v1=(int(b.vertices[1].v)-a.v)/16.f,v2=(int(z.v)-a.v)/16.f;
            du=(u1*dy2-u2*dy1)/area;duy=(u2*dx1-u1*dx2)/area;
            dvx=(v1*dy2-v2*dy1)/area;dv=(v2*dx1-v1*dx2)/area;
            if(!Step(du)||!Step(duy)||!Step(dvx)||!Step(dv))return Result::Unsupported;
            u0=a.u/16.f+(left+.5f-x[0])*du+(top+.5f-y[0])*duy;
            v0=a.v/16.f+(left+.5f-x[0])*dvx+(top+.5f-y[0])*dv;
            if(s.prim.iip&&!t.tcc&&(a.a!=z.a||b.vertices[1].a!=z.a))return Result::Unsupported;
        }else{
            if(x[0]==x[1]||y[0]==y[1])return Result::Unsupported;
            float u1=z.u/16.f,v1=z.v/16.f;u0=a.u/16.f;v0=a.v/16.f;
            if(x[0]>x[1])std::swap(u0,u1);if(y[0]>y[1])std::swap(v0,v1);
            du=(u1-u0)/std::fabs(x[1]-x[0]);dv=(v1-v0)/std::fabs(y[1]-y[0]);
            if(!Step(du)||!Step(dv))return Result::Unsupported;
        }
        const int x0=std::max(left,int(c.scissor.x0)),y0=std::max(top,int(c.scissor.y0));
        const int x1=std::min(right+int(triangle),int(c.scissor.x1)+1),y1=std::min(bottom+int(triangle),int(c.scissor.y1)+1);
        if(x1<=x0||y1<=y0)return Result::Unsupported;
        unsigned lo=c.frame.fbp+(y0/32)*c.frame.fbw+x0/64;
        unsigned hi=c.frame.fbp+((y1-1)/32)*c.frame.fbw+(x1-1)/64;
        unsigned source=t.tbp0/32;
        if(hi>=512||(source>=lo&&source<=hi))return Result::Unsupported;
        const float u=u0+(x0-left)*du+(y0-top)*duy,v=v0+(x0-left)*dvx+(y0-top)*dv;
        int32_t xy[6]={x0,y0,x1,y1,0,0};gs_gx_flat_draw prepared;
        if(!gs_gx_prepare_flat(&prepared,6,c.frame.fbp*2048,c.frame.fbw*64,x0,y0,x1,y1,xy,0,s.scanmsk&3))return Result::Unsupported;
        if(unsigned(y0)+prepared.height>480u)return Result::Unsupported;
        if(triangle){
            for(unsigned i=0;i<3;++i){xy[2*i]=int(x[i])*16;xy[2*i+1]=int(y[i])*16;}
            GSFixedTriangleCoverage coverage(xy,x0*16+8,y0*16+8);
            for(unsigned row=0;row<prepared.height;++row){
                if(prepared.right[row]==prepared.left[row])continue;
                const auto span=coverage.rowSpan(row,x1-x0);
                prepared.left[row]=span.begin;prepared.right[row]=span.end;
            }
        }
        bool covered=false;
        for(unsigned row=0;row<prepared.height;++row)if(prepared.right[row]>prepared.left[row]){
            covered=true;
            for(unsigned column:{unsigned(prepared.left[row]),unsigned(prepared.right[row]-1)}){
                const float su=u+column*du+row*duy,sv=v+column*dvx+row*dv;
                if(su<0||sv<0||su>=s.textureWidth||sv>=s.textureHeight)return Result::Unsupported;
            }
        }
        if(!covered)return Result::Unsupported;
        if(triangle&&s.linearFilter&&(std::fabs(du)==.25f||std::fabs(duy)==.25f||std::fabs(dvx)==.25f||std::fabs(dv)==.25f))return Result::Unsupported;
        if(gs_mem_gpu_pending()&&!sampler->CanDecodeNativeTexturePageWithoutVramRead(s))return Result::Fault;
        GSCpuBackend::NativeTextureStamp stamp;
        auto keyFor=[&]{return std::array<uint64_t,6>{stamp.texels,stamp.clut,
            uint64_t(t.tbp0)|(uint64_t(t.tbw)<<14)|(uint64_t(t.psm)<<20)|(uint64_t(t.tw)<<26)|(uint64_t(t.th)<<30),
            uint64_t(s.texa.ta0)|(uint64_t(s.texa.ta1)<<8)|(uint64_t(s.texa.aem)<<16)|(uint64_t(t.cpsm)<<17)|(uint64_t(t.csm)<<23)|(uint64_t(t.csa)<<24),
            uint64_t(t.tcc)|(uint64_t(t.tfx)<<1)|(uint64_t(s.linearFilter)<<3)|(uint64_t(z.r)<<8)|(uint64_t(z.g)<<16)|(uint64_t(z.b)<<24)|(uint64_t(z.a)<<32),
            uint64_t(s.textureWidth)|(uint64_t(s.textureHeight)<<32)};};
        const bool reuse=sourceKind==0&&previousKeyValid&&sampler->GetNativeTextureStamp(s,stamp)&&keyFor()==previousKey;
        std::vector<uint32_t> decoded;
        if(!reuse){if(!sampler->DecodeNativeTexturePage(s,decoded))return Result::Unsupported;++decodes;}else ++decodeReuses;
        if(!reuse&&s.linearFilter){
            std::vector<uint32_t> filtered(size_t(textureWidth)*textureHeight);
            for(unsigned y=0;y<textureHeight;++y)for(unsigned x=0;x<textureWidth;++x){
                const int ix=FloorDiv(int(x)-2,4),iy=FloorDiv(int(y)-2,4);
                const unsigned fx=int(x)-2-ix*4,fy=int(y)-2-iy*4;
                auto sample=[&](int sx,int sy){return decoded[size_t(std::clamp(sy,0,int(s.textureHeight)-1))*s.textureWidth+std::clamp(sx,0,int(s.textureWidth)-1)];};
                const uint32_t c00=sample(ix,iy),c10=sample(ix+1,iy),c01=sample(ix,iy+1),c11=sample(ix+1,iy+1);
                uint32_t pixel=0;
                for(unsigned shift=0;shift<32;shift+=8){
                    const unsigned sum=((c00>>shift)&255)*(4-fx)*(4-fy)+((c10>>shift)&255)*fx*(4-fy)+((c01>>shift)&255)*(4-fx)*fy+((c11>>shift)&255)*fx*fy;
                    pixel|=((sum+8)>>4)<<shift;
                }
                filtered[size_t(y)*textureWidth+x]=pixel;
            }
            decoded=std::move(filtered);
        }
        const auto &pixels=reuse?previous:decoded;
        // Flat TFX is precombined once in SOURCE texture space, with the
        // exact GS integer rules. GX still samples the source per fragment;
        // no screen-sized software shading or mirrored draw is performed.
        if(!reuse)Combine(decoded,t,z);
        uint32_t alpha=t.tcc?pixels[0]>>24:z.a;
        if(c.frame.psm==0&&t.tcc)for(auto pixel:pixels)if((pixel>>24)!=alpha)return Result::Unsupported;
        const bool upload=previousWidth!=textureWidth||previousHeight!=textureHeight||(!reuse&&previous!=decoded);
        // Never overwrite the source allocation while older GX work consumes it.
        // A different precombined source safely falls back after coordinator resolve.
        if(upload&&gs_mem_gpu_pending())return Result::Unsupported;
        if(upload)for(unsigned ty=0;ty<textureHeight;++ty)for(unsigned tx=0;tx<textureWidth;++tx){
            auto pixel=pixels[ty*textureWidth+tx];unsigned offset=((ty/4)*(textureWidth/4)+tx/4)*64+(ty&3)*8+(tx&3)*2;
            tiles[offset]=pixel>>24;tiles[offset+1]=pixel;tiles[offset+32]=pixel>>8;tiles[offset+33]=pixel>>16;
        }
        prepared.psm=c.frame.psm;prepared.rgba=alpha<<24;
        // GX samples at 7/12, not at the software GS sample location. Map
        // from the canonical source value at (x0,y0) to that hardware center.
        // Point-only bias stays inside the validated quantized texel bins.
        // Dolphin 2503 VideoCommon/VertexShaderManager.cpp documents 7/12.
        const float factor=s.linearFilter?4:1;
        if(hostDirty){if(!Invalidate())return Result::Fault;hostDirty=false;}
        if(!ps2x_gx_draw_native_texture(&prepared,tiles,textureWidth,textureHeight,
             (u-(7.f/12)*(du+duy))*factor+1.f/32,(v-(7.f/12)*(dvx+dv))*factor+1.f/32,du*factor,duy*factor,dvx*factor,dv*factor,upload,additive))return Result::Fault;
        if(upload){++uploads;uploadedTexels+=decoded.size();previous=std::move(decoded);previousWidth=textureWidth;previousHeight=textureHeight;}
        else ++reuses;
        previousKeyValid=sampler->GetNativeTextureStamp(s,stamp);if(previousKeyValid)previousKey=keyFor();
        sourceKind=0;triangles+=triangle;return Result::Submitted;
    }
    bool Resolve()override{const bool ok=gs_mem_sync()!=0;
#if defined(PS2X_WII_GX_DEPTH24)
        DepthStats();
#endif
        if(ok){
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        sourceCompleted=sourceUses;
#endif
        InvalidateImages();}return ok;}
    bool CpuWroteVram()override{hostDirty=true;InvalidateImages();return true;}
    bool LoadClut(const GSTex0Reg&,const GSTexClutReg&)override{return true;}
    bool TextureFlush()override{return Invalidate();}
    bool Flush()override{GX_Flush();PS2X_GX_STATUS(attempts,uploads,reuses,triangles,decodes,decodeReuses,flats);PS2X_GX_ADMISSION(admission.data());PS2X_GX_LINEAR(linearAdmission.data());return !gs_gx_faulted();}
    bool Reset()override{
#if defined(PS2X_WII_SOURCE_IMAGE_CACHE)
        ClearSourceImages();
#endif
        InvalidateImages();return Invalidate();}
    bool Shutdown()noexcept override{if(!bound)return true;
#if defined(PS2X_WII_IMMUTABLE_SOURCE_TILES)
        try{FenceSourceImages();}catch(...){return false;}
#endif
        if(!gs_gx_reset_boot_state())return false;
#if defined(PS2X_WII_GX_DEPTH24)
        if(depth24&&!depth24->Shutdown())return false;
#endif
        if(!ps2x_gx_unbind())return false;bound=false;return true;}
};
