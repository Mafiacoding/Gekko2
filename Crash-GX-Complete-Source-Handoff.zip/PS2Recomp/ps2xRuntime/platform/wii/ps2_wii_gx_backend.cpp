// SPDX-License-Identifier: GPL-3.0-or-later
#include <cstdio>
#include <cstdint>
#include <algorithm>
#include <memory>
#include <ogc/lwp_watchdog.h>
#include "ps2_wii_host.h"
#if defined(PS2X_WII_GIF_TRACE)
extern "C" {volatile uint32_t PS2WiiGXDiagnosticSoftwareOnly=0;}
#endif
extern "C" { volatile uint32_t PS2WiiGXStats[8];volatile uint32_t PS2WiiGXAdmission[11];volatile uint32_t PS2WiiGXLinear[8];volatile uint32_t PS2WiiGXImagesSkipped;volatile uint32_t PS2WiiGXFlatSubtractions;
volatile uint32_t PS2WiiGXUntextured[2];
volatile uint32_t PS2WiiGXSourceTiles[2];
volatile uint64_t PS2WiiGXSyncCounts[8];
uint64_t gs_gx_sync_count(unsigned);
uint32_t ps2x_gx_fifo_address(void);uint32_t ps2x_gx_staging_bytes(void);
}
namespace {
void gxBoot(const char *message){
    char line[192];std::snprintf(line,sizeof(line),"%s fifo=%08x staging_bytes=%u",message,ps2x_gx_fifo_address(),ps2x_gx_staging_bytes());
    PS2WiiCheckpoint(line);
}
// RAM counters remain cheap. Batch SD records at ten-second intervals, and
// keep a current snapshot after the bounded history stops accepting records.
bool historyFull=false;uint64_t logStarted=0;
void gxStatus(unsigned attempts,unsigned uploads,unsigned reuses,unsigned triangles,unsigned decodes,unsigned cached,unsigned flats){
    const uint32_t values[8]={attempts,uploads+reuses+flats,triangles,uploads,reuses,decodes,cached,flats};
    for(unsigned i=0;i<8;++i){PS2WiiGXStats[i]=values[i];PS2WiiGXSyncCounts[i]=gs_gx_sync_count(i);}
}
void gxAdmission(const unsigned *v){
    for(unsigned i=0;i<11;++i)PS2WiiGXAdmission[i]=v[i];
}
void gxLinear(const unsigned *v){
    for(unsigned i=0;i<8;++i)PS2WiiGXLinear[i]=v[i];
    static uint64_t previous=0;const uint64_t now=gettime();
    if(ticks_to_millisecs(now-previous)<10000)return;previous=now;
    const auto *a=PS2WiiGXStats;const auto *b=PS2WiiGXAdmission;
    const auto ms=static_cast<unsigned long long>(ticks_to_millisecs(now-logStarted));
    char line[1024];const int bytes=std::snprintf(line,sizeof(line),
      "[GX] attempts=%u native=%u triangles=%u uploads=%u reuse=%u decodes=%u cached=%u flats=%u t_ms=%llu\n"
      "[GX_ADMIT] sprite=%u state=%u blend=%u plan=%u alias=%u decode=%u alpha=%u projective=%u state=%u plan=%u fst_sprite=%u t_ms=%llu\n"
      "[GX_LINEAR] attempts=%u state=%u plan=%u alias=%u coherent=%u blend=%u target=%u accepted=%u image_skipped=%u t_ms=%llu\n",
      a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],ms,
      b[0],b[1],b[2],b[3],b[4],b[5],b[6],b[7],b[8],b[9],b[10],ms,
      v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],uint32_t(PS2WiiGXImagesSkipped),ms);
    if(bytes<=0||size_t(bytes)>=sizeof(line))return;
    if(!historyFull){
        if(FILE *f=std::fopen("sd:/ps2recomp/gx-status.txt","a")){
            if(std::fseek(f,0,SEEK_END)==0){
                const long pos=std::ftell(f);
                if(pos>=0&&pos+bytes<=128*1024)std::fwrite(line,1,bytes,f);
                else if(pos>=0)historyFull=true; // Never truncate a record or keep reopening a full history.
            }
            std::fclose(f);
        }
    }
    if(FILE *f=std::fopen("sd:/ps2recomp/gx-latest.txt","w")){
        std::fwrite(line,1,bytes,f);std::fclose(f);
    }
}
}
#define PS2X_GX_SKIPPED(n) (PS2WiiGXImagesSkipped=(n))
#define PS2X_GX_SUBTRACTED(n) (PS2WiiGXFlatSubtractions=(n))
#define PS2X_GX_UNTEXTURED(total,constant) do { PS2WiiGXUntextured[0]=(total);PS2WiiGXUntextured[1]=(constant); } while(false)
#define PS2X_GX_SOURCE_TILES(bytes,fences) do { PS2WiiGXSourceTiles[0]=(bytes);PS2WiiGXSourceTiles[1]=(fences); } while(false)
#define PS2X_GX_LINEAR(p) gxLinear(p)
#define PS2X_GX_ADMISSION(p) gxAdmission(p)
#define PS2X_GX_BOOT(message) gxBoot(message)
#define PS2X_GX_STATUS(a,b,c,d,e,f,g) gxStatus(a,b,c,d,e,f,g)
#include "ps2_wii_gx_driver.h"
extern "C" uint32_t gs_scanout_read_rgb(uint32_t bp,uint32_t bw,uint32_t x,uint32_t y,uint32_t psm){
    if(psm>1)std::abort();return gs_mem_read_psmct32(bp,bw,x,y);
}
std::unique_ptr<GSRasterBackend> PS2WiiCreateGXBackend(){
    auto software=std::make_unique<GSCpuBackend>();
    auto native=std::make_unique<PS2WiiGXTextureDriver>(software.get());
    historyFull=false;logStarted=gettime();
    if(FILE *f=std::fopen("sd:/ps2recomp/gx-status.txt","w")){std::fputs("GX hybrid experimental; counters are operations, not FPS.\n",f);std::fclose(f);}
    PS2WiiCheckpoint("gx-hybrid-select experimental=1");
    return std::make_unique<GSHybridBackend>(std::move(software),std::move(native));
}
// Runtime::run joins its GS-producing worker before the normal _Exit path.
// The bound FIFO/source allocations must remain alive until this drain finishes.
extern "C" int PS2WiiGXDrain(){return gs_gx_reset_boot_state();}
