// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef int (*ps2x_gx_aux_resolve_fn)(void*);
typedef int (*ps2x_gx_aux_disjoint_fn)(void*,uint32_t,uint32_t);
// Registration/replacement requires drained GPU ownership. Resolve runs before
// RGB/alpha import and must not throw or recursively synchronize shared VRAM.
// The disjoint callback is a pure ownership query. A failed resolve is terminal.
int ps2x_gx_set_aux_hooks(ps2x_gx_aux_resolve_fn,ps2x_gx_aux_disjoint_fn,void*);
#ifdef __cplusplus
}
#endif
