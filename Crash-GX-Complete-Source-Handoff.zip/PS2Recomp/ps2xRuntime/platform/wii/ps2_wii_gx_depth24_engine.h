// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <gccore.h>
#include <malloc.h>
#include <cstdlib>
#include <cstring>
#include "runtime/gs/gs_native_depth24_ledger.h"
#include "runtime/gs/ps2_gs_memory.h"
#include "ps2_wii_gx_depth24_bridge.h"
#include "ps2_wii_gx_owner_hooks.h"
extern "C" int ps2x_gx_source_barrier(void);

// First integrated family: opaque, untextured Z24 GEQUAL triangles. Existing
// renderer handles every other family after the coordinator drains this owner.
class PS2WiiGXDepth24Engine {
 static constexpr unsigned ArenaBytes=128*1024;
 GSNativeDepth24Ledger ledger_;
 uint8_t *vram_=nullptr,*arena_=nullptr;
 unsigned used_=0,zbp_=0,bw_=0,x0_=640,y0_=480,x1_=0,y1_=0;
 std::array<uint8_t,160*120> seeded_{};
 bool installed_=false;
 static unsigned Tile(unsigned w,unsigned x,unsigned y){return ((y/4)*(w/4)+x/4)*64+(y&3)*8+(x&3)*2;}
 uint8_t *Allocate(unsigned bytes){
  bytes=(bytes+31)&~31u;if(bytes>ArenaBytes)return nullptr;
  if(used_+bytes>ArenaBytes){if(!ps2x_gx_source_barrier())return nullptr;used_=0;++fences;}
  auto *p=arena_+used_;used_+=bytes;return p;
 }
 static int ResolveThunk(void *p)noexcept{try{return static_cast<PS2WiiGXDepth24Engine*>(p)->Resolve();}catch(...){return 0;}}
 static int DisjointThunk(void *p,uint32_t lo,uint32_t hi)noexcept{return static_cast<PS2WiiGXDepth24Engine*>(p)->ledger_.SourceDisjoint(lo,hi);}
public:
 unsigned submissions=0,resolutions=0,fences=0,tiles=0;
 ~PS2WiiGXDepth24Engine(){std::free(arena_);}
 bool Initialize(uint8_t *vram){
  arena_=static_cast<uint8_t*>(memalign(32,ArenaBytes));if(!arena_)return false;vram_=vram;
  installed_=ps2x_gx_set_aux_hooks(ResolveThunk,DisjointThunk,this)!=0;return installed_;
 }
 bool Shutdown(){if(!installed_)return true;if(ledger_.Pending())return false;
  if(!ps2x_gx_source_barrier()||!ps2x_gx_set_aux_hooks(nullptr,nullptr,nullptr))return false;installed_=false;return true;}
 bool Pending()const{return ledger_.Pending();}
 bool CanSubmit(const GSPrimitiveBatch &b)const{
  return !b.state.prim.tme&&!b.state.prim.abe&&ledger_.CanAppend(b,true);
 }
 bool Resolve(){
  if(!ledger_.Pending())return true;
  uint8_t *alpha=nullptr,*dirty=nullptr;uint32_t width=0,height=0;
  if(!ps2x_gx_depth24_metadata(&alpha,&dirty,&width,&height)||width!=bw_*64||!ledger_.BeginResolve())return false;
  const unsigned left=x0_&~3u,top=y0_&~3u,w=((x1_+3)&~3u)-left,bottom=(y1_+3)&~3u;
  for(unsigned y=top;y<bottom;y+=64){unsigned h=std::min(64u,bottom-y);const auto *pixels=ps2x_gx_depth24_read(left,y,w,h);if(!pixels)return ledger_.EndResolve(false);
   auto depth=[&](unsigned px,unsigned py){unsigned k=Tile(w,px-left,py-y);return (uint32_t(pixels[k+1])<<16)|(uint32_t(pixels[k+32])<<8)|pixels[k+33];};
   if(!ledger_.ReplayBand(left,y,w,h,[&](unsigned px,unsigned py){return (dirty[py*width+px]&4)!=0;},depth,
    [&](unsigned px,unsigned py,uint8_t a){unsigned i=py*width+px;alpha[i]=a;dirty[i]=(dirty[i]|2u)&~4u;}))return ledger_.EndResolve(false);
   for(unsigned py=y;py<y+h;++py)for(unsigned px=left;px<left+w;++px){
    if(seeded_[(py/4)*160+px/4])GSMem::WriteZ24(vram_,zbp_*32,bw_,px,py,depth(px,py));
    dirty[py*width+px]&=~4u;
   }
  }
  if(!ledger_.EndResolve(true))return false;
  seeded_.fill(0);x0_=640;y0_=480;x1_=y1_=0;++resolutions;return true;
 }
 // -1 terminal failure, 0 cleanly unsupported, 1 submitted.
 int Submit(const GSPrimitiveBatch &b){
  if(!CanSubmit(b))return 0;
  GSNativeLinearPlan p;float xy[6];if(!GSNativeDepth24Plan::Prepare(b,xy)||!GSNativeLinearPlan::Prepare(b,p)||p.x+p.width>b.state.context.frame.fbw*64)return 0;
  const auto &c=b.state.context;
  gs_gx_flat_draw d{};d.bp=c.frame.fbp*2048;d.bw=c.frame.fbw*64;d.psm=c.frame.psm;d.x=p.x;d.y=p.y;d.width=p.width;d.height=p.height;
  for(unsigned y=0;y<d.height;++y){d.left[y]=p.left[y];d.right[y]=p.right[y];}
  // Target preparation may resolve a previous RGB owner; append only afterwards.
  if(!ps2x_gx_depth24_prepare(&d))return -1;
  if(!ledger_.Pending()){zbp_=c.zbuf.zbp;bw_=c.frame.fbw;}
  if(!ledger_.Append(b,true,0))return -1;
  x0_=std::min(x0_,unsigned(p.x));y0_=std::min(y0_,unsigned(p.y));x1_=std::max(x1_,unsigned(p.x+p.width));y1_=std::max(y1_,unsigned(p.y+p.height));
  // Seed only previously untouched Z tiles, never newer resident Z.
  for(unsigned y=p.y;y<unsigned(p.y+p.height);y+=4)for(unsigned x=p.x;x<unsigned(p.x+p.width);){
   if(seeded_[(y/4)*160+x/4]){x+=4;continue;}
   unsigned end=x+4;while(end<unsigned(p.x+p.width)&&end<x+128&&!seeded_[(y/4)*160+end/4])end+=4;
   unsigned w=end-x;auto *out=Allocate(w*4*4);if(!out)return -1;
   for(unsigned yy=0;yy<4;++yy)for(unsigned xx=0;xx<w;++xx){unsigned z=GSMem::ReadZ24(vram_,zbp_*32,bw_,x+xx,y+yy),k=Tile(w,xx,yy);out[k]=255;out[k+1]=z>>16;out[k+32]=z>>8;out[k+33]=z;}
   if(!ps2x_gx_depth24_seed(out,x,y,w,4))return -1;
   for(unsigned xx=x;xx<end;xx+=4)seeded_[(y/4)*160+xx/4]=1;x=end;
  }
  for(unsigned y=p.y;y<unsigned(p.y+p.height);y+=64)for(unsigned x=p.x;x<unsigned(p.x+p.width);x+=128){
   unsigned w=std::min(128u,unsigned(p.x+p.width)-x),h=std::min(64u,unsigned(p.y+p.height)-y);auto *out=Allocate(w*h*4);if(!out)return -1;std::memset(out,0,w*h*4);
   for(unsigned py=y;py<y+h;++py){unsigned row=py-p.y,left=std::max(x,unsigned(p.x)+p.left[row]),right=std::min(x+w,unsigned(p.x)+p.right[row]);
    for(unsigned px=left;px<right;++px){unsigned z=GSNativeDepth24Plan::Depth(b,p,px-p.x,row),k=Tile(w,px-x,py-y);if(z>0xffffff)return -1;out[k]=255;out[k+1]=z>>16;out[k+32]=z>>8;out[k+33]=z;}}
   if(!ps2x_gx_depth24_draw(&d,out,x,y,w,h,p.matrices.data(),xy))return -1;++tiles;
  }
  ++submissions;return 1;
 }
};
