/* SPDX-License-Identifier: GPL-3.0-or-later */
#pragma once
#include <stdint.h>

/* Screen-space runs with one blend gate/coefficient. Joining disjoint,
 * vertically adjacent rectangles changes no coverage or fragment permission.
 * Texture/color planes remain bound by the caller for the whole primitive. */
typedef struct {
 uint32_t left,right,top,bottom,blend,factor;
} ps2x_gx_run;
typedef struct { ps2x_gx_run pending; int valid; } ps2x_gx_run_batch;

/* Returns an older run to emit when it cannot be extended. */
static inline int ps2x_gx_run_offer(ps2x_gx_run_batch *batch,
 const ps2x_gx_run *next,ps2x_gx_run *emit)
{
 if(batch->valid&&batch->pending.left==next->left&&
    batch->pending.right==next->right&&batch->pending.bottom==next->top&&
    batch->pending.blend==next->blend&&batch->pending.factor==next->factor){
  batch->pending.bottom=next->bottom;return 0;
 }
 const int ready=batch->valid;
 if(ready)*emit=batch->pending;
 batch->pending=*next;batch->valid=1;return ready;
}
static inline int ps2x_gx_run_drain(ps2x_gx_run_batch *batch,ps2x_gx_run *emit)
{
 if(!batch->valid)return 0;
 *emit=batch->pending;batch->valid=0;return 1;
}
