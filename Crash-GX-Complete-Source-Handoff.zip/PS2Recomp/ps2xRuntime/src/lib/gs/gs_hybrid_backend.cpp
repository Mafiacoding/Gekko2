#include "runtime/gs/gs_hybrid_backend.h"
#include <exception>
#include <stdexcept>

GSHybridBackend::GSHybridBackend(std::unique_ptr<GSRasterBackend> software,
                               std::unique_ptr<GSNativeDrawDriver> native)
    : m_software(std::move(software)), m_native(std::move(native))
{
    if (!m_software || !m_native)
        throw std::invalid_argument("Hybrid GS requires software and native drivers");
}
GSHybridBackend::~GSHybridBackend()
{
    if (m_nativeOwned && !m_native->Shutdown())
        std::terminate();
}
void GSHybridBackend::Check() const
{
    if (!m_initialized || m_faulted)
        throw std::runtime_error("Hybrid GS is uninitialized or faulted");
}
void GSHybridBackend::Require(bool success) const
{
    if (!success)
    {
        m_faulted = true;
        throw std::runtime_error("Hybrid GS synchronization/driver failure");
    }
}
void GSHybridBackend::Resolve() const
{
    Check();
    if (!m_pending)
        return;
    Require(DriverCall([&] { return m_native->Resolve(); }));
    // Preserve guest-latched texels: raster writes and FINISH deliberately do
    // not invalidate the software GS texture cache. Only guest TEXFLUSH does.
    m_pending = false;
    ++m_counters.resolves;
}
void GSHybridBackend::CpuWrote() const
{
    if (m_enabled)
        Require(DriverCall([&] { return m_native->CpuWroteVram(); }));
}
void GSHybridBackend::Initialize(uint8_t *vram, uint32_t size)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    if (!vram || size != 4u * 1024u * 1024u)
        throw std::invalid_argument("Hybrid GS requires shared 4 MiB VRAM");
    if (m_faulted)
        throw std::runtime_error("Faulted hybrid GS requires driver destruction");
    if (m_initialized)
    {
        Resolve();
        if (m_enabled)
            Require(m_native->Shutdown());
        m_nativeOwned = false;
        m_enabled = false;
        m_initialized = false;
    }
    m_software->Initialize(vram, size);
    // Initialization may retain VRAM before throwing. Destruction must fence
    // that driver too, even if it never became enabled.
    m_nativeOwned = true;
    m_enabled = DriverCall([&] { return m_native->Initialize(vram, size); });
    m_nativeOwned = m_enabled;
    m_initialized = true;
    m_pending = false;
    m_counters = {};
}
void GSHybridBackend::Reset()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    if (m_enabled)
        Require(DriverCall([&] { return m_native->Reset(); }));
    m_software->Reset();
    CpuWrote();
}
void GSHybridBackend::Submit(const GSPrimitiveBatch &batch)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Check();
    if (m_enabled && (!batch.state.prim.tme ||
                     m_native->SharesTextureCacheWith(m_software.get())))
    {
        if (m_pending && DriverCall([&] { return m_native->NeedsResolveBeforeSubmit(batch); }))
            Resolve();
        // Default: finish GPU writes before CPU source materialization. A driver
        // may prove its sources are latched canonical bytes or disjoint from
        // every pending target, preserving guest cache semantics and live
        // upload buffers; then repeated source draws can remain GPU resident.
        if (batch.state.prim.tme && m_pending &&
            !DriverCall([&] { return m_native->CanPrepareTextureWithoutResolve(batch); }))
            Resolve();
        const auto result = DriverCall([&] { return m_native->TrySubmit(batch); });
        Require(result != GSNativeDrawDriver::Result::Fault);
        if (result == GSNativeDrawDriver::Result::MetadataOnly)
        {
            ++m_counters.metadataDraws;
            return; // CPU depth shadow only; leave pending RGB ownership intact.
        }
        if (result == GSNativeDrawDriver::Result::Submitted)
        {
            m_pending = true;
            ++m_counters.nativeDraws;
            return; // Never mirror an accepted draw on the CPU.
        }
    }
    Resolve();
    m_software->Submit(batch);
    CpuWrote();
    ++m_counters.softwareDraws;
}
void GSHybridBackend::LoadClut(const GSTex0Reg &tex, const GSTexClutReg &clut)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    m_software->LoadClut(tex, clut);
    if (m_enabled)
        Require(DriverCall([&] { return m_native->LoadClut(tex, clut); }));
}
void GSHybridBackend::BeginTransfer(const GSTransferCommand &command)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    m_software->BeginTransfer(command); // May already write local-to-local data.
    CpuWrote();
}
void GSHybridBackend::UploadImage(const uint8_t *data, uint32_t size)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    m_software->UploadImage(data, size);
    CpuWrote();
}
void GSHybridBackend::Flush()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Check();
    if (m_enabled)
        Require(DriverCall([&] { return m_native->Flush(); }));
    m_software->Flush();
}
void GSHybridBackend::TextureFlush()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    m_software->TextureFlush();
    if (m_enabled)
        Require(DriverCall([&] { return m_native->TextureFlush(); }));
}
void GSHybridBackend::Sync(GSSyncReason reason)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    m_software->Sync(reason);
}
PresentationFrame GSHybridBackend::Present(const GSPresentationRequest &request)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve(); // CPU RGBA contract for now; direct GX presentation remains open.
    return m_software->Present(request);
}
bool GSHybridBackend::ClearFramebuffer(const GSContext &context, uint32_t rgba)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    const bool cleared = m_software->ClearFramebuffer(context, rgba);
    CpuWrote();
    return cleared;
}
uint32_t GSHybridBackend::ConsumeLocalToHostBytes(uint8_t *dst, uint32_t size)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    return m_software->ConsumeLocalToHostBytes(dst, size);
}
uint32_t GSHybridBackend::ReadVram(uint32_t psm, uint32_t base, uint32_t bw,
                                   uint32_t x, uint32_t y) const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    return m_software->ReadVram(psm, base, bw, x, y);
}
void GSHybridBackend::WriteVram(uint32_t psm, uint32_t base, uint32_t bw,
                                uint32_t x, uint32_t y, uint32_t value)
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    m_software->WriteVram(psm, base, bw, x, y, value);
    CpuWrote();
}
void GSHybridBackend::SnapshotVram(std::vector<uint8_t> &out) const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Resolve();
    m_software->SnapshotVram(out);
}
GSTransferSnapshot GSHybridBackend::GetTransferSnapshot() const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    Check();
    return m_software->GetTransferSnapshot(); // Metadata only; no VRAM access.
}
GSHybridBackend::Counters GSHybridBackend::GetCounters() const
{
    std::lock_guard<std::mutex> lock(m_mutex);
    return m_counters;
}
