// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "runtime/gs/gs_native_linear_plan.h"
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_texture_coordinates.h"
// Row scratch only; no framebuffer RGB or full-screen action buffer.
struct GSNativeFragmentPlan {
 const GSPrimitiveBatch *batch=nullptr;const GSNativeLinearPlan *plan=nullptr;
 const std::vector<uint32_t> *image=nullptr;GSCpuBackend *sampler=nullptr;
 GSCpuBackend::NativeDepthCounts depth{};
 unsigned uniformAlpha=0;bool uniform=false;
 unsigned TextureAlpha(int col,int row)const {
  if(uniform)return uniformAlpha;
  const auto &s=batch->state;const auto stq=plan->sample(*batch,col,row);
  const float inv=1.f/std::fabs(stq[2]);
  const float u=stq[0]*inv*s.textureWidth-.5f;
  const float v=stq[1]*inv*s.textureHeight-.5f;
  const int x=int(std::floor(u)),y=int(std::floor(v));const float fx=u-x,fy=v-y;
  auto tap=[&](int xx,int yy){
   xx=GSWrapTextureCoordinate(xx,s.textureWidth,s.context.clamp&3,0,0);
   yy=GSWrapTextureCoordinate(yy,s.textureHeight,(s.context.clamp>>2)&3,0,0);
   return float((*image)[size_t(yy)*s.textureWidth+xx]>>24);
  };
  const float a=tap(x,y),b=tap(x+1,y),c=tap(x,y+1),d=tap(x+1,y+1);
  const float top=a+(b-a)*fx,bottom=c+(d-c)*fx;
  return std::clamp(int(std::lround(top+(bottom-top)*fy)),0,255);
 }
 static int Row(void *opaque,uint32_t row,uint32_t left,uint32_t right,
  uint8_t *actions,uint8_t *sourceAlpha,uint8_t *storedAlpha){
  auto &p=*static_cast<GSNativeFragmentPlan*>(opaque);const auto &b=*p.batch;
  const auto &s=b.state;const auto &t=s.context.tex0;
  uint32_t z[640];
  const unsigned ztest=(s.context.test>>17)&3;
  const bool needZ=ztest>=2||(!s.context.zbuf.zmask&&ztest==1);
  if(!needZ)std::fill(z+left,z+right,0u);
  for(unsigned x=left;x<right;++x){
   float w[3]{};if(needZ||s.prim.iip)p.plan->weights(x,row,w);
   if(needZ){const double zz=b.vertices[0].z*w[0]+b.vertices[1].z*w[1]+b.vertices[2].z*w[2];
    // Vertex range preflight keeps this conversion representable.
    z[x]=static_cast<uint32_t>(zz+.5);}
   unsigned a=s.prim.iip?std::clamp(int(b.vertices[0].a*w[0]+b.vertices[1].a*w[1]+b.vertices[2].a*w[2]),0,255):b.vertices[2].a;
   if(s.prim.tme&&t.tcc){const unsigned ta=p.TextureAlpha(x,row);
    a=t.tfx==0?std::min(255u,(ta*a)>>7):t.tfx==2?std::min(255u,ta+a):ta;}
   sourceAlpha[x]=a;
  }
  return p.sampler->ProcessNativeFragmentRow(s,p.plan->x+left,p.plan->y+row,right-left,
    sourceAlpha+left,z+left,actions+left,storedAlpha+left,p.depth);
 }
};
