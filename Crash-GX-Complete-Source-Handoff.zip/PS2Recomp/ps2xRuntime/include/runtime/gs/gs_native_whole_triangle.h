// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "runtime/gs/gs_types.h"
#include <cmath>

// First whole-primitive family. No destination-dependent fragment permission
// may remain. Exact 12.4 screen vertices limit the initial GS/GX edge-ownership
// experiment; off-lattice and clipped geometry stays on canonical rows.
struct GSNativeWholeTriangle {
 static bool StateEligible(const GSPrimitiveBatch &b){
  const auto &s=b.state;const auto &c=s.context;
  const unsigned atst=(c.test>>1)&7,ztst=(c.test>>17)&3;
  return b.vertexCount==3&&(s.prim.type==GS_PRIM_TRIANGLE||s.prim.type==GS_PRIM_TRISTRIP||s.prim.type==GS_PRIM_TRIFAN)&&
   !s.prim.fge&&!s.prim.aa1&&c.frame.psm<=1&&!c.frame.fbmsk&&
   !(c.test&0x4000)&&(!(c.test&1)||atst==1)&&ztst==1&&c.zbuf.zmask&&
   !s.scanmsk&&(!s.prim.abe||!s.pabe)&&(s.colclamp&1);
 }
 static bool Geometry(const GSPrimitiveBatch &b,float (&xy)[6]){
  if(b.vertexCount!=3)return false;
  const auto &c=b.state.context;
  if(c.scissor.x0>c.scissor.x1||c.scissor.y0>c.scissor.y1||c.scissor.x1>=640||c.scissor.y1>=480)return false;
  for(unsigned i=0;i<3;++i){
   const float x=b.vertices[i].x-c.xyoffset.ofx/16.f,y=b.vertices[i].y-c.xyoffset.ofy/16.f;
   if(!std::isfinite(x)||!std::isfinite(y)||x*16.f!=std::floor(x*16.f)||y*16.f!=std::floor(y*16.f)||
    x<c.scissor.x0||x>c.scissor.x1+1u||y<c.scissor.y0||y>c.scissor.y1+1u)return false;
   // GX's sample position in this projection is 7/12; the reference GS uses
   // 1/2. Translate geometry only; existing shader planes retain their bias.
   xy[i*2]=x+1.f/12.f;xy[i*2+1]=y+1.f/12.f;
  }
  return true;
 }
 static bool Prepare(const GSPrimitiveBatch &b,float (&xy)[6]){return StateEligible(b)&&Geometry(b,xy);}
};
