#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <cstring>

namespace GSMem
{
    class TexturePageCache
    {
    public:
        static constexpr uint32_t kPageSize = 8192u;

        void Invalidate() noexcept
        {
            m_pageBase = UINT32_MAX;
            if (m_revision != UINT64_MAX) ++m_revision;
        }

        uint64_t Revision() const noexcept { return m_revision; }

        bool Contains(uint32_t byteAddress) const noexcept
        {
            return m_pageBase == (byteAddress & ~(kPageSize - 1u));
        }

        // Read-only proof for multi-page native snapshots. A retained stale
        // page must not be replaced with current VRAM merely to enable GX.
        bool CoherentWith(const uint8_t *vram) const noexcept
        {
            return vram && (m_pageBase == UINT32_MAX ||
                std::memcmp(m_bytes.data(), vram + m_pageBase, kPageSize) == 0);
        }

        // byteAddress is the wrapped, swizzled VRAM address. The returned
        // pointer is valid only until the next miss or invalidation.
        const uint8_t* Resolve(const uint8_t* vram, uint32_t byteAddress) noexcept
        {
            const uint32_t pageBase = byteAddress & ~(kPageSize - 1u);
            if (m_pageBase != pageBase)
            {
                std::memcpy(m_bytes.data(), vram + pageBase, kPageSize);
                m_pageBase = pageBase;
                if (m_revision != UINT64_MAX) ++m_revision;
            }
            return m_bytes.data() + (byteAddress & (kPageSize - 1u));
        }

    private:
        alignas(64) std::array<uint8_t, kPageSize> m_bytes{};
        uint32_t m_pageBase = UINT32_MAX;
        uint64_t m_revision = 0;
    };
}
