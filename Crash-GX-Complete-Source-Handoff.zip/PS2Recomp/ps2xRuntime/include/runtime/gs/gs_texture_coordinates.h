// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include <algorithm>
#include <cstdint>
inline int GSWrapTextureCoordinate(int coordinate,int size,uint8_t mode,uint16_t minimum,uint16_t maximum){
    switch(mode&3){
    case 0:return int(uint32_t(coordinate)&uint32_t(size-1));
    case 1:return std::min(std::max(coordinate,0),size-1);
    case 2:return std::min(std::max(coordinate,int(minimum)),int(maximum));
    case 3:return int((uint32_t(coordinate)&uint32_t(minimum))|uint32_t(maximum));
    }
    return coordinate;
}
