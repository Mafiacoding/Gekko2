#pragma once

#include "runtime/gs/gs_backend.h"
#include <memory>
#include <mutex>

// Experimental integration boundary, selected only by the opt-in Wii build. A driver
// must reject unsupported draws BEFORE submitting any GPU work. Accepted draws
// own their results until Resolve() materializes them into the supplied VRAM.
// No extra 4 MiB mirror is allocated by this coordinator.
class GSNativeDrawDriver
{
public:
    // MetadataOnly commits CPU depth/cache metadata without new GPU RGB work.
    // Unsupported must precede all architectural writes and GPU submission.
    enum class Result { Unsupported, Submitted, MetadataOnly, Fault };
    virtual ~GSNativeDrawDriver() = default;
    // False means cleanly unavailable, with no retained resources/VRAM references.
    virtual bool Initialize(uint8_t *vram, uint32_t size) = 0;
    // Default denies native textures. Opt-in drivers must use this exact
    // software backend's guest texel/CLUT cache, not an independent mirror.
    virtual bool SharesTextureCacheWith(const GSRasterBackend *) const noexcept { return false; }
    // Opt-in proof that TrySubmit's source preparation will not read external
    // VRAM that may contain older pending GPU writes. Source reads from external
    // VRAM require a proof of disjointness from every pending native target,
    // in addition to preservation of guest-latched texture/CLUT semantics.
    // It must also avoid overwriting
    // any buffer still sampled by GX. Unsupported must remain side-effect free
    // with respect to GPU submission; fallback still resolves before CPU draw.
    virtual bool CanPrepareTextureWithoutResolve(const GSPrimitiveBatch &) const { return false; }
    // A pending auxiliary owner (for example native Z) may need materialization
    // before a different native path reads CPU metadata. Query is read-only;
    // the coordinator resolves before TrySubmit, preserving clean rejection.
    virtual bool NeedsResolveBeforeSubmit(const GSPrimitiveBatch &) const { return false; }
    virtual Result TrySubmit(const GSPrimitiveBatch &batch) = 0;
    virtual bool Resolve() = 0;
    // Invalidate host-derived source/target caches, preserving guest-latched
    // texels and CLUT. CPU/GPU ownership is not a guest TEXFLUSH.
    virtual bool CpuWroteVram() = 0;
    virtual bool LoadClut(const GSTex0Reg &, const GSTexClutReg &) = 0;
    virtual bool TextureFlush() = 0;
    virtual bool Flush() = 0;
    virtual bool Reset() = 0;
    // Must fence or safely cancel all work and release external VRAM references.
    // Failure at destruction is terminal: continuing could free GPU-owned RAM.
    virtual bool Shutdown() noexcept = 0;
};

class GSHybridBackend final : public GSRasterBackend
{
public:
    struct Counters { uint64_t nativeDraws = 0, softwareDraws = 0, resolves = 0, metadataDraws = 0; };
    GSHybridBackend(std::unique_ptr<GSRasterBackend> software,
                    std::unique_ptr<GSNativeDrawDriver> native);
    ~GSHybridBackend() override;
    void Initialize(uint8_t *, uint32_t) override;
    void Reset() override;
    void Submit(const GSPrimitiveBatch &) override;
    void LoadClut(const GSTex0Reg &, const GSTexClutReg &) override;
    void BeginTransfer(const GSTransferCommand &) override;
    void UploadImage(const uint8_t *, uint32_t) override;
    void Flush() override;
    void TextureFlush() override;
    void Sync(GSSyncReason) override;
    PresentationFrame Present(const GSPresentationRequest &) override;
    bool ClearFramebuffer(const GSContext &, uint32_t) override;
    uint32_t ConsumeLocalToHostBytes(uint8_t *, uint32_t) override;
    uint32_t ReadVram(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t) const override;
    void WriteVram(uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t) override;
    void SnapshotVram(std::vector<uint8_t> &) const override;
    GSTransferSnapshot GetTransferSnapshot() const override;
    Counters GetCounters() const;
private:
    template<class Operation> auto DriverCall(Operation &&operation) const
    {
        try { return operation(); }
        catch (...) { m_faulted = true; throw; }
    }
    void Check() const;
    void Require(bool success) const;
    void Resolve() const;
    void CpuWrote() const;
    std::unique_ptr<GSRasterBackend> m_software;
    std::unique_ptr<GSNativeDrawDriver> m_native;
    mutable std::mutex m_mutex;
    bool m_initialized = false, m_enabled = false, m_nativeOwned = false;
    mutable bool m_pending = false, m_faulted = false;
    mutable Counters m_counters;
};
