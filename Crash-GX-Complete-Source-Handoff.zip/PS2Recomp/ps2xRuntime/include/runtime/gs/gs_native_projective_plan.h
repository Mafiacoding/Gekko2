// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_triangle_coverage.h"
#include "runtime/gs/gs_texture_coordinates.h"
#include <algorithm>
#include <array>
#include <cmath>
// Exact GS coverage and conservative point-sampling admission. Matrix execution
// and RGB lookup are performed by GX, not by a software framebuffer mirror.
// The point-bin proof currently examines covered samples; count that CPU cost
// separately before claiming a speedup. General filtering/Gouraud are excluded.
struct GSNativeProjectivePlan {
    int x=0,y=0,width=0,height=0;
    std::array<uint16_t,480> left{},right{};
    std::array<float,12> matrix{};
    float finalS=0,finalT=0,finalQ=1;
    unsigned checkedPixels=0;
    static bool Prepare(const GSPrimitiveBatch &b,GSNativeProjectivePlan &p){
        const auto &s=b.state;const auto &c=s.context;
        if(b.vertexCount!=3||!s.prim.tme||s.prim.fst||s.linearFilter||
           (s.prim.type!=GS_PRIM_TRIANGLE&&s.prim.type!=GS_PRIM_TRISTRIP&&s.prim.type!=GS_PRIM_TRIFAN)||
           s.textureWidth<4||s.textureHeight<4||s.textureWidth>128||s.textureHeight>128||
           (c.clamp&3)>1||((c.clamp>>2)&3)>1)return false;
        float x[3],y[3];int32_t xy[6];
        for(unsigned i=0;i<3;++i){
            const auto &v=b.vertices[i];
            if(!std::isfinite(v.x)||!std::isfinite(v.y)||std::fabs(v.x)>8192||std::fabs(v.y)>8192||
               !std::isfinite(v.s)||!std::isfinite(v.t)||!std::isfinite(v.q)||v.q<1.e-6f||
               std::fabs(v.s)>1024||std::fabs(v.t)>1024||v.q>1024)return false;
            x[i]=v.x-c.xyoffset.ofx/16.f;y[i]=v.y-c.xyoffset.ofy/16.f;
            xy[i*2]=std::lround(v.x*16.f)-c.xyoffset.ofx;
            xy[i*2+1]=std::lround(v.y*16.f)-c.xyoffset.ofy;
        }
        const float maxQ=std::max({b.vertices[0].q,b.vertices[1].q,b.vertices[2].q});
        const float minQ=std::min({b.vertices[0].q,b.vertices[1].q,b.vertices[2].q});
        if(maxQ/minQ>64)return false;
        p.x=std::clamp(int(std::floor(std::min({x[0],x[1],x[2]}))),int(c.scissor.x0),int(c.scissor.x1));
        p.y=std::clamp(int(std::floor(std::min({y[0],y[1],y[2]}))),int(c.scissor.y0),int(c.scissor.y1));
        int xmax=std::clamp(int(std::ceil(std::max({x[0],x[1],x[2]}))),int(c.scissor.x0),int(c.scissor.x1));
        int ymax=std::clamp(int(std::ceil(std::max({y[0],y[1],y[2]}))),int(c.scissor.y0),int(c.scissor.y1));
        if(p.x<0||p.y<0||xmax>=640||ymax>=480||xmax<p.x||ymax<p.y)return false;
        const int w=xmax-p.x+1,h=ymax-p.y+1;
        p.width=(w+3)&~3;p.height=(h+3)&~3;
        if(p.x+p.width>640||p.y+p.height>480)return false;
        GSFixedTriangleCoverage coverage(xy,p.x*16+8,p.y*16+8),origin(xy,8,8);
        if(!coverage.area)return false;
        const float inv=1.f/float(coverage.area);
        for(unsigned row=0;row<3;++row){
            double a=0,bb=0,cc=0;
            for(unsigned i=0;i<3;++i){
                const auto &v=b.vertices[i];const double f=row==0?v.s:row==1?v.t:v.q;
                a+=f*origin.edges[i].stepX;bb+=f*origin.edges[i].stepY;cc+=f*origin.edges[i].value;
            }
            a/=double(coverage.area);bb/=double(coverage.area);cc/=double(coverage.area);
            // Common homogeneous normalization preserves S/Q and T/Q while
            // avoiding tiny-Q texture matrices in the GX interpolator.
            p.matrix[row*4]=float(a/maxQ);p.matrix[row*4+1]=float(bb/maxQ);p.matrix[row*4+2]=0;
            p.matrix[row*4+3]=float((cc-(a+bb)*(7.0/12.0))/maxQ);
        }
        double low[2]={-INFINITY,-INFINITY},high[2]={INFINITY,INFINITY};
        float minimum[2]={INFINITY,INFINITY};
        constexpr float margin=1.f/1024;
        p.checkedPixels=0;p.left.fill(0);p.right.fill(0);
        for(int row=0;row<h;++row){
            if((s.scanmsk==2&&!((p.y+row)&1))||(s.scanmsk==3&&((p.y+row)&1)))continue;
            const auto span=coverage.rowSpan(row,w);p.left[row]=span.begin;p.right[row]=span.end;
            for(int col=span.begin;col<span.end;++col){
                float weight[3];for(unsigned i=0;i<3;++i)weight[i]=float(coverage.edges[i].value+coverage.edges[i].stepY*row+coverage.edges[i].stepX*col)*inv;
                auto value=[&](unsigned k){float a=k==0?b.vertices[0].s:k==1?b.vertices[0].t:b.vertices[0].q;
                    float bb=k==0?b.vertices[1].s:k==1?b.vertices[1].t:b.vertices[1].q;
                    float cc=k==0?b.vertices[2].s:k==1?b.vertices[2].t:b.vertices[2].q;return a*weight[0]+bb*weight[1]+cc*weight[2];};
                const float qs=value(2),ss=value(0),ts=value(1);
                if(s.prim.iip&&!(c.tex0.tfx==1&&c.tex0.tcc)){
                    for(unsigned k=0;k<4;++k){auto chan=[&](unsigned i){const auto&v=b.vertices[i];return k==0?v.r:k==1?v.g:k==2?v.b:v.a;};
                        const int interpolated=int(chan(0)*weight[0]+chan(1)*weight[1]+chan(2)*weight[2]);
                        if(interpolated!=chan(2))return false;
                    }
                }
                const float gx=p.x+col+7.f/12,gy=p.y+row+7.f/12;
                auto plane=[&](unsigned k){return p.matrix[k*4]*gx+p.matrix[k*4+1]*gy+p.matrix[k*4+3];};
                const float qg=plane(2);if(qg<1.e-7f)return false;
                for(unsigned axis=0;axis<2;++axis){
                    const int size=axis?s.textureHeight:s.textureWidth;const unsigned wrap=(c.clamp>>(axis*2))&3;
                    const float cpu=(axis?ts:ss)*(1.f/qs)*float(size),gpu=plane(axis)/qg*float(size);
                    if(!std::isfinite(cpu)||!std::isfinite(gpu)||std::fabs(cpu)>1048576||std::fabs(gpu)>1048576)return false;
                    minimum[axis]=std::min(minimum[axis],cpu);
                    const int target=int(std::floor(cpu));
                    if(!(wrap==1&&target<=0))low[axis]=std::max(low[axis],double(target)+margin-gpu);
                    if(!(wrap==1&&target>=size-1))high[axis]=std::min(high[axis],double(target)+1-margin-gpu);
                    if(!(low[axis]<high[axis]))return false;
                }
                p.finalS=ss;p.finalT=ts;p.finalQ=qs;++p.checkedPixels;
            }
        }
        if(!p.checkedPixels)return false;
        for(unsigned axis=0;axis<2;++axis){
            const double bias=std::isfinite(low[axis])&&std::isfinite(high[axis])?(low[axis]+high[axis])*.5:
                std::isfinite(low[axis])?low[axis]+.5:std::isfinite(high[axis])?high[axis]-.5:0;
            const double size=axis?s.textureHeight:s.textureWidth;
            // GX's fixed-point repeat addressing of negative STQ coordinates
            // need not round like floor(S/Q) in the GS. Translate by a whole
            // texture period in homogeneous space, preserving every repeat tap
            // while keeping the covered coordinates nonnegative.
            const double period=((c.clamp>>(axis*2))&3)==0?-std::floor(minimum[axis]/size):0;
            for(unsigned j=0;j<4;++j)p.matrix[axis*4+j]=float(p.matrix[axis*4+j]+(bias/size+period)*p.matrix[8+j]);
        }
        // Recheck the rounded float matrix, not just the double bias interval.
        for(int row=0;row<h;++row)for(int col=p.left[row];col<p.right[row];++col){
            float weight[3];for(unsigned i=0;i<3;++i)weight[i]=float(coverage.edges[i].value+coverage.edges[i].stepY*row+coverage.edges[i].stepX*col)*inv;
            float v[3]={};for(unsigned i=0;i<3;++i){v[0]+=b.vertices[i].s*weight[i];v[1]+=b.vertices[i].t*weight[i];v[2]+=b.vertices[i].q*weight[i];}
            const float gx=p.x+col+7.f/12,gy=p.y+row+7.f/12;
            auto plane=[&](unsigned k){return p.matrix[k*4]*gx+p.matrix[k*4+1]*gy+p.matrix[k*4+3];};
            for(unsigned axis=0;axis<2;++axis){
                const int size=axis?s.textureHeight:s.textureWidth;const unsigned wrap=(c.clamp>>(axis*2))&3;
                const float cpu=v[axis]*(1.f/v[2])*size,gpu=(plane(axis)/plane(2))*size;
                if(!std::isfinite(gpu)||std::fabs(gpu)>1048576)return false;
                const int expected=GSWrapTextureCoordinate(int(std::floor(cpu)),size,wrap,0,0);
                if(expected!=GSWrapTextureCoordinate(int(std::floor(gpu)),size,wrap,0,0))return false;
                const float frac=gpu-std::floor(gpu);
                if(!(wrap==1&&(gpu<0||gpu>=size-1))&&(frac<margin*.5f||frac>1-margin*.5f))return false;
            }
        }
        return p.checkedPixels!=0;
    }
};
