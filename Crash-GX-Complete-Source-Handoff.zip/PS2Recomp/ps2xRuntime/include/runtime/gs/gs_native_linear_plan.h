// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "runtime/gs/gs_triangle_coverage.h"
#include "runtime/gs/gs_types.h"
#include <algorithm>
#include <array>
#include <cmath>
// Geometry and shader planes for the experimental hardware-linear RGB path.
// Unlike the strict point plan, this does not shade/check every output pixel.
// RGB precision has a separate bounded-error contract; coverage stays canonical.
struct GSNativeLinearPlan {
    int x=0,y=0,width=0,height=0;
    std::array<uint16_t,480> left{},right{};
    std::array<float,60> matrices{}; // Source STQ, then R/G/B/A ramp coordinates.
    std::array<GSFixedTriangleCoverage::Edge,3> edges{};
    int64_t area=0;float inverseArea=0;
    std::array<float,3> firstSample{},lastSample{};
    bool textured=false;
    void weights(int col,int row,float (&w)[3]) const {
        for(unsigned i=0;i<3;++i)w[i]=float(edges[i].value+edges[i].stepX*col+edges[i].stepY*row)*inverseArea;
    }
    std::array<float,3> sample(const GSPrimitiveBatch &b,int col,int row)const{
        float w[3];weights(col,row,w);
        return {b.vertices[0].s*w[0]+b.vertices[1].s*w[1]+b.vertices[2].s*w[2],
                b.vertices[0].t*w[0]+b.vertices[1].t*w[1]+b.vertices[2].t*w[2],
                b.vertices[0].q*w[0]+b.vertices[1].q*w[1]+b.vertices[2].q*w[2]};
    }
    static bool Prepare(const GSPrimitiveBatch &b,GSNativeLinearPlan &p){
        const auto &s=b.state;const auto &c=s.context;
        if(c.scissor.x0>c.scissor.x1||c.scissor.y0>c.scissor.y1||c.scissor.x1>=640||c.scissor.y1>=480)return false;
        if(b.vertexCount!=3||(s.prim.type!=GS_PRIM_TRIANGLE&&s.prim.type!=GS_PRIM_TRISTRIP&&s.prim.type!=GS_PRIM_TRIFAN))return false;
        if(s.prim.tme&&(s.prim.fst||!s.linearFilter||s.textureWidth<4||s.textureWidth>128||s.textureHeight<4||s.textureHeight>128||
            (c.clamp&3)>1||((c.clamp>>2)&3)>1||((c.tex1>>2)&7)))return false;
        float x[3],y[3],maxQ=0,minQ=INFINITY;int32_t xy[6];
        double minS=INFINITY,minT=INFINITY,maxS=-INFINITY,maxT=-INFINITY;
        for(unsigned i=0;i<3;++i){const auto &v=b.vertices[i];
            if(!std::isfinite(v.x)||!std::isfinite(v.y)||std::fabs(v.x)>8192||std::fabs(v.y)>8192)return false;
            x[i]=v.x-c.xyoffset.ofx/16.f;y[i]=v.y-c.xyoffset.ofy/16.f;
            xy[i*2]=std::lround(v.x*16.f)-c.xyoffset.ofx;xy[i*2+1]=std::lround(v.y*16.f)-c.xyoffset.ofy;
            if(s.prim.tme){
                if(!std::isfinite(v.s)||!std::isfinite(v.t)||!std::isfinite(v.q)||v.q<1.e-6f||v.q>1024)return false;
                maxQ=std::max(maxQ,v.q);minQ=std::min(minQ,v.q);
                const double a=double(v.s)/v.q,bb=double(v.t)/v.q;
                if(!std::isfinite(a)||!std::isfinite(bb)||std::fabs(a)>16||std::fabs(bb)>16)return false;
                minS=std::min(minS,a);maxS=std::max(maxS,a);minT=std::min(minT,bb);maxT=std::max(maxT,bb);
            }
        }
        if(s.prim.tme&&(maxQ/minQ>64||maxS-minS>4||maxT-minT>4))return false;
        p.x=std::clamp(int(std::floor(std::min({x[0],x[1],x[2]}))),int(c.scissor.x0),int(c.scissor.x1));
        p.y=std::clamp(int(std::floor(std::min({y[0],y[1],y[2]}))),int(c.scissor.y0),int(c.scissor.y1));
        const int xmax=std::clamp(int(std::ceil(std::max({x[0],x[1],x[2]}))),int(c.scissor.x0),int(c.scissor.x1));
        const int ymax=std::clamp(int(std::ceil(std::max({y[0],y[1],y[2]}))),int(c.scissor.y0),int(c.scissor.y1));
        if(p.x<0||p.y<0||xmax>=640||ymax>=480||xmax<p.x||ymax<p.y)return false;
        // Resident surfaces import 4x4 tiles. Align the origin, rather than
        // padding an unaligned right/bottom edge beyond the viewport.
        p.x&=~3;p.y&=~3;
        const int w=xmax-p.x+1,h=ymax-p.y+1;p.width=(w+3)&~3;p.height=(h+3)&~3;
        if(p.x+p.width>640||p.y+p.height>480)return false;
        GSFixedTriangleCoverage coverage(xy,p.x*16+8,p.y*16+8),origin(xy,8,8);
        if(coverage.area<256)return false;
        p.area=coverage.area;p.inverseArea=1.f/float(p.area);p.textured=s.prim.tme;
        for(unsigned i=0;i<3;++i)p.edges[i]=coverage.edges[i];
        p.left.fill(0);p.right.fill(0);p.matrices.fill(0);bool covered=false,sampled=false;
        for(int row=0;row<h;++row){
            if(p.y+row<int(c.scissor.y0)||p.y+row>int(c.scissor.y1))continue;
            const auto span=coverage.rowSpan(row,w);
            const int begin=std::max(int(span.begin),int(c.scissor.x0)-p.x);
            const int end=std::min(int(span.end),int(c.scissor.x1)-p.x+1);
            if(begin<end){
                // The software GS samples before WritePixel applies SCANMSK.
                // Rejected field rows still determine the retained texture page.
                if(!sampled)p.firstSample=p.sample(b,begin,row);
                p.lastSample=p.sample(b,end-1,row);sampled=true;
                if((s.scanmsk==2&&!((p.y+row)&1))||(s.scanmsk==3&&((p.y+row)&1)))continue;
                p.left[row]=begin;p.right[row]=end;covered=true;
            }
        }
        if(!covered)return false;
        auto plane=[&](const double (&f)[3],float *out,double scale){
            double a=0,bb=0,cc=0;
            for(unsigned i=0;i<3;++i){a+=f[i]*origin.edges[i].stepX;bb+=f[i]*origin.edges[i].stepY;cc+=f[i]*origin.edges[i].value;}
            a/=p.area;bb/=p.area;cc/=p.area;
            out[0]=float(a*scale);out[1]=float(bb*scale);out[2]=0;out[3]=float((cc-(a+bb)*(7.0/12.0))*scale);
        };
        if(s.prim.tme){
            for(unsigned row=0;row<3;++row){const double f[3]={row==0?b.vertices[0].s:row==1?b.vertices[0].t:b.vertices[0].q,
                row==0?b.vertices[1].s:row==1?b.vertices[1].t:b.vertices[1].q,
                row==0?b.vertices[2].s:row==1?b.vertices[2].t:b.vertices[2].q};plane(f,p.matrices.data()+row*4,1.0/maxQ);}
            for(unsigned axis=0;axis<2;++axis)if(((c.clamp>>(axis*2))&3)==0){
                const double period=-std::floor(axis?minT:minS);
                for(unsigned j=0;j<4;++j)p.matrices[axis*4+j]=float(p.matrices[axis*4+j]+period*p.matrices[8+j]);
            }
        }else p.matrices[11]=1;
        for(unsigned channel=0;channel<4;++channel){
            auto value=[&](unsigned i){const auto &v=b.vertices[s.prim.iip?i:2];return double(channel==0?v.r:channel==1?v.g:channel==2?v.b:v.a);};
            const double f[3]={value(0),value(1),value(2)};float *out=p.matrices.data()+(channel+1)*12;plane(f,out,1.0/256);
            out[7]=.5f;out[11]=1;
        }
        for(float f:p.matrices)if(!std::isfinite(f)||std::fabs(f)>65536)return false;
        return true;
    }
};
