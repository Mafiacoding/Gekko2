// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "runtime/gs/gs_native_depth24_plan.h"
#include <array>
#include <cfenv>

// Bounded metadata for a resident Z24 GEQUAL batch. No texture pointers, image
// ownership or GPU command storage: only immutable guest primitive state and a
// proven uniform texture-alpha value. GPU lifetime fences belong to the driver.
class GSNativeDepth24Ledger {
 struct Record { GSPrimitiveBatch batch; uint8_t textureAlpha; int rounding; };
 class RoundingScope {
  int saved_;bool changed_=false,valid_=false;
 public:
  explicit RoundingScope(int mode):saved_(std::fegetround()){
   if(saved_==-1)return;
   changed_=saved_!=mode;valid_=!changed_||std::fesetround(mode)==0;
  }
  ~RoundingScope(){if(valid_&&changed_)std::fesetround(saved_);}
  bool Valid()const{return valid_;}
 };
 static_assert(sizeof(Record)<=512);
 std::array<Record,128> records_{};
 unsigned size_=0,frameBase_=0,width_=0,zBase_=0,frameFormat_=0;
 bool resolving_=false,faulted_=false;
public:
 static constexpr unsigned Capacity=128;
 unsigned Size()const{return size_;}
 bool Pending()const{return size_!=0;}
 bool Faulted()const{return faulted_;}
 bool CanAppend(const GSPrimitiveBatch &b,bool uniformTextureAlpha)const{
  float xy[6];const auto &c=b.state.context;
  if(faulted_||resolving_||size_==Capacity||!GSNativeDepth24Plan::Prepare(b,xy)||
    !c.frame.fbw||c.frame.fbw>10||c.frame.fbp>=512||c.frame.fbp+15u*c.frame.fbw>512||c.zbuf.zbp>=512||c.zbuf.zbp+15u*c.frame.fbw>512||
    (b.state.prim.tme&&c.tex0.tcc&&!uniformTextureAlpha))return false;
  for(const auto &v:b.vertices)if(v.x-c.xyoffset.ofx/16.f>c.frame.fbw*64u)return false;
  if(!(c.frame.fbp+15u*c.frame.fbw<=c.zbuf.zbp||c.zbuf.zbp+15u*c.frame.fbw<=c.frame.fbp))return false;
  return !size_||(frameBase_==c.frame.fbp&&width_==c.frame.fbw&&zBase_==c.zbuf.zbp&&frameFormat_==c.frame.psm);
 }
 bool Append(const GSPrimitiveBatch &b,bool uniformTextureAlpha,uint8_t textureAlpha){
  const int rounding=std::fegetround();
  if(rounding==-1||!CanAppend(b,uniformTextureAlpha))return false;
  if(!size_){frameBase_=b.state.context.frame.fbp;width_=b.state.context.frame.fbw;zBase_=b.state.context.zbuf.zbp;frameFormat_=b.state.context.frame.psm;}
  records_[size_++]={b,textureAlpha,rounding};return true;
 }
 // Conservative physical envelope, including seeded but untouched Z pixels.
 bool SourceDisjoint(uint32_t lo,uint32_t hi)const{
  if(lo>=hi||hi>4u*1024u*1024u)return false;
  if(!size_)return true;
  const uint32_t begin=zBase_*8192u,end=begin+15u*width_*8192u;
  return hi<=begin||lo>=end;
 }
 bool BeginResolve(){if(faulted_||resolving_)return false;resolving_=true;return true;}
 // Callbacks address global pixels. pending/commit may reference the existing
 // surface metadata; finalDepth reads a completed GPU Z copy. No full-screen
 // alpha or depth mirror is allocated by this class. commit must make pending
 // false for the same pixel, so an older equal-Z draw cannot overwrite alpha.
 template<class Pending,class FinalDepth,class Commit>
 bool ReplayBand(unsigned x,unsigned y,unsigned width,unsigned height,Pending pending,FinalDepth finalDepth,Commit commit)const{
  if(faulted_||!resolving_||x>=640||y>=480||!width||width>640-x||!height||height>480-y)return false;
  if(size_&&x+width>width_*64u)return false;
  for(unsigned i=size_;i>0;--i){const auto &r=records_[i-1];if(r.batch.state.context.frame.psm==GS_PSM_CT24)continue;
   RoundingScope rounding(r.rounding);if(!rounding.Valid())return false;GSNativeLinearPlan p;
   if(!GSNativeLinearPlan::Prepare(r.batch,p))return false;
   const int top=std::max(int(y),p.y),bottom=std::min(int(y+height),p.y+p.height);
   for(int py=top;py<bottom;++py){const int row=py-p.y;
    const int left=std::max(int(x),p.x+p.left[row]),right=std::min(int(x+width),p.x+p.right[row]);
    for(int px=left;px<right;++px)if(pending(px,py)&&GSNativeDepth24Plan::Depth(r.batch,p,px-p.x,row)==finalDepth(px,py))
     commit(px,py,GSNativeDepth24Plan::StoredAlpha(r.batch,p,px-p.x,row,r.textureAlpha));
   }
  }
  return true;
 }
 bool EndResolve(bool completed){
  if(!resolving_)return false;
  resolving_=false;if(!completed){faulted_=true;return false;}
  size_=0;return true;
 }
};

static_assert(sizeof(GSNativeDepth24Ledger)<=66u*1024u);
