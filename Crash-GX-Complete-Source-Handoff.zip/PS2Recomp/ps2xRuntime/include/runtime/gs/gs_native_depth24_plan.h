// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "runtime/gs/gs_native_linear_plan.h"
#include "runtime/gs/gs_native_whole_triangle.h"

// Canonical source samples only: no destination Z read, test, or guest write.
// The first resident-depth family uses GEQUAL + writes and unconditional alpha.
// For this monotonic family the last submitted primitive matching final Z is
// also the last alpha writer. Reverse replay can recover exact eight-bit alpha
// without storing it in GX's RGB8 EFB or replaying all intermediate Z writes.
struct GSNativeDepth24Plan {
 static bool StateEligible(const GSPrimitiveBatch &b){
  const auto &s=b.state;const auto &c=s.context;
  const bool primitive=b.vertexCount==3&&(s.prim.type==GS_PRIM_TRIANGLE||s.prim.type==GS_PRIM_TRISTRIP||s.prim.type==GS_PRIM_TRIFAN);
  if(!primitive||s.prim.fge||s.prim.aa1||c.frame.psm>1||c.frame.fbmsk||
    (c.test&0x4000)||((c.test&1)&&((c.test>>1)&7)!=1)||((c.test>>17)&3)!=2||
    c.zbuf.zmask||c.zbuf.psm!=GS_PSM_Z24||s.scanmsk||(s.prim.abe&&s.pabe)||!(s.colclamp&1))return false;
  for(const auto &v:b.vertices)if(!std::isfinite(v.z)||v.z<0||v.z>0xffffdfu)return false;
  return true;
 }
 static bool Prepare(const GSPrimitiveBatch &b,float (&xy)[6]){
  return StateEligible(b)&&GSNativeWholeTriangle::Geometry(b,xy);
 }
 static uint32_t Depth(const GSPrimitiveBatch &b,const GSNativeLinearPlan &p,int x,int y){
  float w[3];p.weights(x,y,w);
  const double z=b.vertices[0].z*w[0]+b.vertices[1].z*w[1]+b.vertices[2].z*w[2];
  return static_cast<uint32_t>(z+.5);
 }
 // Uniform texture alpha is required whenever TCC consumes texture alpha.
 // Caller must establish uniformity from the canonical decoded source image.
 static uint8_t SourceAlpha(const GSPrimitiveBatch &b,const GSNativeLinearPlan &p,int x,int y,unsigned textureAlpha){
  const auto &s=b.state;const auto &t=s.context.tex0;unsigned a=b.vertices[2].a;
  if(s.prim.iip){float w[3];p.weights(x,y,w);a=std::clamp(int(b.vertices[0].a*w[0]+b.vertices[1].a*w[1]+b.vertices[2].a*w[2]),0,255);}
  if(s.prim.tme&&t.tcc)a=t.tfx==0?std::min(255u,(textureAlpha*a)>>7):t.tfx==2?std::min(255u,textureAlpha+a):textureAlpha;
  return uint8_t(a);
 }
 static uint8_t StoredAlpha(const GSPrimitiveBatch &b,const GSNativeLinearPlan &p,int x,int y,unsigned textureAlpha){
  return uint8_t(SourceAlpha(b,p,x,y,textureAlpha)|((b.state.context.fba&1)?128:0));
 }
};
