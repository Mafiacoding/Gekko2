#pragma once

#include "runtime/gs/gs_backend.h"
#include "runtime/gs/gs_texture_page_cache.h"

#include <array>
#include <mutex>
#include <vector>

class GSCpuBackend final : public GSRasterBackend
{
public:
    GSCpuBackend();

    void Initialize(uint8_t *vram, uint32_t vramSize) override;
    void Reset() override;

    void Submit(const GSPrimitiveBatch &batch) override;
    void LoadClut(const GSTex0Reg &tex0, const GSTexClutReg &texclut) override;
    void BeginTransfer(const GSTransferCommand &command) override;
    void UploadImage(const uint8_t *data, uint32_t sizeBytes) override;

    void Flush() override;
    void TextureFlush() override;
    void Sync(GSSyncReason reason) override;
    PresentationFrame Present(const GSPresentationRequest &request) override;

    bool ClearFramebuffer(const GSContext &context, uint32_t rgba) override;
    uint32_t ConsumeLocalToHostBytes(uint8_t *dst, uint32_t maxBytes) override;

    uint32_t ReadVram(uint32_t psm, uint32_t base, uint32_t bw, uint32_t x, uint32_t y) const override;
    void WriteVram(uint32_t psm, uint32_t base, uint32_t bw, uint32_t x, uint32_t y, uint32_t value) override;
    void SnapshotVram(std::vector<uint8_t> &out) const override;
    GSTransferSnapshot GetTransferSnapshot() const override;

    struct NativeTextureStamp { uint64_t texels=0, clut=0; };
    // Stamp applies to a supported source still latched in the canonical cache.
    // Pair with all source/TEXA/combine state before reusing a decoded upload.
    // Revisions saturate; stamp reuse is disabled permanently on exhaustion.
    bool GetNativeTextureStamp(const GSDrawState &state, NativeTextureStamp &stamp) const;
    // True only when a supported single-page decode would read exclusively
    // latched cache/CLUT bytes, never external VRAM. Valid until another call
    // mutates the canonical cache; coordinator serializes that interval.
    bool CanDecodeNativeTexturePageWithoutVramRead(const GSDrawState &state) const;
    // Materialize raw point-sampled texels through this backend's canonical
    // guest texture/CLUT cache. Restricted to one aligned physical 8 KiB page;
    // rejection leaves both the output and guest cache untouched. Does not
    // perform TFX, filtering, rasterization or framebuffer writes.
    bool DecodeNativeTexturePage(const GSDrawState &state, std::vector<uint32_t> &rgba);
    struct NativeTextureRect { uint16_t x=0,y=0,width=0,height=0; };
    // Raw, already-wrapped source coordinates, not screen pixels. A small
    // footprint of a large texture is allowed only when all texels use one
    // physical cache page. Rejects before changing output or guest cache.
    bool DecodeNativeTextureRect(const GSDrawState &,NativeTextureRect,std::vector<uint32_t> &);
    bool GetNativeTextureRectStamp(const GSDrawState &,NativeTextureRect,NativeTextureStamp &) const;

    // Non-mutating, bounded multi-page source snapshot. Requires every retained
    // texel byte to equal current VRAM; stale retained data rejects rather than
    // being silently flushed. Caller serializes and excludes pending GPU writes
    // to the source. The CLUT stays latched. No framebuffer pixels are shaded.
    bool GetCoherentNativeImageStamp(const GSDrawState &, uint64_t &clutRevision) const;
    bool SnapshotNativeClut(std::vector<uint16_t> &) const;
    bool SnapshotCoherentNativeImage(const GSDrawState &, std::vector<uint32_t> &);
    // After an accepted draw, reproduce its final actual sample's guest cache
    // state. A snapshot alone never authorizes changing the canonical cache.
    bool CommitCoherentNativeSample(const GSDrawState &, float s, float t, float q);

    enum NativeFragmentAction : uint8_t { NativeRgb=1, NativeAlpha=2, NativeDepth=4, NativeBlend=8 };
    struct NativeDepthCounts { uint64_t tested=0,rejected=0,written=0; };
    // Exact GS alpha/depth permissions and depth shadow only. Never reads or
    // shades framebuffer RGB, and never flushes the retained texture cache.
    // Caller excludes depth aliases with pending/seeded RGB and texture sources
    // before invoking this mutating operation; one lock is held per row.
    bool ProcessNativeFragmentRow(const GSDrawState &,uint32_t x,uint32_t y,uint32_t count,
        const uint8_t *sourceAlpha,const uint32_t *incomingZ,uint8_t *actions,uint8_t *storedAlpha,NativeDepthCounts &);

private:
    void ResetUnlocked();
    void LoadClutUnlocked(const GSTex0Reg &tex0, const GSTexClutReg &texclut);
    uint32_t ReadVramUnlocked(uint32_t psm, uint32_t base, uint32_t bw, uint32_t x, uint32_t y) const;
    uint32_t ReadTextureVramUnlocked(uint32_t psm, uint32_t base, uint32_t bw, uint32_t x, uint32_t y);
    void WriteVramUnlocked(uint32_t psm, uint32_t base, uint32_t bw, uint32_t x, uint32_t y, uint32_t value);

    void DrawPrimitive(const GSPrimitiveBatch &batch);
    void DrawSprite(const GSPrimitiveBatch &batch);
    void DrawTriangle(const GSPrimitiveBatch &batch);
    void DrawLine(const GSPrimitiveBatch &batch);
    void WritePixel(const GSDrawState &state, int x, int y, int z, uint8_t r, uint8_t g, uint8_t b, uint8_t a, uint8_t fog);
    uint32_t SampleTexture(const GSDrawState &state, float s, float t, float q, uint16_t u, uint16_t v);
    uint32_t LookupCLUT(const GSDrawState &state, uint8_t index, uint8_t cpsm, uint8_t csm, uint8_t csa, uint8_t sourcePsm);

    void PerformLocalToLocalTransfer();
    void PerformLocalToHostTransfer();
    PresentationFrame PresentFromLocalMemory(const GSPresentationRequest &request);
    bool CopyFrameToHostRgba(const GSFrameReg &frame,
                             uint32_t width,
                             uint32_t height,
                             std::vector<uint8_t> &outPixels,
                             bool preserveAlpha,
                             bool useLocalMemoryLayout,
                             bool frameBaseIsPages,
                             uint32_t sourceOriginX,
                             uint32_t sourceOriginY,
                             uint32_t storageHeight = 0u) const;

    using WriteVramFunc = void (*)(uint8_t *, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t);
    using ReadVramFunc = uint32_t (*)(uint8_t *, uint32_t, uint32_t, uint32_t, uint32_t);

    static constexpr size_t kPsmHandlerCount = 1u << 6u;
    mutable std::mutex m_mutex;
    uint8_t *m_vram = nullptr;
    uint32_t m_vramSize = 0;
    std::array<ReadVramFunc, kPsmHandlerCount> m_readVramFuncs{};
    std::array<WriteVramFunc, kPsmHandlerCount> m_writeVramFuncs{};
    std::array<uint16_t, 512> m_clut{};
    std::array<uint32_t, 2> m_clutCbp{};
    GSMem::TexturePageCache m_texturePageCache;
    uint64_t m_clutRevision = 0;

    GSTransferCommand m_transfer{};
    GSTransferSnapshot m_transferState{};
    std::vector<uint8_t> m_localToHostBuffer;
    size_t m_localToHostReadPos = 0;
};
