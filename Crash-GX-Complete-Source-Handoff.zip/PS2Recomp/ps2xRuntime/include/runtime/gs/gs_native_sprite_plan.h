// SPDX-License-Identifier: GPL-3.0-or-later
#pragma once
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/gs_texture_coordinates.h"
#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
// Coordinate/coverage planning only. Does not authorize framebuffer, test,
// depth or blend state, read guest VRAM, or shade screen pixels.
struct GSNativeSpritePlan {
    int x=0,y=0,width=0,height=0;
    GSCpuBackend::NativeTextureRect source;
    float u=0,v=0,du=0,dv=0;
    std::array<int32_t,640> columns;
    std::array<int32_t,480> rows;
    static bool Fit(const int32_t *indices,int count,int origin,int last,float slope,float &start,float &step){
        if(count<=0||!std::isfinite(slope)||std::fabs(slope)>16384)return false;
        if(origin==last){start=.5f;step=0;return true;}
        double low=-std::numeric_limits<double>::infinity(),high=-low;
        constexpr double center=7.0/12.0;
        for(int i=0;i<count;++i){
            const double base=double(slope)*(i+center),index=indices[i]-origin;
            if(indices[i]!=origin)low=std::max(low,index+.0625-base);
            if(indices[i]!=last)high=std::min(high,index+.9375-base);
        }
        if(!(low<high))return false;
        const double candidate=std::isfinite(low)&&std::isfinite(high)?(low+high)*.5:std::isfinite(low)?low+.5:high-.5;
        if(!std::isfinite(candidate)||std::fabs(candidate)>1048576)return false;
        start=float(candidate);step=slope;
        for(int i=0;i<count;++i){
            const float sample=start+step*(float(i)+float(center));
            // An interior margin protects GX fixed-point texel quantization.
            const int target=indices[i]-origin;
            if((indices[i]!=origin&&sample<float(target)+.03125f)||(indices[i]!=last&&sample>float(target)+.96875f))return false;
        }
        return true;
    }
    static bool Prepare(const GSPrimitiveBatch &batch,GSNativeSpritePlan &out){
        const auto &s=batch.state;const auto &c=s.context;
        if(batch.vertexCount!=2||s.prim.type!=GS_PRIM_SPRITE||!s.prim.tme||s.linearFilter||s.textureWidth<1||s.textureWidth>1024||s.textureHeight<1||s.textureHeight>1024)return false;
        const auto &a=batch.vertices[0],&b=batch.vertices[1];
        for(const auto *p:{&a,&b})if(!std::isfinite(p->x)||!std::isfinite(p->y)||std::fabs(p->x)>8192||std::fabs(p->y)>8192)return false;
        const float left=std::min(a.x,b.x)-c.xyoffset.ofx/16.f,right=std::max(a.x,b.x)-c.xyoffset.ofx/16.f;
        const float top=std::min(a.y,b.y)-c.xyoffset.ofy/16.f,bottom=std::max(a.y,b.y)-c.xyoffset.ofy/16.f;
        if(!(left<right&&top<bottom))return false;
        out.x=std::max(int(std::ceil(left)),int(c.scissor.x0));out.y=std::max(int(std::ceil(top)),int(c.scissor.y0));
        const int x1=std::min(int(std::ceil(right)),int(c.scissor.x1)+1),y1=std::min(int(std::ceil(bottom)),int(c.scissor.y1)+1);
        out.width=x1-out.x;out.height=y1-out.y;
        if(out.x<0||out.y<0||out.width<=0||out.height<=0||x1>640||y1>480)return false;
        float u0,u1,v0,v1;
        if(s.prim.fst){u0=a.u/16.f;u1=b.u/16.f;v0=a.v/16.f;v1=b.v/16.f;}
        else{
            if(!std::isfinite(a.s)||!std::isfinite(a.t)||!std::isfinite(b.s)||!std::isfinite(b.t)||!std::isfinite(b.q))return false;
            const float q=std::fabs(b.q)>1.e-8f?b.q:1.f;
            u0=(a.s/q)*s.textureWidth;u1=(b.s/q)*s.textureWidth;v0=(a.t/q)*s.textureHeight;v1=(b.t/q)*s.textureHeight;
        }
        if(a.x>b.x)std::swap(u0,u1);if(a.y>b.y)std::swap(v0,v1);
        auto axis=[&](int count,int first,float edge,float length,float lo,float hi,int size,unsigned shift,int32_t *indices,int &minimum,int &maximum){
            minimum=1024;maximum=-1;
            const uint8_t wrap=(c.clamp>>shift)&3;
            const unsigned minShift=shift?24:4,maxShift=shift?34:14;
            const uint16_t regionMin=(c.clamp>>minShift)&1023,regionMax=(c.clamp>>maxShift)&1023;
            for(int i=0;i<count;++i){
                float ratio=(float(first+i)-edge)/length;
                float texel=lo+(hi-lo)*ratio;
                if(!std::isfinite(texel)||std::fabs(texel)>134000000)return false;
                if(s.prim.fst){
                    const float fixed=texel*16.f+.5f;
                    if(fixed>2147483000.f||fixed<-2147483000.f)return false;
                    texel=float(std::clamp(int(fixed),0,65535))/16.f;
                }else texel=(texel/float(size))*float(size); // Same ST round-trip as DrawSprite/SampleTexture.
                int mapped=GSWrapTextureCoordinate(int(std::floor(texel)),size,wrap,regionMin,regionMax);
                if(mapped<0||mapped>1023)return false;
                indices[i]=mapped;minimum=std::min(minimum,mapped);maximum=std::max(maximum,mapped);
            }
            return true;
        };
        int minU,maxU,minV,maxV;
        if(!axis(out.width,out.x,left,right-left,u0,u1,s.textureWidth,0,out.columns.data(),minU,maxU)||!axis(out.height,out.y,top,bottom-top,v0,v1,s.textureHeight,2,out.rows.data(),minV,maxV))return false;
        if(maxU-minU>=128||maxV-minV>=128)return false;
        out.source={uint16_t(minU),uint16_t(minV),uint16_t(maxU-minU+1),uint16_t(maxV-minV+1)};
        if(!Fit(out.columns.data(),out.width,minU,maxU,(u1-u0)/(right-left),out.u,out.du)||!Fit(out.rows.data(),out.height,minV,maxV,(v1-v0)/(bottom-top),out.v,out.dv))return false;
        return true;
    }
};
