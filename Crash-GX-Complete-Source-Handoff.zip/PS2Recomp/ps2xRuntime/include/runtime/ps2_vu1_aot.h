#pragma once
#include "runtime/ps2_vu1.h"

// Generated registries contain only owner-selected instruction words. Selection
// happens during decode, after the existing microcode generation fence.
struct VU1AotProgram
{
    using Block = void (*)(VU1Interpreter &, uint8_t *, uint32_t, GS &, PS2Memory *, uint64_t, bool &);
    const uint8_t *code;
    uint32_t size;
    VU1Interpreter::Unit unit;
    const Block *blocks;
    uint32_t blockCount;
};

struct VU1AotRegistry
{
    template<uint32_t Opcode> static void normalizeFmacResult(VU1Interpreter &, float *, uint8_t, uint8_t[4]);
    template<uint32_t Opcode> static uint32_t calculateFmacProductSticky(VU1Interpreter &, uint8_t);
    template<uint32_t Opcode> static void applyFmacDest(VU1Interpreter &, float *, float *, uint8_t);
    template<uint32_t Opcode> static void applyFmacDestAcc(VU1Interpreter &, float *, uint8_t);
    static const VU1AotProgram *matchProgram(const uint8_t *, uint32_t, VU1Interpreter::Unit);
    static bool runBlock(VU1Interpreter &, uint8_t *, uint32_t, GS &, PS2Memory *, uint64_t, bool &);
    // Cache marker only; never dispatched as instruction semantics.
    static void missingUpper(VU1Interpreter &) {}
    static VU1Interpreter::UpperAotHandler upper(uint32_t instruction);
    static VU1Interpreter::LowerAotHandler lower(uint32_t instruction);
    static VU1Interpreter::UpperAotHandler upper(uint32_t, VU1Interpreter::Unit,
                                                VU1Interpreter::InstructionUsage *);
    static VU1Interpreter::LowerAotHandler lower(uint32_t, VU1Interpreter::Unit,
                                                VU1Interpreter::InstructionUsage *);
    template<uint32_t Instruction> static void runUpper(VU1Interpreter &vu)
    { vu.execUpperAot<Instruction>(); }
    template<uint32_t Instruction> static void runLower(VU1Interpreter &vu, uint8_t *data,
                                                       uint32_t size, GS &gs, PS2Memory *memory)
    { vu.execLowerAot<Instruction>(data, size, gs, memory); }
};
