#pragma once
#include "runtime/ps2_guest_memory.h"
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <limits>
#include <memory>
#include <stdexcept>
#include <vector>
#include <utility>

// Owned snapshot, independent of subsequent guest RAM writes. VIF can retain
// a large logical stream in small blocks without changing command boundaries.
// GIF keeps its existing contiguous packet representation and arbitration.
class Ps2DmaBuffer {
public:
    static constexpr size_t blockBytes = 64u * 1024u;
    explicit Ps2DmaBuffer(bool segmented=false):segmented_(segmented){}
    Ps2DmaBuffer(Ps2DmaBuffer&&other)noexcept:segmented_(other.segmented_),used_(std::exchange(other.used_,0)),capacity_(std::exchange(other.capacity_,0)),linear_(std::move(other.linear_)),blocks_(std::move(other.blocks_)){}
    Ps2DmaBuffer&operator=(Ps2DmaBuffer&&other)noexcept{
        if(this!=&other){segmented_=other.segmented_;used_=std::exchange(other.used_,0);capacity_=std::exchange(other.capacity_,0);linear_=std::move(other.linear_);blocks_=std::move(other.blocks_);}return *this;
    }
    Ps2DmaBuffer(const Ps2DmaBuffer&)=delete;
    Ps2DmaBuffer&operator=(const Ps2DmaBuffer&)=delete;
    size_t size()const{return segmented_?used_:linear_.size();}
    bool empty()const{return size()==0;}
    size_t max_size()const{return std::numeric_limits<uint32_t>::max();}
    void reserve(size_t count){
        if(count>max_size())throw std::length_error("DMA snapshot exceeds stream size");
        if(!segmented_){linear_.reserve(count);return;}
        if(!blocks_.empty())throw std::logic_error("DMA snapshot already reserved");
        blocks_.reserve(count/blockBytes+(count%blockBytes!=0));
        for(size_t pos=0;pos<count;){
            const size_t n=std::min(blockBytes,count-pos);
            blocks_.push_back(std::unique_ptr<uint8_t[]>(new uint8_t[n]));pos+=n;
        }
        capacity_=count;
    }
    void append(const uint8_t*first,const uint8_t*last){
        const size_t count=size_t(last-first);
        if(!segmented_){linear_.insert(linear_.end(),first,last);return;}
        if(count>capacity_-used_)throw std::length_error("DMA snapshot reserve exceeded");
        size_t left=count;
        while(left){const size_t off=used_%blockBytes,n=std::min(left,blockBytes-off);
            std::memcpy(blocks_[used_/blockBytes].get()+off,first,n);used_+=n;first+=n;left-=n;}
    }
    const uint8_t*data()const{
        if(segmented_)throw std::logic_error("Segmented DMA snapshot is not contiguous");
        return linear_.data();
    }
    const uint8_t*contiguous(size_t offset,size_t count)const{
        if(offset>size()||count>size()-offset)throw std::out_of_range("DMA snapshot read");
        if(!count)return nullptr;
        if(!segmented_)return linear_.data()+offset;
        if(count<=blockBytes-offset%blockBytes)return blocks_[offset/blockBytes].get()+offset%blockBytes;
        return nullptr;
    }
    void copy(size_t offset,void*destination,size_t count)const{
        if(offset>size()||count>size()-offset)throw std::out_of_range("DMA snapshot copy");
        auto*out=static_cast<uint8_t*>(destination);
        if(!segmented_){if(count)std::memcpy(out,linear_.data()+offset,count);return;}
        while(count){const size_t off=offset%blockBytes,n=std::min(count,blockBytes-off);
            std::memcpy(out,blocks_[offset/blockBytes].get()+off,n);offset+=n;out+=n;count-=n;}
    }
    uint8_t operator[](size_t offset)const{uint8_t value;copy(offset,&value,1);return value;}
private:
    bool segmented_;
    size_t used_=0,capacity_=0;
    std::vector<uint8_t>linear_;
    std::vector<std::unique_ptr<uint8_t[]>>blocks_;
};

// A single decoder sees the complete logical VIF stream. Only a command's
// requested span is coalesced when it crosses a block; partial commands are
// never passed as separate VIF invocations. Scratch stays local to this drain.
class Ps2DmaInput {
public:
    Ps2DmaInput(const uint8_t*data,uint32_t size):data_(data),size_(size){}
    explicit Ps2DmaInput(const Ps2DmaBuffer&buffer):buffer_(&buffer),size_(uint32_t(buffer.size())){}
    uint32_t size()const{return size_;}
    const uint8_t*span(size_t offset,size_t count){
        if(offset>size_||count>size_-offset)throw std::out_of_range("VIF input span");
        if(!count)return nullptr;
        if(!buffer_)return data_+offset;
        if(const auto*view=buffer_->contiguous(offset,count))return view;
        if(count>scratchCapacity_){scratch_.reset();scratchCapacity_=0;scratch_.reset(new uint8_t[count]);scratchCapacity_=count;}
        buffer_->copy(offset,scratch_.get(),count);return scratch_.get();
    }
    void releaseLargeScratch(){if(scratchCapacity_>Ps2DmaBuffer::blockBytes){scratch_.reset();scratchCapacity_=0;}}
    template<class T>T read(size_t offset){return Ps2GuestRead<T>(span(offset,sizeof(T)));}
private:
    const uint8_t*data_=nullptr;
    const Ps2DmaBuffer*buffer_=nullptr;
    uint32_t size_=0;
    std::unique_ptr<uint8_t[]>scratch_;
    size_t scratchCapacity_=0;
};
