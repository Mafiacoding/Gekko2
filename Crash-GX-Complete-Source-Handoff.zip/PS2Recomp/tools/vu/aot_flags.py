"""Specialize production FMAC helpers by opcode, sharing bodies across registers.

Opt-in generated output belongs in the private registry, not the source tree.
"""
import re


def function(source, signature):
    start = source.index(signature)
    opening = source.index('{', start)
    depth = 1
    end = opening + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[opening + 1:end - 1]


def helpers(core, inline=False):
    product = function(core, 'constexpr bool fmacProductSum(')
    start = core.index('template<typename Real, typename Normalize>')
    end = core.index('\nvoid VU1Interpreter::normalizeFmacResult(', start)
    formula = core[start:end]
    # The production formula has its own anonymous-namespace closing brace.
    formula = formula.rsplit('\n}', 1)[0]
    output = '#ifndef PS2X_VU_AOT_FLAGS_HELPERS\n#define PS2X_VU_AOT_FLAGS_HELPERS\n'
    output += 'namespace {\nconstexpr bool vuAotProductSum(uint32_t upper) {' + product + '}\n'
    output += 'constexpr uint8_t vuAotFlagLane(uint32_t component) {' + function(core, 'constexpr uint8_t laneForComponent(') + '}\n'
    output += formula + '\n}\n'
    signatures = {
        'normalizeFmacResult': 'void VU1AotRegistry::normalizeFmacResult(VU1Interpreter &vu, float *result, uint8_t dest, uint8_t laneFlags[4])',
        'calculateFmacProductSticky': 'uint32_t VU1AotRegistry::calculateFmacProductSticky(VU1Interpreter &vu, uint8_t dest)',
        'applyFmacDest': 'void VU1AotRegistry::applyFmacDest(VU1Interpreter &vu, float *dst, float *result, uint8_t dest)',
        'applyFmacDestAcc': 'void VU1AotRegistry::applyFmacDestAcc(VU1Interpreter &vu, float *result, uint8_t dest)',
    }
    for name, signature in signatures.items():
        body = function(core, ('uint32_t' if name == 'calculateFmacProductSticky' else 'void') + ' VU1Interpreter::' + name + '(')
        body = body.replace('m_currentUpperInstruction', '((vu.m_currentUpperInstruction & 0xfffff800u) | Opcode)')
        body = re.sub(r'\bm_(?!currentUpperInstruction)[A-Za-z0-9_]+\b', lambda match: 'vu.' + match[0], body)
        body = body.replace('fmacProductSum(', 'vuAotProductSum(')
        body = body.replace('laneForComponent(', 'vuAotFlagLane(')
        body = body.replace('calculateFmacExactResult(component, exactResult)',
                            'calculateFmacValue(vu.m_state, ((vu.m_currentUpperInstruction & 0xfffff800u) | Opcode), component, exactResult, vuAotNormalizeOperand)')
        body = body.replace('[this](float value) { return normalizeOperand(value); }', 'vuAotNormalizeOperand')
        body = body.replace('normalizeOperand(', 'vuAotNormalizeOperand(')
        for method in ('normalizeFmacExactResult', 'normalizeResult', 'updateFmacFlags', 'applyDestAcc', 'applyDest'):
            body = re.sub(r'\b' + method + r'\(', 'vu.' + method + '(', body)
        for method in ('normalizeFmacResult', 'calculateFmacProductSticky'):
            body = re.sub(r'\b' + method + r'\(', method + '<Opcode>(vu, ', body)
        attribute = '__attribute__((always_inline)) inline ' if inline else ''
        output += 'template<uint32_t Opcode>\n' + attribute + signature + '\n{' + body + '}\n'
    return output + '#endif\n'


def specialize(text):
    tag = '((Instruction & 0x3fu) < 0x3cu ? (Instruction & 0x3fu) : (Instruction & 0x7ffu))'
    for method in ('applyFmacDestAcc', 'applyFmacDest'):
        text = re.sub(r'\b' + method + r'\(', 'VU1AotRegistry::' + method + '<' + tag + '>(*this, ', text)
    return text
