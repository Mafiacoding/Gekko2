"""Generate bounded, exact-program VU blocks from the production issue loop.

All guest words and generated output belong in the owner-private build tree.
Metadata comes from compiling the production decoder, not a second decoder.
"""
import json
import hashlib
import re
import subprocess
from pathlib import Path


def program_discriminators(programs):
    """Cheap rejection words; a complete byte comparison still authorizes use."""
    groups = [list(range(len(programs)))]; selected = []
    while any(len(group)>1 for group in groups):
        best = None; best_score = len(groups)
        for word in range(4096):
            score = sum(len({programs[i]['words'][word] for i in group}) for group in groups)
            if score>best_score:
                best=word; best_score=score
        if best is None: break  # Identical complete images may share a match.
        selected.append(best)
        split=[]
        for group in groups:
            buckets={}
            for i in group:buckets.setdefault(programs[i]['words'][best],[]).append(i)
            split.extend(buckets.values())
        groups=split
    return selected


def metadata(root, output, programs):
    core = (root/'ps2xRuntime/src/lib/vu/ps2_vu1_core.cpp').read_text()
    helpers = core[core.index('void VU1Interpreter::addVfRead('):core.index('VU1Interpreter::VU1Interpreter(')]
    decoders = core[core.index('VU1Interpreter::InstructionUsage VU1Interpreter::decodeUpperUsage('):core.index('void VU1Interpreter::rebuildDecodedCodeCache(')]
    source = r'''
#include "runtime/ps2_vu1.h"
#include "runtime/ps2_guest_memory.h"
#include "DETAIL"
#include <cstdio>
#include <cstring>
namespace { constexpr uint8_t laneForComponent(uint32_t c) { return uint8_t(1u << (3u-c)); } }
HELPERS
DECODERS
VU1Interpreter::VU1Interpreter(Unit unit):m_unit(unit){}
struct VU1AotRegistry {
 static void dump(VU1Interpreter &vu, uint32_t lower, uint32_t upper) {
  uint8_t code[8]; Ps2GuestWrite<uint32_t>(code,lower); Ps2GuestWrite<uint32_t>(code+4,upper);
  auto d=vu.decodeInstructionPair(code,0);
  auto access=[](auto a){std::printf("{%u,%u}",a.reg,a.lanes);};
  auto usage=[&](auto u){std::printf("{{{");access(u.vfRead[0]);std::printf(",");access(u.vfRead[1]);std::printf("}},");access(u.vfWrite);
   std::printf(",%u,%u,%u,%u,%u,%u,%u,%u,%u,%u,%s,%s,%s,%s,%s,%s}",u.vfReadCount,u.viRead,u.viWrite,u.accRead,u.accWrite,u.latency,u.vfLatency,u.viLatency,unsigned(u.pipeline),0,
    u.waitQ?"true":"false",u.waitP?"true":"false",u.readsClip?"true":"false",u.writesClip?"true":"false",u.delaysNextBranchRead?"true":"false",u.reserved?"true":"false");
  };
  // Output JSON with C++ aggregate strings: exact values from the reference.
  std::printf("{\"lower\":\""); usage(d.lowerUsage); std::printf("\",\"upper\":\"");usage(d.upperUsage);
  std::printf("\",\"flags\":[%u,%u,%u,%u,%u,%u,%u],\"reserved\":%s,\"boundary\":%s",d.iBit,d.eBit,d.mBit,d.dBit,d.tBit,d.upperVfShadowReg,d.suppressedLowerVf,
   d.lowerUsage.reserved||d.upperUsage.reserved?"true":"false",
   d.lowerUsage.pipeline==VU1Interpreter::PipelineXgkick||d.lowerUsage.pipeline==VU1Interpreter::PipelineBranch?"true":"false");
  std::printf(",\"ready_vf\":[");bool first=true;
  for(auto *usage:{&d.upperUsage,&d.lowerUsage})for(unsigned i=0;i<usage->vfReadCount;++i)for(unsigned c=0;c<4;++c)if(usage->vfRead[i].lanes&(8u>>c)){
   std::printf("%s[%u,%u]",first?"":",",usage->vfRead[i].reg,c);first=false;}
  std::printf("],\"ready_vi\":%u,\"ready_acc\":%u,\"mark_vf\":[",d.upperUsage.viRead|d.lowerUsage.viRead,d.upperUsage.accRead|d.lowerUsage.accRead);first=true;
  for(auto *usage:{&d.lowerUsage,&d.upperUsage})if(usage->vfWrite.reg && (usage==&d.upperUsage || usage->vfWrite.reg!=d.suppressedLowerVf))for(unsigned c=0;c<4;++c)if(usage->vfWrite.lanes&(8u>>c)){
   std::printf("%s[%u,%u,%u]",first?"":",",usage->vfWrite.reg,c,usage->vfLatency?usage->vfLatency:usage->latency);first=false;}
  std::printf("],\"mark_vi\":%u,\"vi_latency\":%u,\"mark_acc\":%u}\n",d.lowerUsage.viWrite,d.lowerUsage.viLatency?d.lowerUsage.viLatency:d.lowerUsage.latency,d.upperUsage.accWrite);
 }
};
int main(){VU1Interpreter zero(VU1Interpreter::Unit::VU0),one;unsigned unit,lower,upper;while(std::scanf("%u %u %u",&unit,&lower,&upper)==3)VU1AotRegistry::dump(unit?one:zero,lower,upper);}
'''
    # Pipeline is an enum aggregate field, so emit a cast rather than an integer.
    source = source.replace('DETAIL', str(root/'ps2xRuntime/src/lib/vu/ps2_vu1_detail.h')).replace('HELPERS', helpers).replace('DECODERS', decoders)
    # No padding element exists between pipeline and waitQ.
    source = source.replace('%u,%u,%s,%s,%s,%s,%s,%s}', 'VU1Interpreter::Pipeline(%u),%s,%s,%s,%s,%s,%s}')
    source = source.replace('unsigned(u.pipeline),0,', 'unsigned(u.pipeline),')
    cpp = output/'metadata_probe.cpp'; exe=output/'metadata_probe'
    cpp.write_text(source)
    subprocess.run(['c++','-std=c++20','-O1','-msse4.1','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),str(cpp),'-o',str(exe)],check=True)
    pairs=[]
    for p in programs:
        pairs.extend((p['unit'],*pair) for pair in zip(p['words'][::2],p['words'][1::2]))
    data=''.join(f'{unit} {lo} {hi}\n' for unit,lo,hi in pairs)
    result=subprocess.run([str(exe)],input=data,capture_output=True,text=True,check=True)
    rows=[json.loads(line) for line in result.stdout.splitlines()]
    assert len(rows)==len(pairs)
    return rows


def generate(root, output, programs, semantic_sources):
    if not isinstance(programs,list) or any(not isinstance(p,dict) for p in programs):
        raise ValueError('programs must be an array of program descriptions')
    if not programs:
        (output/'vu_aot_blocks.cpp').unlink(missing_ok=True)
        return '\nconst VU1AotProgram *VU1AotRegistry::matchProgram(const uint8_t *, uint32_t, VU1Interpreter::Unit) { return nullptr; }\nbool VU1AotRegistry::runBlock(VU1Interpreter &, uint8_t *, uint32_t, GS &, PS2Memory *, uint64_t, bool &) { return false; }\n'
    for p in programs:
        if type(p.get('unit')) is not int or p.get('unit') != 1 or not isinstance(p.get('words'),list) or len(p['words'])!=4096:
            raise ValueError('Block programs currently require a complete 16-KiB VU1 word image')
        if any(type(w) is not int or not 0<=w<=0xffffffff for w in p['words']):
            raise ValueError('Program words must be unsigned 32-bit integers')
        if 'blocks' in p and (not isinstance(p['blocks'],list) or any(
                type(pc) is not int or pc<0 or pc>=16384 or pc%64 for pc in p['blocks'])):
            raise ValueError('Program blocks must be aligned 64-byte VU PCs')
    rows=metadata(root,output,programs)
    core=(root/'ps2xRuntime/src/lib/vu/ps2_vu1_core.cpp').read_text()
    issue=core[core.index('        commitReadyPipelines();',core.index('void VU1Interpreter::run(')):]
    issue=issue[:issue.index('        advanceOneCycle();')+len('        advanceOneCycle();')]
    issue=issue.replace('''        if (m_state.pc + 8u > codeSize)
            break;

''','')
    start=issue.index('        const DecodedInstructionPair decoded = ')
    end=issue.index('        if (decoded.upperUsage.reserved',start)
    issue=issue[:start]+issue[end:]
    issue=issue.replace('''            break;
        }

        uint64_t readyCycle''','''            return false;
        }

        uint64_t readyCycle''',1)
    issue=issue.replace('''        if (m_cycle >= budgetEnd)
            break;''','''        if (m_cycle >= budgetEnd)
            return false;''')
    a=issue.index('        auto executeUpper = ');b=issue.index('        if (decoded.iBit)',a)
    issue=issue[:a]+'''        auto executeUpper = [&]() { ++m_aotStats.nativeUpper; execUpperAot<Upper>(); };
        auto executeLower = [&]() { ++m_aotStats.nativeLower; execLowerAot<Lower>(vuData,dataSize,gs,memory); };
'''+issue[b:]
    # Reject reference scheduler changes until the specialized emitter is audited.
    ready=core.split('uint64_t VU1Interpreter::calculatePairReadyCycle(const DecodedInstructionPair &decoded) const\n{\n',1)[1].split('\n}\n\nvoid VU1Interpreter::markPairWrites',1)[0]
    mark=core.split('void VU1Interpreter::markPairWrites(const DecodedInstructionPair &decoded)\n{\n',1)[1].split('\n}\n\nVU1Interpreter::InstructionUsage',1)[0]
    if hashlib.sha256(ready.encode()).hexdigest()!='85db909fecbee3ab48ec2d9fa5175509710d907ecb383e35caeb3a33c011e3f7' or hashlib.sha256(mark.encode()).hexdigest()!='f024dacfb0ccc704aea966090183a0669f16e7597dd2704834f77d272134d275':
        raise ValueError('Reference VU readiness/write rules changed; audit the block emitter')
    issue=issue.replace('calculatePairReadyCycle(decoded)', 'Metadata<Upper,Lower>::ready(vu)')
    issue=issue.replace('markPairWrites(decoded);', 'Metadata<Upper,Lower>::mark(vu);')
    vi_start=issue.index('        uint8_t writtenVi = 0u;')
    vi_end=issue.index('        const VfAccess upperWrite',vi_start)
    issue=issue[:vi_start]+"""        constexpr uint32_t viMask = decoded.lowerUsage.viWrite & 0xfffeu;
        constexpr uint8_t writtenVi = viMask ? __builtin_ctz(viMask) : 0;
        const int32_t oldVi = writtenVi ? m_state.vi[writtenVi] : 0;

"""+issue[vi_end:]
    issue=issue.replace('laneForComponent(', 'vuAotLaneForComponent(')
    issue=re.sub(r'\bm_[A-Za-z0-9_]+\b', lambda m:'vu.'+m[0], issue)
    methods=['commitReadyPipelines','reportReservedInstruction','calculatePairReadyCycle','advanceTo','execUpperAot','execLowerAot','normalizeOperand','queueVfWrite','queueAccWrite','queueViWrite','markPairWrites','recordViWriteForBranch','microAddressMask','advanceOneCycle']
    for method in methods:issue=re.sub(r'\b'+method+r'\b','vu.'+method,issue)
    for token in ['VfAccess','InstructionUsage','ScalarPipelineEntry','PipelineBranch','PipelineFdiv','PipelineEfu','PipelineXgkick','kAccForwardLatency']:
        issue=re.sub(r'\b'+token+r'\b','VU1Interpreter::'+token,issue)
    # Direct calls share one semantic body per instruction word. Inlining the
    # same upper word into many different pairs exhausts Wii MEM1 before all
    # uploaded variants fit; the issue/dependency logic remains pair-specialized.
    text='#include <algorithm>\n'+semantic_sources['upper']+'\n'+semantic_sources['lower']
    text=text.replace('void VU1Interpreter::execUpperAot()', '__attribute__((noinline)) void VU1Interpreter::execUpperAot()').replace('void VU1Interpreter::execLowerAot(', '__attribute__((noinline)) void VU1Interpreter::execLowerAot(')
    text+='\nstatic constexpr uint8_t vuAotLaneForComponent(uint32_t c){return uint8_t(1u<<(3u-c));}\nstruct VU1AotBlockCompiler {\n'
    # The compiler needs the same private access as the registry (declared friend).
    text+='template<uint32_t Upper,uint32_t Lower> struct Metadata;\n'
    text+='template<uint32_t Upper,uint32_t Lower> __attribute__((noinline)) static bool issue(VU1Interpreter &vu,uint8_t *vuData,uint32_t dataSize,GS &gs,PS2Memory *memory,uint32_t codeSize,uint64_t budgetEnd,bool &programEnded) {\nconstexpr auto decoded=Metadata<Upper,Lower>::value;\n'
    text+='if(vu.m_cycle>=budgetEnd || vu.m_stopRequested) return false;\n'+issue+'\nreturn true;\n}\n'
    offset=0; tables=[]; definitions=[]; unique_pairs={}; shared_blocks={}
    for program_index,p in enumerate(programs):
        pairs=list(zip(p['words'][::2],p['words'][1::2]));meta=rows[offset:offset+len(pairs)];offset+=len(pairs)
        blocks=[]
        for block_start in range(0,len(pairs),8):
            if 'blocks' in p and block_start*8 not in p['blocks']:
                blocks.append('nullptr')
                continue
            chunk=pairs[block_start:block_start+8];cm=meta[block_start:block_start+8]
            # Uploaded programs commonly retain most of their code. Share only
            # identical chunks at the same PC: issue order and next-PC guards
            # embed that address, so equal words at different PCs cannot alias.
            key=(p['unit'],block_start,tuple(chunk))
            if key in shared_blocks:
                blocks.append('&VU1AotBlockCompiler::'+shared_blocks[key])
                continue
            name=f'block_{program_index}_{block_start}'
            shared_blocks[key]=name
            blocks.append('&VU1AotBlockCompiler::'+name)
            text+=f'static void {name}(VU1Interpreter &,uint8_t *,uint32_t,GS &,PS2Memory *,uint64_t,bool &);\n'
            definition=f'void VU1AotBlockCompiler::{name}(VU1Interpreter &vu,uint8_t *data,uint32_t size,GS &gs,PS2Memory *memory,uint64_t budget,bool &ended) {{\n'
            definition+='++vu.m_aotStats.nativeBlocks;\nswitch(vu.m_state.pc){\n'
            for j in range(len(chunk)):definition+=f'case {(block_start+j)*8}: goto P{j};\n'
            definition+='default:return;}\n'
            for j,((lo,hi),m) in enumerate(zip(chunk,cm)):
                pc=(block_start+j)*8
                # Aggregate member order follows the production header exactly.
                flags=','.join(str(v) if i>=5 else ('true' if v else 'false') for i,v in enumerate(m['flags']))
                unique_pairs[(hi,lo)]=(m,flags)
                definition+=f'P{j}: {{\n'
                definition+=f'if(!issue<{hi}u,{lo}u>(vu,data,size,gs,memory,16384,budget,ended)) return;\n'
                definition+=f'if(ended || vu.m_state.pc!={(pc+8)%16384}u) return;\n'
                # XGKICK can call into GIF/VIF scheduling: recheck code generation
                # before running another pair. Branches also end the native block.
                if m['boundary']:definition+='return;\n'
                definition+='}\n'
            definition+='}\n'
            definitions.append(definition)
        tables.append((p,blocks))
    text+='};\n'
    for (hi,lo),(m,flags) in unique_pairs.items():
        text+=f'template<> struct VU1AotBlockCompiler::Metadata<{hi}u,{lo}u>{{static constexpr VU1Interpreter::DecodedInstructionPair value{{nullptr,nullptr,{lo}u,{hi}u,{m["lower"]},{m["upper"]},{flags}}};\n'
        text+='__attribute__((always_inline)) static inline uint64_t ready(VU1Interpreter &vu){uint64_t r=vu.m_cycle;\n'
        for reg,lane in sorted(set(map(tuple,m['ready_vf']))):text+=f'r=std::max(r,vu.m_vfReady[{reg}][{lane}]);\n'
        for reg in range(1,16):
            if m['ready_vi']&(1<<reg):text+=f'r=std::max(r,vu.m_viReady[{reg}]);\n'
        for lane in range(4):
            if m['ready_acc']&(8>>lane):text+=f'r=std::max(r,vu.m_accReady[{lane}]);\n'
        text+='if constexpr(value.lowerUsage.pipeline==VU1Interpreter::PipelineFdiv || value.lowerUsage.waitQ)if(vu.m_fdiv.valid)r=std::max(r,vu.m_fdiv.readyCycle);\n'
        text+='if constexpr(value.lowerUsage.pipeline==VU1Interpreter::PipelineEfu)r=std::max(r,vu.m_efuResourceReady);\n'
        text+='if constexpr(value.lowerUsage.waitP){if(vu.m_efu[0].valid)r=std::max(r,vu.m_efu[0].readyCycle);if(vu.m_efu[1].valid)r=std::max(r,vu.m_efu[1].readyCycle);}\n'
        text+='if constexpr(value.lowerUsage.pipeline==VU1Interpreter::PipelineXgkick)if(vu.m_xgkick.active)r=std::max(r,vu.m_cycle+1u);return r;}\n'
        text+='__attribute__((always_inline)) static inline void mark(VU1Interpreter &vu){\n'
        for reg,lane,latency in m['mark_vf']:text+=f'vu.m_vfReady[{reg}][{lane}]=vu.m_cycle+{latency}u;\n'
        for reg in range(1,16):
            if m['mark_vi']&(1<<reg):text+=f'vu.m_viReady[{reg}]=vu.m_cycle+{m["vi_latency"]}u;\n'
        for lane in range(4):
            if m['mark_acc']&(8>>lane):text+=f'vu.m_accReady[{lane}]=vu.m_cycle+VU1Interpreter::kAccForwardLatency;\n'
        text+='}};\n'
    text+=''.join(definitions)
    for i,(p,blocks) in enumerate(tables):
        raw=b''.join(w.to_bytes(4,'little') for w in p['words'])
        text+=f'static const uint8_t code_{i}[]={{'+','.join(map(str,raw))+'};\n'
        text+=f'static const VU1AotProgram::Block blocks_{i}[]={{'+','.join(blocks)+'};\n'
    text+='static const VU1AotProgram programs[]={\n'
    for i,(p,blocks) in enumerate(tables):text+=f'{{code_{i},16384,VU1Interpreter::Unit::VU1,blocks_{i},{len(blocks)}}},\n'
    reject=''.join(f'if(std::memcmp(p.code+{word*4}u,code+{word*4}u,4u)!=0)continue;' for word in program_discriminators(programs))
    text+='};\nconst VU1AotProgram *VU1AotRegistry::matchProgram(const uint8_t *code,uint32_t size,VU1Interpreter::Unit unit){for(const auto &p:programs){if(p.size!=size || p.unit!=unit)continue;'+reject+'if(std::memcmp(p.code,code,size)==0)return &p;}return nullptr;}\n'
    text+='bool VU1AotRegistry::runBlock(VU1Interpreter &vu,uint8_t *data,uint32_t size,GS &gs,PS2Memory *memory,uint64_t budget,bool &ended){if((vu.m_state.pc&7u)!=0 || vu.m_xgkick.active)return false;const auto *p=vu.m_aotProgram;const uint32_t slot=vu.m_state.pc/64u;if(!p || slot>=p->blockCount || !p->blocks[slot])return false;p->blocks[slot](vu,data,size,gs,memory,budget,ended);return true;}\n'
    (output/'vu_aot_blocks.cpp').write_text(text)
    return ''
