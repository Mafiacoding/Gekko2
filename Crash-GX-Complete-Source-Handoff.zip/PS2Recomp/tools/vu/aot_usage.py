"""Generate per-unit operand usage with the production decoder on the build host."""
from aot_blocks import metadata


def decode(root, output, words):
    pairs = [(0x8000033c, w) for w in words['upper']]
    pairs += [(w, 0x2ff) for w in words['lower']]
    programs = [{'unit': unit, 'words': [word for pair in pairs for word in pair]}
                for unit in (0, 1)]
    rows = metadata(root, output, programs)
    count = len(pairs)
    upper_count = len(words['upper'])
    return {half: [(rows[index][half], rows[index + count][half])
                   for index in indices]
            for half, indices in [('upper', range(upper_count)),
                                  ('lower', range(upper_count, count))]}


def registry(half, words, usages):
    name = half.capitalize()
    handler = f'VU1Interpreter::{name}AotHandler'
    signature = f'{handler} VU1AotRegistry::{half}'
    text = f'\n{signature}(uint32_t instruction)\n{{ return {half}(instruction, VU1Interpreter::Unit::VU1, nullptr); }}\n'
    text += f'{signature}(uint32_t instruction, VU1Interpreter::Unit unit, VU1Interpreter::InstructionUsage *usage)\n{{\n'
    text += f' using Handler = {handler};\n'
    text += ' struct Entry { uint32_t word; Handler handler; VU1Interpreter::InstructionUsage zero, one; };\n'
    if not words:
        return text + ' (void)instruction; (void)unit; (void)usage; return nullptr;\n}\n'
    text += ' static const Entry table[] = {\n'
    for word, (zero, one) in zip(words, usages):
        text += f' {{0x{word:08x}u, &run{name}<0x{word:08x}u>, {zero}, {one}}},\n'
    text += ''' };
 size_t first=0,last=sizeof(table)/sizeof(table[0]);
 while(first<last){const size_t mid=first+(last-first)/2;if(table[mid].word<instruction)first=mid+1;else last=mid;}
 if(first==sizeof(table)/sizeof(table[0]) || table[first].word!=instruction)return nullptr;
 const auto &entry=table[first];
 if(usage)*usage=unit==VU1Interpreter::Unit::VU0?entry.zero:entry.one;
 return entry.handler;
}
'''
    return text


def missing_registry(half):
    name = half.capitalize()
    return f'\nVU1Interpreter::{name}AotHandler VU1AotRegistry::{half}(uint32_t, VU1Interpreter::Unit, VU1Interpreter::InstructionUsage *) {{ return nullptr; }}\n'
