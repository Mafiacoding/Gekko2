#!/usr/bin/env python3
"""Reject stale AOT semantics before linking an optional native registry."""
import argparse
import hashlib
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]

def verify(directory):
    report = json.loads((directory/'manifest.json').read_text())
    if report.get('schema') != 1:
        raise ValueError('Unsupported VU AOT manifest')
    for part in ('core', 'upper', 'lower'):
        source = ROOT/f'ps2xRuntime/src/lib/vu/ps2_vu1_{part}.cpp'
        if report['semantic_sha256'].get(part) != hashlib.sha256(source.read_bytes()).hexdigest():
            raise ValueError(f'Stale VU AOT {part} semantics: regenerate the private registry')
    files=report.get('files_sha256',{})
    if not files:raise ValueError('Missing generated-source hashes; regenerate VU AOT')
    if not {'vu_aot_upper.cpp', 'vu_aot_lower.cpp'}.issubset(files):
        raise ValueError('Incomplete generated-source hashes; regenerate VU AOT')
    if (directory/'vu_aot_blocks.cpp').is_file() != ('vu_aot_blocks.cpp' in files):
        raise ValueError('Block source/manifest mismatch; regenerate VU AOT')
    for name,digest in files.items():
        if name not in ('vu_aot_upper.cpp','vu_aot_lower.cpp','vu_aot_blocks.cpp'):
            raise ValueError('Invalid VU AOT source name')
        if hashlib.sha256((directory/name).read_bytes()).hexdigest()!=digest:
            raise ValueError('Changed or incomplete VU AOT source: '+name)
    for half in ('upper', 'lower'):
        if not (directory/f'vu_aot_{half}.cpp').is_file():
            raise ValueError(f'Missing VU AOT {half} source')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    try:
        verify(args.directory)
    except (OSError, ValueError, KeyError) as error:
        parser.exit(2, str(error)+'\n')
