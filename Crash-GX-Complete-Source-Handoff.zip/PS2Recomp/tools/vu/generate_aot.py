#!/usr/bin/env python3
"""Compile selected VU instruction semantics ahead of time; inputs/outputs may be private.

The JSON input has `upper` and `lower` arrays of unsigned 32-bit instruction words.
The timing/hazard scheduler remains authoritative. Missing words use the reference
interpreter. This is instruction specialization, not fused block compilation.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
from aot_blocks import generate as generate_blocks
from aot_flags import helpers as flag_helpers, specialize as specialize_flags
from aot_usage import decode as decode_usage, registry as usage_registry, missing_registry

ROOT = Path(__file__).resolve().parents[2]


def generate(profile, output):
    if type(profile.get("specialize_flags", False)) is not bool:
        raise ValueError("specialize_flags must be boolean")
    if type(profile.get("predecode_usage", False)) is not bool:
        raise ValueError("predecode_usage must be boolean")
    if type(profile.get("inline_flag_helpers", False)) is not bool:
        raise ValueError("inline_flag_helpers must be boolean")
    words = {}
    for half in ('upper', 'lower'):
        values = profile.get(half)
        if not isinstance(values, list) or any(type(v) is not int or not 0 <= v <= 0xffffffff for v in values):
            raise ValueError(f'{half} must be an array of unsigned 32-bit words')
        words[half] = sorted(set(values))
    output.mkdir(parents=True, exist_ok=True)
    core = ROOT / 'ps2xRuntime/src/lib/vu/ps2_vu1_core.cpp'
    core_text = core.read_text()
    normalize = core_text.split('float VU1Interpreter::normalizeOperand(float value) const\n', 1)[1].split('\nfloat VU1Interpreter::normalizeResult', 1)[0]
    normalize = '#ifndef PS2X_VU_AOT_NORMALIZE_HELPER\n#define PS2X_VU_AOT_NORMALIZE_HELPER\nstatic inline float vuAotNormalizeOperand(float value)\n' + normalize + '\n#endif\n'
    hashes = {'core': hashlib.sha256(core.read_bytes()).hexdigest()}
    semantic_sources = {}
    usage = decode_usage(ROOT, output, words) if profile.get('predecode_usage', False) else None
    for half in ('upper', 'lower'):
        source = ROOT / f'ps2xRuntime/src/lib/vu/ps2_vu1_{half}.cpp'
        text = source.read_text()
        hashes[half] = hashlib.sha256(source.read_bytes()).hexdigest()
        if half == 'upper':
            old = 'void VU1Interpreter::execUpper(uint32_t instr)\n{'
            new = 'template<uint32_t Instruction>\nvoid VU1Interpreter::execUpperAot()\n{\n    constexpr uint32_t instr = Instruction;'
        else:
            old = 'void VU1Interpreter::execLower(uint32_t instr, uint8_t *vuData, uint32_t dataSize, GS &gs, PS2Memory *memory, uint32_t upperInstr)\n{'
            new = 'template<uint32_t Instruction>\nvoid VU1Interpreter::execLowerAot(uint8_t *vuData, uint32_t dataSize, GS &gs, PS2Memory *memory)\n{\n    constexpr uint32_t instr = Instruction;\n    constexpr uint32_t upperInstr = 0;'
            # Refuse to silently lose a future dependency on the paired upper word.
            body = text.split(old, 1)[1] if old in text else ''
            if re.sub(r'\(void\)upperInstr;', '', body).count('upperInstr'):
                raise ValueError('Lower semantics now depend on upperInstr; update AOT ABI first')
        if text.count(old) != 1:
            raise ValueError(f'{half} semantics signature changed')
        text = text.replace(old, new)
        # Resolve the reference source's local include from the generated private directory.
        text = text.replace('#include "ps2_vu1_detail.h"', '#include '+json.dumps(str(source.with_name('ps2_vu1_detail.h'))))
        # This helper is state-free. Make its production definition visible so
        # constant-specialized instructions can drop unused operand preparation.
        text = text.replace('normalizeOperand(', 'vuAotNormalizeOperand(')
        if half == 'upper' and profile.get('specialize_flags', False):
            text = specialize_flags(text)
            precision_helpers = flag_helpers(core_text, inline=profile.get('inline_flag_helpers',False))
        else:
            precision_helpers = ''
        start = text.index('template<uint32_t Instruction>')
        text = text[:start] + normalize + '\n' + precision_helpers + '\n' + text[start:]
        text = '#include "runtime/ps2_vu1_aot.h"\n' + text
        semantic_sources[half] = text
        if profile.get('programs'):
            # Match the block TU's shared semantic bodies. Otherwise the word
            # registry inlines another copy of each body into its dispatcher,
            # defeating the MEM1 saving even though the templates coalesce.
            text = text.replace('void VU1Interpreter::execUpperAot()',
                                '__attribute__((noinline)) void VU1Interpreter::execUpperAot()')
            text = text.replace('void VU1Interpreter::execLowerAot(',
                                '__attribute__((noinline)) void VU1Interpreter::execLowerAot(')
        if usage is not None:
            text += usage_registry(half, words[half], usage[half])
        else:
            # Sorted tables resolve once at decode, not on every instruction issue.
            name = half.capitalize()
            text += f'\nVU1Interpreter::{name}AotHandler VU1AotRegistry::{half}(uint32_t instruction)\n{{\n'
            text += f'    using Handler = VU1Interpreter::{name}AotHandler;\n'
            text += '    struct Entry { uint32_t word; Handler handler; };\n'
            if words[half]:
                text += '    static const Entry table[] = {\n'
                text += ''.join(f'        {{0x{word:08x}u, &run{name}<0x{word:08x}u>}},\n' for word in words[half])
                text += '    };\n    size_t first = 0, last = sizeof(table) / sizeof(table[0]);\n'
                text += '    while (first < last) {\n        const size_t mid = first + (last - first) / 2;\n'
                text += '        if (table[mid].word < instruction) first = mid + 1;\n        else last = mid;\n    }\n'
                text += '    return first < sizeof(table) / sizeof(table[0]) && table[first].word == instruction ? table[first].handler : nullptr;\n'
            else:
                text += '    (void)instruction; return nullptr;\n'
            text += '}\n'
            text += missing_registry(half)
        (output / f'vu_aot_{half}.cpp').write_text(text)
    stub = generate_blocks(ROOT, output, profile.get('programs', []), semantic_sources)
    if stub:
        with (output/'vu_aot_upper.cpp').open('a') as f:
            f.write(stub)
    manifest = dict(schema=1, kind='instruction-specialized AOT with reference fallback',
                    counts={k:len(v) for k,v in words.items()}, semantic_sha256=hashes,
                    programs=len(profile.get('programs',[])), specialize_flags=profile.get('specialize_flags',False), predecode_usage=profile.get('predecode_usage',False), inline_flag_helpers=profile.get('inline_flag_helpers',False),
                    files_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in output.glob('vu_aot_*.cpp')})
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    return manifest


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('profile', type=Path)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    try:
        result = generate(json.loads(a.profile.read_text()), a.output)
    except (ValueError, OSError) as error:
        p.exit(2, str(error)+'\n')
    print(json.dumps(result))

if __name__ == '__main__':
    main()
