#!/usr/bin/env python3
"""Generate pinned GPL GX adapters; never mutate Gekko2 or embed game assets."""
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def add_aux_hooks(source):
    """Allow a second GPU owner to resolve before RGB is imported."""
    helper = '''
#include "ps2_wii_gx_owner_hooks.h"
static ps2x_gx_aux_resolve_fn ps2x_aux_resolve;
static ps2x_gx_aux_disjoint_fn ps2x_aux_disjoint;
static void *ps2x_aux_owner;
static int ps2x_aux_resolving;
int ps2x_gx_set_aux_hooks(int (*resolve)(void*),int (*disjoint)(void*,uint32_t,uint32_t),void *owner){
 if(gs_mem_gpu_pending()||ps2x_aux_resolving||(!resolve&&(disjoint||owner)))return 0;
 ps2x_aux_resolve=resolve;ps2x_aux_disjoint=disjoint;ps2x_aux_owner=owner;return 1;
}
static int ps2x_gx_resolve_aux(void){
 if(!ps2x_aux_resolve)return 1;
 if(ps2x_aux_resolving){gx_wait_failed=1;render_enabled=0;return 0;}
 ps2x_aux_resolving=1;int ok=ps2x_aux_resolve(ps2x_aux_owner);ps2x_aux_resolving=0;
 if(!ok){gx_wait_failed=1;render_enabled=0;}return ok&&!gx_wait_failed;
}
'''
    anchor = 'static int surface_enabled=1;'
    if source.count(anchor) != 1:
        raise ValueError('Unexpected auxiliary owner declaration point')
    source = source.replace(anchor, helper + '\n' + anchor, 1)
    resolve_anchor = ' if(!surface||!surface->active)return 0;\n /* A seed has no guest-visible dirty pixels.'
    if source.count(resolve_anchor) != 1:
        raise ValueError('Unexpected auxiliary resolve insertion point')
    source = source.replace(resolve_anchor, ' if(!surface||!surface->active)return 0;\n if(!ps2x_gx_resolve_aux())return 0;\n /* A seed has no guest-visible dirty pixels.', 1)

    return source


def compact_surface(source):
    """Bound staging to a seed row and a 64-row readback band."""
    helper = '''
static int ps2x_skip_seed;
static int ps2x_fully_covered(const gs_gx_flat_draw *d,uint32_t x,uint32_t y){
 if(!ps2x_skip_seed||x<d->x||y<d->y||x+4>d->x+d->width||y+4>d->y+d->height)return 0;
 for(uint32_t yy=y;yy<y+4;yy++){
  uint32_t row=yy-d->y;
  if(d->left[row]>x-d->x||d->right[row]<x+4-d->x)return 0;
 }
 return 1;
}
'''
    source = source.replace('static int surface_enabled=1;', helper + '\nstatic int surface_enabled=1;')
    source = source.replace('if(surface_seeded[index]){surface_counts[10]++;x+=4u;continue;}',
                            'if(surface_seeded[index]||ps2x_fully_covered(draw,x,y)){surface_seeded[index]=1;surface_counts[10]++;x+=4u;continue;}')
    source = source.replace('while(end<x1&&!surface_seeded[(y/4u)*(draw->bw/4u)+end/4u])end+=4u;',
                            'while(end<x1&&!surface_seeded[(y/4u)*(draw->bw/4u)+end/4u]&&!ps2x_fully_covered(draw,end,y))end+=4u;')
    source = source.replace('  uint8_t *pixels=surface_pixels;',
                            '  if(texture_in_flight&&!gx_cpu_wait(0))return 0;\n  uint8_t *pixels=surface_pixels;')
    source = source.replace('t=texture_tile(draw->bw,xx,yy);', 't=texture_tile(end-x,xx-x,yy-y);')
    source = source.replace('DCFlushRange(pixels+texture_tile(draw->bw,x,y),bytes);', 'DCFlushRange(pixels,bytes);')
    source = source.replace('surface_texture(surface_pixels,draw->bw,h,GX_NEAR);', 'surface_texture(surface_pixels,end-x,4,GX_NEAR);')
    source = source.replace('''  vertex(x,y,(float)x/draw->bw,(float)y/h);vertex(end,y,(float)end/draw->bw,(float)y/h);
  vertex(end,y+4u,(float)end/draw->bw,(float)(y+4u)/h);vertex(x,y+4u,(float)x/draw->bw,(float)(y+4u)/h);GX_End();''',
                            '''  vertex(x,y,0,0);vertex(end,y,1,0);
  vertex(end,y+4u,1,1);vertex(x,y+4u,0,1);GX_End();''')
    source = source.replace(''' if(!surface_ensure(draw))return 0;
 if(!gs_gx_surface_mark(surface,draw))return 0;''', ''' ps2x_skip_seed=1;
 int ready=surface_ensure(draw);ps2x_skip_seed=0;
 if(!ready)return 0;
 if(!gs_gx_surface_mark(surface,draw))return 0;''')
    old = ''' surface_copy(readback,x,y,w,h);if(!gx_cpu_wait(1))return 0;
 DCInvalidateRange(readback,bytes);
 if(!gs_gx_surface_import_rect(surface,vram,size,readback,bytes,x,y,w,h))return 0;'''
    new = ''' if(size!=GS_MEM_SIZE||!vram||!w||w>640u||y+h>480u)return 0;
 for(uint32_t band=0;band<h;band+=64u){
  uint32_t rows=h-band;if(rows>64u)rows=64u;
  surface_copy(readback,x,y+band,w,rows);if(!gx_cpu_wait(1))return 0;
  DCInvalidateRange(readback,w*rows*4u);
  const uint8_t *pixels=readback;
  for(uint32_t yy=0;yy<rows;yy++)for(uint32_t xx=0;xx<w;xx++){
   uint32_t sx=x+xx,sy=y+band+yy,i=sy*surface->width+sx;
   if(!surface->dirty[i])continue;
   uint32_t o=target_offset(surface->bp,surface->bw,sx,sy),t=texture_tile(w,xx,yy);
   vram[o]=pixels[t+1];vram[o+1]=pixels[t+32];vram[o+2]=pixels[t+33];
   if(surface->dirty[i]&2)vram[o+3]=surface->alpha[i];
  }
 }
 surface->active=0;'''
    if source.count(old) != 1:
        raise ValueError('Unexpected resident resolve implementation')
    source = source.replace(old, new)
    # Legacy full-surface blits are not exposed by the subset driver.
    source = source.replace('if(!surface_pixels)surface_pixels=memalign(32,GX_PRESENT_TEXTURE);',
                            'if(!surface_pixels)surface_pixels=memalign(32,PS2X_GX_SEED_BYTES);')
    return source


def prepare(gekko, output, limited=True, textures=True):
    gekko, output = Path(gekko).resolve(), Path(output).resolve()
    manifest = json.loads((ROOT / 'tests/gs_hybrid/native/gekko_sources.json').read_text())
    for name, digest in manifest['sha256'].items():
        if hashlib.sha256((gekko / name).read_bytes()).hexdigest() != digest:
            raise ValueError('Unvalidated Gekko2 source: ' + name)
    output.mkdir(parents=True, exist_ok=True)
    (output / 'Gekko2-LICENSE').write_bytes((gekko / 'COPYING.GPLv3').read_bytes())
    source = (gekko / 'source/hw/gs_mem.c').read_text()
    anchor = 'static uint8_t g_gs_mem[GS_MEM_SIZE];'
    if source.count(anchor) != 1:
        raise ValueError('Unexpected VRAM declaration')
    source = source.replace(anchor, 'static uint8_t *g_gs_mem;').replace('sizeof(g_gs_mem)', 'GS_MEM_SIZE')
    source += '''
int ps2x_gx_bind(uint8_t *vram,uint32_t size) {
 if(!vram||size!=GS_MEM_SIZE||!gs_mem_sync())return 0;
 g_gs_mem=vram;g_hash_raw_exposed=1;g_hash_owner.valid=0;return 1;
}
int ps2x_gx_unbind(void) {
 if(!gs_mem_sync())return 0;g_gs_mem=NULL;return 1;
}
int probe_bind(uint8_t *vram,uint32_t size){return ps2x_gx_bind(vram,size);}
int probe_unbind(void){return ps2x_gx_unbind();}
'''
    (output / 'shared_mem.c').write_text(source)
    source = add_aux_hooks((gekko / 'source/hw/gs_gx.c').read_text())
    if limited:
        anchor = '''    fifo=memalign(32,GX_PRESENT_FIFO);texture=memalign(32,GX_PRESENT_TEXTURE);
    if(!fifo||!texture){free(fifo);free(texture);fifo=texture=NULL;return 0;}'''
        if source.count(anchor) != 1:
            raise ValueError('Unexpected GX initialization')
        # Only the resident texture bridge is reachable in this adapter. It
        # supplies its own source texture; the legacy 2 MiB blit texture is unused.
        source = source.replace(anchor, '''
#ifdef PS2X_WII_GAME_GX
    extern void *__real_memalign(size_t,size_t);
    extern void __real_free(void*);
    fifo=__real_memalign(32,GX_PRESENT_FIFO); /* Keep CP FIFO in MEM1. */
    if(fifo&&((uintptr_t)fifo<0x80000000u||(uintptr_t)fifo+GX_PRESENT_FIFO>0x81800000u)){
     __real_free(fifo);fifo=NULL;return 0;
    }
#else
    fifo=memalign(32,GX_PRESENT_FIFO);
#endif
    if(!fifo)return 0;''')
        source = source.replace('#define GX_PRESENT_TEXTURE (1024u*512u*4u)',
                                '#define GX_PRESENT_TEXTURE (640u*64u*4u)\n#define PS2X_GX_SEED_BYTES (640u*4u*4u)')
        source = compact_surface(source)
    else:
        source += '\n#define PS2X_GX_SEED_BYTES GX_PRESENT_TEXTURE\n'
    # Allocate all needed staging before creating a bound GPU FIFO. Clean
    # unavailability therefore occurs before any submitted native operation.
    source += '''
int ps2x_gx_init(void){
 efb_width=640;efb_height=480;
 if(!surface){surface=memalign(32,sizeof(*surface));if(surface)memset(surface,0,sizeof(*surface));}
 if(!surface_pixels)surface_pixels=memalign(32,PS2X_GX_SEED_BYTES);
 if(!readback)readback=memalign(32,GX_PRESENT_TEXTURE);
 if(surface&&surface_pixels&&readback&&initialize())return 1;
 if(initialized)return 0; /* Never free resources still retained by GX. */
 free(surface);free(surface_pixels);free(readback);
 surface=NULL;surface_pixels=NULL;readback=NULL;return 0;
}
int probe_gx_init(void){return ps2x_gx_init();}
int ps2x_gx_source_barrier(void){return initialized&&!gx_wait_failed&&gx_cpu_wait(0);}
uint32_t ps2x_gx_fifo_address(void){return (uint32_t)(uintptr_t)fifo;}
uint32_t ps2x_gx_staging_bytes(void){return PS2X_GX_SEED_BYTES+GX_PRESENT_TEXTURE;}
int ps2x_gx_draw_native_flat(const gs_gx_flat_draw *d){
 if(!d||d->psm>1||!initialized||!render_enabled)return 0;
 return surface_draw_flat(d);
}
'''
    source += '''
static int ps2x_gx_ensure_texture(const gs_gx_flat_draw *d,int additive){
'''
    if limited:
        source += ' ps2x_skip_seed=!additive;\n int ready=surface_ensure(d);ps2x_skip_seed=0;return ready;\n}\n'
    else:
        source += ' (void)additive;return surface_ensure(d);\n}\n'
    if textures:
        source += '\n' + (ROOT / 'ps2xRuntime/platform/wii/ps2_wii_gx_bridge.inc').read_text()
    (output / 'gx_probe.c').write_text(source)
    manifest['limited_staging'] = limited
    manifest['staging_bytes'] = 640 * (64 + 4) * 4 if limited else 3 * 1024 * 512 * 4
    (output / 'adapter.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gekko-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    prepare(args.gekko_root, args.output)
