#!/usr/bin/env python3
"""Summarize optional Wii phase samples; never interpret them as CPU time/FPS."""
import argparse
import json
import re
from pathlib import Path
EE = ['startup/unmarked','scheduler events','EE accounting','EE/runtime safe point',
      'native EE entry','IOP','event wait','DMA','GIF submission (includes native GS)','VIF','VU execution',
      'software GS rasterization','GS synchronization','native GS preparation/submission (includes waits)','GS image upload / swizzle','native GS fragment permissions']
UI = ['unmarked '+str(i) for i in range(32)]
for i,name in {0:'startup/unmarked',1:'host loop',2:'GS frame acquisition',3:'blit/input/VI',
               20:'GS frontend lock',21:'GS backend lifetime lock / synchronization',22:'GS backend conversion',
               23:'GS packed copy',24:'GS RGBA allocation/conversion',31:'unknown'}.items():UI[i]=name

def analyze(text):
    header=re.findall(r'^profile_hz=(\d+) profile_samples=(\d+)$',text,re.M)
    if len(header)!=1:raise ValueError('Expected one complete profile header')
    hz,total=map(int,header[0])
    if hz!=100 or not 0<total<=0xffffffff:raise ValueError('Unsupported rate or empty profile')
    def phases(key,names):
        rows=re.findall(r'^'+key+r'=(.*)$',text,re.M)
        if len(rows)!=1:raise ValueError('Missing or duplicate phase histogram')
        values={}
        for token in rows[0].split():
            m=re.fullmatch(r'(\d+):(\d+)',token)
            if not m:raise ValueError('Malformed phase count')
            index,count=map(int,m.groups())
            if index>=len(names) or index in values or count>total:raise ValueError('Invalid phase bucket')
            values[index]=count
        if len(values)!=len(names) or sum(values.values())!=total:raise ValueError('Incomplete/inconsistent histogram')
        return sorted([dict(phase=i,name=names[i],samples=values[i],percent=round(values[i]*100/total,2)) for i in values],key=lambda x:-x['samples'])
    return dict(scope='Wall-time phase occupancy; EE/UI overlap. Not CPU time, speedup or physical Wii FPS.',
                sample_hz=hz,samples=total,ee=phases('wall_ee_phase_samples',EE),ui=phases('wall_ui_phase_samples',UI))

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('progress',type=Path);p.add_argument('--output',type=Path);a=p.parse_args()
    try:report=analyze(a.progress.read_text())
    except (OSError,ValueError) as e:p.exit(2,str(e)+'\n')
    value=json.dumps(report,indent=2)+'\n'
    if a.output:a.output.write_text(value)
    print(value,end='')
if __name__=='__main__':main()
