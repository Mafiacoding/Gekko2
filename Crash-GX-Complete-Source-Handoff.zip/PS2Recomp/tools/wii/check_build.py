#!/usr/bin/env python3
"""Reject invalid Wii ELF/DOL placement before packaging an experimental build."""
import argparse,hashlib,json,struct,re
from pathlib import Path

def check_dma_storage(symbols, sections):
    """EXI has a 26-bit aligned DMA address, so MEM2 silently aliases MEM1."""
    required = ['__mem1_code_end', '__mem1_sdk_start', '__mem1_sdk_end',
                '__Arena1Lo', 'sramcntrl']
    if any(key not in symbols for key in required):
        raise ValueError('Missing MEM1 SDK DMA placement symbols')
    start, end = symbols['__mem1_sdk_start'], symbols['__mem1_sdk_end']
    sram = symbols['sramcntrl']
    if not (0x80003400 <= symbols['__mem1_code_end'] <= start < end <= 0x81800000):
        raise ValueError('SDK storage overlaps native code or leaves MEM1')
    if symbols['__Arena1Lo'] < end:
        raise ValueError('MEM1 heap overlaps SDK DMA storage')
    if not (start <= sram and sram + 80 <= end) or sram & 31:
        raise ValueError('EXI SRAM DMA buffer must be aligned in MEM1 SDK storage')
    if not any(name == '.mem1sdk' and kind == 1 and address == start and address + size == end
               for name, kind, address, size in sections):
        raise ValueError('MEM1 SDK storage must have a file-backed initialization image')
    return dict(start=start, bytes=end-start, sram_address=sram,
                exi_dma_address=sram & 0x03ffffe0, sram_dma_bytes=64)

def check(elf_path,dol_path):
    elf=Path(elf_path).read_bytes();dol=Path(dol_path).read_bytes()
    if elf[:7]!=b'\x7fELF\x01\x02\x01' or struct.unpack_from('>H',elf,18)[0]!=20:
        raise ValueError('Expected ELF32 big-endian PowerPC')
    shoff=struct.unpack_from('>I',elf,32)[0];step,count,names=struct.unpack_from('>HHH',elf,46)
    if step<40 or shoff+step*count>len(elf):raise ValueError('Invalid ELF sections')
    sections=[struct.unpack_from('>10I',elf,shoff+i*step) for i in range(count)]
    strings=sections[names];names_data=elf[strings[4]:strings[4]+strings[5]]
    def name(s):return names_data[s[0]:].split(b'\0',1)[0].decode('ascii')
    def bank(addr,size):
        if 0x80003400<=addr and addr+size<=0x81800000:return 'MEM1'
        if 0x90002000<=addr and addr+size<=0x933e0000:return 'MEM2'
        raise ValueError(f'Outside available Wii memory: {addr:#x}+{size:#x}')
    allocated=[];symbols={}
    for s in sections:
        n=name(s)
        if s[2]&2 and s[5]:
            if s[2]&0x400:raise ValueError('Unsupported ELF TLS section: '+n)
            bank(s[3],s[5]);allocated.append((s[3],s[3]+s[5],n))
        if s[1]==2:
            strings=sections[s[6]];data=elf[strings[4]:strings[4]+strings[5]]
            for offset in range(s[4],s[4]+s[5],s[9]):
                index,value,*_=struct.unpack_from('>IIIBBH',elf,offset)
                key=data[index:].split(b'\0',1)[0].decode('ascii',errors='replace');symbols[key]=value
    dma_storage=check_dma_storage(symbols, [(name(s),s[1],s[3],s[5]) for s in sections])
    allocated.sort()
    for a,b in zip(allocated,allocated[1:]):
        if a[1]>b[0]:raise ValueError('Overlapping ELF sections: '+a[2]+' / '+b[2])
    if len(dol)<256:raise ValueError('Truncated DOL')
    rows=[];ranges=[];file_ranges=[]
    for kind,slots,off_base,addr_base,size_base in [('text',7,0,0x48,0x90),('data',11,0x1c,0x64,0xac)]:
        for i in range(slots):
            off=struct.unpack_from('>I',dol,off_base+4*i)[0];addr=struct.unpack_from('>I',dol,addr_base+4*i)[0];size=struct.unpack_from('>I',dol,size_base+4*i)[0]
            if not size:continue
            region=bank(addr,size)
            if off<256 or off+size>len(dol):raise ValueError('DOL section outside file')
            rows.append(dict(kind=kind,address=addr,bytes=size,bank=region));ranges.append((addr,addr+size));file_ranges.append((off,off+size))
    bss,size,entry=struct.unpack_from('>3I',dol,0xd8)
    if size:bank(bss,size);ranges.append((bss,bss+size))
    for values in [sorted(ranges),sorted(file_ranges)]:
        if any(a[1]>b[0] for a,b in zip(values,values[1:])):raise ValueError('Overlapping DOL ranges')
    if not any(r['kind']=='text' and r['address']<=entry<r['address']+r['bytes'] for r in rows):raise ValueError('DOL entry outside text')
    if entry!=struct.unpack_from('>I',elf,24)[0]:raise ValueError('ELF/DOL entry mismatch')
    for s in sections:
        if not(s[2]&2) or s[1]==8 or not s[5]:continue
        matched=False
        for kind,slots,ob,ab,sb in [('text',7,0,0x48,0x90),('data',11,0x1c,0x64,0xac)]:
            for i in range(slots):
                off=struct.unpack_from('>I',dol,ob+4*i)[0];addr=struct.unpack_from('>I',dol,ab+4*i)[0];length=struct.unpack_from('>I',dol,sb+4*i)[0]
                if addr<=s[3] and s[3]+s[5]<=addr+length:
                    start=off+s[3]-addr
                    if dol[start:start+s[5]]!=elf[s[4]:s[4]+s[5]]:raise ValueError('ELF/DOL contents differ: '+name(s))
                    matched=True
        if not matched:raise ValueError('ELF section absent from DOL: '+name(s))
    available={}
    for number in [1,2]:
        low=symbols['__Arena'+str(number)+'Lo'];high=symbols['__Arena'+str(number)+'Hi']
        if low>=high:raise ValueError('Invalid arena bounds')
        available['MEM'+str(number)]=high-low
    if available['MEM1']<4*1024*1024 or available['MEM2']<42*1024*1024:raise ValueError('Insufficient initial arena headroom')
    result=dict(valid=True,scope='static layout and ELF/DOL integrity; not boot or peak heap validation',physical_wii=False,
                mem1_sdk=dma_storage,bytes=len(dol),sha256=hashlib.sha256(dol).hexdigest(),entry=entry,sections=rows,bss=dict(address=bss,bytes=size),initial_arena_bytes=available)
    if any('PS2WiiCreateGXBackend' in key for key in symbols):
        hot={}
        for label,fragment in [('submit','PS2WiiGXTextureDriver9TrySubmitE'),('flat','PS2WiiGXTextureDriver7TryFlatE')]:
            matches=[value for key,value in symbols.items() if key.startswith('_ZN') and fragment in key]
            if len(matches)!=1:raise ValueError('Missing native GX hot function: '+label)
            hot[label]=matches[0]
        hot['textured_draw']=symbols.get('ps2x_gx_draw_native_texture',0)
        if 'ps2x_gx_draw_native_subtract_flat' in symbols:
            hot['flat_subtract_draw']=symbols['ps2x_gx_draw_native_subtract_flat']
        if 'ps2x_gx_draw_projective' in symbols:
            hot['projective_draw']=symbols['ps2x_gx_draw_projective']
        if 'ps2x_gx_draw_linear_fragments' in symbols:
            hot['linear_fragments']=symbols['ps2x_gx_draw_linear_fragments']
            for label,fragment in [('linear_submit','PS2WiiGXTextureDriver9TryLinearE'),('fragment_rows','GSNativeFragmentPlan3RowE'),('depth_permissions','ProcessNativeFragmentRowE')]:
                matches=[value for key,value in symbols.items() if key.startswith('_ZN') and fragment in key]
                if len(matches)!=1:raise ValueError('Missing integrated native GX hot function: '+label)
                hot[label]=matches[0]
        for key,address in symbols.items():
            if key.startswith('_ZN') and 'PS2WiiGXTextureDriver11DecodeImageE' in key:
                hot['source_decode_cache']=address
            if key.startswith('_ZN') and 'PS2WiiGXTextureDriver16SourceTilePixelsE' in key:
                hot['source_tile_cache']=address
        if any(not 0x80003400<=address<0x81400000 for address in hot.values()):raise ValueError('Native GX hot code left MEM1')
        gxhot=[section for section in sections if name(section)=='.gxhot']
        if len(gxhot)!=1 or not gxhot[0][5]:raise ValueError('Missing native GX hot section')
        cold=symbols.get('ps2x_gx_init',0)
        if not 0x90002000<=cold<0x93400000:raise ValueError('Native GX cold initialization must leave MEM1 headroom')
        result['native_gx_layout']=dict(mem1_hot_bytes=gxhot[0][5],hot_symbols=hot,cold_initializer=cold,fifo='MEM1 allocation checked before GX_Init at runtime')
    vu_native={half:[value for key,value in symbols.items()
                     if key.startswith('_ZN14VU1AotRegistry8run'+half+'ILj')]
               for half in ('Upper','Lower')}
    if any(vu_native.values()):
        if any(not 0x80003400<=address<0x81400000
               for values in vu_native.values() for address in values):
            raise ValueError('Native VU AOT instruction code left MEM1')
        result['native_vu_layout']=dict(handler_counts={k.lower():len(v) for k,v in vu_native.items()},
                                        instruction_handlers='MEM1',scope='instruction AOT; scheduler and unknown-word fallback retained')
    return result

def check_main_stack(directory):
    matches=[]
    for path in Path(directory).rglob('main.cpp.su'):
        for line in path.read_text().splitlines():
            fields=line.split('\t')
            if len(fields)>=3 and re.search(r'\bmain\(',fields[0]):matches.append((int(fields[1]),fields[2]))
    if len(matches)!=1:raise ValueError('Expected exactly one compiler stack-usage record for main')
    size,kind=matches[0]
    if kind!='static' or size>8192:raise ValueError(f'Unsafe Wii main stack frame: {size} bytes ({kind})')
    return size

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--elf',type=Path,required=True);p.add_argument('--dol',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--stack-usage-root',type=Path);a=p.parse_args()
    report=check(a.elf,a.dol)
    if a.stack_usage_root:report["main_stack_bytes"]=check_main_stack(a.stack_usage_root)
    a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
if __name__=='__main__':main()
