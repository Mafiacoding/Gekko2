#!/usr/bin/env python3
"""Capture an owned Dolphin child's XFBs through native Linux GDB.

Runs without the PPC GDB stub. Keep user/SD images and resulting captures private.
The ELF must match the supplied DOL and use the PS2Recomp Wii host adapter.
Validated against Linux Dolphin 2503 shared-memory layout; other layouts fail
closed. Captures do not establish physical Wii performance or image accuracy.
"""
import argparse, hashlib, json, os, signal, subprocess, tempfile
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('dolphin','gdb','elf','dol','user','output'):
        p.add_argument('--'+name,type=Path,required=True)
    p.add_argument('--nm',required=True)
    p.add_argument('--gdb-python-home',type=Path)
    p.add_argument('--seconds',type=int,default=120)
    p.add_argument('--pal',action='store_true')
    p.add_argument('--backend',choices=['Null','OGL'],default='Null')
    p.add_argument('--platform',choices=['headless','x11'],default='headless')
    p.add_argument('--sd-image',type=Path)
    a=p.parse_args()
    if not 1<=a.seconds<=1800:p.error('seconds must be 1..1800')
    a.output.mkdir(parents=True,exist_ok=True)
    symbols={v[2]:int(v[0],16) for line in subprocess.check_output([a.nm,str(a.elf)],text=True).splitlines() if len(v:=line.split())==3}
    addresses={n:symbols['_ZN12_GLOBAL__N_1L'+str(len(n))+n+'E'] for n in ('back','xfb','mode')}
    if 'PS2WiiGXStats' in symbols:addresses['gx_stats']=symbols['PS2WiiGXStats']
    if 'PS2WiiGXAdmission' in symbols:addresses['gx_admission']=symbols['PS2WiiGXAdmission']
    if 'PS2WiiGXLinear' in symbols:addresses['gx_linear']=symbols['PS2WiiGXLinear']
    config=dict(seconds=a.seconds,output=str(a.output.resolve()),addresses=addresses,
                elf_sha256=hashlib.sha256(a.elf.read_bytes()).hexdigest(),
                dol_sha256=hashlib.sha256(a.dol.read_bytes()).hexdigest(),video_backend=a.backend)
    # Python literals are embedded as Python, never interpolated into shell text.
    script='''set pagination off
set confirm off
set print thread-events off
set auto-solib-add off
set disable-randomization off
handle SIGSEGV nostop noprint pass
handle SIGBUS nostop noprint pass
python
import gdb,threading,time,os,signal,json
CONFIG = CONFIG_LITERAL
started=False
started_at=None
last_signal=None
def start_timer(event):
 global started,started_at
 if started:return
 started=True
 started_at=time.monotonic()
 pid=gdb.selected_inferior().pid
 def interrupt():
  time.sleep(CONFIG['seconds'])
  try:os.kill(pid,signal.SIGINT)
  except ProcessLookupError:pass
 threading.Thread(target=interrupt,daemon=True).start()
def stopped(event):
 global last_signal
 last_signal=getattr(event,'stop_signal',None)
gdb.events.cont.connect(start_timer)
gdb.events.stop.connect(stopped)
end
run
python
if last_signal!='SIGINT':raise RuntimeError('Unexpected native stop: '+str(last_signal))
inferior=gdb.selected_inferior()
maps=[]
for line in open('/proc/%d/maps'%inferior.pid):
 fields=line.split()
 if '/dev/shm/dolphin-emu.' not in line:continue
 lo,hi=[int(x,16) for x in fields[0].split('-')]
 maps.append((lo,hi,int(fields[2],16)))
def mapped(offset,size):
 for lo,hi,file_offset in maps:
  if file_offset==offset and hi-lo>=size:return lo
 raise RuntimeError('Dolphin RAM mapping missing: '+hex(offset)+' maps='+repr(maps))
mem1=mapped(0,0x1800000)
mem2=mapped(0x2040000,0x4000000)
def read(address,size):
 address &= 0x3fffffff
 if 0<=address and address+size<=0x1800000:host=mem1+address
 elif 0x10000000<=address and address+size<=0x14000000:host=mem2+address-0x10000000
 else:raise RuntimeError('Guest read outside RAM')
 return bytes(inferior.read_memory(host,size))
def word(address):return int.from_bytes(read(address,4),'big')
width_height=read(word(CONFIG['addresses']['mode']),12)
w=int.from_bytes(width_height[4:6],'big');h=int.from_bytes(width_height[8:10],'big')
if not 0<w<=720 or not 0<h<=576:raise RuntimeError('Invalid framebuffer dimensions')
frames=[]
import hashlib
for index in (0,1):
 ptr=word(CONFIG['addresses']['xfb']+index*4)
 raw=read(ptr,w*h*2)
 name=CONFIG['output']+'/frame-%d.yuyv'%index
 with open(name,'wb') as f:f.write(raw)
 frames.append(dict(index=index,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),nonblack_luma=sum(x>20 for x in raw[::2])))
report=dict(width=w,height=h,frames=frames,elf_sha256=CONFIG['elf_sha256'],dol_sha256=CONFIG['dol_sha256'],requested_host_seconds=CONFIG['seconds'],elapsed_host_seconds=round(time.monotonic()-started_at,3),native_stop_signal=last_signal,ppc_debugger_enabled=False,physical_wii=False,visible_game_image_verified=False,video_backend=CONFIG['video_backend'])
if 'gx_stats' in CONFIG['addresses']:report['gx_stats']=[word(CONFIG['addresses']['gx_stats']+i*4) for i in range(8)]
if 'gx_admission' in CONFIG['addresses']:report['gx_admission']=[word(CONFIG['addresses']['gx_admission']+i*4) for i in range(11)]
if 'gx_linear' in CONFIG['addresses']:report['gx_linear']=[word(CONFIG['addresses']['gx_linear']+i*4) for i in range(8)]
with open(CONFIG['output']+'/capture.json','w') as f:json.dump(report,f,indent=2)
print(json.dumps(report))
end
kill
quit
'''.replace('CONFIG_LITERAL',repr(config))
    with tempfile.TemporaryDirectory(prefix='dolphin-native-') as td:
        commands=Path(td)/'capture.gdb';commands.write_text(script)
        argv=[str(a.gdb),'--batch','-x',str(commands),'--args',str(a.dolphin),'-u',str(a.user),'-p',a.platform,'-v',a.backend,
              '-C','Dolphin.Core.WiiSDCard=True','-C','Dolphin.Core.CPUThread=False',
              '-C','Dolphin.Core.CPUCore=1','-C','Dolphin.Core.EmulationSpeed=0.0',
              '-C','Dolphin.General.GDBPort=-1','-C','Dolphin.Core.SIDevice0=6',
              '-C','Dolphin.DSP.Backend=No Audio Output']
        if a.sd_image:argv+=['-C','Dolphin.General.WiiSDCardPath='+str(a.sd_image.resolve())]
        if a.backend=='OGL':argv+=['-C','Graphics.Settings.SafeTextureCacheColorSamples=0','-C','Graphics.Hacks.EFBAccessEnable=True','-C','Graphics.Hacks.EFBToTextureEnable=False','-C','Graphics.Hacks.DeferEFBCopies=False']
        if a.pal:argv+=['-C','Dolphin.Core.FallbackRegion=2','-C','SYSCONF.IPL.E60=False','-C','SYSCONF.IPL.PGS=False']
        argv+=['-e',str(a.dol)]
        with (a.output/'native-gdb.log').open('w') as log:
            env=os.environ.copy()
            if a.gdb_python_home:env['PYTHONHOME']=str(a.gdb_python_home)
            proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True,env=env)
            try:result=proc.wait(timeout=a.seconds+90)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid,signal.SIGKILL);proc.wait();raise
        if result or not (a.output/'capture.json').exists():raise SystemExit('Capture failed; inspect private native-gdb.log')
    print((a.output/'capture.json').read_text())
if __name__=='__main__':main()
