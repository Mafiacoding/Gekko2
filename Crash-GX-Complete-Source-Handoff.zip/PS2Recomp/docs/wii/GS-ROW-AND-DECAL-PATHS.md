# Experimental GS row and constant-color paths

These switches default off. They preserve the reference paths for comparison
and do not establish adequate game speed or complete hardware GS support.

`PS2X_GS_TRIANGLE_ROW_SPANS` uses the existing canonical integer edge inequalities
to skip empty pixels in software triangles with bounding boxes at least 32 pixels
wide. It retains the same per-pixel edge values, arithmetic order, texture
sampling order and pixel writes. Smaller boxes keep scalar edge stepping because
signed 64-bit divisions per row can cost more than testing a few pixels.

The coverage test checks 4,096 triangles at widths 1..640 against scalar edge
membership (15,335,424 samples). A private corpus compares complete 4-MiB VRAM
outputs for 128 cases against the pre-change backend, including textured,
Gouraud, clipped, masked, depth-tested and overlapping feedback draws. All
outputs agree. The synthetic host speed difference was small; the 90-second
Dolphin game run showed no meaningful gain. This path remains disabled in the
private game configuration.

`PS2X_GS_UPLOAD_ROW_CURSOR` advances image transfer coordinates without division
and modulo per texel. One- and two-texel steps carry into subsequent rows,
including width-one packed-nibble uploads. Completion retains the original
cursor fields; incomplete input words are still discarded at the same packet
boundaries. The switch changes no GS object layout.

`gs_upload_cursor` compares complete VRAM and transfer snapshots with an
independent scalar-coordinate oracle after every input chunk. It covers 286
uploads / 11,986 comparisons over thirteen color/indexed/depth formats, partial
words, odd final nibbles, page wrapping, offset destinations and zero-width
transfers. Both the original and optimized paths pass. All ten host GS checks
pass with the experimental row switches enabled. Wii phase bucket 14 now
separates image upload/swizzle work from GIF routing; phase samples are wall-time
occupancy, not CPU time or FPS.

`PS2X_WII_GX_CONSTANT_STAGES` specializes constant-color and DECAL native
hardware-linear draws. Constant RGB plane bytes are bound directly to a GX TEV
register, avoiding three ramp-texture fetch stages. Constant HIGHLIGHT alpha uses
a second register and stage, preserving the original modulation/addition order.
DECAL independently takes texture RGB directly, even with varying vertex colors.
Untextured constant RGB uses a single register stage without texture generators.
Nonconstant, out-of-range or nonintegral planes retain the original ramp shader.
The path retains the source matrix, filtering, wrap mode, K3 blend alpha and CPU
alpha/depth decisions. `PS2WiiGXConstantStages` and
`PS2WiiGXDecalSingleStage` count uses of the two shortcuts.

Build the connected real-GX probe with `--constant-stages`
(`--decal-single-stage` is an alias). With source-cache/immutable-tile switches,
its 154 cases pass in single- and dual-core local Dolphin: exact structural
VRAM, bounded hardware RGB error at most 5/255, and exact uniform-color source
lifetime cases. Sixteen additional cases cover constant-color MODULATE, DECAL,
HIGHLIGHT, HIGHLIGHT2 and untextured draws, with an assertion that the constant
path executes. This is not a claim of byte-exact RGB for all triangles or
physical Wii performance. The initial DECAL-only prototype had no uses in the
measured game startup; the extended constant-color path was used 3,979 times in a 90-second game
run, but did not show a clear overall speed gain. It remains disabled in the
private game configuration. Adequate Dolphin gameplay speed is still open.
