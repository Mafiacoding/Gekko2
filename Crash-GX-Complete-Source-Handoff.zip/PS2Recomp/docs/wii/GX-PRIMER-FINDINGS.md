# Wii graphics sources and implications

Reviewed the complete 90-page Wii Graphics Primer (version 1.0.0), including its diagrams, and the complete Wii architecture article. This document records engineering conclusions, not copied source material.

Sources:

- [Wii Graphics Primer](https://pokeacer.xyz/wii/pdf/WiiGraphicsPrimer.pdf), supplied by the user; PDF SHA-1 `48355eebb2cc729fea67088ade54561bc1ddfe08`.
- [Copetti Wii architecture](https://www.copetti.org/writings/consoles/wii/), read through the author's [official source](https://github.com/flipacholas/Architecture-of-consoles/blob/master/articles/wii.Rmd.md).
- [libogc GX implementation](https://github.com/devkitPro/libogc/blob/master/libogc/gx.c) and [API](https://github.com/devkitPro/libogc/blob/master/gc/ogc/gx.h), relevant synchronization and depth sections.
- Dolphin developer discussions [11090](https://github.com/dolphin-emu/dolphin/pull/11090) and [10777](https://github.com/dolphin-emu/dolphin/pull/10777), concerning submission and readback synchronization. These concern host backends; their performance numbers do not transfer to this runtime.

## Implemented experiments

`PS2X_WII_GX_BATCH_LINEAR_RUNS` merges consecutive compatible, vertically adjacent rectangles. It preserves the existing 256-logical-run completion boundaries and drains before each boundary. It also avoids redundant blend state bindings within a primitive. A pure host test checks coverage/order; connected Dolphin probes check structural VRAM equivalence and the existing bounded RGB contract.

`PS2X_WII_GX_FIXED_RUN_VERTICES` sends integer rectangle positions as two signed 16-bit components rather than three floats. The positions already are integer screen boundaries. GX supplies the implicit zero Z component. Position payload falls from 12 to 4 bytes per vertex; CPU integer-to-float conversions disappear. This follows the compact vertex guidance on Primer pages 14–15. It does not imply a threefold frame-rate improvement.

Both options remain off by default. The combined batch/fixed path passed all 146 connected cases with Dolphin CPU threading both disabled and enabled: exact structural VRAM, maximum RGB difference 5 under the established tolerance. The batch/fixed/constant-stage combination also passed all 162 connected cases in both CPU-thread modes, with the same structural and RGB contracts. All 11 host GS tests passed. Whole-game speed is a separate acceptance criterion.

A private 90-second game run with batch/fixed vertices reached 7,026,526 native VU upper operations, compared with 6,790,218 for batch alone. These are progression counters from individual runs, not frame rates or a statistically established speedup. No adequate gameplay speed has been demonstrated.

## Larger work still required

- **Alpha/depth:** Primer pages 33–34 explain early versus late depth. Alpha rejection must not accidentally write depth. EFB RGB8/Z24 and RGBA6/Z24 (page 36) do not directly reproduce all GS 8-bit alpha and 32-bit depth semantics. Unsupported combinations retain the reference path until a tested representation exists.
- **Presentation:** EFB-to-XFB copy performs RGB-to-YUV conversion and vertical scaling in hardware (pages 36 and 40). Removing CPU final conversion requires an authoritative EFB plus correct GS display composition, buffer ownership and synchronization. It is not accomplished merely by calling the copy API.
- **Indexed textures:** Native CI formats can reduce upload data, but TLUT formats are IA8, RGB565 and RGB5A3 (page 72), not arbitrary RGBA32. Directly truncating a GS palette would change colors/alpha. Any alternative encoding needs its own precision, filtering and coherence tests.
- **CPU work:** Broadway must still execute translated EE/VU logic, scheduling and command interpretation. GX is a fixed-function graphics processor, not a general VU instruction executor.
- **Memory:** MEM1 suits latency-sensitive code; MEM2 provides capacity but is partly reserved for IOS (pages 88–89). Cache expansion must use measured heap headroom. Starlet runs IOS and is not a freely available PS2 IOP replacement.

No adequate whole-game Dolphin speed, complete GX migration, or real-Wii speed is asserted by these component tests. No release DOL follows from document review alone.

## Game measurements and rejected routing experiments

With batch/fixed vertices, a single local 90-second run reached 7,026,526 native VU upper operations. Adding constant TEV stages and admitting all supported untextured triangles reached 6,239,283; restricting additional admission to constant-color triangles reached 6,642,690. Neither broader routing experiment demonstrated a gain. The private working configuration therefore restores both extra untextured routes and constant stages to off. `PS2X_WII_GX_CONSTANT_UNTEXTURED` remains an off-by-default experimental subset of the already-tested triangle implementation.

For seconds 30–90, sampled producer phase occupancy changed from approximately 22.2% software GS / 29.0% native GS preparation with batch/fixed vertices to 14.9% / 38.0% with broader untextured admission. More GPU submissions reduced software rasterization but increased preparation/submission cost. These are overlapping-system wall-time phase observations, not GPU load measurements or physical Wii timings. Preparation, CPU fragment permissions and ownership transitions remain necessary optimization targets.
