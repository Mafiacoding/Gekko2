# Native GX projective baseline — unreleased

This checkpoint adds a restricted real-GX STQ triangle path. It does not complete
GS acceleration, filtering, Gouraud shading, native depth, or direct scanout.
No owner DOL is released from this checkpoint, and no Wii speedup is claimed.

## Source ownership

`SnapshotCoherentNativeImage` decodes a bounded, complete logical source image
(up to 128x128) across physical cache pages, using a temporary 8 KiB cache and the
canonical retained CLUT/TEXA interpretation. It never fills, evicts or flushes
the canonical guest texel cache. It rejects if retained texel bytes differ from
current VRAM. Ordinary source writes therefore do not silently become TEXFLUSH.
The driver excludes source overlap with both the current and every pending
native target before materializing external VRAM bytes. Wrapped bounding ranges
conservatively reject when disjointness cannot be established.

After admission, the driver commits the final actual GS sample to reproduce the
canonical cache's final page. Overflowing/NaN coordinates reject before mutation.
This optimization is valid only while source bytes remain coherent and stable;
it does not authorize bypassing cache semantics for a stale initial page.

One additional 64 KiB GPU image allocation is lazy. A changed image cannot replace
an older GPU consumer until its bounded fence completes. Source reuse is keyed
by a conservative CPU/resolve epoch, CLUT revision, layout, TEXA/TFX and shading
state. Resolves and software writes invalidate this host-derived image key,
without invalidating guest-latched texels. Repeated accepted draws need neither
a CPU RGB mirror nor an intervening framebuffer readback. Immutable source reuses
also avoid redundant global GX texture-cache invalidations; actual uploads
still flush CPU bytes and invalidate GX texture cache.

## Geometry and precision

The triangle planner derives coverage from the existing 12.4 GS edge equations.
GX renders covered row spans with a three-component homogeneous texture matrix;
S/Q and T/Q are evaluated by GX. Matrix construction accounts for the GX 7/12
sample location. Common Q normalization avoids tiny texture denominators;
nonpositive Q and a Q ratio above 64 reject.

A point-bin admission check currently examines covered samples and fits a small
homogeneous coordinate bias. A second pass checks the rounded float matrix.
This is CPU admission work, not a CPU RGB framebuffer renderer, but its cost is
unmeasured and may be substantial. It must not be sold as a fast general 3D path.
Negative repeat coordinates initially produced a real GX one-texel mismatch.
Translating by a whole texture period in homogeneous space keeps the covered GX
coordinates nonnegative while preserving the canonical wrapped indices.

Supported sources include all thirteen tested color/indexed/depth formats,
point filtering, repeat/clamp, flat TFX, source-copy-equivalent blending and exact
FIX=128 additive blending. ALPHA reserved bits are ignored in equation admission.
Depth writes must be masked and the depth test must be ALWAYS. DATE, general
PABE/blending, filtering, region wrap and variable fragment alpha into CT32 still
reject. Gouraud is admitted only when it has no effect on decal RGB/alpha or the
sample proof establishes the same constant provoking color. These limitations
are deliberate fallbacks, not missing-state bypasses.

The existing cropped sprite path now also handles large FST sources/nonzero
TEX1 state, using the already tested FST planner. Small legacy sprite/filtered
fixtures keep their previous path. This does not enable mipmaps or general
bilinear GX sampling.

## Diagnostics and validation

The native probe adds 52 projective cases (13 formats, four TFX/state variants)
with three pending draws each, plus two ownership sequences. Full independent
4 MiB VRAM comparisons check repeated source reuse, producer-to-texture ordering,
current-target feedback fallback, retained stale source data and explicit
TEXFLUSH. Negative repeat and out-of-range clamp coordinates are included.
The previous sprite, texture, triangle, alpha and ring regressions remain.

Host ASan/UBSan suites additionally compare multi-page snapshots with actual
software raster output, exercise stale rejection without cache mutation and
check 256 perspective plans with winding, scan masks, negative/clamped UV and
widely scaled Q. Exact final results and ELF identity accompany this document.

The opt-in game target keeps native submission and GPU draw functions in MEM1,
including `ps2x_gx_draw_projective`; image materialization/initialization code is
in MEM2. The MEM1 FIFO range check, minimum arena bounds and SDK EXI DMA execution
check remain enforced. Static layout is not a peak-heap or physical Wii proof.

`GX_ADMIT` counters distinguish sprite/state/blend/plan/alias/decode/alpha rejects
and projective state/plan rejects. The capture tool can read the matching
`PS2WiiGXAdmission` array from the stopped process, alongside the original eight
operation counters. Neither array measures FPS or CPU/GPU time shares. Common
unsupported triangle depth/filter states reject before expensive source-range
walking in the pending-draw preparation callback.

## Still required before an owner update

Implement native depth/test ownership and filtered, Gouraud game geometry;
replace or reduce expensive point-bin admission; cover the remaining blend and
framebuffer cases; implement native copies/presentation; and measure complete,
matched game progression with actual allocation and CPU/GX synchronization
costs. Synthetic native triangles do not establish that Crash's real geometry
has moved to GX, and startup captures do not prove title-to-hub acceptance.


## Recorded checkpoint result

All 636 synthetic full-VRAM checkpoints pass in Dolphin/OpenGL: 160 projective
native draws are included in 392 native triangles total. Two dedicated ownership
sequences also pass. All seven ASan/UBSan host suites pass; 252 of 256 tested
projective candidates were admitted and matched 24307 actual software raster
pixels. See `GX-PROJECTIVE-PROBE-STATUS.json` for exact build identities.

The private game build passed the static layout and linked SDK EXI DMA checks.
An intermediate build, before the final resident-target boundary guard, stayed
alive until the requested interrupt in a 90-host-second local startup run. Its allocation report showed zero failed bytes. This interval had
zero native triangles and only 11 native fills. Admission counters reject the
observed projective candidates at the unsupported-state gate. Consequently this
checkpoint does **not** establish actual Crash geometry acceleration or a speed
improvement. Native depth/filter/Gouraud support remains the release blocker;
no owner DOL is provided.

Three additional full-VRAM regressions reject flat, FST and large STQ targets
near VRAM's end before any native command. A valid small primitive does not
imply that the resident 480-row surface is representable. Unsupported residency
layouts must fall back instead of becoming a terminal GPU fault.
