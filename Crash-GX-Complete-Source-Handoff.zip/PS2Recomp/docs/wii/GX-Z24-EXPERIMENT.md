# Native Z24 experiment: not accepted for runtime integration

The measured initial Crash sequence uses Z24, predominantly GEQUAL with depth writes and unconditional alpha. A new standalone `native_depth_probe.cpp` tests the actual GX depth pipeline rather than inferring it from color rendering.

The probe seeds EFB Z through a Z24 texture, draws whole triangles using interpolated depth, copies RGB and Z back, and compares complete 4 MiB VRAM against the existing CPU reference. It tests GEQUAL and GREATER, 12.4 geometry, varying depth, low values, the measured range, near-equal old depths and values near the 24-bit limit. Depth/readback remain exact acceptance checks; RGB tolerances from the separate connected color probe are not applied here.

Projection must account for libogc `guOrtho` translating Z by `-far/(far-near)`. The experiment overrides that translation and uses an inverted viewport depth range to avoid cancellation near low source depths. A half-unit source bias models the reference's `floor(z + 0.5)` rounding. This is a test hypothesis, not a verified general translation.

Results in local OpenGL Dolphin:

- Corrected projection without the half-unit bias: 0/32 cases fully exact.
- Half-unit bias with default fast depth: 6/32 cases fully exact.
- Half-unit bias with verified `Graphics.Settings.FastDepthCalc=False`: 8/32 cases fully exact. Near-equal comparisons and high-value readback still differ.

The accurate setting reduces observed RGB mismatches, but does not satisfy the contract. A trial using `Graphics.Hacks.FastDepthCalc` was an unrecognized configuration key and is not evidence of accurate-mode behavior. The correct setting is documented in Dolphin's `Core/Config/GraphicsSettings.cpp`.

The developer sources used to interpret the experiment are [PixelShaderGen.cpp](https://github.com/dolphin-emu/dolphin/blob/master/Source/Core/VideoCommon/PixelShaderGen.cpp), [GraphicsSettings.cpp](https://github.com/dolphin-emu/dolphin/blob/master/Source/Core/Core/Config/GraphicsSettings.cpp), and [libogc gu.c](https://github.com/devkitPro/libogc/blob/master/libogc/gu.c). Host depth approximation and reference interpolation must be distinguished from physical GX behavior; no physical Wii result is asserted.

Next acceptance work:

1. Separate interpolation, comparison and readback precision using low-range and near-tie cases.
2. Establish safe state/value families or an exact correction path for ambiguous depths.
3. Define independent Z ownership, CPU fallback/transfer invalidation and guest-visible materialization before keeping Z resident across primitives.
4. Connect only a verified family, then measure real game progression with state diagnostics disabled.

The runtime does not call this prototype. No new DOL is released from these results.

## Canonical source-Z alternative

The isolated seed/readback probe now passes 32/32 cases exactly, including sparse
independent `GX_PeekZ` checks. Interpolation-only still passes 8/32, with sampled
errors up to two units; PE reads and copied Z agree. This isolates the mismatch
to vertex-depth interpolation, not the seed or readback representation.

A new canonical source-Z texture path passes all 32 original cases exactly.
The CPU computes source depth samples using the established canonical arithmetic;
it does not read/compare old depth or perform depth writes. GX performs late
GEQUAL/GREATER comparison and writes the exact supplied Z24 value. This avoids
silently reducing precision or increasing test tolerances.

Sixteen additional overlapping CT32 sequences use the bounded production ledger
to recover exact eight-bit alpha from final GPU Z. All 48 cases pass complete
VRAM comparisons with nearest CPU rounding/single-thread Dolphin and truncation
rounding/dual-thread Dolphin, with fast-depth mode enabled. The accepted ledger
family remains GEQUAL with depth writes; the standalone single-draw probe also
checks GREATER. The host reference test covers another 262,144 pixel states.

These are correctness results. Runtime payload lifetime, resident Z ownership,
source-alias handling and whole-game speed acceptance remain open; see
[GX-Z24-INTEGRATION.md](GX-Z24-INTEGRATION.md).
