# Crash E3: host allocation failure while starting DMA

## Owner evidence

The supplied P20 (`5154c62`) PROGRESS.TXT records:

- two 737,280-byte XFB allocations (the larger 576-row output);
- a 1,310,720-byte host RGBA frame although visible GS dimensions are 640x224;
- failed allocation of 1,890,440 bytes, caller `812b88c8` in
  `PS2Memory::writeIORegister` (the DMA start/snapshot path);
- repeated guest PCs `00162384` / `0015f598`, the VU DMA-status wait/swap loop.

The log shows a real resource failure. It does not by itself prove that every
pictured color/geometry defect has this cause. The previous 480-row Dolphin
output used smaller XFBs and was not an equivalent memory-pressure test.

`PS2Runtime::Store32` previously caught the allocation's `std::bad_alloc` as
`std::exception`, converting a host problem into a guest address-error exception.
That can leave emulated DMA work unfinished; it is not a valid DMA completion.

## Implemented changes

- GS presentation retains its 640-pixel row stride, but allocates only the
  backed output rows. 640x224 needs 573,440 rather than 1,310,720 bytes, saving
  **737,280 bytes per such image**. Different-height CRT composition reserves
  the larger height up front. Field selection, alpha and pixel conversion are
  unchanged.
- Borrowed Wii/headless texture views carry the actual backed height, including
  after mode changes. They no longer describe 512 rows when fewer are backed.
- VU decoded-cache storage follows the actual code extent: 512 pairs for the
  full VU0 code region versus 2,048 for VU1. Generation checks, bounds and the
  untracked-code fallback remain in place. On the host, the interpreter object
  shrinks from 201,616 to 70,568 bytes before its lazily sized cache allocation;
  active cache bytes depend on unit/code size.
- The 2 MiB legacy `PS2Memory` IOP window is now zero-initialized on first
  explicit `getIOPRAM()` access, with synchronized lazy construction. No runtime
  caller used this old window; the executing `IopSubsystem` owns separate RAM.
  Its RAM and byte ownership metadata are retained. Reinitialization/destruction
  still release the compatibility window, and an uninitialized object returns
  null. This removes an unused eager reserve, not the active IOP memory.
- The progress observer writes one final snapshot after joining, so a new
  failure immediately before exit cannot be hidden by the five-second interval.
- All ten runtime load/store entry points rethrow host `bad_alloc`, preserving
  ordinary guest address fault handling. The outer host error path can stop
  emulation rather than silently injecting a PS2 address exception. No DMA IRQ,
  STR clearing or VU completion is invented to escape a wait.

## Verification and limits

- 296 old/new presentation comparisons match the active RGBA rows, including
  dual CRTs, source fallback, formats, origins and fields.
- A constrained allocation test holds the real production 640x224 GS frame and
  the observed 1,890,440-byte snapshot within 2,600,000 tracked bytes. New code
  peaks at 2,463,880; old production code fails under the same budget. This is
  a deterministic component test, not a simulation of every fragmented heap.
- The actual frame handoff still moves ownership with allocation denied.
- Production VU cache lookup/rebuild tests cover both hardware extents, highest
  PCs, generation invalidation, resizing and the external-code fallback.
- 30 injected load/store cases distinguish host OOM, guest address errors and
  successful accesses; OOM does not fabricate a DMA completion.

Exact final-build game, PAL/Dolphin, heap and hardware observations belong in
the accompanying status report. These changes do not establish full graphics
accuracy, all-game support, physical Wii performance or clearance of the
reported Defender detection against the old P20 archive.

## Local reproduction sequence

A debugger-free PAL Dolphin run of the exact P20 baseline reproduced the same
1,890,440-byte failure and guest wait PCs. Compact frames allowed that allocation,
but the final snapshot exposed the next request, 1,896,640 bytes, failing as
well. That finding prompted removal of the unused eager legacy IOP allocation.
Final combined-build results must be read from the status report; the first
successful request alone is not a claim that all memory pressure is resolved.

## Final combined result (runtime 4276405)

The combined Wii build passed its ELF/DOL layout validation and linked-SDK
EXI DMA address execution test. A 180-host-second PAL Dolphin capture used
the same 737,280-byte XFBs as the owner. Its progress snapshot recorded zero
failed allocations (MEM2 payload 44,835,196, peak 44,900,748 bytes), with
continued guest progress. It reached the animated 3D title scene with filled
surfaces and textures, whereas the baseline remained in the dark lab scene
with the exact 1,890,440-byte failure. Images are at different animation
phases; this is progression evidence, not pixel equivalence or a claim that
all visual inaccuracies are fixed.

The final host build passed all 80 GS and 42 VU regressions. The 240-second
scene probe reached title geometry, hub geometry and hub terrain, delivered
12 input packets, then captured 106 nonblack images after the final load.
It completed with exit 0. This is not a physical Wii FPS/playability result.
See FRAME-MEMORY-STATUS.json for precise hashes and scope.

The source handoff contains no game objects, assets or Wii executables. The
reported Defender detection on the old P20 archive remains unresolved; these
correctness tests are not malware clearance.
