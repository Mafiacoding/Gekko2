# Exact decoded native source reuse

`PS2X_WII_SOURCE_IMAGE_CACHE` defaults off. It adds up to sixteen source-image
entries to the native linear/projective texture paths. A shared 512-KiB budget
counts retained capacities for backing bytes, RGBA, source-span metadata, exact
palette snapshots and the working palette. Round-robin eviction frees each
discarded entry's storage. One image requires at most 64 KiB of backing bytes
and 64 KiB of decoded RGBA, before optional native tiles.

A hit requires identical texture layout, TEXA, CLUT mode and every backing byte
in the touched physical 256-byte source blocks. Indexed images additionally
compare the complete canonical palette; truecolor images ignore it. Identical
CLUT reloads retain the revision, while changed contents advance it. All guest
palette reads and CLD/CBP side effects still run. Sorted adjacent blocks merge
into spans, avoiding checks of unused 8-KiB page padding. The canonical software
sampler must first prove its retained texture page coherent with VRAM; existing
native source/target/Z disjointness checks remain in place. No hash or epoch
comparison replaces the byte comparisons.

Entries contain raw decoded images before texture/vertex-color combination.
The combination, first/last guest sample and alpha metadata still run. Reset
and initialization invalidate all entries. DecodeImage is placed in MEM1 and
checked by the Wii layout verifier.

## Immutable GX tiles

`PS2X_WII_IMMUTABLE_SOURCE_TILES` also defaults off and requires the source
cache. An entry may own aligned native RGBA8 tiles, counted in the same budget.
Unchanged tiles can be submitted repeatedly without modifying the shared
upload buffer. A use serial tracks queued GPU readers. Eviction, reset and
shutdown must fence outstanding readers before freeing or replacing their
storage; successful framebuffer resolve also completes those uses. The shared
upload-buffer fallback keeps its existing barrier. SourceTilePixels is checked
for MEM1 placement.

## Validation and limits

The real-GX texture probe accepts `--source-image-cache`. Its 813 complete-VRAM
comparisons pass in local Dolphin, including alternating CT32/CT16/T8 images,
unrelated writes, stale retained pages, TEXFLUSH, changed texels and vertex
combination, changed/restored palettes, seventeen-image ring turnover and
large-image budget eviction.

The connected probe additionally accepts `--immutable-source-tiles`. Its 138
cases pass in both single- and dual-core Dolphin. Existing connected triangle
cases allow RGB error up to 5/255 while requiring exact structural VRAM; the
three added uniform-color source lifetime/eviction cases compare complete VRAM
exactly. They queue draws before the final resolve and check the memory budget
and fences on eviction of live sources.

These checks establish the tested coherence and pixel contracts, not full-game
correctness or physical Wii performance. A private 60-second game comparison
reduced uploads from 33,378 to 31,245, but VU progress remained approximately
5.45 million upper instructions. No meaningful whole-game speedup was shown.
The separate untextured GX triangle option was slower in this local workload
and remains disabled in the private game candidate.
