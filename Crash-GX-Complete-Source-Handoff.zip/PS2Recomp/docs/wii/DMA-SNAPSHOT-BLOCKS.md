# Late title-stage allocation failure: bounded VIF snapshots

## Owner evidence

The supplied physical-Wii logs identify source `d529d89` (P22). Boot status
records `scheduler-exception` followed by `std::bad_alloc`. The final progress
snapshot records `failed_alloc_bytes=2861248`, caller `812b8ac0`, a 640x224
573,440-byte RGBA frame, MEM2 payload 40,996,496 and peak 44,913,808 bytes.
The runtime elapsed counter is 2,311 seconds. The error handler finishes the
worker and returns to HBC; final `_Exit status=0` does not establish a normal
successful game exit.

The matching preserved ELF resolves that caller to the DMA-chain snapshot
reserve in `PS2Memory::writeIORegister`. It is a different, larger request than
the earlier 1,890,440-byte failure. The owner log predates per-snapshot channel
telemetry, so the allocation site alone does not distinguish VIF from GIF.
Large VIF chains are the target of the bounded representation; GIF packet
storage/arbitration remain unchanged. Final game traces and Dolphin results
must establish the relevant channel and progress before claiming the owner
failure is resolved.

## Implementation

VIF0/VIF1 chain payloads use an owned logical byte stream backed by allocations
of at most 64 KiB. The original bounded two-pass DMA walker still measures,
then snapshots guest bytes before committing the channel results and queue.
TTE words, address wrapping, CALL/RET/ASR/ASP, IRQ-tag termination and empty
completion markers follow the same walker. Subsequent guest RAM writes do not
change the snapshot. Normal non-chain DMA behavior is retained.

The VIF decoder runs once over the entire logical stream. It is not invoked
once per block. Scalar reads and small payload spans cross block boundaries
through the input adapter. A span already contained in one block is borrowed;
a crossing span copies only that requested command payload. MPG/UNPACK data
remain bounded by their existing command counts; DIRECT has at most 1 MiB.
Large temporary views are released after DIRECT/image consumption. Scratch
replacement frees its previous allocation before allocating an exact-sized
replacement, avoiding geometric capacity growth and overlapping scratch peaks.
GIF packets keep their original submission boundaries and ordering.

The snapshot is movable and noncopyable. A failed reserve frees all partial
blocks. No DMA completion, STR clearing, interrupt, VU instruction or guest
jump is fabricated. Aggregate memory still has to fit: bounded individual
allocations do not provide unlimited RAM. GIF/arbiter copies and other large
allocations can require further work if subsequent evidence identifies them.

Wii progress now records the latest snapshot channel and requested size.
An opt-in headless trace (`PS2_HEADLESS_DMA_SNAPSHOT_TRACE=1`, or scene-profile
`trace_dma_snapshots: true`) reports channel, size, representation and tag
termination to local logs. It is disabled by default.

## Targeted verification

- The real snapshot/reader retains exactly 2,861,248 synthetic bytes while
  rejecting allocations above 64 KiB. The contiguous negative control fails.
- Reads at block boundaries match source bytes/guest little-endian words;
  moving preserves ownership, later source mutation does not affect it, a
  maximum 1 MiB command span works under that command allocation bound, invalid
  reads reject, and partial reserve failure releases every tracked allocation.
- The production chain walker tests retain payload/TTE byte ordering,
  CALL/RET restart state, TIE termination, empty END completion and bounded
  malformed/cyclic chains. GIF remains contiguous and VIF segmented.
- Integration regression compares contiguous/segmented VIF0 and VIF1 through
  the actual decoder: STROW/STCOL/STMASK, MPG microcode, V4_32 UNPACK, MSCAL and
  DIRECT GIF payloads across block boundaries. Registers, complete VU code/data,
  expected UNPACK values, callback ordering and emitted packet bytes are checked.

Full-build, regression, game-trace and extended PAL observations belong in the
final accompanying report. Component tests alone do not establish in-game Wii
support, speedup, complete graphics accuracy or antivirus clearance.

## Completed local verification

83 GS and 43 VU/VIF regressions passed. Both the normal host scene probe and
the same probe denying exactly 2,861,248-byte C++ allocations reached hub
geometry/terrain, delivered 12 input packets and produced subsequent nonblack
frames. Each consumed the exact owner-sized VIF1 stream 59 times and a largest
2,881,160-byte stream. Under the same targeted failure, preserved P22 stopped
at title with std::bad_alloc, missing both hub milestones. This is explicit
host allocation fault injection, not a simulation of the entire Wii heap.

The compiled Wii DOL ran 710.788 host seconds in PAL Dolphin. It consumed
2,861,248 bytes through VIF1 and then advanced EE points by 87,328 and host UI
frames by 6,393 during the next watcher interval, with zero failed allocations.
At capture the SDK counter was 3,065 seconds and low guest cycle count
2,123,409,248, beyond the owner's 2,069,340,959. The actual XFB shows PRESS START.
The test was deliberately interrupted at that milestone; it was not a normal
game exit or a physical-Wii timing measurement. A separate P22 PAL baseline
under concurrent build load reached only SDK second 1,015 during its 600-host-
second budget, so it did not reproduce the late owner failure. Do not represent
that partial baseline as a before/after Wii failure proof.

The scene probe now rejects caught runtime exceptions even when shutdown
returns exit status 0 and a final headless summary exists. This closes a false-
positive test-harness path discovered in the injected baseline run.

Static ELF/DOL/arena checks, the real linked SDK EXI DMA address check and the
loader's valid target plus seven invalid target checks passed. See the adjacent
JSON report for hashes, source IDs and limits. This build addresses stability;
no speedup, complete visual equivalence or physical-Wii gameplay is claimed.
