# GX pipeline rebuild work queue

Goal: reduce whole-game CPU work by translating GS state into coarse GX work. Preserve game progress, guest-visible memory and tested image contracts. No new owner DOL until local game measurements establish useful progress. Work stays in PS2Recomp until validated for Gekko2 reuse.

## Batch 1 — Baseline and state eligibility

- [x] Preserve current builds and measured rejected alternatives.
- [x] Read Wii architecture and all 90 Primer pages; record hardware limits.
- [x] Measure software GS versus native submission occupancy.
- [x] Add an explicit whole-primitive eligibility contract: unconditional RGB, no variable fragment rejection, compatible blending, canonical coverage.
- [x] Record eligibility/use/rejection counts in local game runs (first unconditional family has zero startup uses).

Acceptance: no mutation on rejection, exact fallback behavior; counters distinguish attempts, accepted primitives and pixels. GPU load is not inferred from draw count.

## Batch 2 — Whole GX triangles

- [x] Prototype a single GX triangle instead of per-row RGB rectangles (experimental exact 12.4 geometry).
- [x] Verify the accepted 12.4 subset: sample positions, edge ownership, both windings, offsets and shared edges against full VRAM; clipped geometry is rejected.
- [x] Admit only a geometry/state subset with demonstrated coverage compatibility; retain old route for everything else.
- [x] Preserve source sampling, pending owner state, exact alpha metadata and source-buffer fences (342 connected cases in both Dolphin CPU-thread modes).
- [x] Remove per-pixel CPU permission processing for proven unconditional CT24 cases; CT32 exact alpha metadata remains.

Acceptance: structural VRAM exact, existing RGB tolerance unchanged, actual whole-triangle counter nonzero, repeat matched local game measurements.

## Batch 3 — GX depth and alpha state families

An actual Z24 seed/interpolation/comparison/readback probe is implemented. Direct interpolation fails near ties; canonical source-Z input passes 48 GPU cases including deferred CT32 alpha. The bounded ledger and auxiliary ownership boundaries are implemented; registering the resident depth engine in the runtime is still open. See [GX-Z24-EXPERIMENT.md](GX-Z24-EXPERIMENT.md) and [GX-Z24-INTEGRATION.md](GX-Z24-INTEGRATION.md).

- [ ] Measure actual GS depth/alpha/blend families in title and gameplay captures. Startup measured: Z24, GEQUAL with depth writes; most sampled triangles have unconditional alpha. Title/gameplay capture remains open.
- [ ] Define depth encoding and precision limits (GS Z32/Z24/Z16 versus GX Z24).
- [ ] Implement and test safe families, including alpha failure write masks and late-Z behavior.
- [ ] Keep explicit fallback for destination-alpha and unsupported equations.

Acceptance: overlap, ordering, partial writes, readbacks and mixed CPU/GX sequences against the reference; no blanket approximate depth conversion.

## Batch 4 — Persistent GPU framebuffer and presentation

- [ ] Separate display acquisition from mandatory VRAM resolve.
- [ ] Define ownership epochs and invalidation for CPU reads/writes, DMA and render-to-texture.
- [ ] Present supported display composition directly with EFB-to-XFB hardware conversion.
- [ ] Retain CPU output for unsupported GS display combinations.

Acceptance: multiple frames, target switches, display offsets, field modes, PMODE composition, CPU texture reads and shutdown fences; conversion CPU occupancy falls in measured runs.

## Batch 5 — Native source textures and command batching

- [ ] Measure source formats and cache churn before extending representations.
- [ ] Add native indexed texture representation only if exact CLUT alpha/color and filtering are preserved.
- [ ] Reuse compatible GX state and group primitives without changing order.
- [ ] Bound cache memory using actual MEM1/MEM2 headroom and lifetime fences.

Acceptance: palette changes, aliasing, source restoration, eviction and mixed-renderer coherence; lower preparation cost and useful game progression gain.

## Batch 6 — Hybrid CPU pipeline

- [ ] Profile remaining EE/VU runtime work after graphics changes.
- [ ] Replace measured recurring VU programs with verified native kernels where semantics permit.
- [ ] Preserve instruction/AOT fallback and full EE/VU state continuity.
- [ ] Reuse proven APIs in Gekko2 and integrate GUI selection after acceptance.

Starlet remains the IOS service processor. Using it as an additional computation core is not assumed or required by this queue.

## Batch 7 — Release acceptance

- [ ] Local title-to-gameplay progression with automatic input and no runtime error.
- [ ] Repeated comparable speed runs with no concurrent compilers or debugger.
- [ ] Image and guest-memory regression checks through gameplay.
- [ ] Heap peaks, hot-code placement and artifact integrity verified.
- [ ] Deliver only the requested runtime DOL with checksum and precise remaining limits.

Current status: adequate Dolphin gameplay speed and full GPU ownership are not achieved. This checklist is an implementation queue, not a claim that the open stages are complete.
