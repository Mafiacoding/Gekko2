# Experimental whole GX triangles

`PS2X_WII_GX_WHOLE_TRIANGLES` is off by default. It introduces the first coarse primitive route in the connected hardware-linear driver; it is not full GS depth/alpha emulation.

The initial state family requires unconditional RGB acceptance: alpha test disabled or ALWAYS, depth ALWAYS with depth writes masked, no destination-alpha test, no scan mask, no AA/fog, no framebuffer bit mask and no PABE-dependent blending. Existing TryLinear source-format, target, alias, blending and texture-coordinate guards still apply. Variable source-alpha blending remains on the row path. Initial geometry uses exact 12.4 screen coordinates after XYOFFSET, with vertices inside the scissor bounds. Off-lattice vertices and clipped triangles keep canonical row rendering.

The [Dolphin vertex shader generator](https://github.com/dolphin-emu/dolphin/blob/master/Source/Core/VideoCommon/VertexShaderGen.cpp) documents the GX sample position, and its [software rasterizer](https://github.com/dolphin-emu/dolphin/blob/master/Source/Core/VideoBackends/Software/Rasterizer.cpp) uses 28.4 edge coordinates with a hardware-calibrated bias. The hardware triangle geometry is shifted by 1/12 pixel to reconcile this GX projection's 7/12 sampling location with the reference's 1/2 sample. Shader planes retain their existing bias. This is an experimental geometry contract verified in local Dolphin probes; physical Wii edge accuracy is not established by those tests.

One GX triangle replaces all RGB row rectangles. Canonical spans are retained for surface seeding and dirty metadata. CT32 still computes exact alpha metadata; eligible CT24 targets bypass the per-pixel CPU fragment permission callback because neither depth nor stored alpha is touched and RGB acceptance is state-proven. This does not eliminate all per-pixel metadata work.

Submission failure after guest sample/metadata mutation is terminal. It never triggers software replay over partially changed state. Existing immutable source lifetimes, owner fences and terminal faults remain in force. The old 256-row-run completion boundaries belong to the row command stream; the new route submits only one triangle after preparation, so it does not introduce repeated RGB run submissions to fence.

`PS2WiiGXWholeTriangles[8]` records:

0. Whole triangle submissions.
1. Canonically covered pixels in those submissions.
2. Canonically nonempty rows replaced.
3. Submissions bypassing CPU fragment permissions (eligible CT24).
4. Driver attempts while the experiment is enabled.
5. Attempts matching the unconditional state family.
6. Attempts also passing 12.4 geometry/scissor preflight.
7. TryLinear operations in that state family that still use the row route.

Counts are work diagnostics, not CPU/GPU load, pixel throughput or frame rate. The acceptance queue is in [GX-REBUILD-BATCH.md](GX-REBUILD-BATCH.md).

Validation: the accepted 12.4 route passed 342 connected cases with Dolphin CPU threading both disabled and enabled. Covered RGB maximum error was 6 within the unchanged per-TFX budgets; structural VRAM stayed exact. Two mixed-renderer sequences additionally compare complete VRAM exactly after additive shared edges and a CPU fallback. Twelve host GS suites and four phase-parser tests pass.

The 90-second initial game run used the whole-triangle family zero times: its actual depth-writing GEQUAL states are excluded. This prototype therefore does not establish a game speedup. State profiling and the separate Z24 experiment now target that measured gap.
