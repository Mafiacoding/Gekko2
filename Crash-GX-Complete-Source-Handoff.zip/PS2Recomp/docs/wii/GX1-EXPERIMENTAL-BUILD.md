# GX1 owner test build

The opt-in Wii target now creates the real shared-VRAM `GSHybridBackend` from
`GS::init`. Its native driver and texture bridge are shared with the synthetic
Dolphin tests rather than copied into a second implementation. Unaccepted draws
remain on the canonical software backend. This is a restricted native subset,
not general GS acceleration or a verified Crash speedup.

Build with the normal private generated sources and devkitPro toolchain, adding
`-DPS2X_WII_NATIVE_GX=ON -DPS2X_GEKKO_ROOT=/path/to/pinned/Gekko2`.
The source generator verifies the existing five upstream SHA256 values, writes
GPL adapters to the build directory and leaves Gekko2 unchanged. Default remains
OFF. EE converter, segmented DMA and guest scheduling behavior are retained;
VU operand experiments remain OFF in this owner candidate.

## Memory and ordering

Selected admission/draw routines occupy approximately 12.8 KiB in `.gxhot` in
MEM1. Other added code, including cold SDK GX initialization, is in MEM2. The
FIFO explicitly uses the MEM1 allocator and its range is checked before GX_Init.
This placement avoids overflowing the existing MEM1 link bound. It is not an
instruction-cache hit-rate measurement or proof that MEM2 has no timing cost.

An initial real-game boot with two 1.2 MiB staging allocations returned with
`std::bad_alloc`; it was rejected. The compact adapter uses a 10 KiB seed row and
a 160 KiB readback band, 174080 bytes combined. The legacy unused source-image
allocation is removed. Surface alpha/dirty metadata, source textures, FIFO and
other runtime allocations are additional to that staging budget.

Opaque draws skip seeding only for fully overwritten 4x4 tiles. Partial/masked
tiles and additive draws preserve destination contents. A seed buffer cannot be
reused until its previous GPU consumer completes. Resolves import aligned bands
without touching unmarked pixels or retained guest texture/CLUT cache entries.
A failed fence remains terminal; it never authorizes stale software fallback.
The subset's flat helper cannot enter the legacy full-size capture fallback.
Normal process exit drains GX after the game worker has joined.

## Validation and owner installation

The compact adapter passes 474 complete 4 MiB VRAM comparisons in real-GX
Dolphin/OpenGL, including full 640x448 surfaces, partial CT24 writes, scan masks,
additive destination reads and pending draws entering new tiles. Existing
texture/triangle/filter/cache tests are retained. The host ownership/cache suites
pass with ASan/UBSan and leak scanning disabled. These tests are not Wii FPS.

A 300-host-second PAL Dolphin run of the compact candidate remained active until
an explicit debugger interrupt, reached SDK second 1085, consumed VIF1 snapshots
up to 2787616 bytes and reported zero failed allocations. This is an early game
startup/progression check, not title-to-hub or physical Wii acceptance. Final
build identity and capture evidence accompany the private artifact.

The DOL replaces only `SD:/ps2recomp/crash-runtime.dol`; keep the existing small
HBC launcher and game files. Do not put this large runtime at `apps/.../boot.dol`.
`boot-status.txt` identifies backend selection and the actual FIFO address.
`gx-status.txt` contains bounded operation counters, not FPS. Unsupported STQ,
general perspective/depth/blend states and other texture shapes remain software.
