# Native GX integration: inspected constraints

This is an implementation design, not an enabled backend. The current
PS2Recomp GS frontend still selects `GSCpuBackend`. Gekko2 remains unchanged.
Existing Gekko2 GX modules compile in an isolated devkitPPC experiment, which
proves dependency discovery only, not integration or rendering correctness.

## Concrete integration boundaries

1. **One authoritative VRAM allocation.** PS2Recomp already owns 4 MiB GS VRAM.
   Gekko2's `source/hw/gs_mem.c` currently owns another static 4 MiB array.
   Reusing that module unchanged would duplicate VRAM and separate ownership.
   A reusable module needs explicit external-memory binding, size/lifetime
   validation, and cache invalidation when binding changes. Do not simply alias
   a raw pointer while GPU work or a resolver still references the old owner.
2. **Ownership and fallback.** Before software rasterization, transfer,
   readback or snapshot, resolve overlapping GPU-owned pages and honor resolver
   failures. After software writes, invalidate overlapping host-derived GPU
   source/target generations, preserving guest-latched texels until TEXFLUSH.
   Gekko2's `gs_mem_sync` and alias-range resolver provide
   useful existing machinery. PS2Recomp raw writes currently bypass that module;
   every such path must be accounted for before declaring coherence.
3. **Direct presentation.** `GSRasterBackend::Present` currently returns a
   CPU RGBA `PresentationFrame`. A resident GX surface needs an explicit native
   surface contract with dimensions, generation, ownership and lifetime, plus
   synchronized Wii presentation. Returning an empty RGBA vector is currently
   an invalid frame. Uploading a CPU-rendered RGBA frame to GX does not move GS
   rasterization off the CPU.
4. **Eligible draws.** Begin with a precisely specified format/test/blend/depth
   subset and map GS units explicitly. Gekko2 flat APIs take integer pixel XY,
   word-address BP and pixel BW, not the frontend's encoded register units.
   Reject unsupported combinations before any partial GPU submission. Compare
   edge coverage, masks, depth, destination alpha, color scaling and texture
   feedback against the software oracle before extending the subset.
5. **Fences and threading.** Existing GS backend lifetime locking is not GPU
   completion. Serialize shared GX state across rendering and presentation;
   preserve texture/FIFO lifetimes and SDK cache operations. A timeout cannot
   be converted into a successful readback or an early DMA completion.
6. **Memory budget.** Retain the P23 segmented DMA snapshot fix and protected
   SDK/MEM1 placement. FIFO, decoded textures, resolve buffers and surfaces need
   bounded accounting alongside resident EE code/RAM, IOP RAM, XFB and GS VRAM.
   Retaining a CPU full-frame mirror for every accepted draw defeats both the
   speed goal and part of the memory benefit.

## Acceptance workload

Use the existing private decoded intro and hub GS streams. First validate their
end markers; feed identical commands into software and candidate backends.
Report accepted/rejected draws, CPU fallback count, resolves and transferred
bytes, packet/frame equivalence, peak memory and time at identical work. A
synthetic flat triangle benchmark alone cannot establish Crash acceleration.
Keep streams and resulting game images private. Native GX acceptance must also
include actual Wii behavior; Unicorn cannot model GX/cache timing and unlimited
Dolphin speed is not physical Wii FPS.

## Other requested acceleration paths

- EE AOT and direct masked RAM helpers already exist. Dynamic code relocation
  alone adds no instruction translation benefit to this runtime. Hot-code/data
  placement must be measured against the small MEM1 budget and cache behavior.
- VU block AOT needs microprogram identity plus code-generation guards, full
  pipeline state, budget exits, delayed branches and ordered XGKICK handoff.
  The interpreter remains the fallback/oracle for changed or unmatched code.
- Asset read-ahead may overlap known reads, within a bounded cache. It cannot
  postpone arbitrary calculations or reorder DMA, uploads, interrupts and
  presentation without preserving guest-visible dependencies.
- Gekko2 and the Wii GUI should consume a proven shared runtime contract later.
  Neither project merge nor GUI work is a substitute for the speed measurement.

## Implemented coordinator, 2026-10-26

`GSHybridBackend` now provides an experimental, unselected integration boundary
for one external VRAM allocation, deferred native draws, ordered software
fallback, transfers/readbacks and terminal driver faults. An accepted draw is
never mirrored through software Submit. A failed resolve cannot silently become
successful CPU fallback. Partial driver initialization is shut down even when
initialization throws before native drawing is enabled.

The standalone `tests/gs_hybrid` suite compares all VRAM bytes using the actual
software backend and a deferred software test double. It covers 256 mixed draws,
cache visibility, transfer/clear/presentation boundaries, rebinding and injected
failures. ASan/UBSan pass (leak scanning disabled); the coordinator also compiles
with devkitPPC CPU750 `-Os -G0`. This establishes coordinator behavior, not GX
rendering, game speed or physical Wii correctness. It is not selected by GS or
added to the released Wii target.

A differential test caught an error in the initial coordinator: resolving GPU
writes must NOT implicitly invalidate guest-latched texture-cache contents.
Raster writes, ordinary Flush and FINISH preserve those contents until guest
TEXFLUSH. The coordinator now preserves that rule. Initially textured native
submissions were withheld. They now require an
explicit identity-checked canonical cache contract; default drivers remain
untextured. The restricted point-texture prototype is documented in
[NATIVE-TEXTURES.md](NATIVE-TEXTURES.md).
Host cache invalidation must not erase guest-latched texels or CLUT state.

Private legacy stream-prefix analysis observed about 4.23 million Submit calls
in the hub capture, with about 86% of measured Submit time in textured draws.
This was one instrumented host replay, excluding presentation conversion/clears,
and both old streams ended truncated. It is prioritization evidence for their
readable prefixes, not a complete-stream acceptance run or whole-game CPU/FPS
measurement. A flat-only GX path cannot address most of that measured work.

## Isolated native GX experiment, 2026-10-27

The following records the original untextured probes; the later native source
texture work is in [NATIVE-TEXTURES.md](NATIVE-TEXTURES.md).

A standalone synthetic ELF now compiles shared-VRAM Gekko2 GX modules alongside
PS2Recomp's actual software renderer. It issues real GX commands, fences them,
resolves to RAM and compares the entire VRAM allocation after each case. This
is distinct from the deferred software test double used for coordinator tests.
See [reproduction and limits](../../tests/gs_hybrid/native/README.md).

The initial eight CT32 cases passed through resident and direct paths after a
test-harness configuration error was corrected: Dolphin 2503 expects the system
name `Graphics`, not `GFX`. The wrong prefix was silently ignored, leaving CPU
EFB access disabled and RAM copies skipped. Those earlier black-readback runs
are not evidence of a GX rendering defect. Dynamic OpenGL call tracing confirms
both drawing and staging readback with the corrected options. Direct EFB/poke
controls also work. The early resident EFB peek point was outside its draw;
subsequent controls used an interior point.

The larger matrix adds CT24 alpha preservation, varied RGBA, unaligned bounds,
scissors, row masks, framebuffer bases and buffer widths. No game rendering,
physical Wii behavior, textured native drawing, or whole-game acceleration is
established by the synthetic probe. Do not select this path in the released
runtime until it passes integration and real-workload gates.

The reproducible matrix build passed 64/64 complete-VRAM comparisons (256 MiB
compared in total), including CT32/CT24, both residency modes and both buffer
widths combined independently. The restricted real-GX driver then passed seven
complete-VRAM checkpoints through `GSHybridBackend`: six native draws, four
software draws and six resolves. The initial accepted-draw check verifies there
is no CPU mirror. CPU-retained texels before TEXFLUSH and refreshed texels after
TEXFLUSH match the oracle. Clears, CPU writes and upload boundaries also match.
OpenGL tracing resolved actual function pointers and observed staging readback,
not just successful SDK fences. See [sanitized results](HYBRID-GX-PROBE-STATUS.json).

Both probes build from `tests/gs_hybrid/native/build_probe.py`, with pinned
Gekko2 core C source hashes and generated GPL adapters confined to a separate
output directory. The integration driver is test-only, accepts a strict flat
sprite subset, and conservatively resets GX host caches after software writes.
It is not a measured speed improvement: real game profiles still require native
general textured rendering, a shared guest cache beyond the single-page subset,
bounded source/target
ownership, memory budgeting and matched-work performance evaluation. Neither
probe is wired into the released Wii target; no owner update DOL was produced.

Native texture follow-up: [single-page source cache and actual GX checks](NATIVE-TEXTURES.md).
