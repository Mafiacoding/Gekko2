# GX2 long-session findings and internal preparation optimization

The owner session identifies runtime source `27cd576`. It ran for 7,265 seconds
and ended normally through the window-close / worker-join / status-0 path.
Allocation diagnostics report zero failed bytes and peak MEM2 payload of
45,751,368 bytes. The snapshot does not time individual loading stages and does
not establish that the entire session was spent in one transition.

The last complete GX history group records 3,858,432 attempts, 577,894 native RGB
operations, 91,745 uploads, 486,138 source reuses and 593,399 decodes. Native RGB
therefore accounts for about 15% of attempted operations, not 15% of pixels or
wall time. The filtered path accepts 1,139,063 of 2,495,350 candidates, including
metadata-only operations; 605,811 fail its state gate and 750,476 fail its geometry/
sampling plan. The old projective fallback rejects 1,497,992 candidates at its
state gate. These gates overlap in routing and must not be added as independent
draw totals. Existing logs cannot rank their time costs or prove a JIT stall.

The 131,072-byte history ends in a partial record. Its cap was reached; the final
portion of the long session is missing. The previous bounded logger also kept
opening/seeking/closing the capped history. That is a concrete diagnostics and
I/O issue, not proof that logging caused the two-hour runtime.

## Internal changes

For admitted textured primitives whose register state excludes every color write
(ZTST=NEVER, or ATST=NEVER with KEEP/Z_ONLY), avoid full decoded-image preparation,
tile conversion, upload and shader setup. Preserve first/final guest sampling,
all required depth writes and pending RGB ownership. Also probe current Z without
writes before materializing a fresh texture of at least 1,024 texels; if every
fragment is occluded, preserve sampling but skip its unused image. Other alpha/depth cases
retain the previous path; geometry, source coherence and alias checks remain.
This does not move depth decisions to GX or claim to fix the complete regression.

Batch the three GX history records into one write per ten seconds. Stop reopening
a full history, never cut a record at the size limit, and keep updating a separate
`gx-latest.txt` snapshot with timestamps and `image_skipped` counts. No new owner
DOL is published for this internal checkpoint.

The 135-case connected Dolphin probe passes, including four exact fallback
negatives, full-width targets, pending RGB through depth-only work, and explicit
assertions that qualifying passes perform no decode/upload. Thirty-five such
passes are exercised. Maximum RGB deviation remains 5/255; alpha/depth/source and
other VRAM stay exact. Nine existing host suites pass. These are correctness
checks, not real-Wii performance measurements. The two-hour transition still
requires phase/cost profiling and broader GX ownership improvements.


In a private local Crash run, a matched 49,152-attempt checkpoint retains exactly
14,826 native operations, 1,875 uploads and 12,940 reuses. Decodes fall from 9,759
to 1,875 (80.79% less decoding); the new counter records 7,884 avoided images.
The scene remains visible. This compares work counts at the same checkpoint,
not host duration or physical Wii FPS, and does not establish a shorter menu-to-
game transition. Profiling is enabled only in the private local build; it is not
part of a newly delivered owner runtime. The phase analyzer now correctly names
bucket 8 as GIF submission (including native GS), matching its code scope rather
than calling it DMA service. Its three existing parser tests pass.


Internal scene profiling now separates native GS preparation/submission (bucket
13, including waits) from software rasterization (11) and VU execution (10).
A local Dolphin run sampled the producer over 30-second windows. In the lab
sequence, excluding the first startup window (host seconds 30–600), occupancy
was VU 56.85%, native GS preparation/submission 26.33%, software GS 9.76%,
and remaining GIF submission 4.78%. IOP was 0.09%. These are sampled wall-time
phase occupancies, not CPU utilization or physical Wii timings. The last capture
still shows the lab without the Crash letters: this does not yet establish the
letter-animation or menu-to-game bottleneck. EE game functions are statically
recompiled; VU execution uses the VU1 interpreter. UI samples overlap the
producer and must not be added to these percentages.
