# Resident Z24 integration contract

Implemented foundation:

- Canonical source-Z samples in `GSNativeDepth24Plan`; no old Z read, comparison or guest write in that helper.
- Exact GPU Z-texture comparisons/writes in the standalone canonical-depth probe.
- Bounded `GSNativeDepth24Ledger`: 128 immutable primitive records, no source texture pointers or full-screen mirror, explicit resolve/fault state and conservative Z source-alias protection. Each record captures the producer CPU rounding mode; replay temporarily restores it and preserves the resolving thread’s mode.
- Deferred CT32 alpha reconstruction for GEQUAL + depth writes: process records in reverse submission order and take the last covered source whose canonical Z equals final GPU Z. Alpha includes canonical interpolation, uniform texture alpha and FBA. A rejected source cannot match final Z unless it was an accepted GEQUAL tie.
- Host comparison against the independent CPU renderer covers 262,144 pixel states, coplanar ties, varying alpha, uniform texture-alpha TFX modes, FBA, capacity, aliases, cross-mode rounding and lifecycle failure. GPU overlap cases independently verify the approach.

The ledger is restricted to one framebuffer format/target and one Z target per batch. Mixing CT24 and CT32 inside the same batch is rejected: a later CT24 depth winner must not erase an earlier CT32 alpha write. GREATER, masked depth writes, dependent alpha tests and nonuniform texture alpha are excluded from this first ledger family.

## Ownership boundaries now implemented

The generated GX adapter has drain-only auxiliary owner registration, a resolve callback before RGB/alpha import, and a read-only source-disjoint callback. It rejects owner changes while GPU work is pending and treats resolve failure as terminal. Connected GPU tests verify ordering before old VRAM is overwritten, mixed CPU/GX transitions and auxiliary source aliases in compact and full staging modes.

`GSNativeDrawDriver::NeedsResolveBeforeSubmit` lets the coordinator materialize a pending auxiliary owner before a different native path reads CPU metadata. Host tests verify that this preserves native routing and that query failures remain terminal. No depth engine is registered by the current game runtime yet.

## Driver wiring still to implement

1. **Resolve hook consumer:** connect Z readback and deferred alpha reconstruction to the implemented pre-RGB hook. Cover internal surface switches/reset as well as explicit `Resolve`, transfers and shutdown. Failure is terminal.
2. **Z ownership:** retain target key and seeded 4x4-tile map. Seed only previously untouched Z tiles from CPU VRAM; never overwrite newer resident GPU Z with stale CPU values. Incompatible state/target or a full ledger resolves before software fallback.
3. **Source aliases:** extend the current native source-disjoint proof to include the whole pending Z owner envelope. An RGB-disjoint source can still alias GPU-owned Z.
4. **Payload lifetime:** use a fixed bounded canonical-Z upload arena. Fence only before recycling arena bytes; retain existing RGB source-image fences. A proposed 128 KiB arena, a 19,200-byte seeded-tile map and the ledger's compile-time 66 KiB upper bound total under 214 KiB. Actual peak heap must still be measured.
5. **Whole-triangle shader:** preserve the existing RGB/TFX shader and add a final Z-texture stage. The stage passes RGB through and supplies exact canonical Z. Use late Z for the texture-derived comparison. Keep fixed/source-alpha blend coefficients separate from stored alpha/FBA.
6. **Metadata:** mark canonical RGB coverage conservatively; rejected GPU fragments preserve seeded destination RGB. Mark deferred alpha without pretending every covered fragment passed. Reconstruct alpha from final Z before RGB import, then materialize Z24 once per resolved region, preserving the unused high VRAM byte.
7. **Acceptance:** mixed native/CPU sequences, source aliases, target changes, TEXFLUSH/transfers, ledger/arena wrap and shutdown; then actual Crash measurements with diagnostics off. No speedup is inferred from the standalone probe.

The runtime currently does not call the new resident-depth path. Direct hardware interpolation remains an unsuccessful precision experiment; canonical-Z input is the verified alternative under development.
