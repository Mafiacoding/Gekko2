# Hybrid performance workstream

Current owner priority: speed and in-game progress. P23 reached the hub and
movement on physical Wii. Preserve that baseline; do not provide another DOL
before internal matched-work acceleration and correctness evidence. The first
guarded optimization and its evidence are in [VU operand experiment](VU-OPERAND-EXPERIMENT.md).

The current Crash DOL already combines statically translated EE code, selected
native system/math functions, and emulated PS2 hardware services. It does not
execute a normal BIOS. A new hybrid name or a BIOS bypass alone cannot remove
the remaining VU, GS, memory or synchronization costs.

## First implemented milestone

`PS2X_WII_SAMPLE_PROFILE=ON` enables an optional 100 Hz observer sampler. Its
counters are in the observer translation unit; generated EE code and VU
instruction execution receive no new instrumentation. OFF retains the original
observer polling path. Counts are included in periodic and final progress
snapshots. No interrupt, DMA completion, VU instruction, pipeline wait or game
function is skipped. The P22 runtime remains preserved separately.

`tools/wii/analyze_phase_profile.py progress.txt --output report.json` validates
complete histograms and reports EE and UI separately. They overlap. These are
wall-time phase occupancies, not exclusive CPU time, physical Wii FPS, or proof
of a predicted speedup. Sleeping, lock waits and sampler/host scheduling can
bias occupancy. The configured 100 Hz is nominal SDK sampling, not a claim
about native host sampling frequency under unlimited-speed Dolphin.

The initial 60-host-second local PAL run recorded 27,000 samples: VU 41.82%,
GS rasterization 34.99%, DMA service 12.43%. This suggests targeting the
VU/graphics/data path before treating EE scheduling as the dominant cost.
The first UI map omitted existing graphics stages 20..24 and bucketed them
as unknown; that histogram is not used for prioritization. The map and
sampler now retain all those stages separately, with a bounded unknown
bucket for unexpected values. This was a telemetry mapping issue, not
evidence of an engine memory fault. The run is an intro sample, not coverage
of the hub, all gameplay or other titles.

Observer tests execute the production code with mock SDK clocks/LWP, real
threads/file I/O, sanitizers, enabled and disabled modes, unwinding of nested
phases, unknown buckets, stop/restart and durable final samples. Parser tests
reject missing/duplicate buckets, invalid counts and old non-profile logs.

## Next hybrid acceptance gates

1. VU: identify frequently executed microprograms/blocks and their code
   generations. A native block must preserve pair read-before-write behavior,
   delayed pipeline writes/flags, branch/E-bit timing, budgets and XGKICK
   ordering. Compare complete resulting state and emitted packets with the
   interpreter; retain fallback for unmatched or changed code.
2. GS: select a narrowly specified eligible draw path through the existing
   backend interface. Keep software output authoritative for unsupported blend,
   mask, depth, texture or render-to-texture combinations. Compare the same
   packets/frame against the software path; faster output with missing work is
   a failed result. GX is a substantial implementation task, not an enabled
   acceleration switch in this prototype.
3. DMA/VIF: measure snapshot sizes, copying and stalls before batching. Preserve
   ownership, visibility, completion ordering and interrupt behavior.
4. Native EE/library replacements: use verified entries, ABI/state guards and
   fallbacks, extending the existing converter approach. Do not introduce
   unchecked library-name hooks, jump skips or universal compatibility claims.
5. For each change, compare identical input/scene work with fallback on/off,
   validate frame/packet/state equivalence, then measure the matched work on
   physical Wii. Dolphin speed is a reproduction aid, not the hardware result.

The latest owner photos show successive intro/title animation states. They
establish visible progression, not frame-synchronous rendering correctness.
The remaining graphics work needs equivalent-phase comparison, especially
textures/UV, alpha/depth and geometry, while retaining the corrected sprite
coverage and memory-failure handling. PCSX2 screenshots remain references and
must never be presented as Wii DOL output.
