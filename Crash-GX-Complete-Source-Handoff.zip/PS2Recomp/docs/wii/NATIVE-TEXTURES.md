# Native GX textures: restricted hybrid prototype

The internal prototype uploads source textures and lets GX sample and shade
covered spans. It does not upload a software-rasterized screen image or mirror
accepted draws through the CPU renderer. The real `GSHybridBackend` coordinator
owns transitions and uses one external 4 MiB VRAM allocation. Default backend
selection is unchanged. An explicit Wii test target is now available via
`PS2X_WII_NATIVE_GX=ON`; see [GX1 build](GX1-EXPERIMENTAL-BUILD.md).

## Supported and verified subset

Source formats are CT32, CT24, CT16, CT16S, T8, T4, T8H, T4HL and T4HH. A source
must fit one aligned physical 8 KiB page. `DecodeNativeTexturePage` expands
texels/TEXA/CLUT through the exact software renderer's guest cache. Indexed
sources currently use CPU palette expansion, not GX CI textures/TLUT.

The native driver accepts integer-coordinate FST sprites and restricted affine
triangles/strips/fans. Triangle area must be a power of two and UV endpoints in each axis must be
zero or a single shared power-of-two value; accepted UV gradients
are 0, +/-0.25, +/-0.5, +/-1 and +/-2 texels/pixel. Triangle coverage uses the
canonical 12.4 edge ownership and sample location. Three edge inequalities find
each row's covered span; GX draws those spans with affine source coordinates.
Scissor and scan masks are preserved. Samples must remain inside the texture;
feedback, VRAM wrapping and targets outside the EFB remain software.

DECAL samples the decoded source directly. With constant vertex color,
MODULATE, HIGHLIGHT and HIGHLIGHT2 are precombined once in **source texture
space**, using exact GS integer arithmetic. GX subsequently samples this source
per fragment. General varying Gouraud modulation remains software. CT32 targets
require uniform resulting texture alpha when TCC selects it; TCC=0 uses uniform
vertex alpha. CT24 preserves destination alpha and can use varying source alpha.

A restricted additive equation `(Cs-0)*128/128+Cd`, with PABE disabled and clamp
enabled, uses actual GX additive blending. Other blend equations, depth writes,
nontrivial depth/alpha tests, FBA, masks, fog and AA remain software.

## Exact filtering without assuming GX/GS rounding equivalence

Random-texture testing rejected direct GX bilinear filtering: one-byte differences
remained even after correcting sample positions. It is not an accepted path.
The current filtered subset prepares a quarter-texel phase atlas from the decoded
source, using the same rounded bilinear result as the software GS, then GX
point-samples this atlas. This preprocessing happens once per reusable source,
not per screen pixel or frame. Filtering precedes source-space TFX.

This path requires clamp in both axes, sources at most 32x32, and the existing
quarter-texel sprite phases or half-texel triangle gradients. A 32x32 source
becomes a 128x128 RGBA8 atlas (64 KiB); it is a deliberate bounded memory tradeoff,
not general native hardware bilinear filtering. Mips, arbitrary phases, region
wrapping and larger filtered sources remain software.

GX samples non-AA pixels at 7/12 rather than 1/2. Texture coordinates account
for this explicitly; point sampling also uses a small interior-bin bias.
See Dolphin 2503 `Source/Core/VideoCommon/VertexShaderManager.cpp` around line 344.
This is an architectural sample-location correction, not a tolerance in image
comparisons. All accepted comparisons require exact bytes.

## Cache lifetime, uploads and residency

An opt-in driver must identify its exact canonical software cache. Source data
and palettes retain the existing guest lifetime: ordinary writes and ownership
transitions do not flush retained texels; TEXFLUSH does not reload CLUT.

`GetNativeTextureStamp` reports saturating texel-cache and palette revisions only
while the complete supported source page remains latched. State keys include
source format/base/shape, palette interpretation, TEXA, TFX, vertex color and
filtering. Repeated sources can skip decoding, repacking and upload. Saturated
revisions disable reuse rather than wrap into old keys.

Pending GPU writes normally resolve before source preparation. A driver can
prove preparation reads only latched bytes; then it can reuse the unchanged
upload without per-draw readback. It must reject before GPU submission if a new
source would overwrite a buffer still sampled by GX. Software fallback still
resolves first. Preparation exceptions remain terminal. A GPU-produced source
whose page is not latched still takes the normal resolve barrier.

The synthetic 16-draw batch verifies one decode, one source upload, zero
intermediate coordinator resolves and one final resolve, with full-VRAM equality
and no CPU mirror. This is an operation-count reduction, not a Wii FPS result.

## Evidence

The ASan/UBSan host suites pass with leak scanning disabled in this ptrace
execution environment. They cover ownership/fallback ordering, preparation
failure, cache stamps, eviction/reset/TEXFLUSH, TEXA, retained/reloaded palettes,
maximum source-page dimensions and rejection without cache/output mutation.

The actual-GX Dolphin probe passed **453 full 4 MiB VRAM comparisons**, including
random texture contents, all four flat TFX modes, additive destination reads,
filtered source phases, mirrored/constant axes, winding/strip/fan coverage,
scissor/scan masks, resident batches, GPU-produced textures and safe fallbacks.
It records 455 native draws, 15 software draws, 301 uploads, 154 upload reuses,
304 decodes and 153 decode reuses. There were zero byte differences.

Dolphin must use `Graphics.Settings.SafeTextureCacheColorSamples=0`, as well as
CPU EFB access and real RAM EFB copies. Default sampled texture hashing missed
small changes in the large seed texture and produced stale background tiles.
The same diagnostic ELF failed with sampled hashing and passed with full hashing;
adding a GX completion fence or changing surface height did not fix that issue.
This diagnoses the local Dolphin test configuration, not the owner's Wii.

Build/run instructions: [native probes](../../tests/gs_hybrid/native/README.md).
Machine-readable record: [texture probe status](NATIVE-TEXTURE-PROBE-STATUS.json).

## Release gates still open

This remains a synthetic, restricted backend prototype. STQ/perspective,
general Gouraud modulation, other blend/depth states, multi-page textures,
direct GPU presentation and game workload acceptance are not complete.
Existing Gekko2 GX staging/surface allocations still require a complete combined
Wii MEM1/MEM2 budget; the bounded source atlas alone does not establish that the
Crash runtime fits. Real Crash scene comparisons, matched-work timing and Wii
validation are required before game backend selection or an owner DOL. No
real-game acceleration, complete graphics correctness or release readiness is
claimed by these probes.
