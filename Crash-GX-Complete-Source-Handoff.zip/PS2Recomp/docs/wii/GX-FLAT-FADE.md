# Exact GX loading fades

The private loading-screen packet stream contains an untextured 640×224 sprite
using `(0-Cs)*As/128+Cd`, with constant source alpha, alpha test GEQUAL 127 and
source alpha 128. The previous flat driver rejected every blended or alpha-tested
sprite, so this full-screen pass went through software rasterization.

The new path admits only the proven subtractive equation, a passing constant
alpha test, CT32/CT24, unmasked/clamped color, no destination-alpha test, no fog
or antialiasing, and the existing masked/ALWAYS depth restriction. Other states
retain software fallback. It computes each uniform source channel once as
`min(255, ceil(Cs*As/128))` and uses GX destination-minus-source blending. Clamping
that source to 255 is exact for an eight-bit destination. Alpha remains exact in
the existing metadata shadow; no per-pixel RGB image is shaded or uploaded.

Destination EFB tiles are seeded when necessary. Existing resident RGB stays
resident across repeated fades; the opaque-fill seed shortcut is not used for
this destination-dependent operation. Integer coverage, scissor and scan masks
use the existing flat coverage plan. The hot bridge is kept in MEM1 and checked
by `tools/wii/check_build.py`.

The extended real-GX Dolphin texture probe passes all 768 cases byte-for-byte
against the software renderer. The 132 added cases cover zero and large alpha,
negative-product rounding, both color formats, scan masks, clipped coverage,
repeated subtraction, passing alpha tests and full-width resident sequences.
All four MiB of VRAM are compared, including alpha and untouched/source bytes.
OpenGL draw/copy tracing confirms actual emulated GX execution.

A private game run recorded 65 native subtractive passes in its first 30-host-
second window. This proves the path is reached, not a whole-game FPS figure.
The loading-to-game duration and acceptable Dolphin speed remain acceptance
requirements. No new owner DOL has been published.
