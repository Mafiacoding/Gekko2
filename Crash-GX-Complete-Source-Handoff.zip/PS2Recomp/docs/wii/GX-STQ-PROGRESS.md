# GX STQ source rendering — work in progress

This extends the opt-in shared Wii driver beyond GX1's integer FST subset.
It is not a completed GX renderer, release candidate, or Wii speed result.
Do not package an owner DOL from this checkpoint as full GX acceleration.

## Implemented

Point-filtered STQ sprites now use cropped source textures. Logical textures
may be up to 1024x1024; each decoded footprint is bounded to 128x128 and one
physical 8 KiB guest texture-cache page. The decoder uses the canonical swizzle,
TEXA and retained CLUT/texel cache. It does not upload software-rendered frames.
All thirteen supported color/indexed/depth source formats share that decoder.
Unsupported footprints reject before touching the guest cache.

The coordinate planner follows the software sprite's second-vertex Q, fractional
coverage, reversed axes and wrapping. It validates point lookup bins against the
GX 7/12 sample position. It rejects a mapping that cannot be represented by a
safe affine GX point lookup. Nonzero TEX1 K does not reject a point sprite when
MXL is zero; actual mip/filter states remain excluded.

A 64 KiB immutable-image ring and 256-entry lookup table are additional to the
previous source allocation. Live image bytes are not overwritten until a bounded
GPU consumer fence completes at wrap. This avoids a framebuffer readback for
each source change; it does not guarantee absence of other ownership resolves.
Keys include retained texel/CLUT revisions, mapped footprint, source layout,
TEXA, TFX and provoking color. Hash collisions never authorize reuse.

Source-copy-equivalent blending and exact FIX=128 additive blending are admitted.
With depth writes masked, AFAIL framebuffer-only writes the framebuffer on both
alpha-test outcomes. Exact alpha remains CPU ownership metadata because EFB
RGB8 lacks the GS eight-bit alpha plane. For varying alpha the driver copies
canonical source alpha taps into that metadata, without CPU RGB shading. This
is explicitly still a hybrid pipeline. General destination-alpha/depth tests,
PABE and other blend equations are not silently bypassed.

The canonical triangle edge solver additionally supplies analytic row spans;
this is coverage planning, not a new general native triangle renderer.

## Validation

Host ASan/UBSan checks cover ownership, retained page decoding, cropped decoding
in thirteen formats, 4096 fractional/clipped/winding/degenerate triangles
(4194304 edge checks), and 1024 sprite coordinate cases compared with the real
software rasterizer (29450 pixels). Leak scanning is disabled under ptrace.

The actual-GX Dolphin/OpenGL probe compares complete independent 4 MiB VRAM
allocations. The extended suite has 579 checkpoints, including the prior 474,
104 STQ format/state combinations, and a 638-draw ring lifetime stress case.
The ring stress requires both reuse and wrap fences, and preserves results while
multiple differently shaded sources remain pending. High raw texture coordinates,
fractional/reversed geometry, source-copy/additive draws and variable source
alpha are covered. See the adjacent machine-readable result for the final ELF
identity. These are synthetic correctness checks, not physical Wii performance.

An intermediate pre-variable-alpha game build completed a 180-host-second local
startup/progression capture with zero failed allocations. Its counters reached
368640 attempts, 65850 native operations (65839 texture uploads and 11 fills),
and zero native triangles. That is actual texture use, but also substantial
software fallback. Concurrent local probes and different guest progress make
this unsuitable for an FPS/speedup comparison. Its SDK progress was second 270;
it did not validate title-to-hub or physical Wii gameplay.

A subsequent variable-alpha game test exposed a padded-envelope bug: the alpha
metadata validator read coordinates for empty 4-pixel padding and stopped the
runtime. Validation now skips uncovered rows/columns. The real-GX regression
suite explicitly uses clipped, non-four-aligned coverage. The failed build is
not an accepted game result and has not been supplied as an owner update.

After that correction, another 180-host-second local game run stayed active
until the requested debugger interrupt, reached SDK second 255 and reported zero
failed allocations. Counters reached 344064 attempts, 118267 native operations
(118256 uploads and 11 fills), zero upload reuses and zero native triangles.
This validates that the startup abort was removed within the tested interval;
it does not establish full-scene correctness or a speedup. In particular, the
zero real-game reuse count means synthetic ring reuse is not evidence of lower
upload cost for this scene.

## Remaining release gates

- General STQ triangles, Gouraud modulation, filtering and multi-page source
  epochs must reach the GPU with explicit precision/cache contracts.
- Native depth writes/tests and the remaining framebuffer/blend/alpha states
  need compatible ownership, import and alias handling.
- Full-screen copies and scanout/presentation still need native paths.
- Complete scene captures with end markers are required. Existing private intro
  and hub streams have truncated tails; prefix state analysis is not acceptance.
- Measure matched scene progress and CPU/GX upload, seed, fence and readback
  costs. Native draw count is neither GPU workload percentage nor speedup.
- Preserve bounded allocation budgets, MEM1 FIFO, EXI DMA correctness, rollback,
  and gameplay/input behavior before supplying a new owner DOL.

The subsequent restricted projective/multi-page baseline and expanded FST
routing are documented in `GX-PROJECTIVE-PROGRESS.md`. The original counters
above describe the STQ checkpoint, not a current speed or coverage guarantee.
