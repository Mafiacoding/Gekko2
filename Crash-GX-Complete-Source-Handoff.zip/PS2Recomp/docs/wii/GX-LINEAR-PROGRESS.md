# Connected GX texture pipeline

The opt-in Wii build connects filtered STQ textured triangles to native GX RGB
rendering with projective bilinear filtering, Gouraud colour and all four GS
texture functions. This is a hybrid renderer with canonical software fallback,
not complete GX coverage or a verified Wii speedup.

CPU row scratch computes exact alpha/depth permissions and maintains the
swizzled GS depth shadow. GX draws only accepted RGB runs. PABE, FBA, alpha
failure, coverage holes and four depth formats preserve canonical semantics.
`MetadataOnly` operations preserve existing pending GPU RGB ownership without
counting CPU depth writes as GPU draws. Ordinary source-alpha/FIX blending is
admitted only for coefficients at most 128; FIX=128 additive is supported.
Unsupported equations, DATE, partial RGB masks, fog, shapes/layouts and unsafe
aliases retain the software fallback. Depth testing itself is still on CPU.

The bridge protects every previously seeded tile from CPU/source/depth aliases,
including untouched padding. Source buffers remain immutable through GX fences.
Raw decoded images are reused across vertex colours and texture functions;
uniformity/maximum alpha are cached per source. Coherent snapshots directly
read backing VRAM after the existing coherence proof, avoiding temporary 8 KiB
page copies while preserving the guest texture latch. Final guest sampling
includes SCANMSK-rejected rows, matching sample-before-WritePixel semantics.
No second VRAM mirror or full-screen CPU RGB/action buffer is introduced.

The submit, row, depth-permission and GX command functions are checked in MEM1.
Startup-only `NuPs2Init*` functions move to MEM2 to preserve at least 4 MiB initial
MEM1 arena space. FIFO placement and SDK SRAM/EXI DMA address checks remain active.

## Validation

- Nine ASan/UBSan host suites pass, including 8,192 permission rows / 131,072
  actual oracle raster pixels, retained depth-texture semantics, and 128 geometry
  cases / 13,296 covered pixels at viewport corners. A separate check compares
  final retained texture pages for every scan mask against real software draws.
- All 636 strict full-VRAM GPU regression checkpoints pass. This older point
  contract remains byte-exact and is not weakened for the new shader.
- The connected probe passes 134 cases: 130 admitted cases, including 640-pixel
  targets and pending RGB across depth-only work, plus four exact negative
  fallback cases for depth aliasing, texture feedback, overbright coefficients
  and partial RGB masks. Maximum observed RGB error is 5/255; alpha, depth,
  source and other VRAM remain exact. Bounded RGB is not pixel equivalence.
- Separate private replays of two real background draws and two visible real
  textured draws match the oracle within one RGB level, with structural VRAM
  exact. Game-derived captures stay outside the repository.
- A local 90-host-second Dolphin run with the release configuration shows the
  laboratory scene and counts 30,113 native textured triangles. Allocation
  diagnostics report zero failed bytes. Counts and host duration are not Wii
  FPS, a matched performance comparison, or proof of complete gameplay.

## Remaining limitations

The experimental untextured shader is disabled in the Wii game configuration.
Enabling it caused a dark-gradient display regression during real progression,
despite isolated draw comparisons passing. Its interaction with scene-wide
presentation/aliasing remains unresolved. Untextured triangles retain the
canonical renderer; the synthetic connected probe enables them only for
component tests. Unsupported textured states also fall back.

Direct GX presentation, native copies, hardware Z, broader render-state coverage
and measured Wii performance remain open. This build does not establish full
graphics correctness or a fully native game port. Replace only the existing
`SD:/ps2recomp/crash-runtime.dol`; retain the separate small HBC launcher and
owner-supplied game files.
