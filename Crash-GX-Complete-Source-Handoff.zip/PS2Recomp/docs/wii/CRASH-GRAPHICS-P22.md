# Crash graphics follow-up (runtime d529d89)

## Image provenance

`reference-fast/frames/frame-040.png` was captured from PCSX2 running the
owner-supplied Crash E3 disc on the PC. It is a reference image, not Wii output.
The Wii test uses the compiled PPC DOL in local PAL Dolphin and captures the
actual YUYV XFBs. Raw 640x576 XFB pixel aspect is not square when the Wii is
configured for widescreen; raw capture proportions must not be compared to a
square-pixel PCSX2 screenshot without applying that display aspect.

## Corrections after the reproduced memory failure

- CT16/CT16S framebuffer clears retain source alpha bit 7, rather than using
  alpha >=64. FBA still forces that bit.
- FRAME.FBMSK uses RGBA8888 bit positions. The clear path now translates its
  stored RGB/alpha bits to RGB5A1 before merging with the existing surface.
- Sprites preserve 12.4 XYOFFSET and endpoint precision. Integer-grid samples
  include left/top and exclude right/bottom; zero-area or unsampled rectangles
  do not invent a pixel. Fractional endpoints also remain in the texture
  interpolation, without adding an unrelated half-pixel step.

The 16-bit test failed on its predecessor, then passed across both formats,
six alpha boundaries, FBA on/off, all 32 single-bit masks and no mask.
The sprite coverage test failed on its predecessor, then passed 200 rectangle
cases/5,000 pixel checks including reversed endpoints, fractional offsets,
subpixel spans and zero area. A separate texture-gradient case checks UV at the
first and second covered integer samples. Existing palette tests had used
zero-area sprites as implicit points; they now use genuine 1x1 rectangles,
retaining their expected palette colors and addressing checks.

The decoded title/hub traces inspected here contain no explicit HLE clear
records, so the clear correction is a general correctness fix, not evidence
that it caused the owner photographs. The reproduced allocation failure is
the established cause of the dark-lab progression block. The inspected hub
trace has 409,430 PRIM writes with AA1 disabled; this does not prove every
instruction, scene or unrecorded draw is supported.

## Verification limits

All 83 GS and 42 VU tests pass. Final-scene and PAL capture results are recorded
in the adjacent JSON report after their completion. Static DOL layout and
linked SDK EXI DMA placement are checked separately.

No full frame-synchronous PCSX2 differential match or physical-Wii image match
has been established. Mipmap/LOD, AA1 and precise attribute/filter arithmetic
are not certified by this test set. Audio/video decoding and universal game
compatibility are outside this correction. Do not label this build completely
graphics-error-free or infer physical FPS from unlimited-speed Dolphin.

The old P20 archive's Defender detection remains unresolved. The official
ClamAV signature endpoint was blocked by the environment network policy (HTTP
403), so no local antivirus clearance is claimed. The user-requested DOL is a
new source-built Wii test artifact, not a repack of the flagged archive or a
means of bypassing Windows protection. It must remain private with the owner's
game-derived code. Do not disable Defender or restore blocked files.
