# GS state-family diagnostics

`PS2X_WII_GX_PROFILE_FAMILIES` is off by default. It samples triangle attempts at one in 64 driver attempts, without file I/O per sample. Selection is periodic rather than random; distributions are diagnostic and may be biased. Counts are not pixel counts, CPU utilization or GPU load.

`PS2WiiGXStateFamilies[64]` is read by the private local observer:

| Slots | Meaning |
| --- | --- |
| 0–3 | Sampled triangles by ZTST |
| 4–7 | By ZTST, with alpha disabled/ALWAYS, DATE disabled and SCANMSK zero |
| 8–11 | By ZTST, with depth writes masked |
| 12–15 | Intersection of the previous two conditions |
| 16–19 | Dependent alpha test, DATE, PABE+ABE, framebuffer mask |
| 20–23 | Fog, AA, color clamping disabled, unsupported framebuffer format |
| 24–26 | Blending, texturing, depth writes masked |
| 27–30 | Constant vertex Z, constant vertex alpha, CT24 target, nonzero SCANMSK |
| 31 | Total sampled triangles |
| 32–36 | Z32, Z24, Z16, Z16S, other depth format |
| 40–43 | Minimum/maximum sampled valid vertex Z, bitwise OR/AND of those Z values |

The optional fragment callback scope uses producer phase 15 to separate native CPU fragment permissions from the rest of native preparation (phase 13). These sampled wall-time occupancies overlap the UI observer and must not be added to UI percentages.

In the measured initial Crash sequence, sampled triangles predominantly use Z24, GEQUAL and depth writes. Vertex Z values observed through 60 host seconds span `0x0` to `0x54d28`. The first unconditional whole-triangle family therefore has no startup uses. This establishes a concrete next target; it does not describe unmeasured title/gameplay states.

A separate 30–90 second diagnostic run attributed approximately 35.3% of producer samples to VU execution, 23.5% to other native GS preparation/submission, 20.7% to software GS, and 8.3% to native fragment permissions. These are phase observations in local Dolphin, not physical Wii timings.
