# Experimental VU instruction AOT

This opt-in path compiles selected VU instruction words into native functions.
It is CPU code (PowerPC on Wii), not GX execution. The instruction path retains
the cycle/hazard scheduler. Experimental program blocks are described below.
The reference interpreter remains the
oracle and the fallback for words absent from the private registry.

`tools/vu/generate_aot.py PROFILE.json --output PRIVATE_DIRECTORY` accepts unsigned
32-bit `upper` and `lower` word arrays. It specializes the production upper/lower
semantics with constant instruction fields. A state-free operand-normalization
helper is copied from the production definition so the compiler can remove
unused operand preparation. It preserves float rules and does not enable fast
math or introduce multiply-add contraction. No game-specific words are checked
into the repository. Source hashes in the generated manifest are checked by a
build guard; regenerate after changing the reference semantics.

Set `PS2X_VU_AOT_DIR` to that private output directory in the Wii or headless
CMake configuration. The default empty path retains reference execution. The
registry is resolved at decode, behind existing VU0/VU1 microcode-generation,
source-pointer and code-size checks. Unknown words select the reference call;
new code cannot reuse an old native handler after tracked invalidation. Untracked
code is decoded afresh. Immediate lower words are not dispatched as instructions.

The issue loop still owns dual-issue shadowing, suppressed writes, delayed
register/flag writes, branches, budget interruption, E/D/T bits and GIF/XGKICK
ordering. Diagnostic native/fallback counts are separate from architectural VU
state. `setAotEnabled(false)` runs the current reference semantics in the same
binary for paired tests. Counters are cumulative over execute/resume/reset and
are collected only when AOT is compiled in.

## Validation

Run `tests/vu_speed/test_aot_generator.py` and the existing VU cache-extent test.
Link `aot_compare.cpp` against the production runtime and generated registry to
replay private snapshots. It compares full VU state, VU data and all GS VRAM with
the current interpreter, alternating reference/native order. Historical snapshot
outputs are deliberately not used as the oracle. Timing is execution-only host
time and includes cache preparation; it is not physical Wii FPS.

`aot_cache.cpp` additionally exercises both units, execute/resume, tracked
microcode replacement, repeated cache reuse, and untracked code. Its synthetic
profile must contain upper words `0x41e208e8`, `0x2ff` and lower words
`0x10010001`, `0x8000033c`; the test selects an absent IADDIU word dynamically to
prove a real fallback after generation invalidation. Run existing production VU unit tests as
well. A successful snapshot replay establishes only captured-program coverage,
not zero fallback for every scene or game.

A speedup must be measured against equal work and matching outputs. Native
instruction calls still have dispatch/call overhead and share precision and
pipeline helpers. Removing the complete interpreter requires further block
translation and coverage of dynamically uploaded programs; this implementation
must not be presented as that completed milestone.

## Internal validation checkpoint

The private Crash registry has 293 upper and 486 lower words, including a small
synthetic cache fixture. Replaying 128 captured VU inputs executes 146,352 upper
and 146,352 lower halves natively, with zero fallback and exact current-reference
VU state/data and complete GS VRAM. Eight VU0/VU1 cache/resume cases and all 43
existing VU unit tests pass. The PPC upper check compares 293 handlers over eight
float patterns (2,344 cases) with exact object bytes. This does not cover every
possible input or establish complete-game coverage.

Across nine paired local host replays, the median reference/native execution-time
ratio is 1.084 (individual ratios 1.045–1.133). The initial eager implementation
was slower; resolving native mappings only when a pair is fetched avoids looking
up unused microcode after every upload. These measurements concern the captured
VU work, not the two-hour transition, whole-game speed or physical Wii FPS.

The Wii build passes layout checks with every generated upper/lower instruction
handler in MEM1. AOT builds place additional generated initialization units in
MEM2 to preserve the existing minimum 4 MiB MEM1 headroom assertion. This also
reduces MEM2 heap headroom; static validation does not establish peak-memory
safety for the complete menu-to-game transition. A 60-host-second Dolphin run
reaches the visible lab with native GX submission active. It is only a startup
check, not a title-to-game acceptance test. No new owner DOL is published.

For PPC checks, compile `tests/vu_speed/ppc_manifest.cpp` with the same headers
and toolchain as the tested ELF, extract `.rodata.vu_manifest` with objcopy, and
pass that binary, the ELF and the private word profile to `verify_aot_ppc.py`.
The script requires Unicorn and prints only aggregate results; detailed output
can contain private instruction words and must remain private.

## Program blocks and additional experiments

The optional profile `programs` array accepts `{unit: 1, words: [...]}` entries
with complete 16-KiB VU1 microcode images (4,096 guest little-endian words).
`tools/vu/aot_blocks.py` obtains operand/dependency metadata from the production
decoder and specializes the paired issue loop in bounded eight-pair blocks.
Selection requires an exact complete-image match. Generation invalidation,
unexpected control flow, active XGKICK and cycle budgets retain their fences.
Identical eight-pair chunks across uploaded images share a block only when
their starting PC also matches. Each complete image retains its own exact-match
guard and block table; equal words at different PCs remain separate blocks.
The block emitter uses direct calls to shared per-word semantic bodies rather
than inlining each body into every instruction pair. This bounds duplication
when different lower words accompany the same upper word. The pair's issue and
dependency checks remain specialized; this tradeoff must be benchmarked with
the actual linked PowerPC build and its MEM1 headroom checks.
When a block profile is present, instruction-registry wrappers also call these
shared bodies, allowing the linker to coalesce copies across translation units.
`PS2X_WII_VU_COMPACT_BLOCKS` defaults on and applies `-Os` to the block translation
unit after the optional hot-source `-O2` setting. The four-MiB MEM1 heap guard
remains mandatory; a profile that exceeds it must not be released.
An optional `blocks` array on each program lists 64-byte-aligned VU PCs to emit.
Omitted slots retain native single-instruction execution through the normal
issue loop. This supports selecting measured hot blocks within the code budget
without omitting guest work. Program selection first checks distinguishing words
to reject unrelated uploads cheaply, then still compares the complete image.
Readiness/write helper hashes reject unaudited scheduler changes. This is not
coverage of every dynamically uploaded program. `PS2X_VU_BLOCKS=OFF` disables
block execution while retaining the linked module for diagnosis.

Additional options default off: `PS2X_VU_PACKET_REUSE` preserves overwritten
XGKICK scratch storage; `PS2X_WII_VU_FAST_CACHE` prefers MEM1 for decoded pairs
with MEM2 allocation fallback; `PS2X_VU_NORMAL_FLAGS_FASTPATH` avoids wider exact
flag calculations for provably interior normal results. Product-sum classification
uses the same production formula in binary64 and retains the original calculation
at normal-range endpoints, zero and exceptional boundaries.
No fast-math flag is enabled. The Wii-only `PS2X_VU_AOT_REFERENCE_ONLY` diagnostic
retains linked AOT code but initializes execution in reference mode.

`PS2X_VU_LAZY_DECODE` validates fetched pairs after code-generation changes rather
than decoding all 2,048 possible pairs on every upload. Unchanged words retain
metadata and handlers; new entries, changed halves, resize, unit/source identity
and unmatched native programs retain their checks. `PS2X_VU_ACTIVE_PIPELINES`
iterates occupied queue slots and first free slots in the original ascending
order, preserving delayed visibility and latest-write arbitration. Occupancy
fields fit existing padding on the tested host/PPC ABIs; they do not change the
architectural VU state. `PS2X_VU_XGKICK_SPANS` removes per-byte modulo from qword
copies without advancing transfer timing. Small data regions, wrap, aliases and
uint32 overflow retain byte-wise semantics.

Private profiles may independently opt into `specialize_flags: true` (shared
opcode-specialized production FMAC helpers) and `predecode_usage: true` (VU0/VU1
operand metadata obtained by compiling the production decoder on the build host).
`inline_flag_helpers: true` additionally exposes the specialized FMAC helper
chain to the compiler; it applies when `specialize_flags` is enabled and retains
the same arithmetic, exceptional cases and flag timing.
Enable `PS2X_VU_AOT_USAGE` to consume that metadata. Missing metadata still uses
the decoder; missing semantics still use reference instruction execution.
`aot_usage.cpp` compares all generated dependency fields with production decoding
for both units. Its catalog is private and must not be committed.

`PS2X_VU_KEEP_RETIRED_PAYLOAD` is another default-off experiment. A retired queue
slot clears its valid bit while retaining inaccessible payload bytes until
allocation initializes the next entry. Every consumer checks validity; scheduler
reset still clears all slots. Raw private scheduler storage is therefore no
longer a canonical zero image. Architectural state, pending visibility and
complete-state reference comparisons retain their requirements.

The PPC verifier defaults to FPSCR RN=1 (toward zero), matching the VU run loop.
Use `--rounding 0` for an additional nearest-rounding comparison. Instruction
counts from this synthetic corpus are not whole-game speed measurements.

Current internal checks: the normal-result flag option and active-queue/span
experiments match an independently compiled pre-change reference over 63,488
complete-state cases. All 43 VU tests,
eight cache/resume cases and both-unit changed/repeated/truncated MPG tests pass.
A private title-to-hub host run captured 14 program images. Its expanded
instruction registry has 559 upper / 944 lower handlers, and a subsequent
240-second host run observed 807,805,316 native upper and 807,103,339 native lower
executions with zero fallback. Required title/hub loads, delivered input and
post-load frames pass; this does not establish real Wii speed or all-level
coverage. Isolated PPC comparisons cover 4,472 upper and 7,552 lower cases.

**Release remains blocked by whole-game speed acceptance.** Dark early Wii frames
also occur with native instruction execution disabled. Executable sections and
constant data matched the ELF in local checks. Packet inspection subsequently
identified a guest-requested full-screen subtractive fade (Cs=249, As=128), so
darkness alone was premature evidence of a graphics regression. Compare equal
guest progress, not screenshots at equal host seconds. The host still reaches
the visible title and hub. Component host speedups do not establish adequate
Dolphin or physical Wii gameplay; the previous owner DOL remains unchanged.

## Measured limits of the current private candidate

The expanded private registry covers 559 upper and 944 lower words, with selected
shared blocks for fourteen complete VU images. Recent independent checks compare
63,488 states and 128 captured inputs against the frozen reference; all 43 VU
unit tests and eight cache/resume cases pass. A separate 240-second host scene
probe reaches title and hub loads with delivered input and subsequent nonblack
GS frames. These are semantic/milestone checks, not a Dolphin speed result.

Short matched local Dolphin runs still show no meaningful whole-game gain from
several additional flag/cache optimizations, despite faster host VU replay.
A tested exponent-only product-flag shortcut was discarded after it failed to
improve actual game progress. It is not part of the runtime. The captured startup
work already has zero VU instruction fallback; that does not establish complete
game coverage or remove the remaining GS/software and synchronization costs.
No adequate Dolphin gameplay speed or physical Wii FPS is established.
