# VU operand experiment, 2026-10-26

Status: implemented behind `PS2X_VU_OPERAND_FASTPATH`, OFF by default. No new
owner test DOL is provided. Preserve the P23 in-game baseline.

The original upper executor normalizes fourteen inputs before opcode dispatch,
including inputs not read by the selected opcode. Two existing NOP encodings
now return after recording the instruction. ADD/MUL/MAX/SUB/MINI still normalize
the same source vectors and use the original arithmetic/flag/write machinery,
but omit unused ACC, Q and I normalization. Other opcodes retain the original
path. No cycle budget, interrupt, pipeline write or XGKICK is skipped.

A decoded-cache reference experiment was rejected: paired synthetic runs were
about 1–3% slower. That source change was removed.

## Verification

- Existing VU/VIF regressions: 43/43 pass with candidate enabled.
- Synthetic completed-state corpus: 14,336 cases, both units, seven opcodes,
  sixteen masks, four aliases and sixteen float patterns (including exceptional
  operands). All 9,519,104 state bytes match baseline.
- Same compiler options and placement for actual PPC code (`-Os -G0`, CPU 750,
  hard float), isolated Unicorn instances: NOP 335 to 31 executed instructions;
  tested full-mask ADD 1,535 to 1,458. Complete interpreter object hashes match
  for these three probes. This is instruction counting, not Wii cache/cycle or
  hardware speed measurement. Do not reuse translated code at the same address
  in a single Unicorn instance without invalidating its translation cache.
- Seven interleaved host trials, five million cycles per synthetic workload,
  completed state/data hashes equal. Median paired ratios: VU1 NOP 1.216,
  ADD 1.048, ADD/MUL 1.035, VU0 NOP 1.209, untracked NOP 1.221. These are
  microbenchmarks, not a predicted whole-game gain.
- 128 private saved Crash VU inputs replayed through baseline/candidate with
  equal budgets. Complete resulting state, VU data and GS VRAM match across
  539,053,056 bytes, SHA-256
  `f5c04756f7909c8de1f3b655939b0a727355698ba782e5471b08267b082d713f`.
  Captures come from an earlier runtime: equality is between the two current
  implementations, not a claim that an old capture is a full-game oracle.
  These isolated calls do not reproduce the entire game's GS/IOP context.
  Nine alternating-order replay trials measured a median paired ratio of
  1.064 (baseline median 0.036455 s, candidate 0.034261 s for the 128 calls).
  This short host replay is useful corroboration, not an in-game or Wii result.

Remaining gates: matched full-scene work, emitted packet/frame comparison,
current hub workload profiling, physical Wii measurements. No full-game speedup,
absence of graphics defects, or native GS acceleration has been demonstrated
by this experiment.
