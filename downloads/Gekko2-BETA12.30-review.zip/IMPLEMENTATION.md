# C01: GS-Registerzugriffe und pending IMR

Vorher: EE LB/LH/LW/SB/SH/SW erreichten GS-CSR/IMR/SIGLBLID nicht; nur
LD/SD wurden geroutet. Ein SW zum Quittieren ließ CSR.SIGNAL unverändert.
Der neue Test scheiterte vor dem Patch bereits am tatsächlichen LW-Leseweg
(`ee_mem_read32(...) & 1`). Alle 8/16/32-Bit-Lanes erreichen nun denselben
GS-Zustand. RAM-Lesefastpfade und bestehende Watchhooks bleiben erhalten.
CSR-Schreibzugriffe werden als W1C-Aktion behandelt, nicht mit gelesenen
unbeteiligten Ereignissen zusammengeführt. IMR-1->0-Maskenübergänge liefern
für bereits gesetzte CSR-Ereignisse einen GS-Interrupt; identische Werte
lösen keinen zusätzlichen Interrupt aus. IMR-Schreibwerte maskieren reservierte
Bits und setzen die feststehenden Bits13/14 entsprechend der Referenz.

Referenz: PCSX2 `091ab68708a555198d80a7216965481c7ddd0d98`,
`pcsx2/GS.cpp`, IMRwrite und gsWrite8/16/32/64_page_01. Eigenständige
lane-basierte C-Implementierung, kein importierter GS-Backend.

Gezielte Tests: neue EE-Alias-/Zugriffsbreiten-/W1C-/SIGLBLID-Regression,
32768 Kombinationen aus CSR-Events und alter/neuer IMR-Maske sowie echte
SB/SH/SW/SD-Instruktionen. Bisherige SIGNAL-PATH1/2/3-/DMA-/XGKICK-
Backpressure- und GS-SIGNAL-Tests bestehen weiterhin. Die zweite SIGNAL-
Nachricht bleibt am Producer, bis der Gast CSR wirklich quittiert.

Dies sind reproduzierte Corefehler, kein Nachweis, dass die konkrete Crash-E3-
Sitzung genau diese Zugriffe benutzt oder dass deren Blackscreen behoben ist.
Vollständiges GS-Reset-/CSR-Readback-/Bus-Timing bleibt getrennt zu bearbeiten.


Privater BETA12.24-Logabgleich: die Sitzung mit Crash-Datei-I/O-Merkmalen
enthält einen nicht wieder aufgenommenen SIGNAL-Wartepfad; in der vorhandenen
Tracehistorie erscheint keine CSR-ACK-Transition. Der Ring meldet jedoch
verlorene Ereignisse. Das Fehlen einer ACK-Zeile beweist daher weder den
konkreten Schreibopcode noch die alleinige Ursache. Die andere Sitzung zeigt
keinen SIGNAL-Wartepfad; ihre Grafikfehler werden nicht mit diesem Interruptfix
erklärt. Rohlogs, Register-/Instruktionswerte und private Pfade bleiben außerhalb
von Git, PRs und Paketen. Der öffentliche Test verwendet ausschließlich eigene
synthetische Pakete und EE-Instruktionen.


# C02: GS Q/K/L, Mipmap-Filter und MTBA

Bisher wählte Gekko2 ein einziges Mip aus dem Verhältnis Texturgröße zur
geclippten Bildschirm-Boundingbox. Dadurch konnte bereits ein SCISSOR-Wechsel
eine andere Textur auswählen. L wurde ignoriert; Mip-Texelkoordinaten und
Wrap-/Clamp-Dimensionen blieben auf Basisebene. MTBA hatte keinen Adresspfad.

Jetzt berechnet der Softwarepfad LOD aus K/16 und, bei STQ/LCM=0,
`-log2(abs(Q)) * (1<<L)`. Dreiecke benutzen interpoliertes Q je Fragment,
Sprites das Q der zweiten Ecke. UV verwendet konstantes K. Die sechs gültigen
MMIN-Modi wählen nearest/bilinear und gerundetes Mip/trilinear, MMAG greift
bei Vergrößerung. MXL ist auf die sechs vorhandenen Mipregister begrenzt.
Koordinaten, TW/TH und Region-/Repeat-/Clamp-Grenzen werden auf Mipebene skaliert,
kanonische Register nach jedem Sample wiederhergestellt.

TEX0-Schreibzugriffe erzeugen bei gültigem MTBA-Kontext die ersten drei
Mip-Adressen aus quadratischer TW-Fläche und physischer Formattiefe. TH/TBW
und MXL beeinflussen diese Autoadressen nicht. Mindestabstand ein Block,
TBP-14-Bit-Wrap, beide Kontexte und ausbleibender TEX2-Trigger werden geprüft.
MIPTBP2 bleibt explizit; MTBA wird nicht als sechs automatisch erzeugte Mips ausgegeben.

Die vorhandenen GX- und Texelcache-Envelopes decken bisher nur die Basisebene
ab. Mipmapped Draws benutzen deshalb den gemeinsamen korrekten Softwarepfad;
alle bestehenden Nicht-Mipmap-GX-Optimierungen bleiben verfügbar. Keine
unvollständige GPU-Texturcache-Zulassung nur zum Erzwingen von GX.

Verhaltensreferenzen: gepinnte PCSX2-GSState.cpp GIFRegHandlerTEX0/GetTex0Layer,
GSRendererSW.cpp und GSDrawScanline.cpp im bestehenden Referenzbaum bzw.
`091ab68708a555198d80a7216965481c7ddd0d98`. Eigenständiges C-Sampling;
kein PCSX2-Rasterizer importiert. Exakte GS-Logarithmus-/Float-Bitpräzision,
AA1 und vollständige GPU-Mipmapgleichheit bleiben offen.

Gezielt erfolgreich: neuer Test mit **11.701 unabhängigen Layout-/Farb-/Zustands-
und Rasterfällen**, darunter alle sechs Filter, negative Koordinaten,
trilineare Zwischenwerte, Q als Zweierpotenzen, beide MTBA-Kontexte,
TEX2/Adressenwrap und wirklich unterschiedlich ausgewählte Mips im selben
Dreieck. Scissor ändert die Q-Werte unveränderter Pixel nicht.
Bisherige Sprite-/Dreieck-/Kontext-Mip- und UV-Bilineartests bestehen ebenfalls.
Alte Solid-Color-Fixtures enthielten absichtlich die bisherige Bildschirmgrößen-
Heuristik; sie setzen nun explizites konstantes K für ihren UV-Zweck.
Die neue variable-Q-Oracle ersetzt diese Heuristikannahme, keine Assertion wird entfernt.

Kein Nachweis korrigierter BIOS-/Tekken-Kacheln oder Crash-Spielbarkeit auf Wii.


# C02b: Native GX-Filterzulassung

Die native Texturkonfiguration transportiert bisher genau einen Filterwert.
Sie kann gemischte GS-Min/Mag-Modi und per-Fragment-Mip-Auswahl nicht einfach
wie gemeinsame nearest/nearest oder linear/linear behandeln. Solche Draws
werden nun ausdrücklich aus den entsprechenden nativen Texturpfaden abgelehnt;
Software-/Source-Shading bleiben verfügbar. Source-Shading verwendet ebenfalls
das interpolierte Q zur Filterauswahl statt des zuletzt geschriebenen RGBAQ.Q.

Die Zulassungsregression prüft alle zwölf Min/Mag-Kombinationen (sechs gültige
MMIN und beide MMAG); die beiden vorhandenen gleichmäßigen Basisfilter bleiben
nativ zugelassen. Bisherige common-GIF-Zulassung, 19584 Shading-Pixel und
11701 Q/LOD-/MTBA-Fälle bestehen. Keine Behauptung vollständiger GPU-Mipmaps.


# C05a: CPU-SQ auf VIF0/1 und Backpressure

Der CPU-128-Bit-Schreibpfad verwendete direkte void-VIF-Parseraufrufe statt
`vif_accept_quadwords`. Bei I-bit-Stall konnte SQ über die begrenzte
Annahmekapazität hinaus retired werden; der große Parser-Restpuffer war kein
korrekter Ersatz für Producer-Backpressure. Der neue Test scheiterte vor dem
Patch an verändertem PC/Delay-/Retirementzustand des noch nicht angenommenen SQ.

CPU und DMA verwenden nun dieselbe begrenzte qword-Annahme. Vor JIT/AOT/
Interpreterausführung prüft SQ die Annahmefähigkeit. Bei vollem Puffer bleiben
PC, next_pc, Delay-Slot und 128-Bit-Quelle erhalten, während die bestehende
Parktick-Gerätezeit weiterläuft. Kein IRQ-/VIF-Stall wird künstlich gelöscht.
STC ist weiterhin die echte Gastaktion, die einen I-bit-Stall aufheben kann.

Test mit realem I-bit-MARK für VIF0 und VIF1, gefüllter Queue, 200 Wiederholungen,
unveränderten Nutzdaten und genau einmaliger Wiederaufnahme nach FBRST.STC.
Die bestehenden IPU-/GIF-Stall- und VIF-DMA-/Interlocktests bleiben Regressionen.

VIF0 nimmt höchstens acht, VIF1 sechzehn qwords an; die Kapazitäten werden
auch im DMA-Pfad eingehalten und STAT.FQC zeigt die akzeptierte Warteschlange.
Referenz: vendored PCSX2 Vif0_Dma.cpp und Vif1_Dma.cpp (FQC-Grenzen 8/16).
Buslatenzen und vollständige Pipeline-/DMA-Sonderfälle bleiben in C05/C06 offen.
Kein direkter Beleg für einen behobenen Crash-/Tekken-Spielablauf auf Wii.


# C09a: Writable ENVX

ENVX-Schreibzugriffe wurden zuvor nur im Registerarray gespeichert. Der Mixer
verwendete weiter seinen alten ADSR-Pegel und überschrieb ENVX beim nächsten
Sample. Nun übernimmt der interne Pegel den vollständigen 16-Bit-Registerwert,
ohne Phase/Zähler zurückzusetzen und ohne eine gestoppte Stimme zu starten.
Referenz: PCSX2 spu2sys.cpp Voice Params, `ADSR.Value = value`,
`091ab68708a555198d80a7216965481c7ddd0d98`.

Große manuelle ENVX-Werte können Post-ADSR-OutX über signed16 hinausheben.
PMON behandelt diese Faktoren ohne unsigned Overflow und mit korrekter
0..3fff-Sättigung. Eine frühe Sättigung hält die restlichen Produkte in 32 Bit.
Das bestehende Checkpointlayout bleibt unverändert; Validatoren akzeptieren
nun auch die gültigen manuell geschriebenen Pegel bis ffffh.

Erfolgreich: 8230 synthetische Fälle über alle 48 Stimmen, unveränderte
Phase/Zähler, Checkpointroundtrips, tatsächliche Capture-Gainwerte und ein
unabhängiges signed64-PMON-Orakel. Bisherige 4196428 Noise/PMON/Sweep-/SPUS-
Checks, Mixer- und Systemcheckpointtests bleiben grün.
Gaussian, Reverb, genauer Key-On und Silent-Voice-/Bus-Timing bleiben offen.
