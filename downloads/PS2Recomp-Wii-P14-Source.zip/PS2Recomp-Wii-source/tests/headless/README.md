# Private full-runtime GS regression runner

This x86-64/SSE4.1 test adapter runs the actual generated guest functions,
EE kernel, IOP, VU/VIF/GIF and software GS runtime. It replaces only the host
window/input/audio interface. It does not emulate Broadway, libogc, IOS or Wii
performance. No game data is bundled or downloaded.

Supply your private generated sources and an extracted owner disc directory:

```sh
cmake -G Ninja -S tests/headless -B /tmp/ps2-headless \
  -DPS2X_GENERATED_DIR=/private/recompiled \
  -DPS2X_EE_NATIVE_FLOAT_CONVERT=OFF
cmake --build /tmp/ps2-headless -j4
PS2_HEADLESS_SECONDS=60 PS2_HEADLESS_OUTPUT=/private/captures \
  /tmp/ps2-headless/crash_headless /private/disc/game.elf
```

The ELF directory is the initial CD root. Retain the extracted game assets
there. `PS2_HEADLESS_AUTO_START=1` enables synthetic Cross/Start pulses for
repeatable menu testing. It is optional and defaults off. Audio/MPEG remain
unavailable in this minimal test target.

Only valid GS presentation frames enter the capture hook; the no-frame
magenta diagnostic does not. PPM captures retain raw GS texel dimensions
(e.g. 640x224) before TV aspect scaling. The runner writes at most 32 images,
with captures spaced after initial samples. Logs include source revision,
valid/nonblack GS-frame counts and a host-only first-frame timestamp.

The guarded float-conversion option defaults OFF. Enable it only for a
library ABI validated against its original generated routines. The owner
Crash release enables it after a private differential check. Special inputs
and resumed/internal entries continue through the original guest code.

The test exercises the same consuming frame handoff used by the Wii adapter.
Host images are evidence of the emulated GS path, not Wii boot, FPS or
playability evidence. Keep images, generated source and game-containing
binaries private.
