P19 Quellcode und reproduzierbarer Host-Szenentest.
Keine Spieldaten, keine generierten Crash-Funktionen, keine neue Test-DOL.
Siehe docs/wii/POSTLOAD-VALIDATION.md und tests/headless/README.md.
Wii-Toolchain: aktuelles devkitPro/devkitPPC/libogc; getestet r50 / GCC 16.1.0 / libogc 3.1.0.
Keine behauptete Wii-Spielbarkeit, kein verifizierter Wii-FPS-Gewinn.
