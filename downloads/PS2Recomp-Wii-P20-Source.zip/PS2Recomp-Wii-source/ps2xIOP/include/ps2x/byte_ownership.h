#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
#include <algorithm>
namespace ps2x::iop::detail {
// Byte-granular ownership in 32-bit words. Bulk ranges inspect/fill full words
// rather than paying a proxy-bit operation for every guest byte.
class ByteOwnership {
 std::size_t bytes_;std::vector<uint32_t> words_;
 static uint32_t mask(unsigned first,unsigned end){return (UINT32_MAX<<first)&(end==32?UINT32_MAX:((uint32_t(1)<<end)-1));}
public:
 explicit ByteOwnership(std::size_t bytes):bytes_(bytes),words_(bytes/32+(bytes%32!=0)){}
 void reset(){std::fill(words_.begin(),words_.end(),0);}
 std::size_t storageBytes()const{return words_.size()*sizeof(uint32_t);}
 bool owns(std::size_t first,std::size_t size)const{
  if(first>bytes_||size>bytes_-first)return false;if(!size)return true;
  const auto last=first+size-1,lo=first/32,hi=last/32;
  const unsigned begin=first%32,end=last%32+1;
  if(lo==hi){auto m=mask(begin,end);return (words_[lo]&m)==m;}
  auto a=mask(begin,32),b=mask(0,end);
  return (words_[lo]&a)==a&&(words_[hi]&b)==b&&
   std::all_of(words_.begin()+lo+1,words_.begin()+hi,[](uint32_t w){return w==UINT32_MAX;});
 }
 void set(std::size_t first,std::size_t size,bool value){
  if(first>bytes_||size>bytes_-first||!size)return;
  const auto last=first+size-1,lo=first/32,hi=last/32;
  auto apply=[&](std::size_t i,uint32_t m){if(value)words_[i]|=m;else words_[i]&=~m;};
  if(lo==hi){apply(lo,mask(first%32,last%32+1));return;}
  apply(lo,mask(first%32,32));apply(hi,mask(0,last%32+1));
  std::fill(words_.begin()+lo+1,words_.begin()+hi,value?UINT32_MAX:0u);
 }
};
}
