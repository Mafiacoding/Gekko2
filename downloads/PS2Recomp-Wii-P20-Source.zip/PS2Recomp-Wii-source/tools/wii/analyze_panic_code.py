#!/usr/bin/env python3
"""Compare a transcribed panic RAM window against its exact linked Wii ELF.

This detects differing bytes, not the writer or cache-coherence root cause.
The caller must verify BUILD against the ELF's build report.
"""
import argparse
import json
import struct
from pathlib import Path


def elf_window(data, pc):
    if len(data) < 52 or data[:7] != b'\x7fELF\x01\x02\x01':
        raise ValueError('Expected ELF32 big-endian file')
    if struct.unpack_from('>H', data, 18)[0] != 20:
        raise ValueError('Expected PowerPC ELF')
    if pc < 4 or pc & 3 or pc > 0xfffffff7:
        raise ValueError('Invalid aligned PC window')
    ph = struct.unpack_from('>I', data, 28)[0]
    step, count = struct.unpack_from('>HH', data, 42)
    if step < 32 or ph + step * count > len(data):
        raise ValueError('Truncated program headers')
    for index in range(count):
        kind, offset, address, _, length, _, flags, _ = struct.unpack_from('>8I', data, ph + step * index)
        if kind == 1 and flags & 1 and address <= pc - 4 and pc + 8 <= address + length:
            start = offset + pc - 4 - address
            if offset + length > len(data):
                raise ValueError('Truncated executable segment')
            return list(struct.unpack_from('>3I', data, start))
    raise ValueError('PC window is not in file-backed executable code')


def analyze(data, pc, cached, ram, dar=None, gprs=None):
    if len(cached) != 3 or len(ram) != 3 or any(not 0 <= word <= 0xffffffff for word in cached + ram):
        raise ValueError('Each RAM view requires three unsigned words')
    expected = elf_window(data, pc)
    result = {
        'pc': f'{pc:08X}', 'elf_words': [f'{word:08X}' for word in expected],
        'cached_matches_elf': cached == expected, 'ram_matches_elf': ram == expected,
        'cached_matches_ram': cached == ram,
        'different_ram_addresses': [f'{pc - 4 + 4 * i:08X}' for i in range(3) if ram[i] != expected[i]],
        'writer_identified': False, 'physical_wii_reproduced_locally': False,
    }
    word = cached[1]
    # Decode only the D-form LFS involved in this report; do not guess other opcodes.
    if word >> 26 == 48:
        ra = (word >> 16) & 31
        displacement = (word & 0xffff) - (0x10000 if word & 0x8000 else 0)
        result['observed_instruction'] = f'lfs f{(word >> 21) & 31},{displacement}(r{ra})'
        if ra == 0 or gprs is not None and ra in gprs:
            address = ((0 if ra == 0 else gprs[ra]) + displacement) & 0xffffffff
            result.update(effective_address=f'{address:08X}', unaligned_word=bool(address & 3))
            if dar is not None:
                result['matches_dar'] = address == dar
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--elf', type=Path, required=True)
    parser.add_argument('--pc', type=lambda s: int(s, 16), required=True)
    parser.add_argument('--cached', nargs=3, type=lambda s: int(s, 16), required=True)
    parser.add_argument('--ram', nargs=3, type=lambda s: int(s, 16), required=True)
    parser.add_argument('--dar', type=lambda s: int(s, 16))
    parser.add_argument('--gpr', action='append', default=[], help='register=hex_value, e.g. 9=0')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    registers = {}
    try:
        for item in args.gpr:
            register, value = item.split('=')
            register, value = int(register), int(value, 16)
            if not 0 <= register < 32 or not 0 <= value <= 0xffffffff:
                raise ValueError('Invalid GPR')
            registers[register] = value
        report = analyze(args.elf.read_bytes(), args.pc, args.cached, args.ram, args.dar, registers)
    except (ValueError, OSError, struct.error) as error:
        parser.error(str(error))
    content = json.dumps(report, indent=2) + '\n'
    if args.output:
        args.output.write_text(content)
    print(content, end='')


if __name__ == '__main__':
    main()
