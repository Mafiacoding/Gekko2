#!/usr/bin/env python3
"""Capture the Wii adapter's two XFBs from a local, stopped Dolphin GDB stub.

Dolphin must be launched with General.GDBPort, CPUThread=False and the exact
ELF/DOL pair. Uses a private local test environment, never downloads game data.
"""
import argparse, hashlib, json, socket, struct, subprocess, time
from pathlib import Path

class Remote:
    def __init__(self, port):
        self.s = socket.create_connection(('127.0.0.1', port), 10)
        self.s.settimeout(10)
    def send(self, value):
        b = value.encode('ascii')
        self.s.sendall(b'$' + b + b'#' + f'{sum(b)%256:02x}'.encode())
    def packet(self):
        while True:
            c = self.s.recv(1)
            if not c: raise EOFError('Dolphin disconnected')
            if c == b'$': break
        data = bytearray()
        while True:
            c = self.s.recv(1)
            if not c: raise EOFError('Dolphin disconnected')
            if c == b'#': break
            data += c
            if len(data) > 100000: raise ValueError('oversized GDB packet')
        checksum = bytearray()
        while len(checksum) < 2:
            c = self.s.recv(2-len(checksum))
            if not c: raise EOFError('Dolphin disconnected')
            checksum += c
        if int(checksum, 16) != sum(data)%256:
            self.s.sendall(b'-');raise ValueError('GDB checksum mismatch')
        self.s.sendall(b'+')
        return data.decode('ascii')
    def hex(self, command, length):
        self.send(command)
        for _ in range(8):
            value = self.packet()
            # Dolphin can emit an extra stop reply and an empty packet.
            if not value or value.startswith(('T', 'S')): continue
            if len(value) != length*2: raise ValueError((command,value))
            return bytes.fromhex(value)
        raise ValueError('too many unexpected GDB packets')
    def read(self, address, size):
        return self.hex(f'm{address:x},{size:x}', size)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--elf', type=Path, required=True)
    p.add_argument('--nm', required=True)
    p.add_argument('--port', type=int, required=True)
    p.add_argument('--seconds', type=float, default=180)
    p.add_argument('--code-address', type=lambda x:int(x,0), required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    if not 0 <= a.seconds <= 3600: p.error('seconds must be 0..3600')
    symbols = {v[2]:int(v[0],16) for line in subprocess.check_output([a.nm,str(a.elf)],text=True).splitlines() if len(v:=line.split()) == 3}
    back = symbols['_ZN12_GLOBAL__N_1L4backE']
    xfb = symbols['_ZN12_GLOBAL__N_1L3xfbE']
    mode = symbols['_ZN12_GLOBAL__N_1L4modeE']
    remote = Remote(a.port)
    try:
        remote.send('?'); initial = remote.packet()
        if not initial.startswith(('T','S')): raise ValueError('Dolphin must start paused in its GDB stub')
        before = remote.read(a.code_address, 12)
        remote.send('c')
        # This is a standalone CLI test tool; wait is bounded by --seconds.
        end = time.monotonic() + a.seconds
        while time.monotonic() < end: time.sleep(min(1,end-time.monotonic()))
        remote.s.sendall(b'\x03')
        stop = remote.packet()
        if not stop.startswith(('T','S')): raise ValueError('missing stop reply')
        after = remote.read(a.code_address, 12)
        pc = remote.hex('p40',4).hex(); lr = remote.hex('p43',4).hex()
        back_index = int.from_bytes(remote.read(back,4),'big')
        if back_index not in (0,1): raise ValueError('invalid XFB index')
        buffers = struct.unpack('>II',remote.read(xfb,8))
        mode_ptr = int.from_bytes(remote.read(mode,4),'big')
        header = remote.read(mode_ptr,12)
        width = int.from_bytes(header[4:6],'big'); height = int.from_bytes(header[8:10],'big')
        if not 0 < width <= 720 or not 0 < height <= 576: raise ValueError('invalid XFB dimensions')
        a.output.mkdir(parents=True,exist_ok=True)
        frames=[]
        for index,ptr in enumerate(buffers):
            address = ptr & 0xbfffffff
            if not (0x80000000 <= address and address+width*height*2 <= 0x81800000): raise ValueError('XFB outside MEM1')
            data = bytearray()
            for offset in range(0,width*height*2,2048):
                data += remote.read(address+offset,min(2048,width*height*2-offset))
            path = a.output/f'frame-{index}.yuyv';path.write_bytes(data)
            frames.append(dict(index=index,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),nonblack_luma=sum(y>20 for y in data[::2])))
        report=dict(elf_sha256=hashlib.sha256(a.elf.read_bytes()).hexdigest(),duration_seconds=a.seconds,pc=pc,lr=lr,width=width,height=height,code_address=hex(a.code_address),code_before=before.hex(),code_after=after.hex(),sampled_code_unchanged=before==after,frames=frames,physical_wii=False,visible_game_image_verified=False)
        (a.output/'capture.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(report,indent=2))
        if before != after: raise SystemExit('native code changed')
    finally:
        remote.s.close()
if __name__ == '__main__': main()
