# EXI SRAM DMA corrupted native code before game execution

## Proven cause

The owner reported P17 (`fb970a9`) ALIGN at PC `807D66A0`. The expected
register move and following instruction had become SRAM bytes. This was not
caused by guest LQ alignment or missing GS geometry.

The custom Wii linker script placed *all* ordinary static data/BSS in MEM2.
That included libogc 3.1.0's `system.o` object `sramcntrl` at `907D66A0`.
During SDK initialization `__sram_read` issues a 64-byte EXI DMA into this
buffer. The linked `EXI_Dma` programs `pData & 0x03FFFFE0`, discarding the
MEM2 address bit. The actual transfer therefore targets physical `007D66A0`,
or cached MEM1 `807D66A0`: exactly the later faulting native instruction.
Real SRAM contents differ from Dolphin's SRAM contents; they need not decode
to the same accidental instruction. Interpreting these words as geometry
floats was not evidence of a geometry writer.

The unmodified owner P17 DOL was reproduced locally in Dolphin 2503 with a
private FAT SD image. It later failed at the same PC/LR (`807D66A0` /
`807DA588`). Native x86 hardware watchpoints on all three MEM1 mappings caught
the first changed byte. The PPC state at that write identified `EXI_Dma` at
`81314C88`, writing EXI channel 0 control, with length 64. Dolphin's EXI SRAM
read was the native call stack. The write occurred during SDK initialization,
before the affected game function was executed. This explains why ordinary
host game runs and correct standalone PPC Read128 tests missed it.

## Correction

The linker now retains libogc archive bulk `.rodata`, `.data` and `.bss`
storage in a dedicated MEM1 SDK section after native text, before the MEM1
heap. This also preserves MEM1 placement for the SDK's static SD-Gecko buffers
and default stacks rather than making a one-symbol exception. SDA/SDA2 small
sections retain their original common MEM2 region and valid small-data offsets.
The SDK section is deliberately **file-backed PROGBITS**, including zeros for
moved NOBITS inputs: a DOL has only one BSS extent, and merging disjoint MEM1
and MEM2 BSS extents would clear unrelated memory. ELF/DOL loads initialize
the section without adding a second startup zeroing path.

Link assertions and the post-build validator require aligned SRAM storage in
MEM1, a complete file-backed SDK section, no overlap with code/heap, and the
existing arena headroom. No cache fences, exception handling or PPC register
save/restore mechanisms were removed. Guest code and game data are unchanged.

## Regressions and limits

- Execute the actual linked SDK `EXI_Dma` on modeled PPC and inspect its MMIO
  writes: preserved P17 reproduces the MEM2 alias; corrected build does not.
- Six synthetic placement tests reject the former address, unaligned SRAM,
  code/heap overlap, and missing file-backed initialization.
- The actual ELF/DOL passes validation; six deliberately invalid artifacts are
  rejected, including a SRAM symbol moved back to the former MEM2 address.
- A separate six-minute full-runtime x86 run using Wii scalar SIMD and ASan
  reported no AddressSanitizer error. It does not cover the SDK DMA path.
- The first corrected Dolphin run continued beyond the previous failure time
  with game/UI progress. Final-build Dolphin results belong in the accompanying
  build report, not in a claim about physical Wii performance.

```sh
python -m unittest discover -s tests/wii_portability -p test_exi_dma_placement.py
python tests/wii_portability/verify_exi_dma.py --elf /private/fixed.elf \
 --nm /path/to/devkitPPC/bin/powerpc-eabi-nm
python tests/wii_portability/verify_exi_dma.py --elf /private/preserved-p17.elf \
 --nm /path/to/devkitPPC/bin/powerpc-eabi-nm --expect-mem2-alias
python tests/wii_portability/verify_build_guards.py \
 --elf /private/fixed.elf --dol /private/boot.dol
```

The cause is reproduced and corrected locally. Physical Wii confirmation of
the new build is still pending. This fixes the demonstrated native code
corruption, not every remaining Crash/runtime/gameplay issue, and establishes
no Wii FPS or playability figure. Keep the working HBC loader: the replacement
runtime goes at `sd:/ps2recomp/crash-runtime.dol`.

For reproducible local captures use `tools/wii/dolphin_capture.py --help`.
It derives XFB pointers from the supplied ELF's symbols, captures both buffers,
records a bounded run and compares twelve bytes at a specified native code
address. Start the matching DOL paused with Dolphin's General.GDBPort setting.
A checksum of a sampled code region is not a whole-memory corruption check;
nonblack luma is not proof of a recognizable game frame. Review raw YUYV images
privately. Keep the SDK, private SD image and generated game code local.
