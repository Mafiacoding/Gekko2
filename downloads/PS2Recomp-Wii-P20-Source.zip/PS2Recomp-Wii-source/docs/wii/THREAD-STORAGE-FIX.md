# P7: replace unsupported pthread keys

Owner P6 boot-status reaches scheduler-reset-done, then records
scheduler-exception: "Wii TLS key allocation failed", followed by worker finish.
This explains the observed automatic HBC return for that run.

In the exact SDK binary, pthread_key_create tests a missing weak platform
hook and returns 0x58 (88, ENOSYS). pthread_getspecific/setspecific similarly
have no backend. Successful thread creation did not establish key support;
the earlier pthread-key portability implementation was incorrect for this SDK.

Ps2ThreadLocal now owns a map of separate values keyed by the supported
std::this_thread::get_id, with mutex protection. It neither emits native ELF
TLS nor calls pthread key APIs. The EE worker releases its dispatch-history
value through an RAII guard on return or exception, so reused thread IDs do
not inherit stale history. No guest instructions, interrupts or errors are
skipped. This is process-local application storage, not Starlet/DMA sharing.

Host validation: two simultaneous worker threads, 20 rounds, separate values,
stable repeated access, explicit release/recreate and destructor counts. These
checks do not prove physical LWP behavior. Wii cross-build retains the 8 KiB
main-frame guard and static DOL/MEM1/MEM2 checks.

The recorded TLS failure is corrected in code. Successful game boot/rendering
and performance remain unverified. Existing primary-panic and durable return
reporting remain enabled to capture subsequent, distinct failures.
