# P14: correct math ABI and first GS frame path

## Evidence and scope

P13's owner trace reached NuTrigInit and soft floating-point packing helpers,
with active EE and UI but no valid GS frame. The initialization calls fptodp,
passes its binary64 result in GPR a0 to sin, then calls dptofp. The old sin HLE
instead read COP1 f12 and wrote f0. That does not match this EE soft-double
calling convention and leaves the GPR result incorrect.

The local full-runtime runner now captures the real Crash title screen and,
with synthetic input, its pause menu through GS::Present. These are game-
produced software-GS frames, not fallback images. They are private host
results. P14 has not been tested on physical Wii; no FPS or gameplay claim.

## Implementation

- Standard double libm names (sin/cos/sqrt/tan/atan/atan2/pow/exp/log/log10/
  ceil/floor/fabs) read complete binary64 GPR arguments and return binary64
  through GPR v0 (with the existing high-word v1 convention). Float kernel
  entry points retain COP1 handling. FPR values are not guessed as doubles.
- Optional fptodp/dptofp entry fast paths use integer bit conversion. They
  require exact function entry, no delay slot, and an aligned direct-RAM
  stack. Non-finite, subnormal and unsupported exponent cases retain the
  original generated body and library policy, as do internal resume entries.
  The CMake option defaults OFF. The private owner release enables it only
  after comparison against its actual generated routines. No precomputed
  game table or function/branch skip is used.
- Wii output takes ownership of the full-stride GS frame rather than packing
  and copying it to another full-size RGBA buffer. A dedicated borrowed
  texture-view API detaches before freeing old scratch storage; the VI/XFB
  keeps the visible image independently. General UpdateTexture still copies.
  The borrowing API is UI-thread-only and requires source lifetime through
  the next update/detach. Layout and size checks reject malformed frames.
- Black-frame context fallback keeps its previous selection behavior, but
  scans RGB before reusing its output vector instead of allocating another
  candidate frame. Original black-frame alpha remains untouched if no valid
  candidate is selected. Valid black GS frames are not suppressed.
- Wii YUV blitting evaluates the original X expression once per column and Y
  once per row, retaining its rounding and clipping. It uses bounded 4 KiB
  stack storage, not another heap image. A two-XFB cache reuses unchanged
  texture/rectangle/background state; updates, console epochs, clear-only
  frames and layered draws invalidate or update it. Input and VI VSync still
  execute each host loop. No PPC save/restore mechanism is removed.
- TV output defaults to nominal PS2 4:3 rather than treating field texel ratio
  (such as 640x224) as display aspect. Wii 4:3/16:9 configuration determines
  physical fitting. Raw captures retain texel dimensions. A separate native
  anamorphic game-aspect option is not implemented.
- tests/headless builds the actual runtime with a minimal host adapter and
  the consuming frame path. It allows private game regression runs before
  asking for another physical-Wii run. It does not test IOS or Wii timing.

## Validation

- 13 real HLE bodies tested for GPR arguments/results and FPR separation.
- Real PPC750 SDK libm and ABI helpers under Unicorn: sin/cos/sqrt and bit
  conversion cases; no physical Wii performance inference.
- 100,000 vectors each for conversion helpers, plus host rounding modes.
- 4,000 private converter inputs match fast OFF/ON, including original
  fallback outputs; 2,217 eligible cases also match the bit model. Return PC,
  SP, full callee-saved GPR storage and f20 are checked.
- 264 production GS presentation cases match the pre-P12 renderer byte for
  byte, including black/invalid/context fallback and alpha-sensitive mixing.
- 100 clipped/fractional YUV cases match the old blitter; 500 cache/clear/
  layered-draw/console-invalidation sequences match an uncached reference.
- The actual GS take method transfers ownership with allocations disabled,
  rejects invalid layouts, and cannot return an already consumed frame.
- TV fitting, DMA/parser, IOP regressions retained; devkitPPC ELF/DOL, arena
  and stack validation required for the final package.

Known limits: this does not complete every GS/VU/IPU/audio feature or prove
Wii playability. The magenta diagnostic remains until a valid GS frame is
available; it has not been replaced with an artificial successful image.
