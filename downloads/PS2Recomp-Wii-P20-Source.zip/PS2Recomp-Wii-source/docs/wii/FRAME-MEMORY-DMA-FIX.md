# P12: frame memory and DMA completion delivery

Owner P11 files show 3,902,080 EE checkpoints at 35 seconds, a repeating
screen-swap/status query, only one UI iteration at frame preparation, then a
main-thread `std::bad_alloc`. They do not identify the failed allocation or
prove that a particular DMA handler caused the wait.

Changes:

- Interlace field expansion copies each selected row only to its paired row;
  it no longer duplicates the complete 640x512 RGBA buffer (1,310,720 bytes).
- Dual-CRT composition reuses CRT1 as its output, retaining each source pixel
  before blending, rather than allocating a third full-size frame.
- Host upload expands packed rows backwards in the existing scratch vector,
  removing the separate persistent 1,310,720-byte upload buffer. Borders stay
  zero and invalid dimensions are rejected. These changes remove three
  full-frame copies/allocations across the pipeline; the exact peak depends on
  active CRT and interlace modes, retained frames and vector capacity.
- Small malloc/aligned allocations retain MEM1 preference but may fall back
  to MEM2 when MEM1 fails. Large requests retain MEM2 preference. Calloc uses
  the same routing with checked multiplication. Free ownership/alignment and
  MEM2 realloc content preservation remain intact. Realloc of a MEM1 pointer
  still uses the SDK allocator; this is not a universal heap replacement.
- Progress and fatal reports include MEM2 payload/peak and the last failed
  malloc request size. Counters are diagnostics, not free/largest-block data.
- The EE event pump consumes actual completed DMA causes even if no further
  Store32 occurs. Direct HLE/device writes can bypass Store32; delivery must
  not depend on an unrelated future guest store. Existing handler/mask policy
  remains in dispatchIrq. Queue consumption prevents duplicate delivery if a
  Store32 already drained that completion. No busy flag or guest flag is
  cleared by this fix and no completion is fabricated.

Validation:

- 256 production presentation cases, four PSMs, dual/single CRT, PMODE mixing
  controls, different display sizes and interlace match the pre-P12 renderer
  byte-for-byte (335,548,416 compared bytes).
- In-place upload tested against separate-buffer packing for 216 sizes and
  invalid bounds, ASan/UBSan.
- Actual allocator compiled with bounded MEM2/failing MEM1 fixtures: routing,
  alignment, calloc, overflow, MEM2 realloc, free accounting and failure size.
- Actual scheduler event-pump body: delivery without Store32, no duplicate
  after queue drain, later transfer delivery, timers and other events retained.
- Actual progress worker and four IOP regression suites pass.
- devkitPPC build plus ELF/DOL/arena/main-stack checks required for delivery.

No physical-Wii result for P12 yet. Game image, gameplay and FPS remain
unverified. The DMA fix addresses a real delivery gap, not a proven exhaustive
explanation of the owner's screen-swap wait.
