# P15: one-buffer GS display composition

The owner's P14 Wii trace identifies source d51f7ed, std::bad_alloc,
failed_bytes=1310720, and failed_new_site=812ccbd0. The ELF maps this
allocation to GSCpuBackend::CopyFrameToHostRgba. The runtime caught the
exception and exited with status 1; the HBC loader had already succeeded.

Both enabled GS display circuits previously allocated full 640x512 RGBA
images before mixing into CRT1. P14's consuming upload path did not remove
that simultaneous CRT2 allocation. P15 keeps CRT1 as the output and reads
CRT2 samples directly from the same locked VRAM. Only a four-byte local
pixel is required for CRT2. This removes 1,310,720 bytes from the dual-circuit
presentation allocation peak. It does not reduce guest RAM or GS VRAM,
disable a circuit, suppress black frames, invent a frame, or skip blending.

The direct reader retains each circuit's independent PSM, origin and FBW,
CT16 alpha expansion, CT24 alpha, background selection, PMODE mixing,
field processing and context fallback. The Wii serial presentation lock
already protects VRAM throughout conversion; snapshot presentation also
reads its private immutable snapshot. Unsupported formats retain fallback
behavior. No change to the HBC loader is required.

Validation: production presentation output is compared byte-for-byte with
the earlier snapshot renderer in 296 cases, including mixed CT32/24/16/16S
circuits with independent origins and sizes, field modes, PMODE and black
context fallback. During every serial Present, the test throws bad_alloc
if large allocations exceed one full RGBA frame in total. The old dual-
image implementation exceeds this budget. The actual full runtime and
owner-generated guest are also rerun locally; the devkitPPC build validates
ELF/DOL and static memory layout.

Limits: removing the observed allocation peak is not proof of physical Wii
boot or of sufficient heap for every later game allocation. Black/scene
alternation and incomplete 3D scenes remain open. No FPS or gameplay claim.
