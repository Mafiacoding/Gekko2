# P11: bundled execution and diagnostics guards

The P10 owner trace proves initialization and the first native call; it does
not distinguish execution, polling, host starvation or a blocked subsystem.
This update keeps P4–P10 fixes and adds one integrated diagnostic path:

- EE dispatch/backedge safe points publish scalar PC/RA/SP, low cycle count,
  wait reason and a 32-sample PC history through lock-free 32-bit atomics.
- Every 128 safe points, at most one timebase check allows a 1 ms host sleep
  if at least 2 ms elapsed. This gives host/input threads CPU time without
  skipping instructions or changing emulated cycle accounting. It has overhead;
  it is a responsiveness safeguard, not an FPS optimization claim.
- A separate observer wakes once per second at highest LWP priority and sleeps
  between observations. Every 5 seconds it overwrites `progress.txt` with a
  bounded diagnostic sample; it never reads a live guest context or takes
  scheduler/GS locks. No unbounded series of logs is created.
- Separate EE/UI phases identify scheduler/events (1), timer accounting (2),
  safe point (3), native guest (4), IOP (5), event wait (6), MMIO (7), GIF (8),
  VIF (9), VU (10), GS rasterizer (11), HLE GS polling (12). Scoped phases restore on exceptions.
  UI phases: loop alive (1), GS latch/conversion (2), input/blit/VI (3).
- Quiet classifications are observations, not proof of deadlock. Idle waits
  remain legitimate. No IRQ, DMA completion, return PC or frame is fabricated.
- C++ stdout/stderr/clog use a fixed 512-byte line sink writing explicitly to
  `runtime.log` (128 KiB cap), independent of newlib descriptor redirection.
  Stream buffers are restored before their backing sink is destroyed.
- The four HLE GS synchronization polling loops also service host time and
  explicit stop requests. Their existing status tests and timeout limits remain;
  no DMA/GIF/VIF busy bit is forcibly cleared.
- Console POWER and Wiimote POWER callbacks request a cooperative stop, as
  HOME/RESET already do. The EE checks this at safe points and the UI checks
  before entering frame conversion. Worker joins and exception guards remain.

Limits: the observer still depends on functioning host interrupts, scheduling
and SD/FAT. A kernel-wide hang, disabled interrupts or blocked filesystem may
prevent saving. Cooperative stop cannot interrupt arbitrary native deadlock;
there is no unsafe forced thread cancellation or promise of remote shutdown.
The additional observer uses the existing 512 KiB worker-stack policy.

Validation: host ASan/UBSan policy/log tests cover quiet-state recovery, long
lines, concurrent sink writes and real file cap. The actual observer runs with
mock LWP/timebase adapters and real host threads/files, proving it writes a
second sample without producer activity, restores scoped phases and joins on
stop/restart. Thread-lifetime/storage regressions and four IOP suites pass.
Wii compilation and ELF/DOL, static arena and main-stack guards are required.
These checks do not establish Wii gameplay or resolve the P10 hang conclusively.
