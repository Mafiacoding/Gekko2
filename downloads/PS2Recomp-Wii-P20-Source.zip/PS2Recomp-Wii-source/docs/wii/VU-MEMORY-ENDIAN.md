# VU data memory on big-endian hosts

VU data memory contains PS2 little-endian bytes, while the interpreter's VF,
VI and pending-store words are native numeric values. Raw memcpy between these
representations reversed every word on Wii. This affected LQ/LQI/LQD and
ILW/ILWR reads, plus delayed masked SQ/ISW-family stores. Native register-to-word
bit casts remain valid and are unchanged.

Loads now use Ps2GuestRead and selected store lanes use Ps2GuestWrite. Address
masking, VI increment/decrement, destination masks and pipeline readiness are
unchanged. Unselected destination bytes are preserved.

Run:

```
python tests/wii_portability/verify_vu_memory_ppc.py \
  --devkitppc /path/to/devkitPPC --output vu-memory.json
```

The test extracts the production instruction case bodies and delayed-store loop,
compiles them for PPC750 and executes them under Unicorn against an independent
little-endian byte oracle. Its 1,632 cases cover all lane masks, signed VI and
address wrap, immediate offsets, delayed stores and out-of-range rejection. A
host-endian load negative control fails the oracle. This verifies those memory
paths, not complete VU instruction accuracy or a visible Crash game frame.

A separate GS frontend path, HWREG, serialized its numeric 64-bit register
with host-endian memcpy before passing it to the image-transfer decoder.
It now uses Ps2GuestWrite<uint64_t>, so bytes match ordinary little-endian
IMAGE transfers. verify_gs_hwreg_ppc.py compiles the production HWREG case
and checks 67 PPC inputs, including every single-bit position. This fixes a
specific transfer path; it does not establish the cause of all dark frames.
