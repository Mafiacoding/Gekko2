# Experimental Wii runtime port

This branch ports the actual PS2Recomp runtime to original Wii hardware. It is
not a completed game release. Gekko2 is a separate, currently paused project.
Upstream baseline: `ran-j/PS2Recomp` commit
`e5636981a1c9de368f6b71e819c3dc188dfedbf4`.

## Native code corruption correction

The custom static-data layout had placed the SDK SRAM DMA buffer in MEM2.
EXI discarded its MEM2 address bit and wrote 64 bytes into native MEM1 code.
The root cause is locally reproduced and the linker placement corrected; see
[EXI-SRAM-CORRUPTION.md](EXI-SRAM-CORRUPTION.md). New-build physical Wii
confirmation remains pending. This is separate from guest graphics fixes.

## Implemented foundation

- Scalar 128-bit lane operations for Broadway without SSE, NEON or AltiVec.
- Explicit PS2 little-endian EE/IOP memory, ELF, VIF/GIF and selected kernel/HLE
  ABI transfers. This is not a claim that every upstream HLE path is audited.
- Bounded interrupt-guarded 64-bit CPU atomics; not an IOS/DMA IPC mechanism.
- Wii VI double-buffered software output, GameCube/Wiimote input and HOME exit.
- Large allocation support in MEM2, worker stack reservation, and explicit per-thread
  storage instead of unsupported native ELF TLS or unavailable pthread keys.
- Separate MEM1/MEM2 linker placement with SDK startup/unwind/BSS logic retained.
  The current placement profile selects NuLight/NuRndr translation units for
  MEM2; it is a Crash prototype profile, not a universal game policy.
- Serialized GS presentation avoids the additional 4 MiB VRAM snapshot on Wii.
- SD runtime log at `sd:/ps2recomp/runtime.log`, including startup stages and
  low-rate transfer/DMA/GIF/GS diagnostics.
- ISO9660 data preparation from 2048-byte ISO and supported raw CD layouts.
  CHD and CUE track parsing are not implemented; convert those externally first.

## Build prerequisites and commands

Use the **current official devkitPro devkitPPC and libogc**, including libfat,
Wii controller/Bluetooth libraries, and their normal installation layout. The
verified toolchain here is devkitPPC r50 / GCC 16.1.0 and libogc 3.1.0. An old
bundled compiler/libogc archive is not the tested configuration. Host tools need
CMake >=3.21, Ninja, Python3 and a host C++ compiler. PPC differential scripts
also need the Python Unicorn package and an x86 host with SSE4.1.

Generated guest C++ and disc data must stay outside the public checkout.
Generate them with the upstream recompiler against an owner-supplied ELF.
Do not enable skip/patch/stub options merely to force successful compilation.
The standalone Wii target does not configure the PC graphics/FFmpeg frontend.

```sh
export DEVKITPRO=/path/to/devkitpro
export DEVKITPPC="$DEVKITPRO/devkitPPC"
cmake -S ps2xRuntime/platform/wii -B /private/wii-build -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE="$PWD/ps2xRuntime/platform/wii/toolchain.cmake" \
  -DPS2X_GENERATED_DIR=/private/generated-game
cmake --build /private/wii-build -j 3
python3 tools/wii/prepare_disc.py --image /private/disc.bin \
  --output /private/SD/ps2recomp
```

The build produces `crash_wii.elf`, `boot.dol`, a map and `build-report.json`.
ELF-to-DOL conversion uses the bundled Python tool; Gekko2 is not a dependency.
The post-build validator rejects illegal memory regions, overlapping sections,
unsupported ELF TLS, mismatched bytes and insufficient initial arena space.
This checks static layout, not worst-case runtime heap use or physical boot.

The P0 runtime is too large for HBC discovery. Build and install the small
launcher as described in [SD-LOADER.md](SD-LOADER.md); place the large runtime
at `SD/ps2recomp/crash-runtime.dol`. Do not use it as the HBC `boot.dol`.
Copy the extracted data into `SD/ps2recomp/`; it includes `game.elf`. No PS2 BIOS
is required by this runtime. Keep existing Gekko2 installations separate.

## Validation completed

- All 2,848 generated Crash translation units and the actual runtime linked.
- Native SSE vs emulated big-endian PPC: 3,360 integer SIMD comparisons.
- Independent byte/integer model vs PPC: 68,064 memory/record/QFSRV word
  comparisons, including all 256 shift values and 64 wrap offsets.
- Original snapshot vs serialized GS output: 32 cases, 41,943,552 identical
  bytes across CT32/CT24/CT16/CT16S, CRT and interlace combinations.
- Four existing upstream IOP test executables pass after the endian changes.
- Disc tool: four test methods, including four sector layouts, unsafe names,
  existing-file preservation and inconsistent endian extent rejection.
- Static artifact validation passes; five deliberately invalid variants fail.

Unicorn executes PPC instructions here; it does not simulate a Wii boot, IOS,
video hardware, controller pairing or actual performance. The tests do not prove
complete EE/VU/FPU instruction accuracy or successful Crash boot/gameplay.

## Open work and acceptance

Audio output and MPEG video decoding are disabled and explicitly reported.
Rendering uses the upstream software GS, not a new GX accelerator. Remaining
upstream HLE/TODO handlers, overlays, timing and further big-endian assumptions
may still prevent correct execution. Peak heap use and worker stack sufficiency
need runtime evidence. Physical Wii boot/gameplay and Dolphin boot are untested.
No FPS or playable-game claim is made.

The first hardware run should establish SD mount → runtime memory allocation →
ELF load → scheduler entry → first emulated image. HOME requests exit; retain
`runtime.log` from that run. A failure at any stage is a failed prototype test,
not a successful conversion. The future GUI plan is in CONVERTER-ROADMAP.md.

Only synthetic tests, runtime sources and recipes belong in the public fork.
Compiled guest code, ELF files, disc images and extracted assets remain private.
