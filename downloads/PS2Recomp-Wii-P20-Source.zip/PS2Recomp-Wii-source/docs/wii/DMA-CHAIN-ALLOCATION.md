# Exact DMA chain snapshot allocation

The post-EXI-fix Dolphin run exposed a separate allocation failure:
`failed_alloc_bytes=2111904`, with the caller in the DMA chain byte-vector
range insertion. The Wii MEM2 allocator had roughly 44.8 MB live payload.
The guest remained in a screen-swap/VU DMA status polling path, and the
sampled output buffer was black. This is a separate issue from SDK EXI DMA
writing into native code; clearing CHCR or inventing an interrupt is not a fix.

The production chain parser now uses its existing bounded tag walker twice:
first to measure the complete snapshot, then to copy into one exact reserve.
The old vector-growth strategy could need the previous and expanded multi-MB
buffers simultaneously. A measured snapshot avoids that transient peak and
extra copies. Both walks use the same parser and restart TADR/ASR0/ASR1/ASP,
tag count, termination and tag-status state. Guest RAM is only read during
these walks, with no new scheduler interruption; register/queue updates remain
after successful snapshot construction. TTE bytes and wrapped payload ranges
use the same append path. Size overflow is rejected before allocation.

Tests execute the extracted production parser under ASan/UBSan. Six large
synthetic GIF/VIF0/VIF1 chains (TTE on/off) fit a 1.1 MB single-allocation
budget; every emitted byte and final tag address are checked. An ordinary
growing byte vector fails the same budget, providing a negative control.
CALL/RET return-stack restoration and IRQ/TIE termination are covered, in
addition to the existing empty END, invalid/cyclic, payload and scheduler
exactly-once completion tests. No game data is embedded in these fixtures.

This does not make arbitrary chains fit Wii RAM. An exact snapshot can still
exceed free memory; it is not a streaming DMA implementation or a claim of
complete game support. Actual local game/build outcomes belong in the test
report. Physical Wii confirmation remains pending.

```sh
python tests/wii_portability/test_dma_chain_budget.py
python tests/wii_portability/test_empty_dma_chain.py
python tests/wii_portability/test_scheduler_dma_delivery.py
```
