# Bounded inline code dispatch (P10)

The owner Wii trace stopped at a missing indirect target in a DMA packet
helper. The ELF contains executable instructions at the target; symbol-based
function coverage omitted the island between known functions.

The recompiler now recognizes a conservative adjacent LUI/ANDI/ADDI/SLL/ADD/JR
sequence with separate base/index registers and at most 16 aligned destinations.
It does not rewrite the jump or bypass guest instructions. Executable islands
are decoded only to the next known function/section boundary, with a 4 KiB cap.
Potential destinations are registered through normal checked guest entries.
An island stays one owner so that a target boundary cannot sever a delay slot.
Other computed expressions continue to use the existing diagnostic fallback.

Validation:

- `test_computed_code_targets.cpp`: bounded/submask targets and rejection of
  malformed instructions, aliases, excessive masks and unaligned addresses;
  host ASan/UBSan.
- `test_computed_dispatch.py <ps2_recomp>`: synthetic ELF through the actual
  generator; all 16 entries share a whole owner. The emitted C++ is compiled
  and executed for each entry, checking return PC, result and observable
  return delay-slot side effect (minimal device-free context, ASan/UBSan).
- Private owner ELF regenerated without configured skips, stubs or patches;
  missing target and aligned DMA-helper variants now have real generated code.
- 128 private leaf cases across four aligned DMA entries match between emitted
  x86 C++, emitted PPC750 code executed in Unicorn, and a separate bounded
  instruction interpreter, comparing GPR64, return PC and 8 KiB of memory.
  This uses an isolated test context, not the complete runtime.

This fixes a demonstrated coverage omission. It does not establish that the
Wii reaches gameplay, that every computed jump is supported, or any FPS gain.
