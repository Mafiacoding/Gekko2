# Post-loading scene validation

The P18 host build can reach the Crash E3 hub after the loading transition.
A 240-second local run with explicit pad-poll inputs loaded E3HUB.GSC and
E3HUB.TER and produced a visible Crash/corridor/HUD capture afterwards. Short
wall-time input pulses and a title/lab image alone were insufficient evidence.
This is a host observation, not a new physical Wii success claim. The Wii-target
Dolphin observation remains the lab scene; post-loading Wii-target progression
and remaining geometry/color issues are open.

`tests/headless/run_scene_probe.py` automates input/load/frame milestones using
an external game profile, with failure if input was generated but not delivered,
loads fail, only pre-load images exist, the process times out, or sanitizers
report an error. It deliberately leaves image correctness unverified. Six
negative/positive parser tests protect this distinction. Raw game captures and
logs remain in the private output directory. See tests/headless/README.md.

## Separate endian correction

The optional libc `__ieee754_rem_pio2f` HLE stub still wrote native floats into
little-endian guest memory. It now uses Ps2GuestWrite<float> for both result
words, retaining its existing numeric reduction and pointer checks. The
645-case compiled PPC750 test covers finite values -16..16, unaligned outputs,
canary preservation and an invalid output pointer. This does not claim correct
large-argument libm reduction and is not identified as the cause of Crash's
loading transition: this demo contains a distinct generated double routine.
