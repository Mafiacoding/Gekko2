# Local post-loading GS investigation

Branch: codex/wii-postload-gs-fix, based on P15 b2bf9e9.
No physical-Wii test or release acceptance is implied by this report.
The owner requested local scene progression before another Wii build.

## Isolated defects

1. VU0 VCLIP emission reversed each positive/negative plane bit and compared
   against signed W rather than its magnitude. The micro interpreter already
   uses +X=bit0, -X=bit1, +Y=bit2, -Y=bit3, +Z=bit4, -Z=bit5. Correct the
   common static translator and regenerate the affected private functions.
   Only five private compilation units change; no guest instruction patch,
   function skip, synthetic packet or forced guest PC is involved.
2. LIBGS GParam was four bytes instead of four guest little-endian 16-bit
   fields. Correct its size/offsets and record serialization. The original
   private library uses halfword stores at offsets 0,2,4,6.
3. sceGszbufaddr takes PSM,width,height in a0,a1,a2. Correct the helper ABI
   and the DBuff callers' temporary argument registers. Use the actual video
   mode fields instead of reading an eight-byte value from an incompatible
   four-byte scratch record. Preserve the signed 16-bit result convention.
4. DBuffDc previously placed the second color buffer at the depth base and
   reversed the display/draw roles. Preserve field-mode shared color storage;
   otherwise place the second color buffer halfway to the depth base. Display
   one buffer while drawing into the opposite one. In the local 640x224 run,
   color/depth bases change from overlapping 0/140/140 to 0/70/140 GS pages.
   This follows original library behavior, not a cosmetic scanout substitution.
5. Match the previously isolated Gekko2 VI semantics: expire conditional
   branch bypass on elapsed clocks, preserve the earliest old VI across
   consecutive writes, and exclude JR/JALR from conditional-branch bypass.
   Upper CLIP wins over FCSET in the same issue pair. Four-cycle flag
   publication is retained.

## Tests

- 74 production GS tests pass. A new table covers 32 PSM/video-mode/height
  combinations, GParam halfword offsets, helper argument ABI, both color
  buffers and depth placement. Clear tests inspect the selected physical
  buffer with the actual swizzle rather than assuming buffer zero/linear RAM.
- 42 production VU tests pass: consecutive writes, stall expiry, canonical
  JR values, same-pair CLIP/FCSET, and the existing arithmetic/VIF/GIF tests.
- 10,000 vectors compile the actual VCLIP emission: plane order, negative W
  and 24-bit history. The old translator fails this same test.
- 518 compiled PPC750 scalar-SIMD VCLIP vectors run under Unicorn and match
  the reference. This is CPU simulation, not Wii or Dolphin evidence.
- tests/headless/run_regressions.py runs shared GS/VU suites against the full
  private host build without GUI dependencies. Its binaries contain private
  guest objects and must not be published.

## Local progression and remaining gate

Baseline captures showed a gradient plus menu/HUD. With the VCLIP correction,
actual GS captures show textured spatial geometry. A subsequent full-runtime
run opens E3HUB.GSC and E3HUB.TER and captures spatial hub geometry with the
pause overlay. These are private game-generated frames, not substituted images.
They do not yet prove a normally framed scene with the player and sustained
controls. That stronger post-loading acceptance remains required before asking
for another Wii test. Do not equate successful file loading, HUD, title geometry
or pause-menu rendering alone with complete gameplay.

Short wall-time input pulses can be missed during expensive guest frames.
The headless adapter now supports explicit wall-time and actual pad-poll input
scripts, bounded capture limits and optional file/VU/pad probes. Input delivery,
level file milestones and captured scene content must be checked separately.
Repeated default START pulses can pause a game that has already progressed.

The owner's P15 DOL matches the published SHA256. Its photographed alignment
exception at a register-only instruction is not explained by these host tests.
No claim that this separate hardware exception is fixed. Existing one-buffer
GS composition, memory reductions and loader remain in place.

References: Gekko2 docs/CRASH-E3-VU-TIMING.md and independent inspection of
owner-private library code; no proprietary fixture or disassembly is committed.

Final local check in this batch: a single START interval at backend pad polls
400..409 is actually returned by scePadRead (analog mode 0x73), then all buttons
are released. The run opens E3HUB.GSC after this input and exits normally at
115 host seconds, with 695 valid GS captures/633 nonblack frames counted.
The final image contains spatial hub/background geometry without a pause
caption. It still does not establish a correctly framed player/corridor scene.
The strict release gate remains OPEN; no new Wii DOL is published by this batch.

## Follow-up: isolated R5900 SQRT source error

The decoded command replay renders substantially the same incorrect title/hub
geometry through Gekko2's independent software GS. This is qualitative evidence
for a fault before rasterization; decoded traces share the frontend and explicit
HLE clears, and the older long capture ends with an incomplete final record.
It is not a complete byte-exact graphics comparison.

A private full-function EE-state/RAM comparison then isolates an independent
translation error: R5900 SQRT.S reads **Ft**, bits 20:16, whereas the emitter
used Fs. Distinct operands cause wrong vector normalization. Correct the common
FPU translator and regenerate the one affected private function; no guest
instruction patch, forced PC, asset substitution or skipped device event.

With the correction, the previously divergent camera-call result memory agrees
with the interpreter. One dead stack word and a caller-clobbered upper temporary
still differ across original low-level code versus HLE/runtime calls; do not
claim whole-state equality for that particular function probe.

The synthetic production-template test covers 3,844 distinct source/destination
alias combinations under ASan/UBSan. The old emitter fails the same test. The
full host runtime again passes 74 GS and 42 VU regression tests. A cold local
run with one START pulse at actual backend polls 400..409 opens the hub files
and captures **the corridor with Crash and Wumpa/lives HUD after loading**.
Subsequent scene frames remain visible with all buttons released. This meets
the requested local scene gate, not sustained controls, full-game correctness,
Wii stability or a performance target. No physical Wii or Dolphin was run.

Earlier 128 private VU1 snapshot comparisons matched end-PC and VI values, with
mostly small float/memory differences. This sample does not prove VU1 complete.
The separate photographed P15 Wii alignment exception remains unresolved.

The fresh Wii cross-build exposed an unavailable scalar-PPC intrinsic in the
LIBGS temporary arguments. Construct the same zero-extended 32-bit lanes with
the existing portable set intrinsic. The GS suite still passes all 74 tests.
`verify_fpu_sqrt_ppc.py` runs 54 synthetic combinations through actual production
SQRT emission/scalar FPU helpers, SDK libm and the portable argument construction
on PPC750 Unicorn. This validates target instructions, not original Wii hardware.

The final clean scene run at source 1a715fe (before this bit-equivalent GS argument
construction adjustment) ends normally after 360 host seconds: 689 valid GS
frames, 655 nonblack. Required hub files open; START and Cross packets are
actually returned by scePadRead. Captures retain the player scene. This remains
a limited scene/control check, not all levels or a physical Wii speed result.
