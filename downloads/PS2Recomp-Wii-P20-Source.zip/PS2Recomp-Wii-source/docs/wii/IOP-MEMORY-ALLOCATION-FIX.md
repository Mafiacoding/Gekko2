# P13: fixed IOP metadata footprint and allocation attribution

P12 owner reports show 45,275,100 bytes of live MEM2 payload, a 45,540,012-byte
peak, a failed 529,824-byte allocation and a native EE polling loop. The
telemetry does not establish which caller requested those bytes or that the
DMA poll has one exclusive cause. No gameplay result is claimed.

Implemented:

- IOP byte-ownership metadata now uses explicit 32-bit bitmap words. Its
  backing storage falls from 2,097,152 to 262,144 bytes: 1,835,008 bytes
  (1.75 MiB) saved for the lifetime of the IOP memory instance. Guest RAM is
  unchanged. Partial-word masks retain exact byte ownership; bulk set/query
  operations fill/check full words. The separate EE IOP mirror remains.
- DMA chain parsing preserves a zero-payload completion marker only after a
  valid terminating tag. The existing transfer drain handles its STR/QWC/IRQ
  bookkeeping. Previously an empty chain buffer suppressed that bookkeeping.
  Invalid addresses and chain-budget exhaustion do not gain a completion.
  VIF TTE upper-tag data and ordinary payloads keep their existing paths.
  This is a real generic gap; the owner's actual stalled chain is not proven
  to be this case (the known Crash write uses TTE).
- C++ scalar/array new wrappers retain the outer allocation call site in 16
  fixed per-LWP slots. No heap allocation, native TLS, pthread key or stack
  walk is used. Capture starts only after Wii heap/LWP setup; exhausted slots
  yield an unknown site without affecting allocation. Exceptions restore the
  previous marker. Direct C allocations fall back to the malloc/memalign/
  realloc caller address. The matching private ELF resolves saved addresses.
- A bounded 64-slot inventory records wrapped allocations >=64 KiB (up to
  32 rows reported), including their allocation sites. Small allocations,
  SDK allocations bypassing wrappers, and overflow beyond capacity are not
  represented. Live fields are independent diagnostic samples, not a coherent
  heap dump, allocator free-block report or exhaustive leak detector.
- Progress includes failure call site and current requested frame dimensions/
  bytes. UI phases 20–24 distinguish frontend-state lock, backend lifetime
  lock, backend conversion, packed-copy allocation and RGBA conversion.
  Fatal boot reports preserve the last failed allocation site as well.

Validation:

- Actual IOP memory implementation versus byte-array ownership reference:
  10,000 mixed writes/queries, cached address aliases, frees, reset, bounds.
  Bitmap tests cover 16,384 partial-word ranges and exact backing size.
- Four rebuilt IOP regression suites pass.
- Actual DMA parser with synthetic END, payload, VIF TTE, bad address and
  cyclic chains; scheduler completion delivery regression retained.
- Actual new-site wrappers tested across real host threads, nested array new,
  exceptions and disabled-before-setup state, ASan/UBSan.
- Actual allocator fallback/inventory and independent progress-worker tests.
- devkitPPC linking verifies new wrappers and strong site capture override;
  ELF/DOL/arena and main-stack checks required before publishing.

No physical Wii result for P13 yet. The fixed metadata saving is established;
resolution of the owner's OOM, screen output and DMA polling still needs a
hardware result. No forced IRQ, busy-bit clearing, guest patch or fake frame.
