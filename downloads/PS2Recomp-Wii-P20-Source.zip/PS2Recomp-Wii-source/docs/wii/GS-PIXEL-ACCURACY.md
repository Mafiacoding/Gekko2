# GS pixel accuracy batch P20

These corrections apply to the shared software GS backend used by the current
PS2Recomp Wii prototype and host scene runner. They do not modify Gekko2's
separate GX renderer or establish correctness for every game.

## Implemented corrections

- COLCLAMP now selects RGB saturation or low-eight-bit wrapping after signed
  blending. Intermediate overflow/negative values are retained until that stage.
- DTHE applies signed three-bit DIMX entries to RGB for CT16/CT16S before
  clamp/wrap and 5551 packing. CT32 and alpha are unaffected by dithering.
- SCANMSK masks the selected even/odd rows before both color and depth writes;
  modes without the enable bit retain normal drawing.
- Sprites retain all UV fractional bits, use vertex two's Q at both ST endpoints,
  and carry the appropriate U/V endpoints when an axis is reversed.
- Negative nearest ST coordinates floor before repeat/clamp addressing.
- Triangle XYOFFSET retains its four fractional bits. Exact signed 64-bit edge
  values and incremental steps replace epsilon-based, double-owned boundaries.
  A shared top-left edge belongs to exactly one triangle, in either winding.

The existing raster sample position and floating attribute interpolation remain
unchanged. This is not a complete implementation of GS subpixel DDA behavior.
No save/restore, code invalidation, interrupt or DMA completion paths are removed.

## Reference review

Behavior was checked against the public PCSX2 software renderer sources:

- https://github.com/PCSX2/pcsx2/blob/master/pcsx2/GS/Renderers/SW/GSRendererSW.cpp
  (`ConvertVertexBuffer`: sprite Q; COLCLAMP/DTHE state setup).
- https://github.com/PCSX2/pcsx2/blob/master/pcsx2/GS/Renderers/SW/GSRasterizer.cpp
  (sprite axis reordering and SCANMSK row selection).
- https://github.com/PCSX2/pcsx2/blob/master/pcsx2/GS/Renderers/SW/GSDrawScanline.cpp
  (dithering before clamp/wrap and framebuffer packing).

Implementations here are independently written; no PCSX2 code is copied into
the runtime. Reference URLs track upstream and may change. This comparison is
not a claim of complete PCSX2 equivalence or original hardware validation.

## Regression evidence

Six additional full-GS test groups cover signed blend overflow/underflow,
all DIMX positions/values across CT16/CT16S/CT32 and enable modes, texture
fractions/Q/negative wrapping/reversed axes, shared blend-edge ownership,
fractional XYOFFSET translation and SCANMSK color/depth preservation.
The prior production backend fails all six new groups and passes its original
74. The corrected backend passes all 80 groups, plus the 42 VU regressions.

The production fixed-point edge helper is additionally compiled for PPC750 and
executed under Unicorn: 320 rectangle tilings / 20,480 pixel ownership checks,
covering both windings/diagonals, every fractional translation, and large signed
coordinates. This is not a physical Wii test.

## Still open

Full GS raster sampling/attribute DDA precision, mipmap/LOD selection, AA1
coverage and complete game-specific visual equivalence remain unverified or
incomplete. The software path remains CPU-heavy. Scene captures and exact
build results belong in the accompanying report; synthetic passes alone do not
prove that all visible Crash defects, post-loading Wii execution or other games
are correct. No physical Wii FPS or playability claim is made.
