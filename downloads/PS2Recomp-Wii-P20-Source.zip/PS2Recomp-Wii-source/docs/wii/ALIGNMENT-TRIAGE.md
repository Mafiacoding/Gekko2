# Wii alignment triage after P16

**Resolution update:** the later local investigation identified SDK EXI SRAM
DMA aliasing MEM2 storage onto native MEM1 code. See
[EXI-SRAM-CORRUPTION.md](EXI-SRAM-CORRUPTION.md). The entries below preserve the
earlier evidence and its limits; they precede that root-cause result.

This batch does **not** establish an alignment-crash fix. The owner's physical
Wii still reports an alignment exception. The local graphics/SQRT correction
and the separate Wii failure must remain distinct.

## Evidence and limits

The reported P16 PC maps inside NuGScnUpdate to an ADDI, not a memory operation.
The nearby LR maps to the ordinary guest Read128 call site. A test executes
that actual linked helper, including its actual library callees, on modeled
PPC with synthetic guest bytes and the reported guest-stack neighborhood.
49 aligned/unaligned/ring-wrap cases return the expected four lanes; no
misaligned multi-byte host memory access is observed. The observer detects a
separate deliberately misaligned output-pointer negative control. The ADDI
at the reported PC also executes successfully in isolation.

This checks the linked code under modeled mappings with translation/interrupts
disabled. It does not model Broadway cache coherence, IOS, exception delivery,
concurrency or the complete preceding game state. It does not rule out every
memory-corruption or alignment problem and does not prove a cache defect.
The installed SDK's exception number and context field layout were inspected;
the custom panic uses the correct ALIGN number and initial context fields.

The unchanged relocated loader explicitly flushes destination data lines and
invalidates instruction lines. Its existing simulated copy/cache tests remain
separate from physical cache verification. No fences or cache operations are
removed or blindly added as a claimed fix.

## One bounded fault record

The panic now also prints its compiled source ID and three code words at
PC-4/PC/PC+4 through both the cached and uncached RAM aliases. It snapshots these
before changing video. An aligned, nonoverflowing, complete window must fit
known Wii MEM1/MEM2 RAM ranges. MMIO, arbitrary pointers, unaligned and crossing
windows are rejected. No stack walk, allocation, SD/IOS call or resume is added.
This reads RAM/data-cache views, **not the instruction cache**. Equal/different
words must be compared with the exact identified ELF before drawing conclusions.

Six actual compiled PPC panic tests pass: corrupt SP, invalid/truncated context,
different cached/uncached fixture values, MMIO PC, unaligned PC and a PC window
crossing the bank boundary. Video/text services are mocked; no physical Wii run.

```sh
python tests/wii_portability/verify_primary_panic.py --devkitppc /path/to/devkitPPC
python tests/wii_portability/verify_linked_read128.py \
  --elf /private/exact-build.elf --helper 0x... --reported-pc 0x... \
  --output /private/linked-read-report.json
```

Addresses must come from that exact build; private ELF/code/state are never
bundled with these synthetic tools. P16 is preserved as the rollback. An
instrumented candidate is diagnostic only until physical evidence identifies
which assumption failed. Do not relabel the existing host scene result or these
PPC tests as a Wii crash fix or performance/playability proof.

## P17 physical report: executable bytes differ from the exact ELF

The next owner's photograph identifies source `fb970a9`. Transcribe its PC as
`807D66A0` (not `807D6640`). The preceding instruction agrees with the preserved
P17 ELF, while the words at PC and PC+4 do not. Both cached and uncached snapshots
contain the same differing words. The observed PC word decodes to an LFS using
r9=0 and displacement 0x3DB3: its effective address exactly matches the reported
DAR and is not word-aligned. The ELF instruction at PC is an ordinary register
move, not a load. This explains the immediate alignment exception **given the
observed RAM contents**; the first erroneous writer is still unidentified.

Do not infer a stale-I-cache-only fault, a guest LQ alignment fault, or a fixed
loader from this record. RAM differs from the expected file, but the photograph
alone cannot establish when it changed (loading versus execution), who changed
it, or whether the complete SD file matches the preserved build. It also does
not establish that the differing words are geometry data: plausible floating
point interpretations alone do not identify their origin.

`tools/wii/analyze_panic_code.py` now performs this comparison against a private
exact ELF. It validates the ELF format, file-backed executable window and input
words, compares the two RAM views independently, and narrowly decodes D-form LFS
when present. Supplying the base GPR permits an effective-address/DAR check.
There is no guessed register state, patching or claimed writer identification.
Five synthetic fixture tests cover unchanged code, shared modifications,
distinct RAM views, missing register state and invalid/truncated ELF windows.

```sh
python -m unittest discover -s tests/wii_portability -p test_panic_code_analysis.py
python tools/wii/analyze_panic_code.py --elf /private/exact-p17.elf \
 --pc 807D66A0 --cached 3B9C0070 C2493DB3 00000000 \
 --ram 3B9C0070 C2493DB3 00000000 --dar 00003DB3 --gpr 9=0
```

Next investigation must locate the first write into executable storage, checking
host output pointers, arena/stack/framebuffer ownership and loader file integrity.
Preserve the exact ELF/DOL and source ID. Avoid repairing the two code words and
continuing: that would hide corruption rather than fix its cause. No additional
Wii test package is released by this offline-analysis change.
