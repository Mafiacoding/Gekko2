#pragma once
#include <cstdint>
struct Ps2ProgressPolicy {
 uint32_t ee=0,ui=0,eeQuiet=0,uiQuiet=0;
 // One observation per second. A quiet EE may legitimately be waiting;
 // classify it, never invent events or change guest time to escape it.
 void observe(uint32_t e,uint32_t u){eeQuiet=e==ee?eeQuiet+1:0;uiQuiet=u==ui?uiQuiet+1:0;ee=e;ui=u;}
 const char* state() const {
  if(eeQuiet>=10&&uiQuiet>=10)return "EE_AND_UI_QUIET";
  if(eeQuiet>=10)return "EE_QUIET_OR_WAITING";
  if(uiQuiet>=10)return "UI_BLOCKED_OR_BUSY";
  return "HOST_PROGRESS";
 }
};
