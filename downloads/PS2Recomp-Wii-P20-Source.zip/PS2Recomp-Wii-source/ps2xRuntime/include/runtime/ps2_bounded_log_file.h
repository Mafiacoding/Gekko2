#pragma once
#include <cstdio>
#include <cstddef>
#include <algorithm>
inline void Ps2AppendBoundedFile(const char*path,const char*s,std::size_t n,long cap){
 FILE*f=std::fopen(path,"a");if(!f)return;
 if(std::fseek(f,0,SEEK_END)==0){
  const long pos=std::ftell(f);
  if(pos>=0&&pos<cap)std::fwrite(s,1,std::min<std::size_t>(n,cap-pos),f);
 }
 std::fflush(f);std::fclose(f);
}
