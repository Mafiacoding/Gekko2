#pragma once
#include <bit>
#include <cstdint>
#include "ps2_simd.h"
// EE soft-double EABI: a complete IEEE binary64 value occupies the low 64
// bits of an argument GPR; float functions use COP1 and must stay distinct.
template<class Context> inline double Ps2EeDoubleArg(const Context*ctx,unsigned reg){
 return std::bit_cast<double>(uint64_t(_mm_extract_epi64(ctx->r[reg],0)));
}
template<class Context> inline void Ps2EeDoubleReturn(Context*ctx,double value){
 auto bits=std::bit_cast<uint64_t>(value);
 ctx->r[2]=_mm_set_epi64x(0,int64_t(bits));
 ctx->r[3]=_mm_set_epi64x(0,int64_t(uint32_t(bits>>32)));
}
