#pragma once
#include <cstdint>
// Conservative EE soft-conversion fast paths. Non-finite/subnormal/overflow
// cases retain the original guest routine, including its flush/NaN policy.
inline bool Ps2TryF32ToF64(uint32_t in,uint64_t&out){
 const uint32_t exp=(in>>23)&255,frac=in&0x7fffff;
 if(exp==255||(!exp&&frac))return false;
 out=uint64_t(in>>31)<<63;
 if(exp)out|=uint64_t(exp+896)<<52|uint64_t(frac)<<29;
 return true;
}
inline bool Ps2TryF64ToF32(uint64_t in,uint32_t&out){
 const auto exp=uint32_t((in>>52)&2047);const uint64_t frac=in&0xfffffffffffffull;
 out=uint32_t(in>>63)<<31;
 if(!exp)return frac==0;
 if(exp==2047)return false;
 int e=int(exp)-1023;if(e<-126||e>127)return false;
 const uint64_t significand=frac|0x10000000000000ull;
 uint32_t mant=uint32_t(significand>>29);const uint32_t remainder=uint32_t(significand&0x1fffffff);
 if(remainder>0x10000000||(remainder==0x10000000&&(mant&1)))++mant;
 if(mant==0x1000000){mant>>=1;if(++e>127)return false;}
 out|=uint32_t(e+127)<<23|(mant&0x7fffff);return true;
}
