#pragma once
#if defined(PS2X_WII)
#include <thread>
#include <mutex>
#include <memory>
#include <map>
// Broadway has no native ELF TLS setup; this SDK also lacks pthread keys.
// Keep separately owned values keyed by supported thread identity. Owners
// must call releaseCurrent before exiting, preventing stale values on ID reuse.
// Returned references belong to that thread; no other thread may release them.
template<class T> class Ps2ThreadLocal {
 std::mutex mutex_;
 std::map<std::thread::id,std::unique_ptr<T>> values_;
public:
 T &get(){
  const auto id=std::this_thread::get_id();
  std::lock_guard<std::mutex> lock(mutex_);
  auto it=values_.find(id);
  if(it==values_.end())it=values_.emplace(id,std::make_unique<T>()).first;
  return *it->second;
 }
 void releaseCurrent(){
  std::lock_guard<std::mutex> lock(mutex_);
  values_.erase(std::this_thread::get_id());
 }
};
#endif
