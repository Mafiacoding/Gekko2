#pragma once
#include <cstdint>

// Exact edge ownership for 12.4 GS coordinates. Interpolation is separate.
// The caller supplies the existing raster sample location in the same units.
struct GSFixedTriangleCoverage
{
    struct Edge
    {
        int64_t value = 0, stepX = 0, stepY = 0;
        bool inclusive = false;
        bool contains(int64_t sample) const { return sample > 0 || (sample == 0 && inclusive); }
    };
    Edge edges[3];
    int64_t area = 0;
    static int64_t orient(int32_t ax, int32_t ay, int32_t bx, int32_t by, int32_t px, int32_t py)
    {
        return int64_t(bx-ax)*(py-ay)-int64_t(by-ay)*(px-ax);
    }
    GSFixedTriangleCoverage(const int32_t (&xy)[6], int32_t sampleX, int32_t sampleY)
    {
        area = orient(xy[0],xy[1],xy[2],xy[3],xy[4],xy[5]);
        const int sign = area < 0 ? -1 : 1;
        area *= sign;
        for (unsigned i=0;i<3;++i)
        {
            const unsigned a=(i+1)%3,b=(i+2)%3;
            const int32_t dx=(xy[2*b]-xy[2*a])*sign;
            const int32_t dy=(xy[2*b+1]-xy[2*a+1])*sign;
            edges[i]={orient(xy[2*a],xy[2*a+1],xy[2*b],xy[2*b+1],sampleX,sampleY)*sign,
                      -int64_t(dy)*16,int64_t(dx)*16,dy<0||(dy==0&&dx>0)};
        }
    }
};
