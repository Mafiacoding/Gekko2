#pragma once
#include <vector>
#include <cstdint>
#include <cstring>
#include <algorithm>
#include <stdexcept>
// Expand tightly packed rows backwards in their own allocation. Sources are
// bounded and narrower than the destination; newly exposed borders are zero.
inline void Ps2ExpandFrame(std::vector<uint8_t>&pixels,uint32_t width,uint32_t height,uint32_t dstWidth,uint32_t dstHeight){
 if(width>dstWidth||height>dstHeight||pixels.size()<std::size_t(width)*height*4)
  throw std::runtime_error("Invalid host frame dimensions");
 pixels.resize(std::size_t(dstWidth)*dstHeight*4);
 for(uint32_t y=height;y>0;--y){
  auto *dst=pixels.data()+std::size_t(y-1)*dstWidth*4;
  std::memmove(dst,pixels.data()+std::size_t(y-1)*width*4,std::size_t(width)*4);
  std::memset(dst+std::size_t(width)*4,0,std::size_t(dstWidth-width)*4);
 }
 std::fill(pixels.begin()+std::size_t(height)*dstWidth*4,pixels.end(),0);
}
