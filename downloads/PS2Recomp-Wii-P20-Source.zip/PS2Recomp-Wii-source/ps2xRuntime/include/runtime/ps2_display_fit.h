#pragma once
#include <algorithm>
// Source framebuffer dimensions are texel dimensions, not the TV display
// aspect (e.g. a 640x224 PS2 field). Fit nominal PS2 4:3 to the actual TV.
struct Ps2DisplayRect{float x,y,width,height;};
inline Ps2DisplayRect Ps2FitDisplay(float width,float height,float hostAspect,float targetAspect=4.0f/3.0f){
 const float fraction=targetAspect/hostAspect;
 const float w=width*std::min(1.0f,fraction),h=height*std::min(1.0f,1.0f/fraction);
 return {(width-w)*0.5f,(height-h)*0.5f,w,h};
}
