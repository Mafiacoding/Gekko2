#pragma once
#include <streambuf>
#include <mutex>
#include <cstddef>
// Fixed memory, line-oriented sink; avoids relying on redirected newlib FILE
// descriptors being picked up by already-constructed C++ standard streams.
class Ps2LineLogBuffer final:public std::streambuf {
 void(*sink_)(const char*,std::size_t);std::mutex mutex_;char line_[512]{};std::size_t used_=0;
 void emit(){if(used_){sink_(line_,used_);used_=0;}}
 void append(char c){line_[used_++]=c;if(c=='\n'||used_==sizeof line_)emit();}
protected:
 int_type overflow(int_type c)override {std::lock_guard lock(mutex_);if(!traits_type::eq_int_type(c,traits_type::eof()))append(traits_type::to_char_type(c));return traits_type::not_eof(c);}
 std::streamsize xsputn(const char*s,std::streamsize n)override{std::lock_guard lock(mutex_);for(std::streamsize i=0;i<n;++i)append(s[i]);return n;}
 int sync()override{std::lock_guard lock(mutex_);emit();return 0;}
public:
 explicit Ps2LineLogBuffer(void(*sink)(const char*,std::size_t)):sink_(sink){}
};
