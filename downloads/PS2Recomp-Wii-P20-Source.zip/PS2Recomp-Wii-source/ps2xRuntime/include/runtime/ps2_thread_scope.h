#pragma once
#include <thread>
#include <utility>
// Construct immediately after an owned worker. Stop and join before the
// std::thread destructor on every scope exit, including exception unwinding.
// Stop must not throw; the owner must not join itself.
template<class Stop> class Ps2ThreadScope {
 std::thread &thread_;Stop stop_;
public:
 Ps2ThreadScope(std::thread &thread,Stop stop):thread_(thread),stop_(std::move(stop)){}
 Ps2ThreadScope(const Ps2ThreadScope&)=delete;
 Ps2ThreadScope& operator=(const Ps2ThreadScope&)=delete;
 ~Ps2ThreadScope(){stop_();if(thread_.joinable())thread_.join();}
};
