#pragma once
#include "ps2_wii_host.h"
#include <algorithm>
#include <array>
#include <cstdint>
#include <stdexcept>
inline int Ps2YuvByte(int v){return std::clamp(v,0,255);}
inline uint32_t Ps2YuvPair(Color a,Color b){
 int y0=((66*a.r+129*a.g+25*a.b+128)>>8)+16;
 int y1=((66*b.r+129*b.g+25*b.b+128)>>8)+16;
 int r=(int(a.r)+b.r)/2,g=(int(a.g)+b.g)/2,blue=(int(a.b)+b.b)/2;
 int u=((-38*r-74*g+112*blue+128)>>8)+128;
 int v=((112*r-94*g-18*blue+128)>>8)+128;
 return uint32_t(Ps2YuvByte(y0))<<24|uint32_t(Ps2YuvByte(u))<<16|uint32_t(Ps2YuvByte(y1))<<8|uint32_t(Ps2YuvByte(v));
}
inline void Ps2BlitYuv(uint32_t*p,int width,int height,const uint8_t*pixels,int tw,int th,Rectangle src,Rectangle dst){
 // Keep the original floating-point coordinate expression, but evaluate X
 // once per column and Y once per row instead of twice per pixel pair.
 if(width<=0||height<=0||width>1024||tw<=0||th<=0)throw std::runtime_error("Invalid Wii blit dimensions");
 std::array<int,1024> column;std::fill_n(column.begin(),width,-1);
 for(int x=0;x<width;++x)if(x>=dst.x&&x<dst.x+dst.width)
  column[x]=std::clamp(int(src.x+(x-dst.x)*src.width/dst.width),0,tw-1);
 for(int y=std::max(0,int(dst.y));y<std::min(height,int(dst.y+dst.height));++y){
  const int sy=y<dst.y||y>=dst.y+dst.height?-1:std::clamp(int(src.y+(y-dst.y)*src.height/dst.height),0,th-1);
  auto pixel=[&](int x){if(sy<0||x<0||x>=width||column[x]<0)return BLACK;
   const size_t offset=(size_t(sy)*tw+column[x])*4;
   return Color{pixels[offset],pixels[offset+1],pixels[offset+2],pixels[offset+3]};};
  for(int x=std::max(0,int(dst.x))&~1;x<std::min(width,int(dst.x+dst.width)+1);x+=2)
   p[(size_t(y)*width+x)/2]=Ps2YuvPair(pixel(x),pixel(x+1));
 }
}
struct Ps2BlitKey {
 uint32_t texture=0,consoleEpoch=0,clearPixel=0,width=0,height=0;uint64_t revision=0;
 std::array<float,8> rectangle{};
 bool operator==(const Ps2BlitKey&)const=default;
};
class Ps2PresentationCache {
 struct Slot{bool valid=false;Ps2BlitKey key;};Slot slots_[2];unsigned back_=0,draws_=0;
 bool clear_=false,prepared_=false;uint32_t clearPixel_=0;
public:
 void begin(unsigned back){back_=back;draws_=0;clear_=prepared_=false;}
 void clear(uint32_t p){clear_=true;prepared_=false;draws_=0;clearPixel_=p;}
 template<class Clear,class Draw>bool draw(Ps2BlitKey key,Clear clearFn,Draw drawFn){
  key.clearPixel=clearPixel_;auto&s=slots_[back_];
  if(clear_&&!draws_&&s.valid&&s.key==key){prepared_=true;++draws_;return false;}
  if(clear_&&!prepared_)clearFn(clearPixel_);
  drawFn();prepared_=true;
  if(clear_&&!draws_){s.valid=true;s.key=key;}else s.valid=false;
  ++draws_;return true;
 }
 template<class Clear>void finish(Clear clearFn){if(clear_&&!prepared_){clearFn(clearPixel_);slots_[back_].valid=false;prepared_=true;}}
};
