/* Preserve the first exception. Never walk a potentially corrupt backchain,
 * follow arbitrary pointers, resume execution, or access SD/IOS.
 * A fixed aligned RAM-only code window is sampled through both aliases before
 * changing video. This cannot read I-cache contents or establish a cache bug. */
#include <gccore.h>
#include <tuxedo/ppc/exception.h>
#include <stdint.h>
extern void VIDEO_SetFramebuffer(void*);
extern void __VIClearFramebuffer(void*,u32,u32);
extern void __console_init(void*,int,int,int,int,int);
#ifndef PS2X_WII_BUILD_ID
#define PS2X_WII_BUILD_ID "unknown"
#endif
static volatile unsigned entered;
static int readable_code_window(uintptr_t p){
 return !(p&3)&&((p>=0x80003404u&&(uint64_t)p+8<=0x81800000u)||
                  (p>=0x90002004u&&(uint64_t)p+8<=0x933e0000u));
}
static void code_window(uintptr_t pc,uint32_t cached[3],uint32_t ram[3]){
 for(unsigned i=0;i<3;i++){
  uintptr_t a=pc-4u+i*4u;
  cached[i]=*(volatile const uint32_t*)a;
  ram[i]=*(volatile const uint32_t*)(a|0x40000000u);
 }
}
static int readable_context(uintptr_t p){
 return !(p&3)&&((p>=0x80003400u&&(uint64_t)p+sizeof(PPCContext)<=0x81800000u)||(p>=0x90002000u&&(uint64_t)p+sizeof(PPCContext)<=0x933e0000u));
}
static void primary_panic(unsigned cause,PPCContext *ctx){
 if(entered++)for(;;)__asm__ volatile("sync");
 /* Snapshot only fixed context fields, before changing the display. */
 uint32_t dar,dsisr,pc=0,lr=0,msr=0,sp=0,regs[32]={0};
 __asm__ volatile("mfdar %0":"=r"(dar));__asm__ volatile("mfdsisr %0":"=r"(dsisr));
 uint32_t code_cached[3]={0},code_ram[3]={0};
 int code_valid=0;
 int valid=readable_context((uintptr_t)ctx);
 if(valid){pc=ctx->pc;lr=ctx->lr;msr=ctx->msr;sp=ctx->gpr[1];for(unsigned i=0;i<32;i++)regs[i]=ctx->gpr[i];}
 if(valid&&(code_valid=readable_code_window(pc)))code_window(pc,code_cached,code_ram);
 unsigned height=VIDEO_GetCurrentTvMode()==VI_PAL?574:480;
 void *frame=(void*)0xc1700000u;
 VIDEO_SetFramebuffer(frame);__VIClearFramebuffer(frame,height*640*2,COLOR_MAROON);
 __console_init(frame,32,32,576,(int)height-64,1280);
 kprintf("PS2Recomp PRIMARY PANIC - no stack walk\n");
 kprintf("BUILD %s\n",PS2X_WII_BUILD_ID);
 kprintf("EXCEPTION %u  CTX %08X  valid=%u\n",cause,(unsigned)(uintptr_t)ctx,valid);
 kprintf("PC %08X  LR %08X\nMSR %08X SP %08X\n",pc,lr,msr,sp);
 kprintf("DAR %08X DSISR %08X\n",dar,dsisr);
 kprintf("CODE_VALID %u  window=PC-4,PC,PC+4\n",code_valid);
 if(code_valid){
  kprintf("CODE_CACHED %08X %08X %08X\n",code_cached[0],code_cached[1],code_cached[2]);
  kprintf("CODE_RAM    %08X %08X %08X\n",code_ram[0],code_ram[1],code_ram[2]);
 }
 for(unsigned i=0;i<32;i+=4)kprintf("R%02u %08X  %08X  %08X  %08X\n",i,regs[i],regs[i+1],regs[i+2],regs[i+3]);
 kprintf("Stopped. Photograph this screen; power off afterwards.\n");
 for(;;)__asm__ volatile("sync");
}
void __SYS_InstallPanicHandler(void){PPCExcptCurPanicFn=primary_panic;}
