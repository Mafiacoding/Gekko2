#include "ps2_wii_host.h"
#include <atomic>
#include <cstdio>
extern "C" [[noreturn]] void __real_abort(void);
extern "C" [[noreturn]] void __real__Exit(int);
namespace {
 std::atomic_flag reporting=ATOMIC_FLAG_INIT;
 void record(const char *kind,int status){
  if(reporting.test_and_set())return;
  char text[80];std::snprintf(text,sizeof text,"process-%s status=%d",kind,status);
  PS2WiiCheckpoint(text);
 }
}
extern "C" [[noreturn]] void __wrap_abort(){record("abort",-1);__real_abort();}
extern "C" [[noreturn]] void __wrap__Exit(int status){record("_Exit",status);__real__Exit(status);}
