#include "ps2_wii_host.h"
#include "ps2_wii_blit.h"
#ifndef PS2X_WII_CONVERTERS_ENABLED
#define PS2X_WII_CONVERTERS_ENABLED 0
#endif
#ifndef PS2X_WII_BUILD_ID
#define PS2X_WII_BUILD_ID "unversioned"
#endif
#include <gccore.h>
#include <ogc/conf.h>
#include "runtime/ps2_line_log.h"
#include "runtime/ps2_bounded_log_file.h"
#include <iostream>
#include <wiiuse/wpad.h>
#include <ogc/lwp_watchdog.h>
#include <fat.h>
#include <ogc/libversion.h>
#include <unistd.h>
#include <algorithm>
#include <atomic>
#include <cstdlib>
#include <cstring>
#include <cstdio>
#include <stdexcept>
#include <map>
#include <vector>
namespace {
 GXRModeObj *mode=nullptr;void *xfb[2]{};unsigned back=0;
 std::atomic<bool> closed{false},connected{false};std::atomic<uint32_t> buttons{0},axes{0x80808080};
 float displayAspect=4.0f/3.0f;
 bool ready=false;uint64_t started=0,last=0;float delta=1.0f/60;
 struct Texture {int width,height;std::vector<Color> pixels;uint64_t revision=1;const uint8_t*view=nullptr;};
 Ps2PresentationCache frameCache;std::atomic<uint32_t>consoleEpoch{0};
 std::map<unsigned,Texture> textures;unsigned nextTexture=1;
 uint32_t yuv(Color a,Color b){return Ps2YuvPair(a,b);}
 void sample(){
  WPAD_ScanPads();uint32_t gc=PAD_ScanPads();uint32_t w=WPAD_ButtonsHeld(0),p=PAD_ButtonsHeld(0);uint32_t bits=0;
  auto set=[&](int n,bool on){if(on)bits|=1u<<n;};
  set(GAMEPAD_BUTTON_LEFT_FACE_UP,(w&WPAD_BUTTON_UP)||(p&PAD_BUTTON_UP));
  set(GAMEPAD_BUTTON_LEFT_FACE_DOWN,(w&WPAD_BUTTON_DOWN)||(p&PAD_BUTTON_DOWN));
  set(GAMEPAD_BUTTON_LEFT_FACE_LEFT,(w&WPAD_BUTTON_LEFT)||(p&PAD_BUTTON_LEFT));
  set(GAMEPAD_BUTTON_LEFT_FACE_RIGHT,(w&WPAD_BUTTON_RIGHT)||(p&PAD_BUTTON_RIGHT));
  set(GAMEPAD_BUTTON_RIGHT_FACE_DOWN,(w&WPAD_BUTTON_A)||(p&PAD_BUTTON_A));
  set(GAMEPAD_BUTTON_RIGHT_FACE_RIGHT,(w&WPAD_BUTTON_B)||(p&PAD_BUTTON_B));
  set(GAMEPAD_BUTTON_RIGHT_FACE_LEFT,(w&WPAD_BUTTON_1)||(p&PAD_BUTTON_X));
  set(GAMEPAD_BUTTON_RIGHT_FACE_UP,(w&WPAD_BUTTON_2)||(p&PAD_BUTTON_Y));
  set(GAMEPAD_BUTTON_MIDDLE_RIGHT,(w&WPAD_BUTTON_PLUS)||(p&PAD_BUTTON_START));
  set(GAMEPAD_BUTTON_MIDDLE_LEFT,w&WPAD_BUTTON_MINUS);
  set(GAMEPAD_BUTTON_LEFT_TRIGGER_1,p&PAD_TRIGGER_L);set(GAMEPAD_BUTTON_RIGHT_TRIGGER_1,p&PAD_TRIGGER_R);
  set(GAMEPAD_BUTTON_RIGHT_TRIGGER_2,p&PAD_TRIGGER_Z);
  buttons.store(bits);uint32_t type=0;connected.store((gc&1)||WPAD_Probe(0,&type)==WPAD_ERR_NONE);
  auto axis=[](int x){return uint32_t(std::clamp(x+128,0,255));};
  axes.store(axis(PAD_StickX(0))|axis(-int(PAD_StickY(0)))<<8|axis(PAD_SubStickX(0))<<16|axis(-int(PAD_SubStickY(0)))<<24);
  if(w&WPAD_BUTTON_HOME)closed.store(true);
 }
 void reset(uint32_t,void*){closed.store(true);}
 void power(){closed.store(true);}
 void remotePower(int){closed.store(true);}
 [[noreturn]] void noAudio(){throw std::runtime_error("Wii audio backend unavailable; enable only after porting");}
}
namespace {
 void runtimeLine(const char *s,std::size_t n){
  // Bound SD traffic and disk use. Boot markers and progress remain separate.
  Ps2AppendBoundedFile("sd:/ps2recomp/runtime.log",s,n,128*1024);
 }
}
extern void PS2WiiHeapInit();
void PS2WiiCheckpoint(const char *stage){
 kprintf("[BOOT] %s\n",stage);consoleEpoch.fetch_add(1);
 FILE *file=std::fopen("sd:/ps2recomp/boot-status.txt","a");
 if(!file){kprintf("[BOOT] checkpoint file open failed\n");return;}
 std::fprintf(file,"%s\n",stage);
 if(std::fflush(file)!=0)kprintf("[BOOT] checkpoint flush failed\n");
 if(std::fclose(file)!=0)kprintf("[BOOT] checkpoint close failed\n");
}
void PS2WiiBootstrap(){
 if(ready)return;
 VIDEO_Init();WPAD_Init();PAD_Init();mode=VIDEO_GetPreferredMode(nullptr);
 displayAspect=CONF_GetAspectRatio()==CONF_ASPECT_16_9?16.0f/9.0f:4.0f/3.0f;
 xfb[0]=MEM_K0_TO_K1(SYS_AllocateFramebuffer(mode));xfb[1]=MEM_K0_TO_K1(SYS_AllocateFramebuffer(mode));
 if(!xfb[0]||!xfb[1])throw std::bad_alloc();
 console_init(xfb[0],16,16,mode->fbWidth-32,mode->xfbHeight-32,mode->fbWidth*2);
 VIDEO_Configure(mode);VIDEO_SetNextFramebuffer(xfb[0]);VIDEO_SetBlack(false);VIDEO_Flush();VIDEO_WaitVSync();
 if(mode->viTVMode&VI_NON_INTERLACE)VIDEO_WaitVSync();
 SYS_SetPowerCallback(power);WPAD_SetPowerButtonCallback(remotePower);
 SYS_SetResetCallback(reset);started=last=gettime();ready=true;
 PS2WiiHeapInit();
 if(!fatInitDefault())throw std::runtime_error("SD/FAT mount failed");
 // Persist each startup marker independently of redirected standard streams.
 FILE *status=std::fopen("sd:/ps2recomp/boot-status.txt","w");
 if(!status)throw std::runtime_error("Cannot create sd:/ps2recomp/boot-status.txt");
 std::fprintf(status,"source=%s\n",PS2X_WII_BUILD_ID);std::fflush(status);std::fclose(status);
 PS2WiiCheckpoint("fat-ready");
 PS2WiiCheckpoint("stdout-open-begin");
 FILE *initialLog=std::fopen("sd:/ps2recomp/runtime.log","w");
 if(!initialLog)throw std::runtime_error("Cannot initialize runtime log");
 std::fprintf(initialLog,"PS2RECOMP_WII source=%s\n",PS2X_WII_BUILD_ID);
 std::fflush(initialLog);std::fclose(initialLog);
 if(!std::freopen("sd:/ps2recomp/runtime.log","a",stdout))throw std::runtime_error("Cannot open runtime stdout log");
 setvbuf(stdout,nullptr,_IONBF,0);
 PS2WiiCheckpoint("stdout-open-done");
 if(!std::freopen("sd:/ps2recomp/runtime.log","a",stderr))throw std::runtime_error("Cannot open runtime stderr log");
 setvbuf(stderr,nullptr,_IONBF,0);
 PS2WiiCheckpoint("stderr-open-done");
 static Ps2LineLogBuffer cppLog(runtimeLine);
 struct CppRouting {
  std::streambuf *out,*err,*log;
  explicit CppRouting(Ps2LineLogBuffer &b):out(std::cout.rdbuf(&b)),err(std::cerr.rdbuf(&b)),log(std::clog.rdbuf(&b)){}
  ~CppRouting(){std::cout.flush();std::cerr.flush();std::clog.flush();std::cout.rdbuf(out);std::cerr.rdbuf(err);std::clog.rdbuf(log);}
 };
 static CppRouting routing(cppLog);
 PS2WiiCheckpoint("cpp-log-sink-ready");
 PS2WiiCheckpoint("OPTIONS scalar_simd=1 renderer=software audio=disabled mpeg=disabled progress=1");
 std::printf("PS2RECOMP_WII experimental source=%s compiler=%s libogc=%d.%d.%d\n",PS2X_WII_BUILD_ID,__VERSION__,_V_MAJOR_,_V_MINOR_,_V_PATCH_);
 std::printf("OPTIONS scalar_simd=1 guest_little_endian=1 renderer=software audio=disabled mpeg=disabled\n");
 if(PS2X_WII_CONVERTERS_ENABLED)PS2WiiCheckpoint("OPTIONS ee_native_float_convert=1 presentation_cache=1");
 else PS2WiiCheckpoint("OPTIONS ee_native_float_convert=0 presentation_cache=1");
 PS2WiiCheckpoint("bootstrap-ready");
 sample();
}
void InitWindow(int,int,const char *title){PS2WiiBootstrap();std::printf("%s\nWii experimental runtime, HOME exits, audio disabled\n",title);}
void CloseWindow(){closed.store(true);}bool IsWindowReady(){return ready;}
void SetConfigFlags(unsigned){}void SetTargetFPS(int){}
bool WindowShouldClose(){return closed.load();}
float PS2WiiDisplayAspect(){return displayAspect;}
int GetScreenWidth(){return mode?mode->fbWidth:640;}int GetScreenHeight(){return mode?mode->xfbHeight:480;}
double GetTime(){return double(ticks_to_microsecs(gettime()-started))/1000000;}
float GetFrameTime(){return delta;}
void BeginDrawing(){sample();back^=1;frameCache.begin(back);}
void ClearBackground(Color c){frameCache.clear(yuv(c,c));}
void EndDrawing(){frameCache.finish([](uint32_t color){auto*p=static_cast<uint32_t*>(xfb[back]);std::fill(p,p+GetScreenWidth()*GetScreenHeight()/2,color);});VIDEO_SetNextFramebuffer(xfb[back]);VIDEO_Flush();VIDEO_WaitVSync();uint64_t now=gettime();delta=float(ticks_to_microsecs(now-last))/1000000;last=now;}
Image GenImageColor(int w,int h,Color c){if(w<=0||h<=0||w>2048||h>2048)throw std::runtime_error("invalid image size");auto *p=static_cast<Color*>(std::malloc(size_t(w)*h*4));if(!p)throw std::bad_alloc();std::fill(p,p+size_t(w)*h,c);return {p,w,h,1,7};}
void UnloadImage(Image i){std::free(i.data);}
Texture2D LoadTextureFromImage(Image i){unsigned id=nextTexture++;Texture t{i.width,i.height,{}};t.pixels.assign(static_cast<Color*>(i.data),static_cast<Color*>(i.data)+size_t(i.width)*i.height);textures.emplace(id,std::move(t));return{id,i.width,i.height,1,7};}
void UnloadTexture(Texture2D t){textures.erase(t.id);}
void UpdateTexture(Texture2D t,const void *data){auto &v=textures.at(t.id);v.pixels.resize(size_t(v.width)*v.height);std::memcpy(v.pixels.data(),data,v.pixels.size()*4);v.view=nullptr;++v.revision;}
void PS2WiiTextureView(Texture2D t,const void*data){auto&v=textures.at(t.id);std::vector<Color>().swap(v.pixels);v.view=static_cast<const uint8_t*>(data);++v.revision;}
void DrawTexturePro(Texture2D tex,Rectangle src,Rectangle dst,Vector2 origin,float rotation,Color tint){
 if(rotation||origin.x||origin.y||tint.r!=255||tint.g!=255||tint.b!=255||tint.a!=255)throw std::runtime_error("unsupported Wii host blit transform");
 if(dst.width<=0||dst.height<=0||src.width<=0||src.height<=0)return;
 auto &t=textures.at(tex.id);uint32_t*p=static_cast<uint32_t*>(xfb[back]);int width=GetScreenWidth(),height=GetScreenHeight();
 Ps2BlitKey key;key.texture=tex.id;key.revision=t.revision;key.consoleEpoch=consoleEpoch.load();key.width=width;key.height=height;
 key.rectangle={src.x,src.y,src.width,src.height,dst.x,dst.y,dst.width,dst.height};
 frameCache.draw(key,[&](uint32_t color){std::fill(p,p+size_t(width)*height/2,color);},
  [&]{if(!t.view&&t.pixels.empty())throw std::runtime_error("Detached Wii texture view");
   Ps2BlitYuv(p,width,height,t.view?t.view:reinterpret_cast<const uint8_t*>(t.pixels.data()),t.width,t.height,src,dst);});
}
bool IsGamepadAvailable(int n){return n==0&&connected.load();}
bool IsGamepadButtonDown(int n,int b){return n==0&&b>0&&b<32&&(buttons.load()&(1u<<b));}
float GetGamepadAxisMovement(int n,int a){return n==0&&a>=0&&a<4?(int((axes.load()>>(8*a))&255)-128)/128.0f:0;}
bool IsKeyDown(int){return false;}
void InitAudioDevice(){}void CloseAudioDevice(){}bool IsAudioDeviceReady(){return false;}
Wave LoadWaveFromMemory(const char*,const unsigned char*,int){noAudio();}Sound LoadSoundFromWave(Wave){noAudio();}
void UnloadWave(Wave){noAudio();}void UnloadSound(Sound){noAudio();}void PlaySound(Sound){noAudio();}void StopSound(Sound){noAudio();}
bool IsSoundPlaying(Sound){return false;}void SetSoundPitch(Sound,float){noAudio();}void SetSoundVolume(Sound,float){noAudio();}
