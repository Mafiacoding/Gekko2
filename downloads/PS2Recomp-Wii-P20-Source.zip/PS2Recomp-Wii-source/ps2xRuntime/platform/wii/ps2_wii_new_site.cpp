#include <gccore.h>
#include <atomic>
#include <cstddef>
#include <cstdint>
// Fixed per-LWP nesting markers: no native TLS, pthread keys or allocations.
// These record the C++ allocation call site, not an unsafe stack walk at OOM.
namespace {
 std::atomic<bool> enabled{false};
 std::atomic<uint32_t> owners[16]{},sites[16]{};
 std::atomic<uint32_t>* slot(){
  if(!enabled.load())return nullptr;
  const uint32_t id=LWP_GetSelf();if(!id)return nullptr;
  for(unsigned i=0;i<16;++i){auto owner=owners[i].load();if(owner==id)return &sites[i];
   if(owner==0&&owners[i].compare_exchange_strong(owner,id))return &sites[i];}
  return nullptr;
 }
 struct Marker {std::atomic<uint32_t>*site;uint32_t old;
  explicit Marker(uint32_t pc):site(slot()),old(site?site->load():0){if(site&&!old)site->store(pc);}
  ~Marker(){if(site)site->store(old);}
 };
}
extern "C" void*__real__Znwj(std::size_t);
extern "C" void*__real__Znaj(std::size_t);
extern "C" void*__wrap__Znwj(std::size_t n){Marker marker(uint32_t(uintptr_t(__builtin_return_address(0))));return __real__Znwj(n);}
extern "C" void*__wrap__Znaj(std::size_t n){Marker marker(uint32_t(uintptr_t(__builtin_return_address(0))));return __real__Znaj(n);}
extern "C" uint32_t PS2WiiCurrentNewSite(){auto*s=slot();return s?s->load():0;}

extern "C" void PS2WiiNewSitesEnable(){enabled.store(true);}
