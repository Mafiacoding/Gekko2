#!/usr/bin/env python3
"""Execute the real EE math ABI helpers/stubs and SDK libm on emulated PPC750."""
from pathlib import Path
import subprocess,tempfile,struct,math,re,json,argparse
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *
parser=argparse.ArgumentParser();parser.add_argument('--devkitppc',type=Path,required=True);parser.add_argument('--output',type=Path);args=parser.parse_args()
root=Path(__file__).resolve().parents[2];cc=args.devkitppc/'bin/powerpc-eabi-g++'
s=(root/'ps2xRuntime/src/lib/Kernel/Stubs/LibC.cpp').read_text();bodies=[]
for name in ['sin','cos','sqrt']:
 m=re.search(r'    void '+name+r'\(uint8_t \*rdram, R5900Context \*ctx, PS2Runtime \*runtime\)\n    \{',s);a=m.start();b=m.end();depth=1
 while depth:
  if s[b]=='{':depth+=1
  if s[b]=='}':depth-=1
  b+=1
 bodies.append(s[a:b])
source=r'''
#include "runtime/ps2_ee_math_abi.h"
#include "runtime/ps2_soft_float_bits.h"
#include <cmath>
#include <cstddef>
extern "C" void*memset(void*p,int value,size_t n){auto*d=(volatile unsigned char*)p;for(size_t i=0;i<n;++i)d[i]=value;return p;}
extern "C" void*memcpy(void*d,const void*s,size_t n){auto*p=(volatile unsigned char*)d;auto*q=(const volatile unsigned char*)s;for(size_t i=0;i<n;++i)p[i]=q[i];return d;}
extern "C" int*__errno(){static int error;return &error;}
struct R5900Context{__m128i r[32]{};float f[32]{};};struct PS2Runtime{};
'''+ '\n'.join(bodies)+r'''
extern "C" void cases(const uint32_t*in,uint32_t*out){
 R5900Context c;PS2Runtime runtime;c.r[4]=_mm_set_epi64x(0x1234,int64_t((uint64_t(in[1])<<32)|in[0]));c.f[12]=12345.0f;c.f[0]=9876.0f;
 auto emit=[&]{auto bits=uint64_t(_mm_extract_epi64(c.r[2],0));*out++=uint32_t(bits);*out++=uint32_t(bits>>32);};
 sin(nullptr,&c,&runtime);emit();cos(nullptr,&c,&runtime);emit();sqrt(nullptr,&c,&runtime);emit();
 *out++=std::bit_cast<uint32_t>(c.f[12]);*out++=std::bit_cast<uint32_t>(c.f[0]);
 uint64_t wide=0;bool a=Ps2TryF32ToF64(in[2],wide);*out++=a;*out++=uint32_t(wide);*out++=uint32_t(wide>>32);
 uint32_t narrow=0;bool b=Ps2TryF64ToF32((uint64_t(in[1])<<32)|in[0],narrow);*out++=b;*out++=narrow;
}
'''
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'test.cpp').write_text(source)
 subprocess.run([str(cc),'-std=c++20','-O2','-mcpu=750','-meabi','-mno-altivec','-mno-vsx','-DPS2X_WII_SCALAR_SIMD','-I'+str(root/'ps2xRuntime/include'),'-nostdlib','-Wl,--gc-sections','-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(p/'test.cpp'),'-lm','-lgcc','-o',str(p/'test.elf')],check=True)
 data=(p/'test.elf').read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',data,28)[0];step,count=struct.unpack_from('>HH',data,42)
 for i in range(count):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',data,ph+i*step)
  if kind==1:u.mem_write(addr,data[off:off+length])
 entry=struct.unpack_from('>I',data,24)[0]
 for value in [0.0,-0.0,0.25,0.5,1.0,math.pi/2,math.pi,16.0,65535.0]:
  bits=struct.unpack('>Q',struct.pack('>d',value))[0];f=struct.unpack('>I',struct.pack('>f',value))[0]
  u.mem_write(0x90000000,struct.pack('>3I',bits&0xffffffff,bits>>32,f));u.reg_write(UC_PPC_REG_1,0x801fe000);u.reg_write(UC_PPC_REG_3,0x90000000);u.reg_write(UC_PPC_REG_4,0x90001000);u.reg_write(UC_PPC_REG_LR,0x80001000);u.reg_write(UC_PPC_REG_MSR,0x2000)
  u.emu_start(entry,0x80001000,count=1000000);assert u.reg_read(UC_PPC_REG_PC)==0x80001000
  result=struct.unpack('>13I',u.mem_read(0x90001000,52))
  for i,expected in enumerate([math.sin(value),math.cos(value),math.sqrt(value)]):
   actual=struct.unpack('>d',struct.pack('>Q',(result[i*2+1]<<32)|result[i*2]))[0]
   assert math.isclose(actual,expected,rel_tol=2e-14,abs_tol=1e-15),(value,i,actual,expected)
  assert result[6]==struct.unpack('>I',struct.pack('>f',12345.0))[0]
  assert result[7]==struct.unpack('>I',struct.pack('>f',9876.0))[0]
  assert result[8]==1 and ((result[10]<<32)|result[9])==struct.unpack('>Q',struct.pack('>d',struct.unpack('>f',struct.pack('>I',f))[0]))[0]
  assert result[11]==1 and result[12]==f
 report=dict(cases=9,math_results=27,matched=True,scope='actual PPC750 libm and GPR/FPR ABI plus conversion bits',physical_wii=False)
 if args.output:args.output.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
