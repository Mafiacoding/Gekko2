#include "ps2_wii_blit.h"
#include <cassert>
#include <cstdio>
#include <random>
#include <vector>
#include <algorithm>
static uint32_t oldYuv(Color a,Color b){int y0=((66*a.r+129*a.g+25*a.b+128)>>8)+16,y1=((66*b.r+129*b.g+25*b.b+128)>>8)+16;
 int r=(int(a.r)+b.r)/2,g=(int(a.g)+b.g)/2,bl=(int(a.b)+b.b)/2;
 auto byte=[](int v){return std::clamp(v,0,255);};return uint32_t(byte(y0))<<24|uint32_t(byte(((-38*r-74*g+112*bl+128)>>8)+128))<<16|uint32_t(byte(y1))<<8|uint32_t(byte(((112*r-94*g-18*bl+128)>>8)+128));}
static void reference(uint32_t*p,int width,int height,const Color*image,int tw,int th,Rectangle src,Rectangle dst){
 auto pixel=[&](int x,int y){if(x<dst.x||y<dst.y||x>=dst.x+dst.width||y>=dst.y+dst.height)return BLACK;
 int sx=std::clamp(int(src.x+(x-dst.x)*src.width/dst.width),0,tw-1),sy=std::clamp(int(src.y+(y-dst.y)*src.height/dst.height),0,th-1);return image[size_t(sy)*tw+sx];};
 for(int y=std::max(0,int(dst.y));y<std::min(height,int(dst.y+dst.height));++y)for(int x=std::max(0,int(dst.x))&~1;x<std::min(width,int(dst.x+dst.width)+1);x+=2)p[(size_t(y)*width+x)/2]=oldYuv(pixel(x,y),pixel(x+1,y));
}
int main(){
 std::mt19937 rng(0x750);std::vector<Color> image(13*17);for(auto&c:image)c={uint8_t(rng()),uint8_t(rng()),uint8_t(rng()),255};
 for(unsigned i=0;i<100;++i){std::vector<uint32_t>a(64*48/2,0x12345678),b=a;
  Rectangle src{float(int(rng()%5)-2),float(int(rng()%5)-2),float(1+rng()%20),float(1+rng()%20)};
  Rectangle dst{float(int(rng()%30)-15)+.25f,float(int(rng()%20)-10)+.75f,float(1+rng()%90),float(1+rng()%70)};
  reference(a.data(),64,48,image.data(),13,17,src,dst);Ps2BlitYuv(b.data(),64,48,reinterpret_cast<const uint8_t*>(image.data()),13,17,src,dst);assert(a==b);
 }
 Ps2PresentationCache cache;std::vector<uint32_t> actual[2],expected[2];
 for(int b=0;b<2;++b){actual[b].assign(32,0);expected[b]=actual[b];}
 unsigned draws=0,rendered=0;
 for(unsigned frame=0;frame<500;++frame){auto back=frame%2;cache.begin(back);
  if(frame%71==0){actual[back][31]=expected[back][31]=99;} // console mutation between frames
  auto clear=[&](uint32_t c){std::fill(actual[back].begin(),actual[back].end(),c);};
  auto requestClear=[&](uint32_t c){std::fill(expected[back].begin(),expected[back].end(),c);cache.clear(c);};
  if(frame%7)requestClear(4);
  auto draw=[&](unsigned texture,unsigned revision){Ps2BlitKey key;key.texture=texture;key.revision=revision;key.consoleEpoch=frame/71;
   auto paint=[&](std::vector<uint32_t>&p){for(unsigned i=texture;i<24;i+=3)p[i]=texture*100+revision;};
   paint(expected[back]);++draws;if(cache.draw(key,clear,[&]{paint(actual[back]);}))++rendered;
  };
  if(frame%9)draw(1,frame/31);
  if(frame%17==0)draw(2,frame/23);
  if(frame%19==0){requestClear(8);if(frame%2)draw(3,frame/29);}
  cache.finish(clear);if(actual[back]!=expected[back]){std::fprintf(stderr,"cache mismatch frame=%u\n",frame);for(unsigned i=0;i<32;++i)if(actual[back][i]!=expected[back][i])std::fprintf(stderr,"%u %u %u\n",i,actual[back][i],expected[back][i]);}assert(actual[back]==expected[back]);
 }
 assert(rendered<draws);
}
