#!/usr/bin/env python3
"""End-to-end synthetic ELF regression; no commercial game code required."""
import pathlib, struct, subprocess, sys, tempfile

def fixture(path):
    text = bytearray(0x11c)
    for index in range(16):
        # Each selectable leaf returns its index, with an observable delay slot.
        struct.pack_into('<4I', text, index*16, 0x24020000|index, 0x03e00008, 0x24630001, 0)
    struct.pack_into('<7I', text, 0x100,
                     0x3c090020, 0x308a000f, 0x21290000,
                     0x000a5100, 0x012a4820, 0x01200008, 0)
    names=b'\0.text\0.symtab\0.strtab\0.shstrtab\0'
    strings=b'\0dispatch\0'
    symbols=bytes(16)+struct.pack('<IIIBBH',1,0x200100,28,0x12,0,1)
    sections=[bytes(40)]
    data=bytearray(52)
    for name,kind,flags,address,payload,link,info,align,entry in [
        (1,1,6,0x200000,text,0,0,4,0),
        (7,2,0,0,symbols,3,1,4,16),
        (15,3,0,0,strings,0,0,1,0),
        (23,3,0,0,names,0,0,1,0)]:
        while len(data)%align:data.append(0)
        offset=len(data); data+=payload
        sections.append(struct.pack('<10I',name,kind,flags,address,offset,len(payload),link,info,align,entry))
    while len(data)%4:data.append(0)
    shoff=len(data);data+=b''.join(sections)
    data[:52]=struct.pack('<16sHHIIIIIHHHHHH',b'\x7fELF\x01\x01\x01'+bytes(9),2,8,1,0x200100,0,shoff,0,52,0,0,40,5,4)
    path.write_bytes(data)

with tempfile.TemporaryDirectory() as temp:
    root=pathlib.Path(temp); fixture(root/'fixture.elf')
    (root/'config.toml').write_text('[general]\ninput = "'+str(root/'fixture.elf')+'"\noutput = "'+str(root/'out')+'"\nlow_memory_mode = true\n')
    result=subprocess.run([sys.argv[1],str(root/'config.toml')],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    if result.returncode:raise RuntimeError(result.stdout)
    output=root/'out'
    registration=(output/'register_functions.cpp').read_text()
    owners=list(output.glob('computed_dispatch_200000*.cpp'))
    assert len(owners)==1, result.stdout
    generated=owners[0].read_text()
    for index in range(16):
        address=0x200000+16*index
        line=next(line for line in registration.splitlines() if '// 0x'+format(address,'x') in line)
        assert 'computed_dispatch_200000' in line,line
        assert hex(address+8)[2:] in generated # delay slot remains in owner
    # Execute the actual emitted owner, including all return delay slots.
    # Minimal test context/macros isolate code generation from device emulation.
    body='\n'.join(line for line in generated.splitlines() if not line.startswith('#include'))
    harness = r"""
#include <cstdint>
#include <cassert>
struct R5900Context { uint32_t pc=0, branch_pc=0, gpr[32]{}; bool in_delay_slot=false; };
struct PS2Runtime {};
#define GPR_U32(c,r) ((c)->gpr[r])
#define SET_GPR_S32(c,r,v) ((c)->gpr[r]=uint32_t(v))
#define ADD32(a,b) (uint32_t(a)+uint32_t(b))
""" + body + r"""
int main() {
 for (uint32_t i=0;i<16;++i) {
  uint8_t memory[16]{}; R5900Context c; PS2Runtime runtime;
  c.pc=0x200000+16*i; c.gpr[3]=41; c.gpr[31]=0x12345678;
  computed_dispatch_200000_0x200000(memory,&c,&runtime);
  assert(c.gpr[2]==i && c.gpr[3]==42 && c.pc==0x12345678);
 }
}
"""
    (root/'execute.cpp').write_text(harness)
    subprocess.run(['c++','-std=c++20','-fsanitize=undefined,address',str(root/'execute.cpp'),'-o',str(root/'execute')],check=True)
    subprocess.run([str(root/'execute')],check=True)
    print('PASS: synthetic ELF, 16 computed destinations, one whole owner, delay slots retained')
