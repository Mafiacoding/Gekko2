#!/usr/bin/env python3
"""Check actual GS HWREG serialization on big-endian PPC, not a host mock."""
import argparse, json, struct, subprocess, tempfile
from pathlib import Path
from unicorn import Uc, UC_ARCH_PPC, UC_MODE_PPC32, UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *
p=argparse.ArgumentParser();p.add_argument('--devkitppc',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/gs/gs_frontend.cpp').read_text()
body=s.split('case GS_REG_HWREG:',1)[1].split('break;',1)[0]
source='''#include "runtime/ps2_guest_memory.h"
extern "C" void*memcpy(void*d,const void*s,size_t n){auto*p=(volatile unsigned char*)d;auto*q=(const volatile unsigned char*)s;for(size_t i=0;i<n;++i)p[i]=q[i];return d;}
struct Sink {uint8_t*out;void processImageData(const uint8_t*p,unsigned n){for(unsigned i=0;i<n;++i)out[i]=p[i];}void write(uint64_t value) BODY }};
extern "C" void cases(const uint32_t*in,uint8_t*out){Sink s{out};s.write((uint64_t(in[1])<<32)|in[0]);}
'''.replace('BODY',body)
with tempfile.TemporaryDirectory(prefix='gs-hwreg-') as td:
 d=Path(td);(d/'test.cpp').write_text(source);elf=d/'test.elf'
 subprocess.run([str(a.devkitppc/'bin/powerpc-eabi-g++'),'-std=c++20','-O2','-mcpu=750','-meabi','-mno-altivec','-mno-vsx','-DPS2X_WII_SCALAR_SIMD','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),'-nostdlib','-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(d/'test.cpp'),'-lgcc','-o',str(elf)],check=True)
 b=elf.read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',b,28)[0];step,n=struct.unpack_from('>HH',b,42)
 for i in range(n):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',b,ph+i*step)
  if kind==1:u.mem_write(addr,b[off:off+length])
 entry=struct.unpack_from('>I',b,24)[0]
 vectors=[0,0xffffffffffffffff,0x8070605040302010]+[1<<i for i in range(64)]
 for value in vectors:
  u.mem_write(0x90000000,struct.pack('>II',value&0xffffffff,value>>32))
  for r,v in ((UC_PPC_REG_1,0x801fe000),(UC_PPC_REG_3,0x90000000),(UC_PPC_REG_4,0x90001000),(UC_PPC_REG_LR,0x80001000),(UC_PPC_REG_MSR,0x2000)):u.reg_write(r,v)
  u.emu_start(entry,0x80001000,count=10000)
  assert bytes(u.mem_read(0x90001000,8))==value.to_bytes(8,'little'),hex(value)
 assert (0x8070605040302010).to_bytes(8,'big')!=(0x8070605040302010).to_bytes(8,'little')
 report=dict(cases=len(vectors),matched=True,physical_wii=False,scope='production GS HWREG case on compiled PPC750; transfer payload byte order')
 a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
