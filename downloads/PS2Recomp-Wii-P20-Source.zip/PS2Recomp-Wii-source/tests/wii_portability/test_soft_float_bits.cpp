#include "runtime/ps2_soft_float_bits.h"
#include <bit>
#include <random>
#include <cassert>
#include <cfenv>
#include <vector>
struct Case{uint64_t input;uint32_t output;};
int main(){
 std::mt19937 rng(0x750);std::vector<Case>cases;
 for(unsigned i=0;i<100000;++i){
  auto bits=rng();uint64_t out;if(Ps2TryF32ToF64(bits,out))assert(out==std::bit_cast<uint64_t>(double(std::bit_cast<float>(uint32_t(bits)))));
  uint64_t wide=(uint64_t(rng())<<32)|rng();uint32_t narrow;
  if(Ps2TryF64ToF32(wide,narrow)){assert(narrow==std::bit_cast<uint32_t>(float(std::bit_cast<double>(wide))));if(cases.size()<1000)cases.push_back({wide,narrow});}
 }
 for(auto mode:{FE_TONEAREST,FE_DOWNWARD,FE_UPWARD,FE_TOWARDZERO}){
  std::fesetround(mode);for(auto c:cases){uint32_t out;assert(Ps2TryF64ToF32(c.input,out)&&out==c.output);}
 }
 uint64_t wide;uint32_t narrow;
 assert(!Ps2TryF32ToF64(0x7f800000,wide));assert(!Ps2TryF32ToF64(1,wide));
 assert(!Ps2TryF64ToF32(0x7ff0000000000000ull,narrow));assert(!Ps2TryF64ToF32(1,narrow));
 assert(Ps2TryF32ToF64(0x80000000,wide)&&wide==0x8000000000000000ull);
 assert(Ps2TryF64ToF32(0x8000000000000000ull,narrow)&&narrow==0x80000000);
}
