#!/usr/bin/env python3
"""Compile the actual scheduler event pump with a deterministic queue fixture."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/Kernel/EeScheduler.cpp').read_text();a=s.index('void EeScheduler::processPendingEvents()');b=s.index('\nvoid EeScheduler::',a+10);body=s[a:b]
prefix=r'''
#include <atomic>
#include <cstdint>
#include <vector>
#include <deque>
#include <mutex>
#include <cassert>
struct EeEvent{unsigned id;};
struct Memory{std::vector<uint32_t> completed;auto consumeCompletedDmacCauses(){std::vector<uint32_t> r;r.swap(completed);return r;}};
struct Runtime{Memory mem;Memory&memory(){return mem;}};
class EeScheduler{
public:
 Runtime m_runtime;uint32_t m_pendingEeTimerInterrupts=0;std::mutex m_eventMutex;std::deque<EeEvent> m_events;
 std::atomic<uint64_t>m_nextDeadlineCycle{0};uint64_t m_eeCycle=0;std::atomic<bool>m_stopRequested{false},m_checkpointPending{false};
 std::vector<unsigned> dma,timers,events;unsigned preemptions=0;
 void assertExecutor(){}void processDueDeadlines(){}
 void dispatchIrq(bool dmac,unsigned cause){(dmac?dma:timers).push_back(cause);}
 void processEvent(EeEvent e){events.push_back(e.id);}
 void applyPendingPreemption(){++preemptions;}
 void processPendingEvents();
};
'''
main=r'''
int main(){
 EeScheduler s;s.m_runtime.mem.completed={1,2};s.m_pendingEeTimerInterrupts=4;s.m_events.push_back({7});
 // No guest Store32: completed DMA still reaches the normal IRQ dispatcher.
 s.processPendingEvents();assert((s.dma==std::vector<unsigned>{1,2}));
 assert((s.timers==std::vector<unsigned>{11}));assert(s.events[0]==7);assert(s.preemptions==1);
 s.processPendingEvents();assert(s.dma.size()==2&&s.timers.size()==1); // no duplicates
 s.m_runtime.mem.completed={1};auto deliveredByStore=s.m_runtime.mem.consumeCompletedDmacCauses();assert(deliveredByStore.size()==1);
 s.processPendingEvents();assert(s.dma.size()==2); // already consumed by Store32
 s.m_runtime.mem.completed={1};s.processPendingEvents();assert(s.dma.size()==3); // later real transfer
}
'''
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'test.cpp').write_text(prefix+body+main)
 subprocess.run(['c++','-std=c++20','-pthread','-fsanitize=address,undefined',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: scheduler DMA delivery without Store32, exactly once, timers/events retained')
