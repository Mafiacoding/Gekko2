#!/usr/bin/env python3
"""Compile the production VCLIP emitter body and check plane ordering/history."""
from pathlib import Path
import re,json,subprocess,tempfile,argparse
root=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--translator',type=Path,default=root/'ps2xRecomp/src/lib/vu_translator.cpp');args=parser.parse_args()
s=args.translator.read_text()
s=s.split('case VU0_S2_VCLIPw:',1)[1].split('case VU0_S2_VNOP:',1)[0].split('return fmt::format(',1)[1].split('inst.rd,',1)[0]
body=''.join(json.loads('"'+x+'"') for x in re.findall(r'"((?:[^"\\]|\\.)*)"',s)).format(2,3,3,'_MM_SHUFFLE(3,3,3,3)')
source=r'''
#include <immintrin.h>
#include <cstdint>
#include <cmath>
#include <cassert>
#include <cstdio>
#include <random>
struct Context{__m128 vu0_vf[32]{};uint32_t vu0_clip_flags=0;};
void emitted(Context*ctx){BODY}
int main(){Context ctx;std::mt19937 random(1234);unsigned count=0;
 for(unsigned i=0;i<10000;++i){
  float fs[4],ft[4]={0,0,0,0};
  for(unsigned c=0;c<4;++c)fs[c]=float(int(random()%20001)-10000)/32;
  ft[3]=(i%2?-1.0f:1.0f)*float(random()%10000)/32;
  if(i<12){for(auto&f:fs)f=0;ft[3]=i%2?-1:1;fs[(i/2)%3]=i%2?-2:2;}
  ctx.vu0_vf[2]=_mm_loadu_ps(fs);ctx.vu0_vf[3]=_mm_loadu_ps(ft);
  uint32_t flags=0;for(unsigned c=0;c<3;++c){if(fs[c]>std::fabs(ft[3]))flags|=1u<<(c*2);if(fs[c]<-std::fabs(ft[3]))flags|=2u<<(c*2);}
  uint32_t expected=((ctx.vu0_clip_flags<<6)|flags)&0xffffffu;
  emitted(&ctx);assert(ctx.vu0_clip_flags==expected);++count;
 }std::printf("PASS: %u production VCLIP vectors, plane ordering, negative W, 24-bit history\n",count);
}
'''.replace('BODY',body)
with tempfile.TemporaryDirectory(prefix='ps2-vclip-') as tmp:
 d=Path(tmp);(d/'test.cpp').write_text(source)
 subprocess.run(['g++','-std=c++20','-O1','-msse4.1','-fsanitize=address,undefined',str(d/'test.cpp'),'-o',str(d/'test')],check=True)
 subprocess.run([str(d/'test')],check=True)
