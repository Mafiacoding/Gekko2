#!/usr/bin/env python3
"""Replay a linked PPC guest Read128 helper with synthetic data only.

Memory mappings are modeled, translation/interrupts disabled. This is not a
physical Wii exception reproduction. Supply exact addresses for the linked ELF.
"""
from pathlib import Path
import struct,json,argparse
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN,UC_HOOK_MEM_READ,UC_HOOK_MEM_WRITE
from unicorn.ppc_const import *
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--elf',type=Path,required=True)
parser.add_argument('--helper',type=lambda v:int(v,0),required=True)
parser.add_argument('--reported-pc',type=lambda v:int(v,0),required=True)
parser.add_argument('--output',type=Path)
args=parser.parse_args()
elf=args.elf.read_bytes()
if len(elf)<52 or elf[:7]!=b'\x7fELF\x01\x02\x01' or struct.unpack_from('>H',elf,18)[0]!=20:
 raise SystemExit('Expected ELF32 big-endian PPC')
if args.helper&3 or args.reported_pc&3:raise SystemExit('Unaligned code address')
u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x1800000);u.mem_map(0x90000000,0x4000000)
ph=struct.unpack_from('>I',elf,28)[0];step,n=struct.unpack_from('>HH',elf,42)
if step<32 or ph+step*n>len(elf):raise SystemExit('Truncated program headers')
executable=[]
for i in range(n):
 kind,off,addr,_,length,*_=struct.unpack_from('>8I',elf,ph+i*step)
 if kind==1 and length:
  if off+length>len(elf) or not (0x80003400<=addr and addr+length<=0x81800000 or 0x90002000<=addr and addr+length<=0x93400000):raise SystemExit('Invalid ELF load range')
  u.mem_write(addr,elf[off:off+length])
  if struct.unpack_from('>I',elf,ph+i*step+24)[0]&1:executable.append((addr,addr+length))
if not all(any(a<=pc and pc+4<=b for a,b in executable) for pc in (args.helper,args.reported_pc)):raise SystemExit('Requested code address is not executable ELF input')
violations=[]
def access(uc,kind,address,size,value,unused):
 if size in (2,4,8) and address%size:violations.append((uc.reg_read(UC_PPC_REG_PC),address,size))
u.hook_add(UC_HOOK_MEM_READ|UC_HOOK_MEM_WRITE,access)
base=0x9114b680;out=0x90a93be0;stop=0x80001000;count=0
# The helper at the screenshot's LR call site, with recorded guest SP and
# nearby/alignment/wrap variants. No guest instruction or asset fixture.
for address in [0x1effdb0+i for i in range(-16,17)]+[0x1ffffff-i for i in range(16)]:
 data=bytes((i*23+19)&255 for i in range(16))
 for i,v in enumerate(data):u.mem_write(base+((address+i)&0x1ffffff),bytes([v]))
 u.mem_write(out,bytes(16));u.reg_write(UC_PPC_REG_1,0x90a93bd0);u.reg_write(UC_PPC_REG_3,out);u.reg_write(UC_PPC_REG_4,base);u.reg_write(UC_PPC_REG_5,address);u.reg_write(UC_PPC_REG_LR,stop);u.reg_write(UC_PPC_REG_MSR,0x2000)
 u.emu_start(args.helper,stop,count=50000)
 assert u.reg_read(UC_PPC_REG_PC)==stop
 expected=b''.join(data[i:i+4][::-1] for i in range(0,16,4))
 assert bytes(u.mem_read(out,16))==expected
 count+=1
assert not violations,violations
# Check a pure ADDI at the reported PC, rather than assuming it can align-fault.
word=struct.unpack('>I',u.mem_read(args.reported_pc,4))[0]
assert word>>26==14,'Reported PC is not ADDI; use the disassembly, do not guess'
ra=(word>>16)&31;rt=(word>>21)&31;imm=word&65535;imm=imm-65536 if imm&32768 else imm
u.reg_write(UC_PPC_REG_0+ra,0x1effd20)
u.emu_start(args.reported_pc,args.reported_pc+4,count=1)
assert u.reg_read(UC_PPC_REG_0+rt)==(((0x1effd20 if ra else 0)+imm)&0xffffffff)
# A deliberately misaligned output tests the observer itself. It must not
# silently accept a generated word store at an unaligned host address.
violations.clear()
u.reg_write(UC_PPC_REG_1,0x90a93bd0);u.reg_write(UC_PPC_REG_3,out+1);u.reg_write(UC_PPC_REG_4,base);u.reg_write(UC_PPC_REG_5,0x1effdb0);u.reg_write(UC_PPC_REG_LR,stop)
u.emu_start(args.helper,stop,count=50000)
assert violations,'Alignment observer failed its negative control'
report={'linked_read128_cases':count,'misaligned_host_accesses':0,'negative_control_detected':True,'reported_pc_instruction':hex(struct.unpack('>I',u.mem_read(args.reported_pc,4))[0]),'reported_pc_single_step_passed':True,'physical_wii':False,'root_cause_proven':False}

if args.output:args.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
