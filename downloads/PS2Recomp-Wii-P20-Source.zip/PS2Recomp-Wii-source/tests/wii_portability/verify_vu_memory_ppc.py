#!/usr/bin/env python3
"""Execute production VU memory case bodies on big-endian PPC750, with byte oracles."""
import argparse, json, struct, subprocess, tempfile
from pathlib import Path
from unicorn import Uc, UC_ARCH_PPC, UC_MODE_PPC32, UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *
root = Path(__file__).resolve().parents[2]
p = argparse.ArgumentParser()
p.add_argument('--devkitppc', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
lower = (root/'ps2xRuntime/src/lib/vu/ps2_vu1_lower.cpp').read_text()
core = (root/'ps2xRuntime/src/lib/vu/ps2_vu1_core.cpp').read_text()
def block(s, marker):
 start = s.index('{', s.index(marker)); depth = 1; end = start + 1
 while depth:
  depth += (s[end] == '{') - (s[end] == '}'); end += 1
 return s[start:end]
names = ['case 0x00: // LQ ', 'case 0x34: // LQI ', 'case 0x36: // LQD ',
         'case 0x04: // ILW ', 'case 0x3E: // ILWR ']
methods = '\n'.join('void op%d(uint32_t instr,uint8_t*vuData,uint32_t dataSize){uint8_t viS=VIS(instr),viT=VIT(instr),vfT=FT(instr),dest=DEST(instr);%s}'%(i, block(lower,n)) for i,n in enumerate(names))
store = block(core[core.index('void VU1Interpreter::commitReadyPipelines'):], 'for (PendingStore &store : m_storePipeline)')
source = r'''
#include "runtime/ps2_guest_memory.h"
#include "ps2_vu1_detail.h"
extern "C" void*memcpy(void*d,const void*s,size_t n){auto*p=(volatile unsigned char*)d;auto*q=(const volatile unsigned char*)s;for(size_t i=0;i<n;++i)p[i]=q[i];return d;}
extern "C" void*memset(void*d,int x,size_t n){auto*p=(volatile unsigned char*)d;for(size_t i=0;i<n;++i)p[i]=x;return d;}
struct Test {
 struct { float vf[32][4];int32_t vi[16]; } m_state{};
 static void applyDest(float*d,const float*s,uint8_t mask){for(unsigned i=0;i<4;++i)if(mask&(8>>i))d[i]=s[i];}
 static unsigned laneForComponent(unsigned c){return 8>>c;}
 METHODS
 struct PendingStore {bool valid;uint32_t readyCycle,address,laneMask,words[4];};
 PendingStore m_storePipeline[1]{};uint32_t m_cycle=7,m_activeVuDataSize=64;uint8_t*m_activeVuData;
 void commit(){for(PendingStore&store:m_storePipeline) STORE }
};
extern "C" void cases(const uint32_t*in,uint32_t*out){
 Test t;uint8_t bytes[64];for(unsigned i=0;i<64;++i)bytes[i]=uint8_t(i*37+11);
 unsigned kind=in[0],mask=in[1];t.m_state.vi[1]=in[2];
 for(unsigned i=0;i<4;++i)t.m_state.vf[2][i]=99.0f;
 uint32_t instr=(mask<<21)|(2<<16)|(1<<11)|(in[3]&2047);
 switch(kind){case 0:t.op0(instr,bytes,64);break;case 1:t.op1(instr,bytes,64);break;case 2:t.op2(instr,bytes,64);break;case 3:t.op3(instr,bytes,64);break;case 4:t.op4(instr,bytes,64);break;case 5:
 t.m_activeVuData=bytes;t.m_storePipeline[0]={true,in[3],in[2],mask,{0x3f800000,0x89abcdef,0x80000000,0x1234fedc}};t.commit();break;}
 memcpy(out,t.m_state.vf[2],16);out[4]=t.m_state.vi[1];out[5]=t.m_state.vi[2];
 for(unsigned i=0;i<64;++i)out[6+i]=bytes[i];out[70]=t.m_storePipeline[0].valid;
}
'''.replace('METHODS',methods).replace('STORE',store)
with tempfile.TemporaryDirectory(prefix='vu-memory-ppc-') as td:
 d=Path(td);(d/'test.cpp').write_text(source);elf=d/'test.elf'
 cmd=[str(a.devkitppc/'bin/powerpc-eabi-g++'),'-std=c++20','-O2','-mcpu=750','-meabi','-mno-altivec','-mno-vsx','-DPS2X_WII_SCALAR_SIMD','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),'-I'+str(root/'ps2xRuntime/src/lib/vu'),'-nostdlib','-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(d/'test.cpp'),'-lgcc','-o',str(elf)]
 subprocess.run(cmd,check=True)
 b=elf.read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',b,28)[0];step,n=struct.unpack_from('>HH',b,42)
 for i in range(n):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',b,ph+i*step)
  if kind==1:u.mem_write(addr,b[off:off+length])
 entry=struct.unpack_from('>I',b,24)[0];total=0;negative_control=False
 vectors=[(k,m,base,imm) for k in range(5) for m in range(16) for base in (0,1,3,32767,-32768,-1) for imm in (-1,0,1)]
 vectors += [(5,m,addr,ready) for m in range(16) for addr in (0,16,48,64) for ready in (0,7,8)]
 for kind,mask,base,imm in vectors:
  mem=bytearray((i*37+11)&255 for i in range(64));vf=[0x42c60000]*4;vi1=base;vi2=0;valid=0
  if kind<5:
   if kind==2:vi1=((base-1+32768)%65536)-32768
   addr=((vi1+(imm if kind in (0,3) else 0))*16)&63
   words=struct.unpack_from('<4I',mem,addr)
   if kind<3:
    vf=[words[i] if mask&(8>>i) else vf[i] for i in range(4)]
    if mask==15 and list(struct.unpack_from('>4I',mem,addr))!=vf:negative_control=True
   else:
    component=next((i for i in range(3) if mask&(8>>i)),3);vi2=((words[component]&65535)^32768)-32768
   if kind==1:vi1=((base+1+32768)%65536)-32768
  else:
   vi1=base;valid=int(imm>7)
   if not valid and base+16<=64:
    for i,w in enumerate((0x3f800000,0x89abcdef,0x80000000,0x1234fedc)):
     if mask&(8>>i):struct.pack_into('<I',mem,base+4*i,w)
  expected=vf+[vi1&0xffffffff,vi2&0xffffffff]+list(mem)+[valid]
  u.mem_write(0x90000000,struct.pack('>4I',kind,mask,base&0xffffffff,imm&0xffffffff))
  for r,v in ((UC_PPC_REG_1,0x801fe000),(UC_PPC_REG_3,0x90000000),(UC_PPC_REG_4,0x90001000),(UC_PPC_REG_LR,0x80001000),(UC_PPC_REG_MSR,0x2000)):u.reg_write(r,v)
  u.emu_start(entry,0x80001000,count=100000)
  assert u.reg_read(UC_PPC_REG_PC)==0x80001000
  actual=list(struct.unpack('>71I',u.mem_read(0x90001000,284)))
  assert actual==expected,(kind,mask,base,imm,[(i,hex(x),hex(y)) for i,(x,y) in enumerate(zip(actual,expected)) if x!=y])
  total+=1
 assert negative_control,'old host-endian load must fail byte oracle'
 report=dict(cases=total,matched=True,old_native_endian_load_rejected=True,physical_wii=False,scope='production LQ/LQI/LQD/ILW/ILWR and delayed masked stores compiled for PPC750')
 a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
