#include "emulator/core/iop_memory.h"
#include <cassert>
#include <vector>
#include <algorithm>
#include <random>
int main(){
 using ps2x::iop::detail::IopMemory;
 ps2x::iop::detail::ByteOwnership full(IopMemory::RamSize),bitmap(256);
 assert(full.storageBytes()==262144);
 for(unsigned i=0;i<128;++i)for(unsigned n=0;n<128;++n){
  bitmap.reset();bitmap.set(i,n,true);assert(bitmap.owns(i,n));
  if(i)assert(!bitmap.owns(i-1,n+1));
  assert(!bitmap.owns(i,n+1));bitmap.set(i,n,false);if(n)assert(!bitmap.owns(i,n));
 }
 IopMemory mem;std::vector<uint8_t> reference(IopMemory::RamSize);
 std::mt19937 rng(0x750);
 for(unsigned step=0;step<10000;++step){
  unsigned addr=rng()%(IopMemory::RamSize-130),n=rng()%130;
  switch(step%4){
   case 0:assert(mem.zeroRam(addr,n));std::fill(reference.begin()+addr,reference.begin()+addr+n,1);break;
   case 1:mem.write8(addr,1);reference[addr]=1;break;
   case 2:mem.write16(addr,0xabcd);reference[addr]=reference[addr+1]=1;break;
   case 3:mem.write32(addr,0x12345678);std::fill(reference.begin()+addr,reference.begin()+addr+4,1);break;
  }
  bool expected=std::all_of(reference.begin()+addr,reference.begin()+addr+n,[](auto v){return v!=0;});
  assert(mem.ownsRamRange(addr,n)==expected);
  unsigned start=addr?addr-1:0;
  expected=std::all_of(reference.begin()+start,reference.begin()+addr+n+1,[](auto v){return v!=0;});
  assert(mem.ownsRamRange(start,addr+n+1-start)==expected);
  assert(mem.ownsRamRange(0x80000000|addr,n)==mem.ownsRamRange(addr,n));
 }
 assert(mem.ownsRamRange(IopMemory::RamSize,0));
 assert(!mem.ownsRamRange(IopMemory::RamSize,1));assert(!mem.ownsRamRange(0,SIZE_MAX));
 for(unsigned offset=0;offset<65;++offset){
  auto addr=mem.allocate(65+offset,16);assert(addr);assert(mem.ownsRamRange(addr,65+offset));
  assert(mem.freeAllocation(addr));assert(!mem.ownsRamRange(addr,65+offset));
 }
 mem.reset();assert(!mem.ownsRamRange(0,1));assert(!mem.ownsRamRange(IopMemory::RamSize-1,1));
}
