#!/usr/bin/env python3
"""Run the production VCLIP emission using the actual scalar PPC750 backend."""
from pathlib import Path
import argparse,re,json,subprocess,tempfile,struct,random
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *
p=argparse.ArgumentParser();p.add_argument('--devkitppc',type=Path,required=True);p.add_argument('--output',type=Path);args=p.parse_args()
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRecomp/src/lib/vu_translator.cpp').read_text().split('case VU0_S2_VCLIPw:',1)[1].split('case VU0_S2_VNOP:',1)[0].split('return fmt::format(',1)[1].split('inst.rd,',1)[0]
body=''.join(json.loads('"'+x+'"') for x in re.findall(r'"((?:[^"\\]|\\.)*)"',s)).format(2,3,3,'_MM_SHUFFLE(3,3,3,3)')
source='''#include "ps2_simd.h"
#include <cstdint>
#include <cstddef>
extern "C" void*memset(void*p,int value,size_t n){auto*d=(volatile unsigned char*)p;for(size_t i=0;i<n;++i)d[i]=value;return p;}
extern "C" void*memcpy(void*d,const void*s,size_t n){auto*p=(volatile unsigned char*)d;auto*q=(const volatile unsigned char*)s;for(size_t i=0;i<n;++i)p[i]=q[i];return d;}
struct Context{__m128 vu0_vf[32];uint32_t vu0_clip_flags;};
extern "C" void cases(const uint32_t*in,uint32_t*out){Context c;auto*ctx=&c;
ctx->vu0_vf[2]=_mm_loadu_ps(reinterpret_cast<const float*>(in));
ctx->vu0_vf[3]=_mm_loadu_ps(reinterpret_cast<const float*>(in+4));ctx->vu0_clip_flags=in[8];
BODY
*out=ctx->vu0_clip_flags;
}
'''.replace('BODY',body)
rng=random.Random(1123);vectors=[]
for i in range(512):vectors.append(([rng.randrange(-10000,10001)/32 for _ in range(4)],[0,0,0,rng.randrange(-10000,10001)/32],rng.randrange(1<<24)))
for axis in range(3):
 for sign in [-1,1]:
  fs=[0.,0.,0.,0.];fs[axis]=sign*2.;vectors.append((fs,[0.,0.,0.,-1.],0))
with tempfile.TemporaryDirectory(prefix='ps2-vclip-ppc-') as tmp:
 d=Path(tmp);(d/'test.cpp').write_text(source)
 subprocess.run([str(args.devkitppc/'bin/powerpc-eabi-g++'),'-std=c++20','-O2','-mcpu=750','-meabi','-mno-altivec','-mno-vsx','-DPS2X_WII_SCALAR_SIMD','-I'+str(root/'ps2xRuntime/include'),'-nostdlib','-Wl,--gc-sections','-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(d/'test.cpp'),'-lgcc','-o',str(d/'test.elf')],check=True)
 data=(d/'test.elf').read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',data,28)[0];step,count=struct.unpack_from('>HH',data,42)
 for i in range(count):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',data,ph+i*step)
  if kind==1:u.mem_write(addr,data[off:off+length])
 entry=struct.unpack_from('>I',data,24)[0]
 for fs,ft,history in vectors:
  flags=0
  for c in range(3):
   if fs[c]>abs(ft[3]):flags|=1<<(c*2)
   if fs[c]<-abs(ft[3]):flags|=2<<(c*2)
  expected=((history<<6)|flags)&0xffffff
  u.mem_write(0x90000000,struct.pack('>8fI',*fs,*ft,history));u.reg_write(UC_PPC_REG_1,0x801fe000);u.reg_write(UC_PPC_REG_3,0x90000000);u.reg_write(UC_PPC_REG_4,0x90001000);u.reg_write(UC_PPC_REG_LR,0x80001000);u.reg_write(UC_PPC_REG_MSR,0x2000)
  u.emu_start(entry,0x80001000,count=100000);assert u.reg_read(UC_PPC_REG_PC)==0x80001000
  actual=struct.unpack('>I',u.mem_read(0x90001000,4))[0];assert actual==expected,(fs,ft,history,actual,expected)
 report=dict(cases=len(vectors),matched=True,physical_wii=False,scope='production VCLIP on compiled PPC750 scalar SIMD under Unicorn; finite normal operands')
 if args.output:args.output.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
