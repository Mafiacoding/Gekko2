#include "runtime/ps2_display_fit.h"
#include <cassert>
#include <cmath>
int main(){
 auto a=Ps2FitDisplay(640,480,4.f/3);assert(a.x==0&&a.y==0&&a.width==640&&a.height==480);
 auto b=Ps2FitDisplay(640,480,16.f/9);assert(std::abs(b.width-480)<.001f&&b.height==480&&std::abs(b.x-80)<.001f);
 auto c=Ps2FitDisplay(640,528,4.f/3);assert(c.width==640&&c.height==528&&c.x==0&&c.y==0);
 auto d=Ps2FitDisplay(1280,720,1280.f/720);assert(d.width==960&&d.height==720&&d.x==160&&d.y==0);
}
