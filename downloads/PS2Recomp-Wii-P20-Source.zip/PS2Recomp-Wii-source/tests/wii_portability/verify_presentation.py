#!/usr/bin/env python3
"""Compare locked Wii presentation to the original VRAM snapshot path on host."""
from pathlib import Path
import subprocess,tempfile,hashlib,json,argparse
parser=argparse.ArgumentParser();parser.add_argument("--reference-source",type=Path);args=parser.parse_args()
root=Path(__file__).resolve().parents[2]
source=r'''
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/ps2_gs_memory.h"
#include <cstdio>
#include <vector>
#include <cstdlib>
#include <new>
static bool constrainAllocations=false;
static size_t frameAllocations=0;
void* operator new(size_t n){
 if(constrainAllocations && n>=65536){frameAllocations+=n;if(frameAllocations>size_t(640)*512*4)throw std::bad_alloc();}
 if(void*p=std::malloc(n?n:1))return p;throw std::bad_alloc();
}
void operator delete(void*p)noexcept{std::free(p);}
void operator delete(void*p,size_t)noexcept{std::free(p);}
static void beginFrame(){frameAllocations=0;
#ifdef PS2X_WII_SERIAL_PRESENT
constrainAllocations=true;
#endif
}
static void endFrame(){constrainAllocations=false;}
int main(){
 GSMem::InitLookupTables();std::vector<uint8_t> vram(4*1024*1024);
 GSCpuBackend backend;backend.Initialize(vram.data(),vram.size());
 for(uint32_t psm:{0u,1u,2u,10u}){
  for(unsigned y=0;y<48;y++)for(unsigned x=0;x<64;x++)backend.WriteVram(psm,0,1,x,y,psm==2||psm==10?0x8000u|((x+y*64)&0x7fff):0x80000000u|(x*3u)|(y*5u<<8)|((x+y)*2u<<16));
  for(unsigned flags=0;flags<64;flags++){
   GSPresentationRequest req{};req.pmode=(flags&1?3:1)|uint64_t((flags>>3)&7)<<5|0x80u<<8;req.smode2=(flags>>1)&3;req.vsyncTick=flags&1;
   req.dispfb1=1ull<<9|uint64_t(psm)<<15;req.dispfb2=req.dispfb1;
   req.display1=63ull<<32|47ull<<44;req.display2=31ull<<32|24ull<<44;req.bgcolor=0x203040;
   beginFrame();auto frame=backend.Present(req);endFrame();if(!frame||frame.pixels.size()!=size_t(640)*512*4)return 2;
   uint32_t header[]={psm,flags,frame.width,frame.height};std::fwrite(header,1,sizeof header,stdout);
   std::fwrite(frame.pixels.data(),1,frame.pixels.size(),stdout);
  }
 }
 // Different CRT formats, dimensions and origins, with the same one-frame budget.
 for(uint32_t psm1:{0u,1u,2u,10u})for(uint32_t psm2:{0u,1u,2u,10u})for(unsigned mode=0;mode<2;++mode){
  for(unsigned y=0;y<48;++y)for(unsigned x=0;x<64;++x){
   backend.WriteVram(psm1,128,1,x,y,(psm1==2||psm1==10)?0xbdefu:0x40203070u+x);
   backend.WriteVram(psm2,256,1,x,y,(psm2==2||psm2==10)?0x6abcu:0x90108020u+y);
  }
  GSPresentationRequest req{};req.pmode=3u|(mode?0x60u:0u)|0x70u<<8;req.smode2=mode;req.vsyncTick=1;
  req.dispfb1=4ull|1ull<<9|uint64_t(psm1)<<15|3ull<<32|5ull<<43;
  req.dispfb2=8ull|1ull<<9|uint64_t(psm2)<<15|7ull<<32|2ull<<43;
  req.display1=31ull<<32|15ull<<44;req.display2=47ull<<32|23ull<<44;req.bgcolor=0x201050;
  beginFrame();auto frame=backend.Present(req);endFrame();if(!frame)return 4;
  uint32_t header[]={psm1,psm2,mode,frame.width,frame.height};std::fwrite(header,1,sizeof header,stdout);std::fwrite(frame.pixels.data(),1,frame.pixels.size(),stdout);
 }
 // Black-source fallback: preserve alpha if candidates are black/invalid;
 // choose exactly the same alternative when it contains RGB data.
 for(unsigned flags=0;flags<8;++flags){
  for(unsigned y=0;y<48;++y)for(unsigned x=0;x<64;++x){backend.WriteVram(0,0,1,x,y,0x80000000);backend.WriteVram(0,32,1,x,y,0x10000000);backend.WriteVram(0,64,1,x,y,(flags&1)?0x80203040:0x20000000);}
  GSPresentationRequest req{};req.pmode=3u|0x80u<<8|uint64_t(flags&2?1:0)<<7;req.dispfb1=1ull<<9;req.dispfb2=req.dispfb1;
  req.display1=63ull<<32|47ull<<44;req.display2=req.display1;req.bgcolor=0x203040;
  req.contextFrames[0].fbp=1;req.contextFrames[0].fbw=1;req.contextFrames[0].psm=flags&4?63:0;
  req.contextFrames[1].fbp=2;req.contextFrames[1].fbw=1;req.contextFrames[1].psm=0;
  beginFrame();auto frame=backend.Present(req);endFrame();if(!frame)return 3;uint32_t header[]={flags,frame.width,frame.height};std::fwrite(header,1,sizeof header,stdout);std::fwrite(frame.pixels.data(),1,frame.pixels.size(),stdout);
 }
}
'''
with tempfile.TemporaryDirectory(prefix='ps2-wii-present-') as td:
 d=Path(td);(d/'test.cpp').write_text(source);results=[]
 for mode in ['snapshot','serial']:
  exe=d/mode;cmd=['g++','-std=c++20','-O1','-msse4.1','-pthread','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),str(d/'test.cpp'),str(args.reference_source if mode=='snapshot' and args.reference_source else root/'ps2xRuntime/src/lib/gs/gs_cpu_backend.cpp'),str(root/'ps2xRuntime/src/lib/gs/ps2_gs_memory.cpp'),'-o',str(exe)]
  if mode=='serial':cmd+=['-DPS2X_WII_SERIAL_PRESENT']
  subprocess.run(cmd,check=True);results.append(subprocess.check_output([str(exe)]))
 assert results[0]==results[1],'presentation outputs differ'
 print(json.dumps(dict(cases=296,compared_bytes=len(results[0]),sha256=hashlib.sha256(results[0]).hexdigest(),matched=True,physical_wii=False)))
