#!/usr/bin/env python3
from pathlib import Path
import subprocess,tempfile,unittest
root=Path(__file__).resolve().parents[2]
class ExitReportingTests(unittest.TestCase):
 def test_original_exit_semantics_preserved(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td);(d/'test.cpp').write_text('''#include <cstdio>
#include <cstdlib>
void PS2WiiCheckpoint(const char*s){std::puts(s);std::fflush(stdout);}
extern "C" [[noreturn]] void __real_abort(){std::_Exit(77);}
extern "C" [[noreturn]] void __real__Exit(int n){std::_Exit(n);}
extern "C" void __wrap_abort();extern "C" void __wrap__Exit(int);
int main(int n,char**){if(n>1)__wrap_abort();else __wrap__Exit(23);}
''')
   exe=d/'test';subprocess.run(['c++','-std=c++20','-Wall','-Wextra','-Werror','-I'+str(root/'ps2xRuntime/platform/wii'),str(root/'ps2xRuntime/platform/wii/ps2_wii_exit.cpp'),str(d/'test.cpp'),'-o',str(exe)],check=True)
   for args,status,line in [([],23,'process-_Exit status=23'),(['abort'],77,'process-abort status=-1')]:
    result=subprocess.run([str(exe),*args],capture_output=True,text=True);self.assertEqual(result.returncode,status);self.assertEqual(result.stdout.strip(),line)
if __name__=='__main__':unittest.main()
