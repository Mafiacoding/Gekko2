#!/usr/bin/env python3
"""Execute production math HLE bodies with distinct FPR/GPR sentinels."""
from pathlib import Path
import re,tempfile,subprocess
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/Kernel/Stubs/LibC.cpp').read_text();names=['sin','cos','sqrt','tan','exp','log','log10','ceil','floor','fabs','atan','pow','atan2'];bodies=[]
for name in names:
 m=re.search(r'    void '+name+r'\(uint8_t \*rdram, R5900Context \*ctx, PS2Runtime \*runtime\)\n    \{',s);assert m,name;a=m.start();b=m.end();depth=1
 while depth:
  if s[b]=='{':depth+=1
  if s[b]=='}':depth-=1
  b+=1
 bodies.append(s[a:b])
prefix=r'''
#include "runtime/ps2_ee_math_abi.h"
#include <cmath>
#include <cassert>
struct R5900Context{__m128i r[32]{};float f[32]{};};struct PS2Runtime{};
'''
main='int main(){R5900Context c;PS2Runtime runtime;\n'
for name in names:
 main+='''for(double value:{0.0,-0.0,0.5,1.0,3.141592653589793,16.0}){
 c.r[4]=_mm_set_epi64x(0x1234,int64_t(std::bit_cast<uint64_t>(value)));
 c.r[5]=_mm_set_epi64x(0x5678,int64_t(std::bit_cast<uint64_t>(2.0)));
 c.f[12]=12345.0f;c.f[0]=9876.0f;
'''
 main+=name+'(nullptr,&c,&runtime);double expected=std::'+name+'(value'+(',2.0' if name in ['pow','atan2'] else '')+');\n'
 main+='''auto actual=Ps2EeDoubleArg(&c,2);assert((std::isnan(actual)&&std::isnan(expected))||std::bit_cast<uint64_t>(actual)==std::bit_cast<uint64_t>(expected));
 assert(c.f[0]==9876.0f&&c.f[12]==12345.0f);assert(_mm_extract_epi64(c.r[4],1)==0x1234);
}\n'''
main+='}\n'
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'test.cpp').write_text('#include <initializer_list>\n'+prefix+'\n'.join(bodies)+main)
 subprocess.run(['c++','-std=c++20','-O1','-msse4.1','-fsanitize=address,undefined','-I'+str(root/'ps2xRuntime/include'),str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: 13 production double HLE functions, GPR arguments/results, FPR/callee data preserved')
