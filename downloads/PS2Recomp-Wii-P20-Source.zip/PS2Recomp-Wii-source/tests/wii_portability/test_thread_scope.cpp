#include "runtime/ps2_thread_scope.h"
#include <atomic>
#include <cassert>
#include <stdexcept>
int main(){
 for(bool throws:{false,true}){
  std::atomic<bool> stop{false},finished{false};bool caught=false;
  try {
   std::thread worker([&]{while(!stop.load())std::this_thread::yield();finished=true;});
   Ps2ThreadScope scope(worker,[&]{stop=true;});
   if(throws)throw std::runtime_error("original presentation failure");
  }catch(const std::runtime_error &e){caught=true;assert(std::string(e.what())=="original presentation failure");}
  assert(finished&&stop&&caught==throws);
 }
}
