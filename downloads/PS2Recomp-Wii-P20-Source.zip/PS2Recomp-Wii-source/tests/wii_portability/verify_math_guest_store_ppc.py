#!/usr/bin/env python3
"""Execute production argument-reduction HLE stores on big-endian PPC750."""
import argparse, json, math, struct, subprocess, tempfile
from pathlib import Path
from unicorn import Uc, UC_ARCH_PPC, UC_MODE_PPC32, UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *
p=argparse.ArgumentParser();p.add_argument('--devkitppc',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/Kernel/Stubs/LibC.cpp').read_text();start=s.index('    void __ieee754_rem_pio2f(');end=s.index('\n    void tan(',start);body=s[start:end]
source=r'''
#include "runtime/ps2_guest_memory.h"
#include <cmath>
struct R5900Context {float f[32]{};uint32_t address;int32_t result;};struct PS2Runtime {};
uint32_t getRegU32(R5900Context*c,int){return c->address;}
void setReturnS32(R5900Context*c,int32_t n){c->result=n;}
uint8_t*getMemPtr(uint8_t*p,uint32_t a){return a<=60?p+a:nullptr;}
extern "C" void*memset(void*p,int x,size_t n){auto*d=(volatile unsigned char*)p;for(size_t i=0;i<n;++i)d[i]=x;return p;}
extern "C" void*memcpy(void*d,const void*s,size_t n){auto*p=(volatile unsigned char*)d;auto*q=(const volatile unsigned char*)s;for(size_t i=0;i<n;++i)p[i]=q[i];return d;}
BODY
extern "C" void cases(const uint32_t*in,uint32_t*out){
 uint8_t bytes[64];for(unsigned i=0;i<64;++i)bytes[i]=0xa5;
 R5900Context c;c.f[12]=std::bit_cast<float>(in[0]);c.address=in[1];PS2Runtime runtime;
 __ieee754_rem_pio2f(bytes,&c,&runtime);out[0]=uint32_t(c.result);
 for(unsigned i=0;i<64;++i)out[i+1]=bytes[i];
}
'''.replace('BODY',body)
with tempfile.TemporaryDirectory(prefix='math-guest-store-') as td:
 d=Path(td);(d/'test.cpp').write_text(source);elf=d/'test.elf'
 subprocess.run([str(a.devkitppc/'bin/powerpc-eabi-g++'),'-std=c++20','-O2','-ffp-contract=off','-mcpu=750','-meabi','-mno-altivec','-mno-vsx','-DPS2X_WII_SCALAR_SIMD','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),'-nostdlib','-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(d/'test.cpp'),'-lm','-lgcc','-o',str(elf)],check=True)
 b=elf.read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',b,28)[0];step,n=struct.unpack_from('>HH',b,42)
 for i in range(n):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',b,ph+i*step)
  if kind==1:u.mem_write(addr,b[off:off+length])
 entry=struct.unpack_from('>I',b,24)[0];count=0
 f32=lambda x:struct.unpack('>f',struct.pack('>f',x))[0]
 pi=f32(3.14159265358979323846);half=f32(pi*0.5);inv=f32(2.0/pi)
 for value in [i/4 for i in range(-64,65)]:
  n=round(f32(value*inv));y=f32(value-f32(f32(n)*half))
  for address in (0,1,16,56,64):
   expected=bytearray([0xa5]*64)
   if address<64:expected[address:address+8]=struct.pack('<ff',y,0.0)
   u.mem_write(0x90000000,struct.pack('>fI',value,address))
   for r,v in ((UC_PPC_REG_1,0x801fe000),(UC_PPC_REG_3,0x90000000),(UC_PPC_REG_4,0x90001000),(UC_PPC_REG_LR,0x80001000),(UC_PPC_REG_MSR,0x2000)):u.reg_write(r,v)
   u.emu_start(entry,0x80001000,count=100000)
   assert u.reg_read(UC_PPC_REG_PC)==0x80001000
   result=struct.unpack('>65I',u.mem_read(0x90001000,260))
   assert result[0]==n&0xffffffff and list(result[1:])==list(expected),(value,address,result[0],n)
   count+=1
 report=dict(cases=count,matched=True,physical_wii=False,scope='production rem_pio2f finite input reduction, unaligned little-endian guest stores and invalid-pointer preservation; not full argument-reduction accuracy')
 a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
