#include "runtime/ps2_frame_pack.h"
#include <cassert>
int main(){
 for(unsigned w=0;w<=17;++w)for(unsigned h=0;h<=11;++h){
  std::vector<uint8_t> pixels(w*h*4);for(unsigned i=0;i<pixels.size();++i)pixels[i]=uint8_t(i*13+7);
  std::vector<uint8_t> expected(17*11*4,0);
  for(unsigned y=0;w&&y<h;++y)std::memcpy(expected.data()+y*17*4,pixels.data()+y*w*4,w*4);
  Ps2ExpandFrame(pixels,w,h,17,11);assert(pixels==expected);
 }
 std::vector<uint8_t> bad(1);bool rejected=false;
 try{Ps2ExpandFrame(bad,2,2,1,1);}catch(const std::runtime_error&){rejected=true;}assert(rejected);
}
