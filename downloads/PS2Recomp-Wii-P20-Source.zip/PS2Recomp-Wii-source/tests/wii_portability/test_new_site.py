#!/usr/bin/env python3
"""Run the real fixed per-thread new markers, including nested exceptions."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp)
 (p/'gccore.h').write_text('''#pragma once
#include <atomic>
inline unsigned LWP_GetSelf(){static std::atomic<unsigned>next{1};thread_local unsigned id=next.fetch_add(1);return id;}
''')
 (p/'test.cpp').write_text('''#include <cstdint>
#include <cstdlib>
#include <new>
#include <thread>
#include <cassert>
extern "C" uint32_t PS2WiiCurrentNewSite();
extern "C" void PS2WiiNewSitesEnable();
extern "C" void*__wrap__Znwj(std::size_t);extern "C" void*__wrap__Znaj(std::size_t);
extern "C" void*__real__Znwj(std::size_t n){auto site=PS2WiiCurrentNewSite();assert(site);std::this_thread::yield();assert(PS2WiiCurrentNewSite()==site);if(n==13)throw std::bad_alloc();return std::malloc(n);}
extern "C" void*__real__Znaj(std::size_t n){auto site=PS2WiiCurrentNewSite();assert(site);void*p=__wrap__Znwj(n);assert(PS2WiiCurrentNewSite()==site);return p;}
void cases(){assert(PS2WiiCurrentNewSite()==0);for(unsigned i=0;i<100;++i){auto*p=__wrap__Znaj(64);std::free(p);assert(PS2WiiCurrentNewSite()==0);try{(void)__wrap__Znwj(13);assert(false);}catch(const std::bad_alloc&){}assert(PS2WiiCurrentNewSite()==0);}}
int main(){assert(PS2WiiCurrentNewSite()==0);PS2WiiNewSitesEnable();std::thread a(cases),b(cases);cases();a.join();b.join();}
''')
 subprocess.run(['c++','-std=c++20','-pthread','-fsanitize=address,undefined','-I'+str(p),str(p/'test.cpp'),str(root/'ps2xRuntime/platform/wii/ps2_wii_new_site.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: real new-site markers, independent threads, nested array new, exception restoration')
