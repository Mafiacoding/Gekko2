#!/usr/bin/env python3
"""Exercise the production GS sync function with deterministic MMIO mocks."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/Kernel/Stubs/GS.cpp').read_text();start=s.index('    void sceGsSyncPath(');end=s.index('\n    void ',start+10);body=s[start:end]
prefix=r'''
#include <cstdint>
#include <cassert>
struct R5900Context {uint32_t r[32]{};};
uint32_t getRegU32(R5900Context*c,int r){return c->r[r];}
void setReturnS32(R5900Context*c,int v){c->r[2]=uint32_t(v);}
struct Mem {
 uint32_t remaining[4]{};unsigned pending=0;
 void processPendingTransfers(){++pending;}
 uint32_t readIORegister(uint32_t a){
  const uint32_t addresses[]{0x10009000,0x1000a000,0x10003c00,0x10003020};
  const uint32_t masks[]{0x100,0x100,0x1f000003,0xc00};
  for(unsigned i=0;i<4;++i)if(a==addresses[i]){if(remaining[i]){--remaining[i];return masks[i];}return 0;}
  assert(false);return 0;
 }
};
struct PS2Runtime {Mem mem;Mem&memory(){return mem;}};
struct PS2WiiProgressScope {explicit PS2WiiProgressScope(unsigned){}};
unsigned polls=0,stopAfter=0;
bool PS2WiiServicePoll(){++polls;return stopAfter&&polls>=stopAfter;}
'''
main=r'''
int main(){
 {PS2Runtime rt;R5900Context c;for(auto &v:rt.mem.remaining)v=2;polls=0;stopAfter=0;
  sceGsSyncPath(nullptr,&c,&rt);assert(c.r[2]==0&&polls==8&&rt.mem.pending==1);}
 for(unsigned channel=0;channel<4;++channel){
  PS2Runtime rt;R5900Context c;rt.mem.remaining[channel]=UINT32_MAX;polls=0;stopAfter=3;
  sceGsSyncPath(nullptr,&c,&rt);assert(c.r[2]==UINT32_MAX&&polls==3);
  assert(rt.mem.remaining[channel]==UINT32_MAX-3); // no fabricated completion
 }
 {PS2Runtime rt;R5900Context c;c.r[4]=1;for(auto &v:rt.mem.remaining)v=UINT32_MAX;polls=0;stopAfter=1;
  sceGsSyncPath(nullptr,&c,&rt);assert(c.r[2]==0x17&&polls==0&&rt.mem.pending==0);}
 {PS2Runtime rt;R5900Context c;rt.mem.remaining[0]=UINT32_MAX;polls=0;stopAfter=0;
  sceGsSyncPath(nullptr,&c,&rt);assert(c.r[2]==UINT32_MAX&&polls==0x1000001);}
}
'''
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'test.cpp').write_text(prefix+body+main)
 subprocess.run(['c++','-std=c++20','-O1','-DPS2X_WII','-fsanitize=address,undefined',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: real HLE GS sync, four stop paths, unchanged poll mode and timeout, no forced DMA completion')
