"""Synthetic placement checks for the EXI SRAM corruption regression."""
import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('buildcheck',Path(__file__).parents[2]/'tools/wii/check_build.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)

class ExiPlacement(unittest.TestCase):
    def setUp(self):
        self.symbols={'__mem1_code_end':0x813c0000,'__mem1_sdk_start':0x813c0000,
                      '__mem1_sdk_end':0x813f0000,'__Arena1Lo':0x813f0000,'sramcntrl':0x813e0000}
        self.sections=[('.mem1sdk',1,0x813c0000,0x30000)]

    def test_dma_roundtrip_mem1(self):
        report=module.check_dma_storage(self.symbols,self.sections)
        self.assertEqual(report['exi_dma_address']|0x80000000,self.symbols['sramcntrl'])

    def test_observed_old_mem2_address_aliases_code(self):
        self.assertEqual((0x907d66a0&0x03ffffe0)|0x80000000,0x807d66a0)
        self.symbols['sramcntrl']=0x907d66a0
        with self.assertRaisesRegex(ValueError,'EXI SRAM'):
            module.check_dma_storage(self.symbols,self.sections)

    def test_reject_unaligned_buffer(self):
        self.symbols['sramcntrl']+=4
        with self.assertRaises(ValueError):module.check_dma_storage(self.symbols,self.sections)

    def test_reject_heap_overlap(self):
        self.symbols['__Arena1Lo']=0x813e8000
        with self.assertRaises(ValueError):module.check_dma_storage(self.symbols,self.sections)

    def test_reject_nobits_initialization(self):
        with self.assertRaises(ValueError):module.check_dma_storage(self.symbols,[('.mem1sdk',8,0x813c0000,0x30000)])

    def test_reject_code_overlap(self):
        self.symbols['__mem1_code_end']=0x813c0004
        with self.assertRaises(ValueError):module.check_dma_storage(self.symbols,self.sections)

if __name__=='__main__':unittest.main()
