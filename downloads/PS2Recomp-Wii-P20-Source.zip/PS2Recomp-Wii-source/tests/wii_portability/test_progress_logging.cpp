#include "runtime/ps2_progress_policy.h"
#include "runtime/ps2_line_log.h"
#include "runtime/ps2_bounded_log_file.h"
#include <unistd.h>
#include <cassert>
#include <ostream>
#include <string>
#include <thread>
#include <cstring>
static std::string output;
static void sink(const char*p,std::size_t n){assert(n<=512);output.append(p,n);}
int main(){
 char path[]="/tmp/ps2-log-XXXXXX";int fd=mkstemp(path);assert(fd>=0);close(fd);
 std::string payload(1000,'z');
 Ps2AppendBoundedFile(path,payload.data(),payload.size(),700);
 Ps2AppendBoundedFile(path,payload.data(),payload.size(),700);
 FILE*f=std::fopen(path,"rb");assert(f);std::fseek(f,0,SEEK_END);assert(std::ftell(f)==700);std::fclose(f);unlink(path);
 Ps2ProgressPolicy p;for(unsigned i=1;i<=20;++i)p.observe(i,i);assert(std::strcmp(p.state(),"HOST_PROGRESS")==0);
 for(unsigned i=21;i<=30;++i)p.observe(20,i);assert(std::strcmp(p.state(),"EE_QUIET_OR_WAITING")==0);
 for(unsigned i=0;i<10;++i)p.observe(20,30);assert(std::strcmp(p.state(),"EE_AND_UI_QUIET")==0);
 for(unsigned i=21;i<=40;++i)p.observe(i,30);assert(std::strcmp(p.state(),"UI_BLOCKED_OR_BUSY")==0);
 p.observe(41,31);assert(std::strcmp(p.state(),"HOST_PROGRESS")==0);
 Ps2LineLogBuffer b(sink);std::ostream stream(&b);
 stream<<"partial";assert(output.empty());stream.flush();assert(output=="partial");
 output.clear();stream<<std::string(5000,'x')<<'\n';assert(output==std::string(5000,'x')+'\n');
 output.clear();std::thread a([&]{for(int i=0;i<100;++i)b.sputn("aaa\n",4);});
 std::thread c([&]{for(int i=0;i<100;++i)b.sputn("bbb\n",4);});a.join();c.join();assert(output.size()==800);
 for(std::size_t i=0;i<output.size();i+=4)assert(output.substr(i,4)=="aaa\n"||output.substr(i,4)=="bbb\n");
}
