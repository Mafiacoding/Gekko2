#!/usr/bin/env python3
"""Exercise production SQRT.S emission with distinct Fs/Ft and aliased Fd.

No owner code: compile the emitted template and architectural operand indices.
Use --translator to check the old emitter as a negative control.
"""
import argparse,json,re,subprocess,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--translator',type=Path,default=root/'ps2xRecomp/src/lib/fpu_translator.cpp');args=p.parse_args()
s=args.translator.read_text().split('case COP1_S_SQRT:',1)[1].split('case COP1_S_ABS:',1)[0]
m=re.search(r'return fmt::format\(("(?:[^"\\]|\\.)*"),\s*(\w+),\s*(\w+)\);',s)
if not m:raise SystemExit('SQRT emitter shape changed: adapt the test')
template=json.loads(m[1]);parameters=m[2],m[3]
body=template.format(*parameters)
source=r'''
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
struct Context {float f[32];};
#define FPU_SQRT_S(value) std::sqrt(std::fabs(value))
static uint32_t bits(float v){uint32_t b;std::memcpy(&b,&v,4);return b;}
static void emitted(Context*ctx,unsigned fd,unsigned fs,unsigned ft){BODY}
int main(){unsigned count=0;
 for(unsigned fs=0;fs<32;++fs)for(unsigned ft=0;ft<32;++ft){
  if(fs==ft)continue;
  for(unsigned fd=0;fd<32;++fd){
   if(fd!=0&&fd!=fs&&fd!=ft&&fd!=31)continue;
   Context c;for(unsigned i=0;i<32;++i)c.f[i]=float((i+2)*(i+2));
   c.f[fs]=-121.0f;c.f[ft]=49.0f;emitted(&c,fd,fs,ft);
   if(bits(c.f[fd])!=bits(7.0f)){std::fprintf(stderr,"wrong SQRT operand fs=%u ft=%u fd=%u\n",fs,ft,fd);return 1;}++count;
  }
 }std::printf("PASS: %u production SQRT.S operand/alias cases\n",count);
}
'''.replace('BODY',body)
with tempfile.TemporaryDirectory(prefix='ps2-sqrt-') as tmp:
 d=Path(tmp);(d/'test.cpp').write_text(source)
 subprocess.run(['g++','-std=c++20','-O1','-fsanitize=address,undefined',str(d/'test.cpp'),'-o',str(d/'test')],check=True)
 subprocess.run([str(d/'test')],check=True)
