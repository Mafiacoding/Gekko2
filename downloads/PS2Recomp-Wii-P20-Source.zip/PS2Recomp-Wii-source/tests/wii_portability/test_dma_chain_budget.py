#!/usr/bin/env python3
"""Run production DMA chain walker with a budget that rejects geometric growth."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/ps2_memory.cpp').read_text();a=s.index('                auto enqueueTransfer =');b=s.index('                const bool autoProcessTransfers',a)
body=s[a:b].replace('std::vector<uint8_t> chainBuf;','Bytes chainBuf;')
prefix=r'''
#include <cstdint>
#include <vector>
#include <unordered_map>
#include <stdexcept>
#include <cassert>
#include <memory>
#include <algorithm>
size_t maxAllocation=1100000,allocationCount=0,largestAllocation=0;
template<class T>struct BudgetAllocator:std::allocator<T>{
 using value_type=T;
 template<class U>struct rebind{using other=BudgetAllocator<U>;};
 T*allocate(size_t n){if(n*sizeof(T)>maxAllocation)throw std::bad_alloc();++allocationCount;largestAllocation=std::max(largestAllocation,n*sizeof(T));return std::allocator<T>::allocate(n);}
 template<class U>bool operator==(const BudgetAllocator<U>&)const{return true;}
};
using Bytes=std::vector<uint8_t,BudgetAllocator<uint8_t>>;
constexpr uint32_t PS2_RAM_SIZE=32*1024*1024,PS2_SCRATCHPAD_SIZE=16384;
template<class T>T loadScalar(const uint8_t*p,uint32_t off,uint32_t,const char*,uint32_t){T v=0;for(unsigned i=0;i<sizeof(T);++i)v|=T(p[off+i])<<(8*i);return v;}
struct PendingTransfer{bool fromScratchpad=false;uint32_t srcAddr=0,qwc=0;Bytes chainData;};
struct Fixture{
 std::vector<uint8_t>ram=std::vector<uint8_t>(PS2_RAM_SIZE),scratch=std::vector<uint8_t>(PS2_SCRATCHPAD_SIZE);
 uint8_t*m_rdram=ram.data(),*m_scratchpad=scratch.data();
 std::unordered_map<uint32_t,uint32_t>m_ioRegisters;
 std::vector<PendingTransfer>m_pendingGifTransfers,m_pendingVif1Transfers,m_pendingVif0Transfers;
 bool isScratchpad(uint32_t a){return (a&0xffffc000)==0x70000000;}
 uint32_t translateAddress(uint32_t a){return isScratchpad(a)?a&0x3fff:a&0x1fffffff;}
 void start(uint32_t channelBase,uint32_t value){uint32_t madr=0,qwc=0;
'''
suffix=r'''
 }
 auto&queue(unsigned channel){if(channel==0x1000a000)return m_pendingGifTransfers;if(channel==0x10009000)return m_pendingVif1Transfers;return m_pendingVif0Transfers;}
 void tag(uint32_t offset,uint64_t low,uint64_t high){for(unsigned i=0;i<8;++i){ram[offset+i]=low>>(8*i);ram[offset+8+i]=high>>(8*i);}}
};
int main(){
 // Reproduce the transient-allocation issue without a game asset: each REF
 // appends the same synthetic payload; END/REFE and optional TTE retain order.
 constexpr uint32_t tags=129,payload=8192,source=0x10000;
 {Bytes oldGrowth;bool failed=false;try{for(unsigned i=0;i<tags;++i)oldGrowth.insert(oldGrowth.end(),payload,0);}catch(const std::bad_alloc&){failed=true;}assert(failed);}
 for(unsigned channel:{0x1000a000u,0x10009000u,0x10008000u})for(bool tte:{false,true}){
  Fixture f;for(unsigned i=0;i<payload;++i)f.ram[source+i]=uint8_t(i*29+17);
  for(unsigned i=0;i<tags;++i)f.tag(i*16,(uint64_t(source)<<32)|((i+1==tags?0ull:3ull)<<28)|(payload/16),0x1122334455667788ull+i);
  allocationCount=0;largestAllocation=0;
  f.start(channel,0x105|(tte?0x40:0));
  assert(f.queue(channel).size()==1);auto&out=f.queue(channel)[0].chainData;
  const bool tagData=tte&&channel!=0x1000a000u;
  assert(out.size()==tags*(payload+(tagData?8:0))&&allocationCount==1&&largestAllocation==out.size());
  size_t offset=0;for(unsigned tag=0;tag<tags;++tag){if(tagData){for(unsigned i=0;i<8;++i)assert(out[offset++]==f.ram[tag*16+8+i]);}for(unsigned i=0;i<payload;++i)assert(out[offset++]==f.ram[source+i]);}
  assert(f.m_ioRegisters[channel+0x30]==tags*16);
 }
 // CALL -> RET -> END must restart the second walk with the initial ASR/ASP.
 {Fixture f;f.tag(0,(uint64_t(0x100)<<32)|(5ull<<28)|1,0);f.tag(32,(7ull<<28)|1,0);f.tag(0x100,(6ull<<28)|1,0);
  f.ram[16]=0x11;f.ram[0x110]=0x22;f.ram[48]=0x33;
  f.start(0x10009000,0x105);auto&out=f.queue(0x10009000)[0].chainData;
  assert(out.size()==48&&out[0]==0x11&&out[16]==0x22&&out[32]==0x33);
  assert((f.m_ioRegisters[0x10009000]&0x30)==0&&f.m_ioRegisters[0x10009040]==32);
 }
 // TIE must terminate at IRQ; the second tag is deliberately unreachable.
 {Fixture f;f.tag(0,(uint64_t(source)<<32)|(3ull<<28)|(1ull<<31)|1,0);f.ram[source]=0xa5;
  f.start(0x10009000,0x185);auto&out=f.queue(0x10009000)[0].chainData;
  assert(out.size()==16&&out[0]==0xa5&&f.m_ioRegisters[0x10009030]==16);
 }
}
'''
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'test.cpp').write_text(prefix+body+suffix)
 subprocess.run(['c++','-std=c++20','-O1','-fsanitize=address,undefined',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: production parser, 6 large chains under 1.1 MB allocation budget, byte order/TTE, CALL/RET, TIE, geometric-growth negative control')
