#include "ps2recomp/computed_code_targets.h"
#include <cassert>
int main() {
    // Synthetic addresses/registers: LUI; ANDI; ADDI; SLL; ADD; JR.
    std::array<uint32_t,6> w{0x3c090020,0x308a000f,0x21290100,0x000a5100,0x012a4820,0x01200008};
    auto targets = ps2recomp::computedCodeTargets(w);
    assert(targets.size() == 16 && targets.front() == 0x200100 && targets.back() == 0x2001f0);
    w[1] = 0x308a0005;
    targets = ps2recomp::computedCodeTargets(w);
    assert((targets == std::vector<uint32_t>{0x200100,0x200110,0x200140,0x200150}));
    const auto good = w;
    for (unsigned i=0; i<6; ++i) { w=good; w[i]=0xffffffff; assert(ps2recomp::computedCodeTargets(w).empty()); }
    w=good; w[1]=0x312a0005; assert(ps2recomp::computedCodeTargets(w).empty()); // overwritten input
    w=good; w[1]=0x308a00ff; assert(ps2recomp::computedCodeTargets(w).empty()); // unbounded
    w=good; w[3]=0x000a5040; assert(ps2recomp::computedCodeTargets(w).empty()); // unaligned
    w=good; w[2]=0x21290101; assert(ps2recomp::computedCodeTargets(w).empty());
    w=good; w[0]=0x3c09ffff; w[2]=0x21297ff0; w[1]=0x308a000f;
    assert(!ps2recomp::computedCodeTargets(w).empty()); // valid upper address
}
