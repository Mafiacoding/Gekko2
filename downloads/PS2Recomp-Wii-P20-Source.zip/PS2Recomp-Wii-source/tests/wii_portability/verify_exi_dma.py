#!/usr/bin/env python3
"""Execute the linked SDK EXI_Dma and inspect its programmed address.

Models register writes, not a complete EXI device or physical Wii DMA transfer.
Use --expect-mem2-alias ONLY to verify an archived broken baseline.
"""
import argparse,json,struct,subprocess
from pathlib import Path
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--elf',type=Path,required=True);p.add_argument('--nm',required=True)
p.add_argument('--expect-mem2-alias',action='store_true');p.add_argument('--output',type=Path)
a=p.parse_args();data=a.elf.read_bytes()
if len(data)<52 or data[:7]!=b'\x7fELF\x01\x02\x01' or struct.unpack_from('>H',data,18)[0]!=20:
 raise SystemExit('Expected ELF32 big-endian PPC')
symbols={parts[2]:int(parts[0],16) for line in subprocess.check_output([a.nm,str(a.elf)],text=True).splitlines() if len(parts:=line.split())==3}
u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN)
u.mem_map(0x80000000,0x1800000);u.mem_map(0x90000000,0x4000000);u.mem_map(0xcd006000,0x1000)
ph=struct.unpack_from('>I',data,28)[0];step,count=struct.unpack_from('>HH',data,42)
if step<32 or ph+step*count>len(data):raise SystemExit('Invalid ELF program table')
for i in range(count):
 kind,offset,address,_,size,*_=struct.unpack_from('>8I',data,ph+i*step)
 if kind!=1 or not size:continue
 if offset+size>len(data) or not (0x80003400<=address and address+size<=0x81800000 or 0x90002000<=address and address+size<=0x93400000):
  raise SystemExit('Invalid load segment')
 u.mem_write(address,data[offset:offset+size])
# SDK v3.1 exibus_priv: flags is the seventh word. Select channel 0 and
# use the null callback path, so no interrupt callback mock is needed.
u.mem_write(symbols['eximap']+24,struct.pack('>I',4))
sram=symbols['sramcntrl'];stop=0x80001000
for reg,value in [(UC_PPC_REG_1,0x817ffe00),(UC_PPC_REG_3,0),(UC_PPC_REG_4,sram),
                  (UC_PPC_REG_5,64),(UC_PPC_REG_6,0),(UC_PPC_REG_7,0),
                  (UC_PPC_REG_LR,stop),(UC_PPC_REG_MSR,0x2000)]:u.reg_write(reg,value)
u.emu_start(symbols['EXI_Dma'],stop,count=10000)
assert u.reg_read(UC_PPC_REG_PC)==stop and u.reg_read(UC_PPC_REG_3)==1
address,length,control=struct.unpack('>III',u.mem_read(0xcd006804,12))
assert length==64 and control==3
aliases=(address!=(sram&0x3fffffff))
assert aliases==a.expect_mem2_alias,{'buffer':hex(sram),'dma':hex(address),'alias':aliases}
if not a.expect_mem2_alias:assert 0x80003400<=sram and sram+80<=0x81800000
report={'linked_sdk_exi_dma_executed':True,'sram_buffer':hex(sram),'dma_address':hex(address),
        'dma_bytes':length,'mem2_alias_detected':aliases,'physical_wii':False}
if a.output:a.output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
