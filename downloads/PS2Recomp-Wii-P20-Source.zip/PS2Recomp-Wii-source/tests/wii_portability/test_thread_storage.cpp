#include "runtime/ps2_thread_local.h"
#include <atomic>
#include <cassert>
#include <thread>
struct Value {
 static std::atomic<int> alive;
 int count=0;
 Value(){++alive;}
 ~Value(){--alive;}
};
std::atomic<int> Value::alive{0};
int main(){
 Ps2ThreadLocal<Value> storage;
 storage.get().count=41;
 for(int repeat=0;repeat<20;++repeat){
  std::atomic<int> ready{0};
  auto worker=[&]{
   auto &v=storage.get();assert(v.count==0);v.count=7;
   ++ready;while(ready.load()!=2)std::this_thread::yield();
   assert(&storage.get()==&v&&v.count==7);
   storage.releaseCurrent();assert(storage.get().count==0);storage.releaseCurrent();
  };
  std::thread a(worker),b(worker);a.join();b.join();
  assert(storage.get().count==41);assert(Value::alive==1);
 }
 storage.releaseCurrent();assert(Value::alive==0);
}
