"""Synthetic ELF fixtures; no game code or owner assets."""
import importlib.util
import struct
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location('panic', Path(__file__).parents[2] / 'tools/wii/analyze_panic_code.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def fixture(flags=5):
    data = bytearray(128)
    data[:7] = b'\x7fELF\x01\x02\x01'
    struct.pack_into('>H', data, 18, 20)
    struct.pack_into('>I', data, 28, 52)
    struct.pack_into('>HH', data, 42, 32, 1)
    struct.pack_into('>8I', data, 52, 1, 96, 0x80004000, 0, 12, 12, flags, 4)
    struct.pack_into('>3I', data, 96, 0x60000000, 0x7f83e378, 0x60000000)
    return data


class PanicAnalysis(unittest.TestCase):
    def test_matching_code(self):
        words = [0x60000000, 0x7f83e378, 0x60000000]
        result = module.analyze(fixture(), 0x80004004, words, words)
        self.assertTrue(result['ram_matches_elf'])
        self.assertEqual(result['different_ram_addresses'], [])

    def test_shared_modified_code_explains_alignment(self):
        words = [0x60000000, 0xc2493db3, 0]
        result = module.analyze(fixture(), 0x80004004, words, words, 0x3db3, {9: 0})
        self.assertFalse(result['ram_matches_elf'])
        self.assertTrue(result['cached_matches_ram'])
        self.assertEqual(result['different_ram_addresses'], ['80004004', '80004008'])
        self.assertTrue(result['matches_dar'])
        self.assertTrue(result['unaligned_word'])
        self.assertFalse(result['writer_identified'])

    def test_distinct_views_do_not_claim_same_ram(self):
        expected = [0x60000000, 0x7f83e378, 0x60000000]
        result = module.analyze(fixture(), 0x80004004, [0, 0, 0], expected)
        self.assertTrue(result['ram_matches_elf'])
        self.assertFalse(result['cached_matches_ram'])

    def test_unknown_register_does_not_invent_address(self):
        words = [0, 0xc2493db3, 0]
        self.assertNotIn('effective_address', module.analyze(fixture(), 0x80004004, words, words))

    def test_reject_invalid_inputs(self):
        for data, pc in [(fixture(4), 0x80004004), (fixture()[:100], 0x80004004),
                         (fixture(), 0x80004005), (fixture(), 0x80005004), (b'', 0x80004004)]:
            with self.subTest(pc=pc, length=len(data)):
                with self.assertRaises(ValueError):
                    module.elf_window(data, pc)


if __name__ == '__main__':
    unittest.main()
