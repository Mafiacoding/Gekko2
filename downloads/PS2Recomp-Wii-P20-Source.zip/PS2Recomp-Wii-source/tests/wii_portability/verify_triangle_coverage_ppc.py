#!/usr/bin/env python3
"""Check production fixed-point triangle coverage on PPC against rectangle tilings."""
import argparse,json,struct,subprocess,tempfile
from pathlib import Path
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *
p=argparse.ArgumentParser();p.add_argument('--devkitppc',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parents[2]
source=r'''
#include "runtime/gs/gs_triangle_coverage.h"
#include <cstddef>
extern "C" void*memset(void*p,int x,size_t n){auto*d=(volatile unsigned char*)p;for(size_t i=0;i<n;++i)d[i]=x;return p;}
extern "C" void cases(const int32_t*in,uint32_t*out){
 int32_t xy[6];for(unsigned t=0;t<2;++t){
  for(unsigned j=0;j<6;++j)xy[j]=in[6*t+j];
  GSFixedTriangleCoverage c(xy,in[12],in[13]);
  int64_t rows[3]={c.edges[0].value,c.edges[1].value,c.edges[2].value};
  for(unsigned y=0;y<8;++y){int64_t e[3]={rows[0],rows[1],rows[2]};
   for(unsigned k=0;k<3;++k)rows[k]+=c.edges[k].stepY;
   for(unsigned x=0;x<8;++x){bool covered=c.area!=0;for(unsigned k=0;k<3;++k){covered&=c.edges[k].contains(e[k]);e[k]+=c.edges[k].stepX;}out[t*64+y*8+x]=covered;}
  }
 }
}
'''
with tempfile.TemporaryDirectory(prefix='gs-coverage-') as td:
 d=Path(td);(d/'test.cpp').write_text(source);elf=d/'test.elf'
 subprocess.run([str(a.devkitppc/'bin/powerpc-eabi-g++'),'-std=c++20','-O2','-mcpu=750','-meabi','-nostdlib','-I'+str(root/'ps2xRuntime/include'),'-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(d/'test.cpp'),'-lgcc','-o',str(elf)],check=True)
 b=elf.read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',b,28)[0];step,n=struct.unpack_from('>HH',b,42)
 for i in range(n):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',b,ph+i*step)
  if kind==1:u.mem_write(addr,b[off:off+length])
 entry=struct.unpack_from('>I',b,24)[0];count=0;pixels=0
 for offset in (-65535,-17,0,7,65535):
  for fraction in range(16):
   for winding in (0,1):
    for diagonal in (0,1):
     left,top=offset+fraction,offset+fraction;right,bottom=left+64,top+80
     corners=[(left,top),(right,top),(right,bottom),(left,bottom)]
     indices=[(0,1,3),(1,2,3)] if diagonal==0 else [(0,1,2),(0,2,3)]
     tris=[]
     for ids in indices:
      if winding:ids=ids[::-1]
      tris.extend(v for i in ids for v in corners[i])
     sampleX=offset-8;sampleY=offset-8
     u.mem_write(0x90000000,struct.pack('>14i',*tris,sampleX,sampleY))
     for r,v in ((UC_PPC_REG_1,0x801fe000),(UC_PPC_REG_3,0x90000000),(UC_PPC_REG_4,0x90001000),(UC_PPC_REG_LR,0x80001000)):u.reg_write(r,v)
     u.emu_start(entry,0x80001000,count=100000);assert u.reg_read(UC_PPC_REG_PC)==0x80001000
     masks=struct.unpack('>128I',u.mem_read(0x90001000,512))
     for y in range(8):
      for x in range(8):
       expected=int(left<=sampleX+16*x<right and top<=sampleY+16*y<bottom)
       i=y*8+x;assert masks[i]+masks[64+i]==expected,(offset,fraction,winding,diagonal,x,y)
       pixels+=1
     count+=1
 report=dict(cases=count,pixel_ownership_checks=pixels,matched=True,physical_wii=False,scope='PPC750 production exact edge values/steps/top-left rule; both windings, diagonals, fractional translations and large coordinates')
 a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
