#!/usr/bin/env python3
"""Execute production SQRT emission/FPU helpers and argument lanes on PPC750.

Synthetic inputs only. Unicorn execution is not physical Wii validation.
"""
from pathlib import Path
import re,json,struct,subprocess,tempfile,math,argparse
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--devkitppc',type=Path,required=True)
parser.add_argument('--output',type=Path)
args=parser.parse_args()
root=Path(__file__).resolve().parents[2]
cc=str(args.devkitppc/'bin/powerpc-eabi-g++')
s=(root/'ps2xRecomp/src/lib/fpu_translator.cpp').read_text().split('case COP1_S_SQRT:',1)[1].split('case COP1_S_ABS:',1)[0]
m=re.search(r'return fmt::format\(("(?:[^"\\]|\\.)*"),\s*(\w+),\s*(\w+)\);',s);body=json.loads(m[1]).format(m[2],m[3])
macros=(root/'ps2xRuntime/include/ps2_runtime_macros.h').read_text();helpers=macros.split('constexpr uint32_t PS2_FLOAT_MAX_BITS',1)[1].split('enum class Ps2VecOp',1)[0];helpers='constexpr uint32_t PS2_FLOAT_MAX_BITS'+helpers
src='''#include <bit>
#include <cstdint>
#include <cmath>
#include <cstddef>
#include "ps2_simd.h"
#define PS2_FLOAT_NOINLINE __attribute__((noinline))
extern "C" void*memset(void*p,int value,size_t n){auto*d=(volatile unsigned char*)p;for(size_t i=0;i<n;++i)d[i]=value;return p;}
extern "C" void*memcpy(void*d,const void*s,size_t n){auto*p=(volatile unsigned char*)d;auto*q=(const volatile unsigned char*)s;for(size_t i=0;i<n;++i)p[i]=q[i];return d;}
extern "C" int*__errno(){static int error;return &error;}
'''+helpers+'''
#define FPU_SQRT_S(a) ps2_fsqrt(a)
struct Context{float f[32];};
extern "C" void cases(const uint32_t*in,uint32_t*out){Context c{};auto*ctx=&c;unsigned fd=0,fs=5,ft=12;c.f[fs]=121;c.f[ft]=std::bit_cast<float>(in[0]);BODY
out[0]=std::bit_cast<uint32_t>(c.f[0]);auto arg=_mm_set_epi32(0,0,0,int32_t(in[1]));for(int i=0;i<4;i++)out[i+1]=arg.u32[i];}
'''.replace('BODY',body)
# extract_epi32 accepts a run-time index in the scalar portability implementation.
src=src.replace('arg.u32[i]','_mm_extract_epi32(arg,i)')
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'test.cpp').write_text(src)
 subprocess.run([cc,'-std=c++20','-Os','-mcpu=750','-meabi','-mno-altivec','-mno-vsx','-DPS2X_WII_SCALAR_SIMD','-I'+str(root/'ps2xRuntime/include'),'-nostdlib','-Wl,--gc-sections','-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(d/'test.cpp'),'-lm','-lgcc','-o',str(d/'test.elf')],check=True)
 data=(d/'test.elf').read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',data,28)[0];step,count=struct.unpack_from('>HH',data,42)
 for i in range(count):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',data,ph+i*step)
  if kind==1:u.mem_write(addr,data[off:off+length])
 entry=struct.unpack_from('>I',data,24)[0]
 for value in [0.,1.,4.,9.,16.,49.,100.,-49.,0.25]:
  for arg in [0,63,224,640,0x80000000,0xffffffff]:
   bits=struct.unpack('>I',struct.pack('>f',value))[0];u.mem_write(0x90000000,struct.pack('>2I',bits,arg));u.reg_write(UC_PPC_REG_1,0x801fe000);u.reg_write(UC_PPC_REG_3,0x90000000);u.reg_write(UC_PPC_REG_4,0x90001000);u.reg_write(UC_PPC_REG_LR,0x80001000);u.reg_write(UC_PPC_REG_MSR,0x2000)
   u.emu_start(entry,0x80001000,count=1000000);assert u.reg_read(UC_PPC_REG_PC)==0x80001000
   got=struct.unpack('>5I',u.mem_read(0x90001000,20));expected=struct.unpack('>I',struct.pack('>f',math.sqrt(abs(value))))[0];assert got==(expected,arg,0,0,0),(value,arg,got)
 report={'cases':54,'matched':True,'scope':'actual SQRT emission, production scalar FPU helpers, SDK libm and GS argument lane construction on PPC750 Unicorn','physical_wii':False}
 
 if args.output:args.output.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
