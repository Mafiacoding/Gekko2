#!/usr/bin/env python3
"""Exercise production DMA chain parsing against synthetic guest tags."""
from pathlib import Path
import subprocess,tempfile
root=Path(__file__).resolve().parents[2]
s=(root/'ps2xRuntime/src/lib/ps2_memory.cpp').read_text();a=s.index('                auto enqueueTransfer =');b=s.index('                const bool autoProcessTransfers',a);body=s[a:b]
prefix=r'''
#include <cstdint>
#include <vector>
#include <unordered_map>
#include <stdexcept>
#include <cassert>
#include <cstring>
constexpr uint32_t PS2_RAM_SIZE=4096,PS2_SCRATCHPAD_SIZE=256;
template<class T>T loadScalar(const uint8_t*p,uint32_t off,uint32_t,const char*,uint32_t){T v=0;for(unsigned i=0;i<sizeof(T);++i)v|=T(p[off+i])<<(i*8);return v;}
struct PendingTransfer{bool fromScratchpad=false;uint32_t srcAddr=0,qwc=0;std::vector<uint8_t>chainData;};
struct Fixture{
 uint8_t ram[4096]{},scratch[256]{};uint8_t*m_rdram=ram,*m_scratchpad=scratch;
 std::unordered_map<uint32_t,uint32_t> m_ioRegisters;
 std::vector<PendingTransfer>m_pendingGifTransfers,m_pendingVif1Transfers,m_pendingVif0Transfers;
 bool isScratchpad(uint32_t a){return (a&0xffff0000)==0x70000000;}
 uint32_t translateAddress(uint32_t a){if(isScratchpad(a)){if((a&0xffff)>=256)throw std::runtime_error("bad");return a&0xffff;}if(a>=4096)throw std::runtime_error("bad");return a;}
 void start(uint32_t channelBase,uint32_t value){uint32_t madr=0,qwc=0;
'''
suffix=r'''
 }
 std::vector<PendingTransfer>&queue(unsigned channel){if(channel==0x1000a000)return m_pendingGifTransfers;if(channel==0x10009000)return m_pendingVif1Transfers;return m_pendingVif0Transfers;}
 void tag(uint64_t word){for(unsigned i=0;i<8;++i)ram[i]=word>>(8*i);}
};
int main(){
 for(unsigned c:{0x1000a000u,0x10009000u,0x10008000u}){
  {Fixture f;f.tag(7ull<<28);f.start(c,0x105);assert(f.queue(c).size()==1&&f.queue(c)[0].chainData.empty());}
  {Fixture f;f.tag(2ull<<28);f.start(c,0x105);assert(f.queue(c).empty());} // bounded nonterminating NEXT
  {Fixture f;f.m_ioRegisters[c+0x30]=4096;f.start(c,0x105);assert(f.queue(c).empty());} // invalid address
  {Fixture f;f.tag(1ull | (uint64_t(32)<<32));f.ram[32]=0xa5;f.start(c,0x105);assert(f.queue(c).size()==1&&f.queue(c)[0].chainData.size()==16&&f.queue(c)[0].chainData[0]==0xa5);}
 }
 for(unsigned c:{0x10009000u,0x10008000u}){Fixture f;f.tag(7ull<<28);f.start(c,0x145);assert(f.queue(c).size()==1&&f.queue(c)[0].chainData.size()==8);}
}
'''
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'test.cpp').write_text(prefix+body+suffix)
 subprocess.run(['c++','-std=c++20','-O1','-fsanitize=address,undefined',str(p/'test.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],check=True)
print('PASS: real chain parser, empty END completion, TTE, payload, invalid and bounded cyclic chains')
