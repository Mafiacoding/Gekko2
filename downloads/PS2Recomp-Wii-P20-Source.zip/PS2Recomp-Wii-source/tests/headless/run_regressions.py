#!/usr/bin/env python3
"""Run shared GS/VU suites against an already configured private Ninja host build.

The linked executable contains private guest objects. Keep the build directory
private; never publish it as a synthetic fixture or public source artifact.
"""
import argparse,os,shlex,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--build-dir',type=Path,required=True);p.add_argument('--suite',choices=['all','gs','vu'],default='all');args=p.parse_args()
root=Path(__file__).resolve().parents[2];build=args.build_dir.resolve()
subprocess.run(['cmake','--build',str(build),'-j4'],check=True)
line=next(x for x in (build/'build.ninja').read_text().splitlines() if x.startswith('build crash_headless:'))
objects=line.split(': ',1)[1].split()[1:];objects=[x for x in objects if x.endswith('.o') and not x.endswith('/ps2xRuntime/src/main.cpp.o')]
assert objects and all((build/x).is_file() for x in objects),'Incomplete host build'
cache=(build/'CMakeCache.txt').read_text().splitlines();compiler=next(x.split('=',1)[1] for x in cache if x.startswith('CMAKE_CXX_COMPILER:'))
includes=['-I'+str(root/x) for x in ['ps2xTest/include','ps2xRuntime/include','ps2xIOP/include','ps2xRuntime/src/lib/Kernel','tests/headless','ps2xRuntime/platform/wii']]
suites=['gs','vu'] if args.suite=='all' else [args.suite]
oldmask=os.umask(0o077)
try:
 for suite in suites:
  name='ps2_gs' if suite=='gs' else 'ps2_vu1';d=build/'private-regressions'/suite;d.mkdir(parents=True,exist_ok=True)
  (d/'main.cpp').write_text('#include "MiniTest.h"\nvoid register_'+name+'_tests();int main(){register_'+name+'_tests();return MiniTest::Run();}\n')
  for src,label in [(d/'main.cpp','main'),(root/'ps2xTest/src'/(name+'_tests.cpp'),'tests')]:
   subprocess.run([compiler,'-std=c++20','-O1','-msse4.1','-DPS2X_HAS_FFMPEG=0',*includes,'-c',str(src),'-o',str(d/(label+'.o'))],check=True)
  exe=d/'regressions'
  # Response files avoid command-line limits with a fully generated guest.
  rsp=d/'objects.rsp';rsp.write_text('\n'.join(shlex.quote(str(build/x)) for x in objects))
  subprocess.run([compiler,'-Wl,--gc-sections','@'+str(rsp),str(d/'main.o'),str(d/'tests.o'),'-lpthread','-lm','-o',str(exe)],check=True)
  subprocess.run([str(exe)],check=True)
finally:os.umask(oldmask)
