#!/usr/bin/env python3
"""Run a private game regression and summarize input/load/frame evidence.

A passing probe establishes milestones, not image correctness or playability.
Game data, raw logs and captures stay in the supplied private output directory.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess


def inspect(text, profile):
    milestones = profile['milestones']
    reached = {}
    delivered = 0
    generated = 0
    captures_after_load = 0
    valid_frames = nonblack_frames = 0
    source = None
    summary = False
    sanitizer_error = False
    last_required_line = -1
    lines = text.splitlines()
    for number, line in enumerate(lines):
        if '[HEADLESS] source=' in line:
            match = re.search(r'\[HEADLESS\] source=(\S+)', line)
            if match: source = match[1]
        generated += '[HEADLESS_INPUT]' in line
        if '[PAD_PACKET]' in line:
            match = re.search(r'bytes=([0-9a-fA-F]{2}),([0-9a-fA-F]{2})', line)
            if match and match.groups() != ('ff', 'ff'): delivered += 1
        if 'ERROR: AddressSanitizer' in line or 'runtime error:' in line:
            sanitizer_error = True
        for milestone in milestones:
            label = milestone['name']
            if label not in reached and re.search(milestone['pattern'], line):
                reached[label] = number
        match = re.search(r'\[HEADLESS_SUMMARY\] valid_gs_frames=(\d+) nonblack_frames=(\d+)', line)
        if match:
            summary = True
            valid_frames, nonblack_frames = map(int, match.groups())
    if len(reached) == len(milestones):
        last_required_line = max(reached.values())
        for line in lines[last_required_line + 1:]:
            match = re.search(r'\[GS_CAPTURE\].* nonblack=(\d+)', line)
            if match and int(match[1]) >= profile.get('minimum_nonblack_pixels', 1):
                captures_after_load += 1
    missing = [m['name'] for m in milestones if m['name'] not in reached]
    passed = (summary and not sanitizer_error and not missing and captures_after_load > 0
              and (not profile.get('require_delivered_input', True) or delivered > 0))
    return dict(matched=passed, source_label=source, reached=list(reached), missing=missing,
                generated_input_samples=generated, delivered_input_packets=delivered,
                nonblack_captures_after_last_load=captures_after_load,
                valid_gs_frames=valid_frames, nonblack_gs_frames=nonblack_frames,
                completed_normally=summary, sanitizer_error=sanitizer_error,
                visible_image_correctness_verified=False, physical_wii=False,
                scope='Host input delivery, required load milestones, subsequent GS frames; no FPS or playability proof')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--elf', type=Path, required=True)
    parser.add_argument('--profile', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    profile = json.loads(args.profile.read_text())
    seconds = int(profile['seconds'])
    if not 1 <= seconds <= 3600: parser.error('profile seconds must be 1..3600')
    if not profile['milestones']: parser.error('at least one load milestone is required')
    binary, elf = args.binary.resolve(strict=True), args.elf.resolve(strict=True)
    args.output.mkdir(parents=True, exist_ok=True)
    # Explicit inputs, never inherit an earlier test's automatic button schedule.
    env = {k:v for k,v in os.environ.items() if not k.startswith('PS2_HEADLESS_')}
    env.update(PS2_HEADLESS_SECONDS=str(seconds), PS2_HEADLESS_TRACE_FILES='1',
               PS2_HEADLESS_TRACE_PAD='1', PS2_HEADLESS_CAPTURE_NONBLACK='1',
               PS2_HEADLESS_CAPTURE_LIMIT=str(profile.get('capture_limit', 120)),
               PS2_HEADLESS_OUTPUT=str((args.output/'frames').resolve()))
    if 'button_polls' in profile: env['PS2_HEADLESS_BUTTON_POLLS'] = profile['button_polls']
    log = args.output/'runtime.log'
    timed_out = False
    with log.open('wb') as target:
        try:
            run = subprocess.run([str(binary),str(elf)], cwd=elf.parent, env=env,
                                 stdout=target, stderr=subprocess.STDOUT,
                                 timeout=seconds+30)
            exit_code = run.returncode
        except subprocess.TimeoutExpired:
            timed_out = True; exit_code = None
    report = inspect(log.read_text(errors='replace'), profile)
    report.update(profile=profile['name'], binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
                  elf_sha256=hashlib.sha256(elf.read_bytes()).hexdigest(),
                  host_seconds_requested=seconds, process_exit=exit_code, timed_out=timed_out)
    report['matched'] &= not timed_out and exit_code == 0
    (args.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    return 0 if report['matched'] else 1

if __name__ == '__main__': raise SystemExit(main())
