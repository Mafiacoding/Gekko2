#pragma once
// Test-only host API declarations; production uses its normal backend.
#include "ps2_wii_host.h"
