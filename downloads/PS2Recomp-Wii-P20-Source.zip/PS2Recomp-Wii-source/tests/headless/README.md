# Private full-runtime GS regression runner

This x86-64/SSE4.1 test adapter runs the actual generated guest functions,
EE kernel, IOP, VU/VIF/GIF and software GS runtime. It replaces only the host
window/input/audio interface. It does not emulate Broadway, libogc, IOS or Wii
performance. No game data is bundled or downloaded.

Supply your private generated sources and an extracted owner disc directory:

```sh
cmake -G Ninja -S tests/headless -B /tmp/ps2-headless \
  -DPS2X_GENERATED_DIR=/private/recompiled \
  -DPS2X_EE_NATIVE_FLOAT_CONVERT=OFF
cmake --build /tmp/ps2-headless -j4
PS2_HEADLESS_SECONDS=60 PS2_HEADLESS_OUTPUT=/private/captures \
  /tmp/ps2-headless/crash_headless /private/disc/game.elf
```

The ELF directory is the initial CD root. Retain the extracted game assets
there. `PS2_HEADLESS_AUTO_START=1` enables synthetic Cross/Start pulses for
repeatable menu testing. It is optional and defaults off. Audio/MPEG remain
unavailable in this minimal test target.

Only valid GS presentation frames enter the capture hook; the no-frame
magenta diagnostic does not. PPM captures retain raw GS texel dimensions
(e.g. 640x224) before TV aspect scaling. The runner writes at most 32 images,
with captures spaced after initial samples. Logs include source revision,
valid/nonblack GS-frame counts and a host-only first-frame timestamp.

The guarded float-conversion option defaults OFF. Enable it only for a
library ABI validated against its original generated routines. The owner
Crash release enables it after a private differential check. Special inputs
and resumed/internal entries continue through the original guest code.

The test exercises the same consuming frame handoff used by the Wii adapter.
Host images are evidence of the emulated GS path, not Wii boot, FPS or
playability evidence. Keep images, generated source and game-containing
binaries private.

For post-loading scene tests, set `PS2_HEADLESS_SINGLE_START=1` alongside
`PS2_HEADLESS_AUTO_START=1`. This sends one START pulse at seconds 8–8.2,
then releases every button; it does not repeatedly pause the game.
`PS2_HEADLESS_CAPTURE_NONBLACK=1` skips black captures only in the saved
image set (all frames still count and present normally).
`PS2_HEADLESS_CAPTURE_LIMIT=N` changes the default maximum of 32 files.

For explicit reproducible inputs, `PS2_HEADLESS_BUTTON_SCRIPT="8:8.2:S,15:15.2:X"`
sets absolute host-time START (S) and Cross (X) intervals; no later inputs occur.

For input that cannot be missed while 3D rendering takes longer, use
`PS2_HEADLESS_BUTTON_POLLS="200:203:S,220:223:X"`. Intervals count actual
backend pad-state polls, starting at one, rather than wall time. The host
adapter logs each pressed poll. Do not equate a successful input pulse with
level loading: verify the file milestones and GS captures separately.
`PS2_HEADLESS_TRACE_FILES=1` reports VFS open results; optional
`PS2_HEADLESS_TRACE_VU=1` reports sampled VU runs. These are local host probes.

Run the existing production GS and VU regression suites without GUI packages:

```sh
python tests/headless/run_regressions.py --build-dir /private/ps2-headless
```

This reuses the configured Ninja host objects and creates test executables
under that private build. They contain private generated guest functions;
never publish these binaries or the build directory.
`PS2_HEADLESS_TRACE_PAD=1` logs non-neutral packets actually returned by
scePadRead, to distinguish a simulated host button from delivered guest input.

For a private decoded GS command stream, opt in with
`PS2_HEADLESS_GS_TRACE=/private/gs-stream.bin`. No trace is written by default.
The bounded little-endian host stream records register/packed writes, tag Q
resets, image uploads, explicit HLE clears, direct VRAM writes and presentation
metadata. This is a frontend-to-backend diagnostic, not a raw GIF or CPU trace.
Keep it private: it contains textures and other owner game data.

`python tests/headless/inspect_gs_trace.py /private/gs-stream.bin` checks record
sizes and the end marker/counters, and prints only counts. Normal termination,
the 2-GiB cap, malformed records and truncated output are distinguished. A
complete end marker means a clean capture boundary; it does not mean the game,
pending GS work, or a complete frame has finished. External termination/disk
errors can still produce incomplete streams. The stream is flushed on presents
and closed explicitly when the headless time limit is reached.

Replaying these decoded commands through another GS isolates raster/state
behavior. It cannot independently validate the original GIF decoder, VU/EE
geometry generation, HLE clear semantics, or race-free identical frame snapshots.
The independent replay adapter and owner traces used in the investigation remain
outside this repository. The public sink/parser tests use synthetic data only:
`python tests/headless/test_gs_trace.py`.

## Wii scalar representation with native memory checking

For a separate local regression build, configure
`-DPS2X_HEADLESS_SCALAR_SIMD=ON -DPS2X_HEADLESS_ASAN=ON`. Both default OFF.
The first option uses the Wii scalar lane representation; the second enables
AddressSanitizer on GCC/Clang. Every translation unit and the link receive the
sanitizer configuration. This is still an x86 process: it cannot detect a
Broadway ABI fault or a libogc hardware DMA address limitation. The EXI SRAM
regression specifically requires the linked PPC test or a Wii/Dolphin run.

A reproducible private scene probe can drive inputs, check required load
milestones and require subsequent GS frames in one run:

```sh
python tests/headless/run_scene_probe.py \
  --binary /private/ps2-headless/crash_headless \
  --elf /private/disc/game.elf \
  --profile tests/headless/profiles/crash_e3.json \
  --output /private/scene-probe
```

The supplied Crash E3 profile uses actual pad-poll counts and a 240-second host
budget. It requires title/hub geometry and hub terrain to load, delivered
controller packets, a nonblack GS capture after these loads, normal completion
and no reported sanitizer error. Missing optional files are not promoted to
required milestones. `report.json` summarizes evidence; raw logs and images
remain private. A passing report does not verify image correctness, controls
inside the level, physical Wii behavior or FPS. Review captures separately.
