#!/usr/bin/env python3
"""Validate private decoded GS streams; print counts, never packet payloads.

This checks serialization/completeness, not GS semantics or image equivalence.
"""
import argparse
from collections import Counter
import json
from pathlib import Path
import struct
MAX_RECORD=16*1024*1024
SIZES={0:0,1:12,2:20,4:0,5:20,6:40,7:24,0xffffffff:20}
NAMES={0:'reset',1:'register',2:'packed',3:'image',4:'tag_q',5:'present',6:'clear',7:'vram_write'}


def inspect(path):
    counts=Counter();records=0;position=8
    with Path(path).open('rb') as f:
        magic=f.read(8)
        if magic not in (b'PS2GSTR1',b'PS2GSTR2'):
            raise ValueError('unknown GS stream magic')
        while True:
            header=f.read(8)
            if not header:
                return {'version':int(chr(magic[-1])),'records':records,'counts':dict(counts),
                        'complete':False,'status':'missing_end_record'}
            if len(header)!=8:
                raise ValueError('truncated record header')
            kind,size=struct.unpack('<II',header)
            if size>MAX_RECORD or (kind!=3 and (kind not in SIZES or size!=SIZES[kind])):
                raise ValueError('unknown record or invalid payload length')
            data=f.read(size)
            if len(data)!=size:
                raise ValueError('truncated payload')
            if kind==0xffffffff:
                if magic!=b'PS2GSTR2':raise ValueError('legacy stream has unexpected end record')
                status,total,bytes_before=struct.unpack('<IQQ',data)
                if status>2 or total!=records or bytes_before!=position or f.read(1):
                    raise ValueError('end record counts/status/trailing data mismatch')
                return {'version':2,'records':records,'counts':dict(counts),
                        'complete':status==0,'status':('complete','size_limit','invalid_record')[status]}
            counts[NAMES[kind]]+=1;records+=1;position+=8+size


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('trace',type=Path)
    p.add_argument('--allow-incomplete',action='store_true');args=p.parse_args()
    try:report=inspect(args.trace)
    except (ValueError,OSError) as exc:p.exit(2,f'GS trace invalid: {exc}\n')
    print(json.dumps(report))
    return 0 if report['complete'] or args.allow_incomplete else 1
if __name__=='__main__':raise SystemExit(main())
