#!/usr/bin/env python3
"""Synthetic bounded/concurrent GS stream checks against the production sink."""
import importlib.util
from pathlib import Path
import struct
import subprocess
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('inspect_gs',Path(__file__).with_name('inspect_gs_trace.py'))
trace=importlib.util.module_from_spec(spec);spec.loader.exec_module(trace)
class TraceTests(unittest.TestCase):
 def test_actual_sink_disabled_cap_bad_record_and_concurrency(self):
  with tempfile.TemporaryDirectory() as tmp:
   d=Path(tmp);source=d/'test.cpp';exe=d/'test'
   source.write_text(r'''
#include "gs_replay_trace.h"
#include <thread>
#include <vector>
#include <string>
int main(int,char**argv){std::string dir=argv[1];
 {Ps2GsTrace::Sink disabled(nullptr);disabled.record(0,nullptr,0);disabled.finish();}
 {Ps2GsTrace::Sink sink((dir+"/full.bin").c_str());
  std::vector<std::thread> threads;
  for(int i=0;i<4;++i)threads.emplace_back([&]{for(int n=0;n<1000;++n)sink.record(Ps2GsTrace::TagQReset,nullptr,0);});
  for(auto&t:threads){t.join();}
  sink.finish();sink.record(0,nullptr,0);sink.finish();
 }
 {Ps2GsTrace::Sink sink((dir+"/cap.bin").c_str(),44);sink.record(0,nullptr,0);sink.record(0,nullptr,0);}
 {Ps2GsTrace::Sink sink((dir+"/bad.bin").c_str());sink.record(1,nullptr,12);}
}
''')
   subprocess.run(['c++','-std=c++20','-O1','-pthread','-Wall','-Wextra','-Werror','-I'+str(ROOT/'tests/headless'),str(source),'-o',str(exe)],check=True)
   subprocess.run([str(exe),str(d)],check=True)
   full=trace.inspect(d/'full.bin');self.assertTrue(full['complete']);self.assertEqual(full['records'],4000)
   cap=trace.inspect(d/'cap.bin');self.assertEqual(cap['status'],'size_limit');self.assertEqual((d/'cap.bin').stat().st_size,44)
   bad=trace.inspect(d/'bad.bin');self.assertEqual(bad['status'],'invalid_record');self.assertFalse(bad['complete'])

 def test_reject_partial_lengths_footer_counts_and_trailing_bytes(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'stream'
   p.write_bytes(b'PS2GSTR1');self.assertFalse(trace.inspect(p)['complete'])
   fixtures=[b'PS2GSTR2'+b'\x00',
     b'PS2GSTR2'+struct.pack('<II',3,5)+b'ab',
     b'PS2GSTR2'+struct.pack('<II',1,0),
     b'PS2GSTR2'+struct.pack('<II',3,trace.MAX_RECORD+1),
     b'PS2GSTR2'+struct.pack('<IIIQQ',0xffffffff,20,0,1,8),
     b'PS2GSTR2'+struct.pack('<IIIQQ',0xffffffff,20,0,0,8)+b'x']
   for data in fixtures:
    p.write_bytes(data)
    with self.assertRaises(ValueError):trace.inspect(p)
if __name__=='__main__':unittest.main()
