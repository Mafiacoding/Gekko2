#pragma once
// GPL-3.0-or-later. Opt-in local diagnostic stream, little-endian host only.
// Contains owner game data. Keep streams/captures outside public repositories.
#include <bit>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <initializer_list>
#include <mutex>

namespace Ps2GsTrace {
static_assert(std::endian::native == std::endian::little);
enum Kind : uint32_t { Reset, Register, Packed, Image, TagQReset, Present, Clear, VramWrite,
                       End = 0xffffffffu };
enum Status : uint32_t { Complete, SizeLimit, InvalidRecord };
constexpr uint32_t MaxRecord = 16u * 1024u * 1024u;
constexpr uint64_t MaxStream = uint64_t(2) * 1024u * 1024u * 1024u;

class Sink {
public:
    explicit Sink(const char* path, uint64_t limit = MaxStream)
        : requested_(path && *path), limit_(limit) {
        if (!requested_) return;
        if (limit_ < 36u || !(file_ = std::fopen(path, "wb"))) {
            std::fprintf(stderr, "[GS_TRACE] cannot open bounded private stream\n");
            return;
        }
        if (std::fwrite("PS2GSTR2", 1, 8, file_) != 8) { ioFailure(); return; }
        bytes_ = 8;
    }
    ~Sink() { finish(); }
    Sink(const Sink&) = delete;
    Sink& operator=(const Sink&) = delete;
    void record(uint32_t kind, const void* data, uint32_t size) {
        // requested_ is immutable: disabled tracing never takes a mutex.
        if (!requested_) return;
        std::lock_guard<std::mutex> lock(mutex_);
        if (!file_) return;
        if (kind > VramWrite || size > MaxRecord || (size && !data)) {
            finishLocked(InvalidRecord); return;
        }
        // Reserve the complete end record, even when the size cap is reached.
        if (bytes_ + 8u + size + 28u > limit_) { finishLocked(SizeLimit); return; }
        const uint32_t header[] = {kind, size};
        if (std::fwrite(header, 1, 8, file_) != 8 ||
            (size && std::fwrite(data, 1, size, file_) != size)) { ioFailure(); return; }
        bytes_ += 8u + size;
        ++records_;
        if (kind == Present && std::fflush(file_)) ioFailure();
    }
    void finish() {
        if (!requested_) return;
        std::lock_guard<std::mutex> lock(mutex_);
        finishLocked(Complete);
    }
private:
    void ioFailure() {
        std::fprintf(stderr, "[GS_TRACE] write failed; stream is incomplete\n");
        if (file_) std::fclose(file_);
        file_ = nullptr;
    }
    void finishLocked(uint32_t status) {
        if (!file_) return;
        const uint32_t end[] = {End, 20u, status, uint32_t(records_), uint32_t(records_ >> 32),
                               uint32_t(bytes_), uint32_t(bytes_ >> 32)};
        if (std::fwrite(end, 1, sizeof(end), file_) != sizeof(end)) { ioFailure(); return; }
        if (std::fclose(file_)) std::fprintf(stderr, "[GS_TRACE] close failed; verify stream before replay\n");
        file_ = nullptr;
    }
    const bool requested_;
    const uint64_t limit_;
    std::mutex mutex_;
    FILE* file_ = nullptr;
    uint64_t bytes_ = 0, records_ = 0;
};

inline Sink& sink() { static Sink instance(std::getenv("PS2_HEADLESS_GS_TRACE")); return instance; }
inline thread_local unsigned packedDepth = 0;
inline void event(uint32_t kind, const void* data, uint32_t size) { sink().record(kind, data, size); }
inline void words(uint32_t kind, std::initializer_list<uint32_t> data) {
    event(kind, data.begin(), uint32_t(data.size() * sizeof(uint32_t)));
}
inline void finish() { sink().finish(); }
struct PackedScope {
    PackedScope() { ++packedDepth; }
    ~PackedScope() { --packedDepth; }
    PackedScope(const PackedScope&) = delete;
};
}
