#ifndef PS2RECOMP_COMPUTED_CODE_TARGETS_H
#define PS2RECOMP_COMPUTED_CODE_TARGETS_H
#include <array>
#include <cstdint>
#include <vector>
namespace ps2recomp {
// Recognize a bounded inline code dispatch, not a memory jump table.
// All six instructions must be adjacent in a single straight-line block.
inline std::vector<uint32_t> computedCodeTargets(const std::array<uint32_t, 6>& w) {
    auto op = [](uint32_t x) { return x >> 26; };
    auto rs = [](uint32_t x) { return (x >> 21) & 31; };
    auto rt = [](uint32_t x) { return (x >> 16) & 31; };
    auto rd = [](uint32_t x) { return (x >> 11) & 31; };
    const auto base = rt(w[0]), index = rt(w[1]);
    if (!base || !index || base == index || rs(w[1]) == base ||
        op(w[0]) != 15 || rs(w[0]) != 0 || op(w[1]) != 12 ||
        op(w[2]) != 8 || rs(w[2]) != base || rt(w[2]) != base ||
        op(w[3]) != 0 || (w[3] & 63) != 0 || rs(w[3]) != 0 ||
        rt(w[3]) != index || rd(w[3]) != index ||
        op(w[4]) != 0 || (w[4] & 63) != 32 ||
        rs(w[4]) != base || rt(w[4]) != index || rd(w[4]) != base ||
        ((w[4] >> 6) & 31) != 0 ||
        w[5] != ((base << 21) | 8u)) return {};
    const uint32_t mask = w[1] & 65535, shift = (w[3] >> 6) & 31;
    // Keep analysis finite and reject ambiguous byte/halfword destinations.
    if (mask > 15 || shift > 4 || (mask && shift < 2)) return {};
    const int64_t start = int64_t((w[0] & 65535) << 16) + int16_t(w[2] & 65535);
    const int64_t end = start + (mask << shift);
    if (start < 0 || end > UINT32_MAX || (start & 3)) return {};
    std::vector<uint32_t> targets;
    for (uint32_t i = 0; i <= mask; ++i)
        if ((i & ~mask) == 0) targets.push_back(uint32_t(start) + (i << shift));
    return targets;
}
}
#endif
