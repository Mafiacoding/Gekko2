# P5: closed-file startup checkpoints

Owner P4 result: the previous panic is absent, but output remains black and
runtime.log is empty. This establishes neither ELF loading nor scheduler or
game progress. File creation indicates that at least the log-open path ran.

The old dup2 implementation was inspected and does reference-count descriptors;
closing the original descriptor is therefore not established as the cause.
P5 removes dependence on that path by using append-mode freopen streams with
unbuffered output, initially creating/flushing/closing a version banner.
Both stdout and stderr append, avoiding overwrite through independent offsets.

A separate boot-status.txt receives a handful of open/write/flush/close markers:
FAT ready, standard-stream opening, bootstrap completion, runtime construction,
initialization, ELF load and run/scheduler entry. Console output mirrors them.
The file is not evidence that later markers ran: only its recorded content is.
The primary panic path still bypasses SD/stdio streams entirely.

This is a startup-observability change, not a demonstrated black-screen fix.
The original stack-overflow fix remains active. All runtime functionality and
audio/MPEG limitations are unchanged. Future diagnosis uses the last marker,
not the assumption that a black display means a running load operation.

## Confirmed framebuffer overrun corrected

Both launcher and runtime previously passed console_init a (20,20) origin
with full framebuffer width/height. libogc 3.1 console.c uses that origin
plus the supplied dimensions in __console_clear; they are not screen bounds.
For 640x480, the last write ends 25,640 bytes past a 614,400-byte XFB.
It can damage adjacent framebuffer/heap storage. The console now uses aligned
(16,16) margins and dimensions (width-32,height-32), keeping clears and scrolling
inside the framebuffer. This is an independently established memory error;
its causal role in the owner's current black screen is not yet proven.
