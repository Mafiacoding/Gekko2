Gekko2 BETA12.29 – Entwicklungs-Teststand

apps/Gekko2 auf SD kopieren. Vorhandene Einstellungen werden nicht geliefert.
Eigene rechtmäßige BIOS/Disc-Dateien verwenden. Alle Experimente ab Werk OFF;
gespeicherte frühere Einstellungen bleiben erhalten. Änderungen: EE-Control, SPU2-Datapath und GETENTSPACE. Settings,
Experiments/Developer switches; nächster Cold Boot übernimmt die Auswahl.

Optional vorhandene Karte: sd:/pcsx2/memcards/MemoryCard1.ps2.
Keine automatische Erstellung/Formatierung. Der emulierte FORMAT-Befehl
formatiert jetzt tatsächlich; Karte und Daten werden niemals mitgeliefert.

Kontroll-DOL ohne Chain-Unterstützung, ELF, Source und Prüfungen im Review-ZIP.
Das ist kein Nachweis von Crash/Tekken-Spielbarkeit, korrigierten BIOS-Kacheln
oder höherer Wii-FPS. Vollständigen Bericht im Review-ZIP lesen.
