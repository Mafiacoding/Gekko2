#include <gccore.h>
#include <ogc/lwp_heap.h>
#include <ogc/mutex.h>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <algorithm>
#include <cerrno>
#include <atomic>
extern "C" void *__real_malloc(size_t);
extern "C" void *__real_calloc(size_t,size_t);
extern "C" void *__real_memalign(size_t,size_t);
extern "C" void *__real_realloc(void*,size_t);
extern "C" void __real_free(void*);
namespace {std::atomic<uint32_t> used{0},peak{0},failed{0};heap_cntrl heap;mutex_t mutex;uintptr_t begin=0,end=0;bool ready=false;struct Header {void *base;size_t bytes;};
 bool owns(void *p){return ready&&uintptr_t(p)>=begin&&uintptr_t(p)<end;}
 void *allocate(size_t alignment,size_t bytes){
  if(!ready||alignment<sizeof(void*)||(alignment&(alignment-1))||bytes>SIZE_MAX-alignment-sizeof(Header))return nullptr;
  LWP_MutexLock(mutex);void *base=__lwp_heap_allocate(&heap,uint32_t(bytes+alignment+sizeof(Header)));LWP_MutexUnlock(mutex);if(!base)return nullptr;
  uintptr_t value=(uintptr_t(base)+sizeof(Header)+alignment-1)&~(alignment-1);auto *h=reinterpret_cast<Header*>(value)-1;h->base=base;h->bytes=bytes;auto current=used.fetch_add(uint32_t(bytes))+uint32_t(bytes);auto old=peak.load();while(current>old&&!peak.compare_exchange_weak(old,current)){}return reinterpret_cast<void*>(value);
 }
}
void PS2WiiHeapInit(){
 if(ready)return;begin=(uintptr_t(SYS_GetArena2Lo())+31)&~uintptr_t(31);end=uintptr_t(SYS_GetArena2Hi())&~uintptr_t(31);
 if(end<=begin+1024*1024)return;end-=256*1024;
 if(LWP_MutexInit(&mutex,false)!=0)return;
 if(!__lwp_heap_init(&heap,reinterpret_cast<void*>(begin),uint32_t(end-begin),32))return;
 SYS_SetArena2Lo(reinterpret_cast<void*>(end));ready=true;
}
extern "C" void *__wrap_malloc(size_t n){
 if(n>=65536){if(void*p=allocate(32,n))return p;void*p=__real_malloc(n);if(!p)failed=uint32_t(n);return p;}
 if(void*p=__real_malloc(n))return p;
 void*p=allocate(32,n);if(!p)failed=uint32_t(n);return p;
}
extern "C" void *__wrap_memalign(size_t a,size_t n){if(a<sizeof(void*)||(a&(a-1))){errno=EINVAL;return nullptr;}if(n>=65536){if(void*p=allocate(std::max<size_t>(32,a),n))return p;return __real_memalign(a,n);}
 if(void*p=__real_memalign(a,n))return p;
 return allocate(std::max<size_t>(32,a),n);}
extern "C" void __wrap_free(void *p){if(owns(p)){auto *h=static_cast<Header*>(p)-1;used.fetch_sub(uint32_t(h->bytes));LWP_MutexLock(mutex);__lwp_heap_free(&heap,h->base);LWP_MutexUnlock(mutex);}else __real_free(p);}
extern "C" void *__wrap_calloc(size_t n,size_t bytes){if(bytes&&n>SIZE_MAX/bytes){errno=ENOMEM;return nullptr;}size_t total=n*bytes;void*p=__wrap_malloc(total);if(p)std::memset(p,0,total);return p;}

extern "C" void *__wrap_realloc(void *p,size_t n){if(!p)return __wrap_malloc(n);if(!n){__wrap_free(p);return nullptr;}if(!owns(p))return __real_realloc(p,n);auto *h=static_cast<Header*>(p)-1;void *q=__wrap_malloc(n);if(q){std::memcpy(q,p,std::min(n,h->bytes));__wrap_free(p);}return q;}

void PS2WiiHeapSnapshot(uint32_t*out){out[0]=used.load();out[1]=peak.load();out[2]=failed.load();}
