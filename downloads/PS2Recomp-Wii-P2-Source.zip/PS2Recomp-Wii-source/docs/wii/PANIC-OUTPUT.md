# P2: readable startup failure output

Owner hardware result for P1: HBC sees the small loader, the image is read,
then a red-bordered screen appears. No runtime.log was found. Successful
runtime initialization or gameplay is not established.

The red frame matches libogc 3.1 default_panic.c. Examination found two output
paths: default CRT DEBUGPrint is a no-op; the standard libogc panic actually
uses kprintf/dietPrint, whose default sink writes stderr. Runtime redirection
can send that into SD/file I/O during an exception. The empty DEBUGPrint alone
does not explain the standard panic. The original CPU exception is unknown.

P2 wraps DEBUGPrint for early kernel messages and supplies __SYS_PreInit to
install a direct console sink for dietPrint before the standard panic handler
is installed. The latter preserves the SDK formatter and bypasses stdout,
stderr, files and application locks. NULL padding blocks are handled explicitly.
No exceptions are suppressed or allowed to resume. No guessed PC/IRQ patch.

A host sink test verifies formatted PC/LR text, truncation and direct dietPrint
text/padding. Wii cross-build and static artifact checks pass. Physical panic
text, boot and gameplay remain unverified until an owner run. If reproduced,
photograph Exception, PC/LR and DAR/DSISR lines. This is a diagnostic correction,
not a claim that the startup crash itself is fixed.
