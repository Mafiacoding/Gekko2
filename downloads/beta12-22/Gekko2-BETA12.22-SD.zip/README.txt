Separate test app; retain your previous DOL for rollback. Both experiments factory OFF; saved choices apply at Cold Boot. No BIOS/discs included. Real Wii testing required.
