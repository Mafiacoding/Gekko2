BETA12.22 extends the canonical GS-to-GX texture upload to all 13 legal formats and adds four-format GX scanout. Eligible CT16/CT16S draws use a bounded GX source/readback route with exact GS destination tests, packing, masks and depth updates. Complex states retain software fallback.

Fixes independent CSM2 palette banks, CT16 AFAIL=RGB_ONLY alpha preservation, rejected XGKICK tag latching and IPU DC precision/reset behavior. Terminal GX failures pause and block unsafe resume/cold boot; the accidental B+Minus+Plus loader shortcut now pauses.

Validation: 37 host suites, 12,201 MPEG coefficient cases, 1,024 full-VRAM target comparisons, linked PPC format/XGKICK/IPU/fence/DMA/VIF tests and 20 chain/PSM mode comparisons. Both devkitPPC Wii DOL/ELF and MEM1 checks pass. Both experiments remain factory OFF. No real-Wii gameplay, BIOS-tile, purple-screen or FPS claim. See docs/BETA12.22-GS-GX-FORMATS.md for exact scope and gaps.
