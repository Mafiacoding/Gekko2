Quellcode-Batch P18. Kein Spiel und keine generierten Crash-Funktionen enthalten.
Siehe docs/wii/EXI-SRAM-CORRUPTION.md, DMA-CHAIN-ALLOCATION.md und VU-MEMORY-ENDIAN.md.
Der SDK-DMA-Code-Ueberschreiber ist lokal reproduziert und korrigiert.
Ein sichtbares GS-Laborbild ist im Wii-Build unter Dolphin belegt.
Fortschritt nach dem Loading-Screen, komplette Grafik und echte Wii-Spielbarkeit bleiben offen.
Den HBC-Loader nicht ersetzen; dies ist ein Quellcodepaket, kein neuer Wii-Testauftrag.
Toolchain: devkitPPC r50 / GCC 16.1.0 / libogc 3.1.0.
