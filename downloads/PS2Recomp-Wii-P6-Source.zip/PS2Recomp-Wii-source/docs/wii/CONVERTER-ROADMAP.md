# Wii converter roadmap

Status: design target, not an implemented converter or a compatibility claim.
The immediate target remains one complete owner-private Crash prototype build.
Gekko2 development is paused for this work.

## Intended user workflow

1. Select an owner-supplied disc: ISO, CHD, or BIN with its CUE where needed.
2. Inspect the disc filesystem, boot ELF, disc identity, and executable hashes.
3. Match a versioned, tested game profile. An unknown image may be analyzed, but
   must not be labelled supported or successfully converted by default.
4. Extract required files locally, generate native code, and compile with a
   verified devkitPPC/libogc toolchain.
5. Check unresolved targets, memory layout, DOL sections, and runtime features.
6. Produce an SD directory containing boot.dol, separate game data, and a build
   manifest; report explicitly whether hardware acceptance has been completed.

ISO/CHD/BIN are storage formats. Reading them does not establish that a game's
CPU code, overlays, VU programs, graphics, audio, and timing are supported.
CHD requires a CHD reader or chdman integration. Raw BIN requires correct sector
layout detection and track metadata; changing extensions is insufficient.

## Gates before a GUI

- Actual runtime execution on Broadway, including little-endian guest memory
  and all 128-bit lane widths. Native x86 and emulated PPC comparisons are
  useful tests, not physical Wii evidence.
- Linkable code and bounded combined MEM1/MEM2 usage, including guest RAM,
  VRAM, stacks, display buffers, registry, generated code, and heap headroom.
- Complete initial-disc mounting, executable loading, function dispatch, and
  observable failures for unsupported execution paths.
- Correct VU/GIF/GS transport, display and input; honest audio/MPEG limitations.
- A repeatable Crash boot test and an explicit physical-Wii acceptance result.

The initial -O1 Crash compilation produced 2,848 generated translation-unit
objects with 38,882,526 bytes of text and 1,054,629 bytes of BSS in aggregate.
These are unlinked sizes, not the final DOL or final memory requirement. Code
size and placement are unresolved; MEM1 alone is insufficient for that code.

## Architecture

Build a headless command-line pipeline first; the GUI invokes that same pipeline
and displays structured progress and diagnostics. Keep format readers, profile
selection, generation, compilation, validation, and packaging separate. Record
input hashes, profile version, compiler/library versions and enabled features in
every build manifest. Cancel safely and preserve the original disc files.

Game profiles record executable/overlay discovery, runtime requirements, and
verified compatibility. Shared fixes belong in the common runtime wherever
possible. Profiles must not silently skip required behavior or substitute fake
rendering just to report a successful conversion.

Compiled game code and extracted assets remain owner-private. The public
repository contains tools, runtime, synthetic tests, and build recipes only.
No GUI work is required before the first complete game port passes its gates.
