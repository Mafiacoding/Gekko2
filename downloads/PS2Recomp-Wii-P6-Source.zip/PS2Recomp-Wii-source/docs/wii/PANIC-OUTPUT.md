# P2: readable startup failure output

Owner hardware result for P1: HBC sees the small loader, the image is read,
then a red-bordered screen appears. No runtime.log was found. Successful
runtime initialization or gameplay is not established.

The red frame matches libogc 3.1 default_panic.c. Examination found two output
paths: default CRT DEBUGPrint is a no-op; the standard libogc panic actually
uses kprintf/dietPrint, whose default sink writes stderr. Runtime redirection
can send that into SD/file I/O during an exception. The empty DEBUGPrint alone
does not explain the standard panic. The original CPU exception is unknown.

P2 wraps DEBUGPrint for early kernel messages and supplies __SYS_PreInit to
install a direct console sink for dietPrint before the standard panic handler
is installed. The latter preserves the SDK formatter and bypasses stdout,
stderr, files and application locks. NULL padding blocks are handled explicitly.
No exceptions are suppressed or allowed to resume. No guessed PC/IRQ patch.

A host sink test verifies formatted PC/LR text, truncation and direct dietPrint
text/padding. Wii cross-build and static artifact checks pass. Physical panic
text, boot and gameplay remain unverified until an owner run. If reproduced,
photograph Exception, PC/LR and DAR/DSISR lines. This is a diagnostic correction,
not a claim that the startup crash itself is fixed.

## P3: nested exception in the SDK stack walker

The owner's P2 screenshot shows PC 0x8130f9ec, DAR 0x0a420a47, DSISR
0x04000000. Against that exact ELF, PC is __libogc_print_stack at
`lwz r4,4(r31)`; r31 is 0x0a420a43. This is a secondary DSI during panic
backchain traversal. The original exception context is not established by
this screenshot. No claim about game-code execution can follow from it.

P3 replaces __SYS_InstallPanicHandler with a bounded primary-context handler.
It snapshots only fixed PPCContext fields after checking address/alignment and
physical memory bounds, then displays PC/LR/MSR/SP and DAR/DSISR plus GPRs.
It never walks SP/backchains, dumps code at PC, calls SD/IOS or resumes execution.
Re-entry stops instead of overwriting the first screen with another context.
The SDK's fixed exception framebuffer at 0xC1700000 is used for display.

Three actual-PPC handler tests cover corrupt SP, invalid context, and a context
crossing the memory boundary, with mocked video/text sinks. This establishes
bounded memory access in those cases, not hardware panic/video operation.
The underlying startup exception remains unresolved pending the first context.
