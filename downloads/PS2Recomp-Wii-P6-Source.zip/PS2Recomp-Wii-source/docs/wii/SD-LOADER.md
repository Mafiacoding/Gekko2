# HBC launcher for the large Crash runtime

The P0 runtime is 24,496,408 bytes. HBC's appentry.c rejects entries larger
than LD_MAX_SIZE before displaying them. Its config.h derives that size from
LD_MIN_ADDR, BASE_ADDR and ARGS_MAX_LEN. The standalone loader is 445,800 bytes.
Reference: https://github.com/fail0verflow/hbc/tree/master/channel/channelapp

SD layout for P1:

    apps/ps2recomp-crash/boot.dol        (small loader)
    apps/ps2recomp-crash/meta.xml
    ps2recomp/crash-runtime.dol         (original large runtime)
    ps2recomp/game.elf
    ps2recomp/...                       (original extracted disc files)

The launcher reserves free MEM2 from 0x91800000 upwards before mounting SD.
It reads crash-runtime.dol into that reserved staging area, validates file
extents, destinations, entry and BSS overlaps, and copies a 220-byte transfer
stub to 0x93300000. Target destinations must be below the staging area. Thus
neither the image nor the active stub is overwritten by the target sections.
After shutdown/interrupt masking, the position-independent stub copies all
sections, performs cache maintenance, clears BSS and jumps to the entry. It
uses no stack, globals, IOS or C/library calls while replacing the launcher.
IOS IPC memory at and above 0x933e0000 is not touched.

Build from the repository root with current devkitPPC/libogc/libfat:

    make -f ps2xRuntime/platform/wii/loader/Makefile

Validation: build with -Wall -Wextra -Werror; actual PPC stub executed by Unicorn
in 12 cases (all section slots, empty/unaligned transfers, BSS and entry).
The exact C guards accept the current runtime and reject seven corrupt variants.
These tests do not simulate IOS shutdown, FAT access, HBC discovery or Wii boot.
The loader and runtime remain physically untested; no gameplay claim is made.
Runtime code, rendering, audio/MPEG limitations are unchanged from P0.
