# P4: reproduced startup stack overflow

The owner's P3 primary context shows ISI (exception 4), PC 0x0a460a44 and
LR 0x0a460a47. SP is 0x9074fa90; a retained register points to __once_proxy,
and other registers point into GS lookup-table initialization.

The P3 main prologue reserves 0x7f728 (522,024) bytes for its frame, including
the automatic PS2Runtime object. libogc 3.1 tuxedo/default_stacks.c supplies
s_mainStack[0x20000], only 131,072 bytes. The overflow occurs before bootstrap
and log creation. In P3 the overrun reaches PageTableC32, whose initialization
writes over active stack frames and saved return addresses.

Local exact reproduction: execute P3's actual compiled GSMem::InitLookupTables
at 0x812c1ff4 in Unicorn with SP=0x9074fa90 and a sentinel LR. The table writes
replace saved LR with 0x0a460a47; the return attempts PC=0x0a460a44 and raises
an unmapped instruction fetch, matching the owner screenshot. With SP outside
the tables at 0x907cf000, the same compiled function preserves the sentinel LR
and returns correctly. The owner-generated DOL stays private.

Fix: allocate PS2Runtime with std::make_unique and retain a reference for the
existing call sites. The Wii bootstrap initializes the MEM2 allocator before
this allocation. The new main frame is 232 bytes, as measured by GCC's
-fstack-usage report. Object ownership/destruction remain automatic.

Build acceptance now requires exactly one main stack report, a static frame,
and at most 8 KiB. It rejects the original 522,024-byte report, dynamic frames
and missing reports. This supplements ELF/DOL and initial arena checks; it is
not a complete bound on all generated guest call chains or peak heap use.

The startup corruption is reproduced and corrected locally. A successful Wii
boot, first image, gameplay and FPS remain unverified until the owner runs P4.
P3's bounded primary-panic screen remains enabled for any further exception.
Audio/MPEG and software-GS limitations remain unchanged.
