/* libogc 3.1 routes panic text through DEBUGPrint; its default CRT stub is
 * empty. Write to the initialized console directly, even after stdout has
 * been redirected to SD. No file I/O, heap allocation or application lock. */
#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>
struct _reent;
extern ssize_t __console_write(struct _reent*,void*,const char*,size_t);
void __wrap_DEBUGPrint(int channel,const char *format,...){
 (void)channel;
 if(!format)return;
 char text[768];va_list args;va_start(args,format);
 int length=vsnprintf(text,sizeof text,format,args);va_end(args);
 if(length<=0)return;
 size_t count=(size_t)length;if(count>=sizeof text)count=sizeof text-1;
 __console_write(NULL,NULL,text,count);
}
/* The standard libogc panic uses kprintf/dietPrint rather than DEBUGPrint.
 * Its default sink writes stderr, which may point at SD or hold stdio locks.
 * Install the direct sink before SYS_Init installs the panic handler. Keep
 * the SDK's allocation-free formatter and support its NULL padding chunks. */
typedef void (*DietPrintFn)(const char*,size_t);
extern DietPrintFn g_dietPrintFn;
static void panic_console_bytes(const char *text,size_t count){
 if(text){__console_write(NULL,NULL,text,count);return;}
 static const char spaces[]="                                ";
 while(count){size_t n=count<sizeof(spaces)-1?count:sizeof(spaces)-1;__console_write(NULL,NULL,spaces,n);count-=n;}
}
void __SYS_PreInit(void){g_dietPrintFn=panic_console_bytes;}
