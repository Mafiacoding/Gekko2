/* Preserve the first exception. Never walk a potentially corrupt backchain,
 * read instructions at the faulting PC, resume execution, or access SD/IOS. */
#include <gccore.h>
#include <tuxedo/ppc/exception.h>
#include <stdint.h>
extern void VIDEO_SetFramebuffer(void*);
extern void __VIClearFramebuffer(void*,u32,u32);
extern void __console_init(void*,int,int,int,int,int);
static volatile unsigned entered;
static int readable_context(uintptr_t p){
 return !(p&3)&&((p>=0x80003400u&&(uint64_t)p+sizeof(PPCContext)<=0x81800000u)||(p>=0x90002000u&&(uint64_t)p+sizeof(PPCContext)<=0x933e0000u));
}
static void primary_panic(unsigned cause,PPCContext *ctx){
 if(entered++)for(;;)__asm__ volatile("sync");
 /* Snapshot only fixed context fields, before changing the display. */
 uint32_t dar,dsisr,pc=0,lr=0,msr=0,sp=0,regs[32]={0};
 __asm__ volatile("mfdar %0":"=r"(dar));__asm__ volatile("mfdsisr %0":"=r"(dsisr));
 int valid=readable_context((uintptr_t)ctx);
 if(valid){pc=ctx->pc;lr=ctx->lr;msr=ctx->msr;sp=ctx->gpr[1];for(unsigned i=0;i<32;i++)regs[i]=ctx->gpr[i];}
 unsigned height=VIDEO_GetCurrentTvMode()==VI_PAL?574:480;
 void *frame=(void*)0xc1700000u;
 VIDEO_SetFramebuffer(frame);__VIClearFramebuffer(frame,height*640*2,COLOR_MAROON);
 __console_init(frame,32,32,576,(int)height-64,1280);
 kprintf("PS2Recomp PRIMARY PANIC - no stack walk\n");
 kprintf("EXCEPTION %u  CTX %08X  valid=%u\n",cause,(unsigned)(uintptr_t)ctx,valid);
 kprintf("PC %08X  LR %08X\nMSR %08X SP %08X\n",pc,lr,msr,sp);
 kprintf("DAR %08X DSISR %08X\n",dar,dsisr);
 for(unsigned i=0;i<32;i+=4)kprintf("R%02u %08X  %08X  %08X  %08X\n",i,regs[i],regs[i+1],regs[i+2],regs[i+3]);
 kprintf("Stopped. Photograph this screen; power off afterwards.\n");
 for(;;)__asm__ volatile("sync");
}
void __SYS_InstallPanicHandler(void){PPCExcptCurPanicFn=primary_panic;}
