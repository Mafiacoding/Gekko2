#pragma once
#include <stdint.h>
#include <stddef.h>
#define PS2_LOADER_STAGE 0x91800000u
typedef struct {uint32_t off[18],addr[18],size[18],bss,bss_size,entry;} Dol;
static int region(uint32_t a,uint32_t n){return n && ((a>=0x80003400u&&(uint64_t)a+n<=0x81800000u)||(a>=0x90002000u&&(uint64_t)a+n<=PS2_LOADER_STAGE));}
static int overlaps(uint32_t a,uint32_t n,uint32_t b,uint32_t m){return n&&m&& (uint64_t)a+n>b&&(uint64_t)b+m>a;}
static const char *validate(const Dol *d,size_t bytes){
 int entry=0;
 for(unsigned i=0;i<18;i++){
  if(!d->size[i])continue;
  if(!region(d->addr[i],d->size[i]))return "Destination outside permitted memory";
  if(d->off[i]<256||(uint64_t)d->off[i]+d->size[i]>bytes)return "Section outside file";
  if(i<7&&d->entry>=d->addr[i]&&(uint64_t)d->entry<(uint64_t)d->addr[i]+d->size[i])entry=1;
  for(unsigned j=0;j<i;j++)if(overlaps(d->addr[i],d->size[i],d->addr[j],d->size[j]))return "Overlapping destinations";
  if(overlaps(d->addr[i],d->size[i],d->bss,d->bss_size))return "BSS overlaps section";
 }
 if(!entry)return "Entry outside executable section";
 if(d->bss_size&&!region(d->bss,d->bss_size))return "Invalid BSS range";
 return NULL;
}
