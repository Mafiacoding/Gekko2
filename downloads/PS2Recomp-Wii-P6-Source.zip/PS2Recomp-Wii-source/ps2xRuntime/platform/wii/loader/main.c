#include <gccore.h>
#include <fat.h>
#include <ogc/irq.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <wiiuse/wpad.h>
#define STAGE 0x91800000u
#define STUB 0x93300000u
#define LIMIT (STUB-STAGE)
#define TARGET "sd:/ps2recomp/crash-runtime.dol"
extern const unsigned char ps2_loader_stub_start[],ps2_loader_stub_end[];
#include "dol_validate.h"
int main(void){
 VIDEO_Init();GXRModeObj *mode=VIDEO_GetPreferredMode(NULL);void *xfb=MEM_K0_TO_K1(SYS_AllocateFramebuffer(mode));
 if(!xfb)return 1;
 console_init(xfb,16,16,mode->fbWidth-32,mode->xfbHeight-32,mode->fbWidth*2);
 VIDEO_Configure(mode);VIDEO_SetNextFramebuffer(xfb);VIDEO_SetBlack(FALSE);VIDEO_Flush();VIDEO_WaitVSync();
 WPAD_Init();
 printf("PS2Recomp Wii SD Loader P1\nTarget: %s\n",TARGET);
 const char *error=NULL;FILE *f=NULL;long length=0;
 if((uintptr_t)SYS_GetArena2Lo()>STAGE||(uintptr_t)SYS_GetArena2Hi()<STUB+0x1000u){error="Reserved MEM2 staging area unavailable";goto fail;}
 SYS_SetArena2Hi((void*)STAGE);
 if(!fatInitDefault()){error="SD mount failed";goto fail;}
 f=fopen(TARGET,"rb");if(!f){error="Target file missing";goto fail;}
 if(fseek(f,0,SEEK_END)||(length=ftell(f))<256||(unsigned long)length>LIMIT||fseek(f,0,SEEK_SET)){error="Invalid or oversized target";goto fail;}
 printf("Reading %ld bytes...\n",length);
 if(fread((void*)STAGE,1,(size_t)length,f)!=(size_t)length){error="Incomplete SD read";goto fail;}
 fclose(f);f=NULL;
 error=validate((const Dol*)STAGE,(size_t)length);if(error)goto fail;
 size_t stub_size=(size_t)(ps2_loader_stub_end-ps2_loader_stub_start);
 if(stub_size>0x1000){error="Transfer stub too large";goto fail;}
 memcpy((void*)STUB,ps2_loader_stub_start,stub_size);
 DCFlushRange((void*)STAGE,(uint32_t)length);DCFlushRange((void*)STUB,(uint32_t)stub_size);ICInvalidateRange((void*)STUB,(uint32_t)stub_size);
 printf("Validated. Starting runtime...\n");VIDEO_WaitVSync();
 WPAD_Shutdown();SYS_ResetSystem(SYS_SHUTDOWN,0,0);IRQ_Disable();
 ((void(*)(void*))STUB)((void*)STAGE);
 return 1;
fail:
 if(f)fclose(f);
 printf("ERROR: %s\nHOME: return to Homebrew Channel\n",error);
 for(;;){WPAD_ScanPads();if(WPAD_ButtonsDown(0)&WPAD_BUTTON_HOME)break;VIDEO_WaitVSync();}
 return 1;
}
