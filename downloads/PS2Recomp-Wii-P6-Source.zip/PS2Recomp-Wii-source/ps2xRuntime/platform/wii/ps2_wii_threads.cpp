#include <pthread.h>
// Recompiled guest call chains need more than an OS default worker stack.
// Respect caller-owned stacks and otherwise reserve 512 KiB for each worker.
extern "C" int __real_pthread_create(pthread_t*,const pthread_attr_t*,void*(*)(void*),void*);
extern "C" int __wrap_pthread_create(pthread_t *thread,const pthread_attr_t *attr,void*(*entry)(void*),void *arg){
 pthread_attr_t options=attr?*attr:pthread_attr_t{};
 if(!options.stackaddr&&options.stacksize<512*1024)options.stacksize=512*1024;
 return __real_pthread_create(thread,&options,entry,arg);
}
