#pragma once
/* CPU portability only. Guest byte order is handled separately. */
#if defined(PS2X_WII_SCALAR_SIMD)
#include "ps2_wii_simd.h"
#elif defined(PS2X_PORTABLE_SIMD)
#ifndef SIMDE_ENABLE_NATIVE_ALIASES
#define SIMDE_ENABLE_NATIVE_ALIASES
#endif
#include <simde/x86/sse4.1.h>
#elif defined(_MSC_VER)
#include <intrin.h>
#elif defined(USE_SSE2NEON)
#include "sse2neon.h"
#else
#include <immintrin.h>
#include <smmintrin.h>
#endif
