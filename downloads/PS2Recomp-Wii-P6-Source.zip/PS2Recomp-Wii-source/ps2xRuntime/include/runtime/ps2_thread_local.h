#pragma once
#if defined(PS2X_WII)
#include <pthread.h>
#include <mutex>
#include <memory>
#include <stdexcept>
// libogc/LWP threads do not establish the ELF TLS register used by the PPC ABI.
// Use pthread keys, with one separately owned value and destructor per thread.
template<class T> class Ps2ThreadLocal {
 pthread_key_t key_{};std::once_flag once_;
 static void destroy(void *p){delete static_cast<T*>(p);}
public:
 T &get(){
  std::call_once(once_,[this]{if(pthread_key_create(&key_,destroy))throw std::runtime_error("Wii TLS key allocation failed");});
  auto *p=static_cast<T*>(pthread_getspecific(key_));
  if(!p){auto value=std::make_unique<T>();if(pthread_setspecific(key_,value.get()))throw std::runtime_error("Wii TLS binding failed");p=value.release();}
  return *p;
 }
};
#endif
