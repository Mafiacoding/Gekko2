#pragma once
#include "ps2x/guest_endian.h"
#include <cstddef>
// Only for ABI records whose complete layout consists of equally sized words.
// Mixed-width records must encode each field explicitly instead.
template<class Record, class Word> inline Record Ps2GuestReadRecord(const uint8_t *bytes) {
 static_assert(std::is_trivially_copyable_v<Record> && sizeof(Record)%sizeof(Word)==0);
 static_assert(std::is_unsigned_v<Word>);
 Record result{};
 for(std::size_t i=0;i<sizeof(Record);i+=sizeof(Word)) {
  Word value=ps2x::endian::read<Word>(bytes+i);
  std::memcpy(reinterpret_cast<uint8_t*>(&result)+i,&value,sizeof value);
 }
 return result;
}
template<class Record, class Word> inline void Ps2GuestWriteRecord(uint8_t *bytes,const Record &record) {
 static_assert(std::is_trivially_copyable_v<Record> && sizeof(Record)%sizeof(Word)==0);
 static_assert(std::is_unsigned_v<Word>);
 for(std::size_t i=0;i<sizeof(Record);i+=sizeof(Word)) {
  Word value;std::memcpy(&value,reinterpret_cast<const uint8_t*>(&record)+i,sizeof value);
  ps2x::endian::write<Word>(bytes+i,value);
 }
}
