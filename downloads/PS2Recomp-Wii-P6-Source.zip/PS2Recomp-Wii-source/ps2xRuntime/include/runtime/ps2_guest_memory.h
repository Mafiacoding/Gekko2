#pragma once
#include <cstdint>
#include <cstring>
#include <bit>
#include <type_traits>
#include "ps2_simd.h"
#include "ps2x/guest_endian.h"
/* PS2 byte order is little endian on every host. Masked variants preserve
 * RAM wrap even for unaligned accesses crossing the last byte. */
template<class T> inline T Ps2GuestRead(const uint8_t *p){return ps2x::endian::read<T>(p);}
template<class T> inline void Ps2GuestWrite(uint8_t *p,T v){ps2x::endian::write<T>(p,v);}
template<class T> inline T Ps2GuestReadRing(const uint8_t *p,uint32_t a,uint32_t mask) {
 a&=mask;if(uint64_t(a)+sizeof(T)<=uint64_t(mask)+1)return Ps2GuestRead<T>(p+a);
 T v=0;for(unsigned i=0;i<sizeof(T);++i)v|=T(p[(a+i)&mask])<<(8*i);return v;
}
template<class T> inline void Ps2GuestWriteRing(uint8_t *p,uint32_t a,T value,uint32_t mask) {
 a&=mask;if(uint64_t(a)+sizeof(T)<=uint64_t(mask)+1){Ps2GuestWrite<T>(p+a,value);return;}
 for(unsigned i=0;i<sizeof(T);++i)p[(a+i)&mask]=uint8_t(value>>(8*i));
}
inline __m128i Ps2GuestRead128Ring(const uint8_t *p,uint32_t a,uint32_t mask) {
 return _mm_set_epi32(int32_t(Ps2GuestReadRing<uint32_t>(p,a+12,mask)),int32_t(Ps2GuestReadRing<uint32_t>(p,a+8,mask)),int32_t(Ps2GuestReadRing<uint32_t>(p,a+4,mask)),int32_t(Ps2GuestReadRing<uint32_t>(p,a,mask)));
}
inline void Ps2GuestWrite128Ring(uint8_t *p,uint32_t a,__m128i v,uint32_t mask) {
 Ps2GuestWriteRing<uint32_t>(p,a,uint32_t(_mm_extract_epi32(v,0)),mask);
 Ps2GuestWriteRing<uint32_t>(p,a+4,uint32_t(_mm_extract_epi32(v,1)),mask);
 Ps2GuestWriteRing<uint32_t>(p,a+8,uint32_t(_mm_extract_epi32(v,2)),mask);
 Ps2GuestWriteRing<uint32_t>(p,a+12,uint32_t(_mm_extract_epi32(v,3)),mask);
}

inline __m128i Ps2GuestRead128(const uint8_t *p){return Ps2GuestRead128Ring(p,0,15);}
inline void Ps2GuestWrite128(uint8_t *p,__m128i v){Ps2GuestWrite128Ring(p,0,v,15);}
