#pragma once
#include <atomic>
#include <cstdint>
#if defined(PS2X_WII)
#include <ogc/irq.h>
/* Broadway has one CPU and no 64-bit reservation instruction. Each operation
 * masks local interrupts for a bounded load/compute/store sequence. No waits,
 * allocation, callbacks or IOS calls occur in this section. All operations
 * provide seq_cst ordering, including requests for a weaker memory_order.
 * These are CPU/LWP atomics, not an IPC protocol for Starlet or DMA. */
class alignas(8) Ps2AtomicU64 {
 volatile uint64_t value_;
 struct Guard {
  uint32_t level;
  Guard() noexcept:level(IRQ_Disable()){__sync_synchronize();}
  ~Guard(){__sync_synchronize();IRQ_Restore(level);}
 };
public:
 static constexpr bool is_always_lock_free=false;
 constexpr Ps2AtomicU64(uint64_t value=0) noexcept:value_(value){}
 Ps2AtomicU64(const Ps2AtomicU64&)=delete;
 Ps2AtomicU64& operator=(const Ps2AtomicU64&)=delete;
 bool is_lock_free()const noexcept{return false;}
 uint64_t load(std::memory_order=std::memory_order_seq_cst)const noexcept{Guard g;return value_;}
 void store(uint64_t v,std::memory_order=std::memory_order_seq_cst)noexcept{Guard g;value_=v;}
 uint64_t exchange(uint64_t v,std::memory_order=std::memory_order_seq_cst)noexcept{Guard g;uint64_t old=value_;value_=v;return old;}
 uint64_t fetch_add(uint64_t v,std::memory_order=std::memory_order_seq_cst)noexcept{Guard g;uint64_t old=value_;value_=old+v;return old;}
 uint64_t fetch_sub(uint64_t v,std::memory_order=std::memory_order_seq_cst)noexcept{Guard g;uint64_t old=value_;value_=old-v;return old;}
 uint64_t fetch_or(uint64_t v,std::memory_order=std::memory_order_seq_cst)noexcept{Guard g;uint64_t old=value_;value_=old|v;return old;}
 uint64_t fetch_and(uint64_t v,std::memory_order=std::memory_order_seq_cst)noexcept{Guard g;uint64_t old=value_;value_=old&v;return old;}
 bool compare_exchange_strong(uint64_t &expected,uint64_t desired,std::memory_order,std::memory_order)noexcept{Guard g;uint64_t old=value_;if(old!=expected){expected=old;return false;}value_=desired;return true;}
 bool compare_exchange_strong(uint64_t &expected,uint64_t desired,std::memory_order order=std::memory_order_seq_cst)noexcept{return compare_exchange_strong(expected,desired,order,order);}
 bool compare_exchange_weak(uint64_t &expected,uint64_t desired,std::memory_order success,std::memory_order failure)noexcept{return compare_exchange_strong(expected,desired,success,failure);}
 bool compare_exchange_weak(uint64_t &expected,uint64_t desired,std::memory_order order=std::memory_order_seq_cst)noexcept{return compare_exchange_strong(expected,desired,order,order);}
 operator uint64_t()const noexcept{return load();}
 uint64_t operator=(uint64_t v)noexcept{store(v);return v;}
 uint64_t operator++()noexcept{return fetch_add(1)+1;}
 uint64_t operator++(int)noexcept{return fetch_add(1);}
};
static_assert(sizeof(Ps2AtomicU64)==8&&alignof(Ps2AtomicU64)==8);
#else
using Ps2AtomicU64=std::atomic<uint64_t>;
#endif
