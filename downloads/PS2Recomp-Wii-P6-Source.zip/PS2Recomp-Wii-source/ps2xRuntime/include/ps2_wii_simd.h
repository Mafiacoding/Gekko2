#pragma once
// Scalar SSE subset used by PS2Recomp. Lanes are defined by bit position,
// independently of the host's byte order. This is not a performance promise.
#include <cstdint>
#include <cstring>
#include <bit>
#include <algorithm>
#include <cmath>
struct alignas(16) Ps2WiiVector { uint32_t w[4]; };
using __m128i=Ps2WiiVector;using __m128=Ps2WiiVector;using __m128d=Ps2WiiVector;
#define _MM_SHUFFLE(z,y,x,w) (((z)<<6)|((y)<<4)|((x)<<2)|(w))
namespace ps2wii {
inline uint64_t get(__m128i a,unsigned bits,unsigned i){
 if(bits==64)return uint64_t(a.w[2*i])|(uint64_t(a.w[2*i+1])<<32);
 return (a.w[(bits*i)/32]>>((bits*i)%32))&((uint64_t(1)<<bits)-1);
}
inline int64_t signed_get(__m128i a,unsigned bits,unsigned i){uint64_t n=get(a,bits,i);if(bits<64&&(n&(uint64_t(1)<<(bits-1))))n|=~((uint64_t(1)<<bits)-1);return std::bit_cast<int64_t>(n);}
inline void put(__m128i &a,unsigned bits,unsigned i,uint64_t v){
 if(bits==64){a.w[2*i]=uint32_t(v);a.w[2*i+1]=uint32_t(v>>32);return;}
 uint32_t mask=uint32_t((uint64_t(1)<<bits)-1);unsigned shift=(bits*i)%32;auto &w=a.w[bits*i/32];w=(w&~(mask<<shift))|(uint32_t(v&mask)<<shift);
}
inline float f(__m128 a,unsigned i){return std::bit_cast<float>(a.w[i]);}
inline void pf(__m128 &a,unsigned i,float v){a.w[i]=std::bit_cast<uint32_t>(v);}
}
inline __m128i _mm_setzero_si128(){return {};}
inline __m128i _mm_set_epi32(int32_t d,int32_t c,int32_t b,int32_t a){return {{uint32_t(a),uint32_t(b),uint32_t(c),uint32_t(d)}};}
inline __m128i _mm_set1_epi32(int32_t a){return _mm_set_epi32(a,a,a,a);}
inline __m128i _mm_set_epi64x(int64_t hi,int64_t lo){__m128i r{};ps2wii::put(r,64,0,uint64_t(lo));ps2wii::put(r,64,1,uint64_t(hi));return r;}
inline __m128i _mm_set1_epi64x(int64_t a){return _mm_set_epi64x(a,a);}
inline __m128i _mm_cvtsi64_si128(int64_t a){return _mm_set_epi64x(0,a);}
inline int64_t _mm_cvtsi128_si64(__m128i a){return ps2wii::signed_get(a,64,0);}
inline int32_t _mm_cvtsi128_si32(__m128i a){return std::bit_cast<int32_t>(a.w[0]);}
inline int _mm_extract_epi8(__m128i a,int i){return int(ps2wii::get(a,8,i&15));}
inline int _mm_extract_epi16(__m128i a,int i){return int(ps2wii::get(a,16,i&7));}
inline int32_t _mm_extract_epi32(__m128i a,int i){return std::bit_cast<int32_t>(a.w[i&3]);}
inline int64_t _mm_extract_epi64(__m128i a,int i){return ps2wii::signed_get(a,64,i&1);}
inline __m128i _mm_insert_epi8(__m128i a,int v,int i){ps2wii::put(a,8,i&15,uint8_t(v));return a;}
inline __m128i _mm_loadu_si128(const __m128i *p){__m128i r;std::memcpy(&r,p,16);return r;}
inline __m128i _mm_load_si128(const __m128i *p){return _mm_loadu_si128(p);}
inline void _mm_storeu_si128(__m128i *p,__m128i a){std::memcpy(p,&a,16);}
inline void _mm_store_si128(__m128i *p,__m128i a){_mm_storeu_si128(p,a);}
inline __m128 _mm_set_ps(float d,float c,float b,float a){return {{std::bit_cast<uint32_t>(a),std::bit_cast<uint32_t>(b),std::bit_cast<uint32_t>(c),std::bit_cast<uint32_t>(d)}};}
inline __m128 _mm_set1_ps(float a){return _mm_set_ps(a,a,a,a);}
inline float _mm_cvtss_f32(__m128 a){return ps2wii::f(a,0);}
inline __m128 _mm_loadu_ps(const float *p){__m128 r;std::memcpy(&r,p,16);return r;}
inline __m128 _mm_load_ps(const float *p){return _mm_loadu_ps(p);}
inline void _mm_storeu_ps(float *p,__m128 a){std::memcpy(p,&a,16);}
inline void _mm_store_ps(float *p,__m128 a){_mm_storeu_ps(p,a);}
inline __m128d _mm_move_sd(__m128d a,__m128d b){a.w[0]=b.w[0];a.w[1]=b.w[1];return a;}
inline __m128i _mm_castpd_si128(__m128i a){return a;}
inline __m128i _mm_castps_si128(__m128i a){return a;}
inline __m128i _mm_castsi128_pd(__m128i a){return a;}
inline __m128i _mm_castsi128_ps(__m128i a){return a;}
inline __m128i _mm_and_si128(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++)r.w[i]=a.w[i]&b.w[i];return r;}
inline __m128i _mm_or_si128(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++)r.w[i]=a.w[i]|b.w[i];return r;}
inline __m128i _mm_xor_si128(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++)r.w[i]=a.w[i]^b.w[i];return r;}
inline __m128i _mm_andnot_si128(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++)r.w[i]=(~a.w[i])&b.w[i];return r;}
inline __m128 _mm_and_ps(__m128 a,__m128 b){return _mm_and_si128(a,b);}
inline __m128 _mm_xor_ps(__m128 a,__m128 b){return _mm_xor_si128(a,b);}
inline __m128i _mm_add_epi8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<16;i++){uint64_t x=ps2wii::get(a,8,i),y=ps2wii::get(b,8,i);ps2wii::put(r,8,i,x+y);}return r;}
inline __m128i _mm_sub_epi8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<16;i++){uint64_t x=ps2wii::get(a,8,i),y=ps2wii::get(b,8,i);ps2wii::put(r,8,i,x-y);}return r;}
inline __m128i _mm_cmpeq_epi8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<16;i++){uint64_t x=ps2wii::get(a,8,i),y=ps2wii::get(b,8,i);ps2wii::put(r,8,i,x==y?~uint64_t(0):0);}return r;}
inline __m128i _mm_cmpgt_epi8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<16;i++){uint64_t x=ps2wii::get(a,8,i),y=ps2wii::get(b,8,i);ps2wii::put(r,8,i,ps2wii::signed_get(a,8,i)>ps2wii::signed_get(b,8,i)?~uint64_t(0):0);}return r;}
inline __m128i _mm_abs_epi8(__m128i a){__m128i r{};for(unsigned i=0;i<16;i++){int64_t x=ps2wii::signed_get(a,8,i);ps2wii::put(r,8,i,uint64_t(x<0?-x:x));}return r;}
inline __m128i _mm_add_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++){uint64_t x=ps2wii::get(a,16,i),y=ps2wii::get(b,16,i);ps2wii::put(r,16,i,x+y);}return r;}
inline __m128i _mm_sub_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++){uint64_t x=ps2wii::get(a,16,i),y=ps2wii::get(b,16,i);ps2wii::put(r,16,i,x-y);}return r;}
inline __m128i _mm_cmpeq_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++){uint64_t x=ps2wii::get(a,16,i),y=ps2wii::get(b,16,i);ps2wii::put(r,16,i,x==y?~uint64_t(0):0);}return r;}
inline __m128i _mm_cmpgt_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++){uint64_t x=ps2wii::get(a,16,i),y=ps2wii::get(b,16,i);ps2wii::put(r,16,i,ps2wii::signed_get(a,16,i)>ps2wii::signed_get(b,16,i)?~uint64_t(0):0);}return r;}
inline __m128i _mm_abs_epi16(__m128i a){__m128i r{};for(unsigned i=0;i<8;i++){int64_t x=ps2wii::signed_get(a,16,i);ps2wii::put(r,16,i,uint64_t(x<0?-x:x));}return r;}
inline __m128i _mm_add_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++){uint64_t x=ps2wii::get(a,32,i),y=ps2wii::get(b,32,i);ps2wii::put(r,32,i,x+y);}return r;}
inline __m128i _mm_sub_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++){uint64_t x=ps2wii::get(a,32,i),y=ps2wii::get(b,32,i);ps2wii::put(r,32,i,x-y);}return r;}
inline __m128i _mm_cmpeq_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++){uint64_t x=ps2wii::get(a,32,i),y=ps2wii::get(b,32,i);ps2wii::put(r,32,i,x==y?~uint64_t(0):0);}return r;}
inline __m128i _mm_cmpgt_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++){uint64_t x=ps2wii::get(a,32,i),y=ps2wii::get(b,32,i);ps2wii::put(r,32,i,ps2wii::signed_get(a,32,i)>ps2wii::signed_get(b,32,i)?~uint64_t(0):0);}return r;}
inline __m128i _mm_abs_epi32(__m128i a){__m128i r{};for(unsigned i=0;i<4;i++){int64_t x=ps2wii::signed_get(a,32,i);ps2wii::put(r,32,i,uint64_t(x<0?-x:x));}return r;}
inline __m128i _mm_min_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++)ps2wii::put(r,16,i,uint64_t(std::min(ps2wii::signed_get(a,16,i),ps2wii::signed_get(b,16,i))));return r;}
inline __m128i _mm_max_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++)ps2wii::put(r,16,i,uint64_t(std::max(ps2wii::signed_get(a,16,i),ps2wii::signed_get(b,16,i))));return r;}
inline __m128i _mm_slli_epi16(__m128i a,unsigned count){__m128i r{};for(unsigned i=0;i<8;i++){uint64_t x=ps2wii::get(a,16,i);ps2wii::put(r,16,i,count>=16?0:(x<<count));}return r;}
inline __m128i _mm_srli_epi16(__m128i a,unsigned count){__m128i r{};for(unsigned i=0;i<8;i++){uint64_t x=ps2wii::get(a,16,i);ps2wii::put(r,16,i,count>=16?0:(x>>count));}return r;}
inline __m128i _mm_srai_epi16(__m128i a,unsigned count){__m128i r{};for(unsigned i=0;i<8;i++){uint64_t x=ps2wii::get(a,16,i);ps2wii::put(r,16,i,uint64_t(ps2wii::signed_get(a,16,i)>>std::min(count,15u)));}return r;}
inline __m128i _mm_min_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++)ps2wii::put(r,32,i,uint64_t(std::min(ps2wii::signed_get(a,32,i),ps2wii::signed_get(b,32,i))));return r;}
inline __m128i _mm_max_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++)ps2wii::put(r,32,i,uint64_t(std::max(ps2wii::signed_get(a,32,i),ps2wii::signed_get(b,32,i))));return r;}
inline __m128i _mm_slli_epi32(__m128i a,unsigned count){__m128i r{};for(unsigned i=0;i<4;i++){uint64_t x=ps2wii::get(a,32,i);ps2wii::put(r,32,i,count>=32?0:(x<<count));}return r;}
inline __m128i _mm_srli_epi32(__m128i a,unsigned count){__m128i r{};for(unsigned i=0;i<4;i++){uint64_t x=ps2wii::get(a,32,i);ps2wii::put(r,32,i,count>=32?0:(x>>count));}return r;}
inline __m128i _mm_srai_epi32(__m128i a,unsigned count){__m128i r{};for(unsigned i=0;i<4;i++){uint64_t x=ps2wii::get(a,32,i);ps2wii::put(r,32,i,uint64_t(ps2wii::signed_get(a,32,i)>>std::min(count,31u)));}return r;}
inline __m128i _mm_slli_epi64(__m128i a,unsigned count){__m128i r{};for(unsigned i=0;i<2;i++)ps2wii::put(r,64,i,count>=64?0:ps2wii::get(a,64,i)<<count);return r;}
inline __m128i _mm_srli_epi64(__m128i a,unsigned count){__m128i r{};for(unsigned i=0;i<2;i++)ps2wii::put(r,64,i,count>=64?0:ps2wii::get(a,64,i)>>count);return r;}
inline __m128i _mm_unpacklo_epi8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++){ps2wii::put(r,8,2*i,ps2wii::get(a,8,i+0));ps2wii::put(r,8,2*i+1,ps2wii::get(b,8,i+0));}return r;}
inline __m128i _mm_unpackhi_epi8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++){ps2wii::put(r,8,2*i,ps2wii::get(a,8,i+8));ps2wii::put(r,8,2*i+1,ps2wii::get(b,8,i+8));}return r;}
inline __m128i _mm_unpacklo_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++){ps2wii::put(r,16,2*i,ps2wii::get(a,16,i+0));ps2wii::put(r,16,2*i+1,ps2wii::get(b,16,i+0));}return r;}
inline __m128i _mm_unpackhi_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++){ps2wii::put(r,16,2*i,ps2wii::get(a,16,i+4));ps2wii::put(r,16,2*i+1,ps2wii::get(b,16,i+4));}return r;}
inline __m128i _mm_unpacklo_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<2;i++){ps2wii::put(r,32,2*i,ps2wii::get(a,32,i+0));ps2wii::put(r,32,2*i+1,ps2wii::get(b,32,i+0));}return r;}
inline __m128i _mm_unpackhi_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<2;i++){ps2wii::put(r,32,2*i,ps2wii::get(a,32,i+2));ps2wii::put(r,32,2*i+1,ps2wii::get(b,32,i+2));}return r;}
inline __m128i _mm_unpacklo_epi64(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<1;i++){ps2wii::put(r,64,2*i,ps2wii::get(a,64,i+0));ps2wii::put(r,64,2*i+1,ps2wii::get(b,64,i+0));}return r;}
inline __m128i _mm_unpackhi_epi64(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<1;i++){ps2wii::put(r,64,2*i,ps2wii::get(a,64,i+1));ps2wii::put(r,64,2*i+1,ps2wii::get(b,64,i+1));}return r;}
inline __m128i _mm_adds_epi8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<16;i++){int64_t x=ps2wii::signed_get(a,8,i),y=ps2wii::signed_get(b,8,i);ps2wii::put(r,8,i,uint64_t(std::clamp<int64_t>(x+y,-128,127)));}return r;}
inline __m128i _mm_subs_epi8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<16;i++){int64_t x=ps2wii::signed_get(a,8,i),y=ps2wii::signed_get(b,8,i);ps2wii::put(r,8,i,uint64_t(std::clamp<int64_t>(x-y,-128,127)));}return r;}
inline __m128i _mm_adds_epu8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<16;i++){int64_t x=ps2wii::get(a,8,i),y=ps2wii::get(b,8,i);ps2wii::put(r,8,i,uint64_t(std::clamp<int64_t>(x+y,0,255)));}return r;}
inline __m128i _mm_subs_epu8(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<16;i++){int64_t x=ps2wii::get(a,8,i),y=ps2wii::get(b,8,i);ps2wii::put(r,8,i,uint64_t(std::clamp<int64_t>(x-y,0,255)));}return r;}
inline __m128i _mm_adds_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++){int64_t x=ps2wii::signed_get(a,16,i),y=ps2wii::signed_get(b,16,i);ps2wii::put(r,16,i,uint64_t(std::clamp<int64_t>(x+y,-32768,32767)));}return r;}
inline __m128i _mm_subs_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++){int64_t x=ps2wii::signed_get(a,16,i),y=ps2wii::signed_get(b,16,i);ps2wii::put(r,16,i,uint64_t(std::clamp<int64_t>(x-y,-32768,32767)));}return r;}
inline __m128i _mm_shuffle_epi32(__m128i a,int imm){__m128i r{};for(unsigned i=0;i<4;i++)r.w[i]=a.w[(imm>>(2*i))&3];return r;}
inline __m128i _mm_shuffle_epi8(__m128i a,__m128i mask){__m128i r{};for(unsigned i=0;i<16;i++){auto n=ps2wii::get(mask,8,i);ps2wii::put(r,8,i,(n&128)?0:ps2wii::get(a,8,n&15));}return r;}
inline __m128i _mm_shufflelo_epi16(__m128i a,int imm){auto r=a;for(unsigned i=0;i<4;i++)ps2wii::put(r,16,i,ps2wii::get(a,16,(imm>>(2*i))&3));return r;}
inline __m128i _mm_shufflehi_epi16(__m128i a,int imm){auto r=a;for(unsigned i=0;i<4;i++)ps2wii::put(r,16,i+4,ps2wii::get(a,16,4+((imm>>(2*i))&3)));return r;}
inline __m128 _mm_shuffle_ps(__m128 a,__m128 b,int imm){return {{a.w[imm&3],a.w[(imm>>2)&3],b.w[(imm>>4)&3],b.w[(imm>>6)&3]}};}
inline __m128i _mm_bsrli_si128(__m128i a,unsigned n){__m128i r{};for(unsigned i=0;i<16;i++)if(i+n<16)ps2wii::put(r,8,i,ps2wii::get(a,8,i+n));return r;}
inline __m128i _mm_srli_si128(__m128i a,unsigned n){return _mm_bsrli_si128(a,n);}
inline __m128i _mm_blendv_epi8(__m128i a,__m128i b,__m128i m){auto r=a;for(unsigned i=0;i<16;i++)if(ps2wii::get(m,8,i)&128)ps2wii::put(r,8,i,ps2wii::get(b,8,i));return r;}
inline __m128 _mm_blendv_ps(__m128 a,__m128 b,__m128 m){auto r=a;for(unsigned i=0;i<4;i++)if(m.w[i]&0x80000000)r.w[i]=b.w[i];return r;}
inline int _mm_movemask_epi8(__m128i a){int r=0;for(unsigned i=0;i<16;i++)r|=int((ps2wii::get(a,8,i)>>7)&1)<<i;return r;}
inline int _mm_movemask_ps(__m128 a){int r=0;for(unsigned i=0;i<4;i++)r|=int(a.w[i]>>31)<<i;return r;}
inline __m128i _mm_mullo_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++)r.w[i]=uint32_t(uint64_t(a.w[i])*b.w[i]);return r;}
inline __m128i _mm_mullo_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<8;i++)ps2wii::put(r,16,i,ps2wii::get(a,16,i)*ps2wii::get(b,16,i));return r;}
inline __m128i _mm_mul_epu32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<2;i++)ps2wii::put(r,64,i,uint64_t(a.w[2*i])*b.w[2*i]);return r;}
inline __m128i _mm_madd_epi16(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++)r.w[i]=uint32_t(ps2wii::signed_get(a,16,2*i)*ps2wii::signed_get(b,16,2*i)+ps2wii::signed_get(a,16,2*i+1)*ps2wii::signed_get(b,16,2*i+1));return r;}
inline __m128i _mm_packs_epi32(__m128i a,__m128i b){__m128i r{};for(unsigned i=0;i<4;i++){ps2wii::put(r,16,i,uint64_t(std::clamp<int64_t>(ps2wii::signed_get(a,32,i),-32768,32767)));ps2wii::put(r,16,i+4,uint64_t(std::clamp<int64_t>(ps2wii::signed_get(b,32,i),-32768,32767)));}return r;}
inline __m128 _mm_cvtepi32_ps(__m128i a){__m128 r{};for(unsigned i=0;i<4;i++)ps2wii::pf(r,i,float(ps2wii::signed_get(a,32,i)));return r;}
inline __m128i _mm_cvttps_epi32(__m128 a){__m128i r{};for(unsigned i=0;i<4;i++){double v=ps2wii::f(a,i);r.w[i]=(!std::isfinite(v)||v<-2147483648.0||v>=2147483648.0)?0x80000000u:uint32_t(int32_t(v));}return r;}
inline __m128 _mm_add_ps(__m128 a,__m128 b){__m128 r{};for(unsigned i=0;i<4;i++)ps2wii::pf(r,i,ps2wii::f(a,i)+ps2wii::f(b,i));return r;}
inline __m128 _mm_sub_ps(__m128 a,__m128 b){__m128 r{};for(unsigned i=0;i<4;i++)ps2wii::pf(r,i,ps2wii::f(a,i)-ps2wii::f(b,i));return r;}
inline __m128 _mm_mul_ps(__m128 a,__m128 b){__m128 r{};for(unsigned i=0;i<4;i++)ps2wii::pf(r,i,ps2wii::f(a,i)*ps2wii::f(b,i));return r;}
inline __m128 _mm_div_ps(__m128 a,__m128 b){__m128 r{};for(unsigned i=0;i<4;i++)ps2wii::pf(r,i,ps2wii::f(a,i)/ps2wii::f(b,i));return r;}
inline __m128 _mm_min_ps(__m128 a,__m128 b){__m128 r{};for(unsigned i=0;i<4;i++){float x=ps2wii::f(a,i),y=ps2wii::f(b,i);ps2wii::pf(r,i,x<y?x:y);}return r;}
inline __m128 _mm_max_ps(__m128 a,__m128 b){__m128 r{};for(unsigned i=0;i<4;i++){float x=ps2wii::f(a,i),y=ps2wii::f(b,i);ps2wii::pf(r,i,x>y?x:y);}return r;}
inline __m128 _mm_cmpgt_ps(__m128 a,__m128 b){__m128 r{};for(unsigned i=0;i<4;i++)r.w[i]=ps2wii::f(a,i)>ps2wii::f(b,i)?0xffffffffu:0;return r;}
inline __m128 _mm_cmplt_ps(__m128 a,__m128 b){__m128 r{};for(unsigned i=0;i<4;i++)r.w[i]=ps2wii::f(a,i)<ps2wii::f(b,i)?0xffffffffu:0;return r;}
inline __m128i _mm_setr_epi8(int v0,int v1,int v2,int v3,int v4,int v5,int v6,int v7,int v8,int v9,int v10,int v11,int v12,int v13,int v14,int v15){__m128i r{};ps2wii::put(r,8,0,uint64_t(v0));ps2wii::put(r,8,1,uint64_t(v1));ps2wii::put(r,8,2,uint64_t(v2));ps2wii::put(r,8,3,uint64_t(v3));ps2wii::put(r,8,4,uint64_t(v4));ps2wii::put(r,8,5,uint64_t(v5));ps2wii::put(r,8,6,uint64_t(v6));ps2wii::put(r,8,7,uint64_t(v7));ps2wii::put(r,8,8,uint64_t(v8));ps2wii::put(r,8,9,uint64_t(v9));ps2wii::put(r,8,10,uint64_t(v10));ps2wii::put(r,8,11,uint64_t(v11));ps2wii::put(r,8,12,uint64_t(v12));ps2wii::put(r,8,13,uint64_t(v13));ps2wii::put(r,8,14,uint64_t(v14));ps2wii::put(r,8,15,uint64_t(v15));return r;}
inline __m128i _mm_set_epi16(int v0,int v1,int v2,int v3,int v4,int v5,int v6,int v7){__m128i r{};ps2wii::put(r,16,7,uint64_t(v0));ps2wii::put(r,16,6,uint64_t(v1));ps2wii::put(r,16,5,uint64_t(v2));ps2wii::put(r,16,4,uint64_t(v3));ps2wii::put(r,16,3,uint64_t(v4));ps2wii::put(r,16,2,uint64_t(v5));ps2wii::put(r,16,1,uint64_t(v6));ps2wii::put(r,16,0,uint64_t(v7));return r;}
