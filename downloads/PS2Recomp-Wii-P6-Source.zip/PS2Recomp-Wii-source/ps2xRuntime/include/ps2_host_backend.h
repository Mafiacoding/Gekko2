#pragma once

#if defined(PS2X_WII)
#include "ps2_wii_host.h"
#else
#include "raylib.h"
#endif
