#pragma once
#include <bit>
#include <cstdint>
#include <cstring>
#include <type_traits>
namespace ps2x::endian {
template<class T> inline T read(const uint8_t *p){
 static_assert((std::is_integral_v<T>||std::is_floating_point_v<T>)&&(sizeof(T)==1||sizeof(T)==2||sizeof(T)==4||sizeof(T)==8));
 T v;if constexpr(std::endian::native==std::endian::little)std::memcpy(&v,p,sizeof v);
 else{uint8_t b[sizeof(T)];for(unsigned i=0;i<sizeof(T);i++)b[i]=p[sizeof(T)-1-i];std::memcpy(&v,b,sizeof v);}return v;
}
template<class T> inline void write(uint8_t*p,T v){
 static_assert((std::is_integral_v<T>||std::is_floating_point_v<T>)&&(sizeof(T)==1||sizeof(T)==2||sizeof(T)==4||sizeof(T)==8));
 if constexpr(std::endian::native==std::endian::little)std::memcpy(p,&v,sizeof v);
 else{uint8_t b[sizeof(T)];std::memcpy(b,&v,sizeof v);for(unsigned i=0;i<sizeof(T);i++)p[i]=b[sizeof(T)-1-i];}
}
template<class T> inline T field(T v){return read<T>(reinterpret_cast<const uint8_t*>(&v));}
}
