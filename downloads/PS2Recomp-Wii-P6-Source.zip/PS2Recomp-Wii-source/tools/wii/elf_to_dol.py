#!/usr/bin/env python3
"""Convert an ELF32 PowerPC image into standard Wii DOL section slots."""
import struct,sys
from pathlib import Path

def convert(source,target):
    data=Path(source).read_bytes()
    if data[:7]!=b'\x7fELF\x01\x02\x01' or struct.unpack_from('>H',data,18)[0]!=20:
        raise ValueError('ELF32 big-endian PowerPC required')
    entry=struct.unpack_from('>I',data,24)[0];start=struct.unpack_from('>I',data,32)[0];step,count=struct.unpack_from('>HH',data,46)
    if step<40 or start+step*count>len(data):raise ValueError('Invalid section table')
    text=[];other=[];bss=[]
    for i in range(count):
        _,kind,flags,addr,offset,size,_,_,_,_=struct.unpack_from('>10I',data,start+i*step)
        if not(flags&2) or not size:continue
        if flags&0x400:raise ValueError('ELF TLS cannot be represented in a Wii DOL')
        if kind==8:bss.append((addr,addr+size));continue
        if offset+size>len(data):raise ValueError('Truncated ELF section')
        (text if flags&4 else other).append((addr,data[offset:offset+size]))
    if len(text)>7 or len(other)>11:raise ValueError('Too many sections for DOL header')
    result=bytearray(256)
    for sections,ob,ab,sb in [(text,0,0x48,0x90),(other,0x1c,0x64,0xac)]:
        for i,(addr,contents) in enumerate(sections):
            result.extend(bytes((-len(result))%32));offset=len(result);result.extend(contents)
            for base,value in [(ob,offset),(ab,addr),(sb,len(contents))]:struct.pack_into('>I',result,base+4*i,value)
    if bss:
        low=min(a for a,b in bss);high=max(b for a,b in bss)
        struct.pack_into('>II',result,0xd8,low,high-low)
    struct.pack_into('>I',result,0xe0,entry)
    Path(target).write_bytes(result)
    print(f'Wrote {len(result)} bytes: {len(text)} text / {len(other)} data sections')
if __name__=='__main__':
    if len(sys.argv)!=3:raise SystemExit('Usage: elf_to_dol.py input.elf output.dol')
    convert(*sys.argv[1:])
