#!/usr/bin/env python3
"""Extract owner-supplied ISO9660 data for the experimental Wii runtime.

This prepares data only; it does not recompile a game or claim compatibility.
CHD and multi-track CUE parsing are deliberately not implemented yet.
"""
import argparse, hashlib, json, re, shutil
from pathlib import Path

class Disc:
    def __init__(self, path):
        self.file = Path(path).open('rb')
        self.size = Path(path).stat().st_size
        for self.stride, self.offset in [(2048, 0), (2352, 16), (2352, 24), (2336, 8)]:
            pvd = self.read(16, 2048)
            if pvd[:7] == b'\x01CD001\x01':
                self.root = self.record(pvd[156:])
                return
        self.file.close()
        raise ValueError('No supported ISO9660 primary volume; CHD/CUE need prior conversion')

    def close(self):
        self.file.close()

    def read(self, lba, length):
        if lba < 0 or length < 0 or (lba + (length + 2047)//2048)*self.stride > self.size:
            raise ValueError('Disc extent outside image')
        result = bytearray()
        for sector in range((length + 2047)//2048):
            self.file.seek((lba+sector)*self.stride+self.offset)
            data = self.file.read(min(2048, length-len(result)))
            if len(data) != min(2048, length-len(result)):
                raise ValueError('Truncated disc sector')
            result.extend(data)
        return bytes(result)

    @staticmethod
    def record(raw):
        if len(raw) < 34 or raw[0] < 34 or raw[0] > len(raw) or 33+raw[32] > raw[0]:
            raise ValueError('Malformed ISO9660 directory record')
        lba = int.from_bytes(raw[2:6], 'little')
        size = int.from_bytes(raw[10:14], 'little')
        if lba != int.from_bytes(raw[6:10], 'big') or size != int.from_bytes(raw[14:18], 'big'):
            raise ValueError('Inconsistent ISO9660 extent fields')
        if raw[25] & 0x80 or raw[26] or raw[27] or raw[1]:
            raise ValueError('Multi-extent, interleaved, or extended-attribute files are unsupported')
        name = raw[33:33+raw[32]].decode('ascii')
        return dict(lba=lba, size=size, directory=bool(raw[25]&2), name=name)

    def entries(self, entry):
        if entry['size'] > 16*1024*1024:
            raise ValueError('Directory too large')
        data = self.read(entry['lba'], entry['size']); position = 0
        while position < len(data):
            length = data[position]
            if not length:
                position = (position//2048+1)*2048
                continue
            if position%2048+length > 2048:
                raise ValueError('Directory record crosses sector')
            result = self.record(data[position:position+length]); position += length
            if result['name'] not in ('\x00', '\x01'):
                yield result

    def extract(self, output):
        output = Path(output)
        if output.exists() and (not output.is_dir() or any(output.iterdir())):
            raise ValueError('Output must be absent or empty; existing data will not be overwritten')
        output.mkdir(parents=True, exist_ok=True)
        rows=[]; paths=set(); directories=set()
        def walk(entry, parent, depth=0):
            if depth > 32 or entry['lba'] in directories:
                raise ValueError('Cyclic or excessively deep directory tree')
            directories.add(entry['lba'])
            for child in self.entries(entry):
                name = re.sub(r';[0-9]+$', '', child['name'])
                if name in ('', '.', '..') or any(c in name for c in '/\\:') or any(ord(c)<32 for c in name):
                    raise ValueError('Unsafe disc filename')
                relative = parent/name; key = str(relative).casefold()
                if key in paths: raise ValueError('Filename collision after ISO version removal')
                paths.add(key); target=output/relative
                if child['directory']:
                    target.mkdir(); walk(child,relative,depth+1)
                else:
                    digest=hashlib.sha256()
                    with target.open('xb') as f:
                        for off in range(0,child['size'],1024*1024):
                            data=self.read(child['lba']+off//2048,min(1024*1024,child['size']-off))
                            f.write(data);digest.update(data)
                    rows.append(dict(path=relative.as_posix(),bytes=child['size'],sha256=digest.hexdigest()))
        walk(self.root,Path())
        cnf=next((r for r in rows if r['path'].upper()=='SYSTEM.CNF'),None)
        if not cnf:raise ValueError('SYSTEM.CNF missing')
        text=(output/cnf['path']).read_text(encoding='ascii')
        match=re.search(r'BOOT2\s*=\s*cdrom0?:[\\/]?([^\s]+)',text,re.I)
        if not match:raise ValueError('BOOT2 ELF not identified')
        boot=re.sub(r';[0-9]+$','',match[1].replace('\\','/')).lstrip('/')
        row=next((r for r in rows if r['path'].casefold()==boot.casefold()),None)
        if not row:raise ValueError('BOOT2 ELF not found')
        original=output/row['path']
        with original.open('rb') as f:
            if f.read(6)!=b'\x7fELF\x01\x01':raise ValueError('BOOT2 must be ELF32 little endian')
        if original!=output/'game.elf':shutil.copyfile(original,output/'game.elf')
        manifest=dict(schema=1,stage='data-extraction-only',compatible=False,physical_wii_tested=False,
                      sector_stride=self.stride,sector_offset=self.offset,boot_elf=row['path'],files=rows)
        (output/'disc-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
        return manifest

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--image',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    disc=Disc(a.image)
    try:report=disc.extract(a.output)
    finally:disc.close()
    print(json.dumps(dict(stage=report['stage'],files=len(report['files']),compatible=False)))
if __name__=='__main__':main()
