#!/usr/bin/env python3
"""Run the loader's exact destination guards against a real and corrupt DOL."""
import argparse,ctypes,struct,subprocess,tempfile,json
from pathlib import Path
root=Path(__file__).resolve().parents[2];p=argparse.ArgumentParser();p.add_argument('--dol',type=Path,required=True);a=p.parse_args();data=a.dol.read_bytes()
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'test.c').write_text('#include "dol_validate.h"\nconst char *probe(const void *p,size_t n){return validate(p,n);}')
 # File fields are big-endian on Wii; decode those fields for the host probe.
 subprocess.run(['cc','-shared','-fPIC','-Wall','-Wextra','-Werror','-I'+str(root/'ps2xRuntime/platform/wii/loader'),str(d/'test.c'),'-o',str(d/'test.so')],check=True)
 f=ctypes.CDLL(str(d/'test.so')).probe;f.argtypes=[ctypes.c_void_p,ctypes.c_size_t];f.restype=ctypes.c_char_p
 def check(b,n):
  header=struct.pack('=57I',*struct.unpack_from('>57I',b));buffer=ctypes.create_string_buffer(header);return f(buffer,n)
 assert check(data,len(data)) is None
 cases=[('entry',0xe0,0),('stage overwrite',0x48,0x91800000),('stub overwrite',0x48,0x93300000),('file overrun',0,0xffffff00),('BSS overlap',0xd8,0x80003f00),('BSS overflow',0xdc,0xffffffff)]
 for label,off,value in cases:
  b=bytearray(data);struct.pack_into('>I',b,off,value);assert check(b,len(data)),label
 assert check(data,256)
 print(json.dumps(dict(valid_target_passed=True,invalid_targets_rejected=len(cases)+1,physical_wii=False)))
