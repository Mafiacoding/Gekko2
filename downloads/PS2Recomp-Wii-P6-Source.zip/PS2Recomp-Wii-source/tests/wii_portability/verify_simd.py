#!/usr/bin/env python3
"""Compare compiled scalar PPC lanes with native x86 SSE, no guest assets."""
from pathlib import Path
import argparse,subprocess,tempfile,struct,ctypes,random,json
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import *
root=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--devkitppc',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
cc=a.devkitppc/'bin/powerpc-eabi-g++'
ops=[]
for name in ['add','sub','cmpeq','cmpgt']:
 for bits in [8,16,32]:ops.append((name+str(bits),f'_mm_{name}_epi{bits}(x,y)'))
for name in ['and','or','xor','andnot']:ops.append((name,f'_mm_{name}_si128(x,y)'))
for bits in [8,16,32]:ops.append(('abs'+str(bits),f'_mm_abs_epi{bits}(x)'))
for bits in [16,32]:
 for name in ['min','max']:ops.append((name+str(bits),f'_mm_{name}_epi{bits}(x,y)'))
for bits in [8,16,32,64]:
 for part in ['lo','hi']:ops.append(('unpack'+part+str(bits),f'_mm_unpack{part}_epi{bits}(x,y)'))
for bits in [8,16]:
 for name in ['adds','subs']:ops.append((name+str(bits),f'_mm_{name}_epi{bits}(x,y)'))
for name in ['adds','subs']:ops.append((name+'unsigned',f'_mm_{name}_epu8(x,y)'))
for bits in [16,32,64]:
 for name in ['slli','srli']+(['srai'] if bits!=64 else []):
  for shift in [0,bits-1,bits,bits+3]:ops.append((name+str(bits)+'_'+str(shift),f'_mm_{name}_epi{bits}(x,{shift})'))
for name in ['mullo_epi16','mullo_epi32','mul_epu32','madd_epi16','packs_epi32','shuffle_epi8','blendv_epi8']:
 expr=f'_mm_{name}(x,y,x)' if name=='blendv_epi8' else f'_mm_{name}(x,y)';ops.append((name,expr))
for name in ['shuffle_epi32','shufflelo_epi16','shufflehi_epi16']:
 for imm in [0,27,114,255]:ops.append((name+str(imm),f'_mm_{name}(x,{imm})'))
for shift in [0,1,7,8,15,16,31]:ops.append(('byteshift'+str(shift),f'_mm_srli_si128(x,{shift})'))
# Mixed-width extraction is essential: this failed with the first SIMD route.
ops.append(('extractions','_mm_set_epi32(int32_t(uint64_t(_mm_extract_epi64(x,0))>>32),int32_t(_mm_extract_epi64(x,0)),_mm_extract_epi16(x,0),_mm_extract_epi8(x,0))'))
body='\n'.join('emit('+expr+');' for _,expr in ops)
source='''#include <cstdint>
#include "ps2_simd.h"
extern "C" void cases(const uint32_t *input,uint32_t *out){
auto x=_mm_set_epi32(input[3],input[2],input[1],input[0]);
auto y=_mm_set_epi32(input[7],input[6],input[5],input[4]);
auto emit=[&](__m128i v){*out++=uint32_t(_mm_extract_epi32(v,0));*out++=uint32_t(_mm_extract_epi32(v,1));*out++=uint32_t(_mm_extract_epi32(v,2));*out++=uint32_t(_mm_extract_epi32(v,3));};
'''+body+'\n}\n'
with tempfile.TemporaryDirectory(prefix='ps2-wii-simd-') as td:
 d=Path(td);src=d/'cases.cpp';src.write_text(source);so=d/'native.so';elf=d/'ppc.elf'
 subprocess.run(['g++','-std=c++20','-O2','-msse4.1','-ffp-contract=off','-shared','-fPIC','-I'+str(root/'ps2xRuntime/include'),str(src),'-o',str(so)],check=True)
 subprocess.run([str(cc),'-std=c++20','-O2','-mcpu=750','-meabi','-mno-altivec','-mno-vsx','-DPS2X_WII_SCALAR_SIMD','-I'+str(root/'ps2xRuntime/include'),'-nostdlib','-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(src),'-lgcc','-o',str(elf)],check=True)
 b=elf.read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',b,28)[0];step,n=struct.unpack_from('>HH',b,42)
 for i in range(n):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',b,ph+i*step)
  if kind==1:u.mem_write(addr,b[off:off+length])
 entry=struct.unpack_from('>I',b,24)[0];fn=ctypes.CDLL(str(so)).cases;fn.argtypes=[ctypes.POINTER(ctypes.c_uint32)]*2
 rng=random.Random(0x750);values=[[0]*8,[0xffffffff]*8,[0x80000000,0x7fffffff,0x00800080,0x7fff8000,0xffffffff,0x12345678,0x00ff7f80,0x01020304]]+[[rng.getrandbits(32) for _ in range(8)] for _ in range(32)]
 for words in values:
  srcarr=(ctypes.c_uint32*8)(*words);expected=(ctypes.c_uint32*(len(ops)*4))();fn(srcarr,expected)
  u.mem_write(0x90000000,struct.pack('>8I',*words));u.reg_write(UC_PPC_REG_1,0x801fe000);u.reg_write(UC_PPC_REG_3,0x90000000);u.reg_write(UC_PPC_REG_4,0x90001000);u.reg_write(UC_PPC_REG_LR,0x80001000)
  u.emu_start(entry,0x80001000,count=1000000);assert u.reg_read(UC_PPC_REG_PC)==0x80001000
  got=struct.unpack('>'+str(len(ops)*4)+'I',u.mem_read(0x90001000,len(ops)*16))
  for i,(native,ppc) in enumerate(zip(expected,got)):assert native==ppc,(ops[i//4][0],i%4,hex(native),hex(ppc))
 report=dict(operations=len(ops),vectors=len(values),comparisons=len(ops)*len(values),matched=True,physical_wii=False,scope='integer SIMD lane semantics, including mixed widths; no floating point or game boot')
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
