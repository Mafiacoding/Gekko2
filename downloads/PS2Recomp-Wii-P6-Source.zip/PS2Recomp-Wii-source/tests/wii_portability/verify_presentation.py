#!/usr/bin/env python3
"""Compare locked Wii presentation to the original VRAM snapshot path on host."""
from pathlib import Path
import subprocess,tempfile,hashlib,json
root=Path(__file__).resolve().parents[2]
source=r'''
#include "runtime/gs/gs_cpu_backend.h"
#include "runtime/gs/ps2_gs_memory.h"
#include <cstdio>
#include <vector>
int main(){
 GSMem::InitLookupTables();std::vector<uint8_t> vram(4*1024*1024);
 GSCpuBackend backend;backend.Initialize(vram.data(),vram.size());
 for(uint32_t psm:{0u,1u,2u,10u}){
  for(unsigned y=0;y<48;y++)for(unsigned x=0;x<64;x++)backend.WriteVram(psm,0,1,x,y,psm==2||psm==10?0x8000u|((x+y*64)&0x7fff):0x80000000u|(x*3u)|(y*5u<<8)|((x+y)*2u<<16));
  for(unsigned flags=0;flags<8;flags++){
   GSPresentationRequest req{};req.pmode=flags&1?3:1;req.smode2=(flags>>1)&3;req.vsyncTick=flags&1;
   req.dispfb1=1ull<<9|uint64_t(psm)<<15;req.dispfb2=req.dispfb1;
   req.display1=63ull<<32|47ull<<44;req.display2=req.display1;req.bgcolor=0x203040;
   auto frame=backend.Present(req);if(!frame||frame.pixels.size()!=size_t(640)*512*4)return 2;
   uint32_t header[]={psm,flags,frame.width,frame.height};std::fwrite(header,1,sizeof header,stdout);
   std::fwrite(frame.pixels.data(),1,frame.pixels.size(),stdout);
  }
 }
}
'''
with tempfile.TemporaryDirectory(prefix='ps2-wii-present-') as td:
 d=Path(td);(d/'test.cpp').write_text(source);results=[]
 for mode in ['snapshot','serial']:
  exe=d/mode;cmd=['g++','-std=c++20','-O1','-msse4.1','-pthread','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),str(d/'test.cpp'),str(root/'ps2xRuntime/src/lib/gs/gs_cpu_backend.cpp'),str(root/'ps2xRuntime/src/lib/gs/ps2_gs_memory.cpp'),'-o',str(exe)]
  if mode=='serial':cmd+=['-DPS2X_WII_SERIAL_PRESENT']
  subprocess.run(cmd,check=True);results.append(subprocess.check_output([str(exe)]))
 assert results[0]==results[1],'presentation outputs differ'
 print(json.dumps(dict(cases=32,compared_bytes=len(results[0]),sha256=hashlib.sha256(results[0]).hexdigest(),matched=True,physical_wii=False)))
