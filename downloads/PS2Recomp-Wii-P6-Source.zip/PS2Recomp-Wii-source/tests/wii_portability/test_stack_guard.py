#!/usr/bin/env python3
"""Reject compiler stack reports corresponding to the actual startup overflow."""
from pathlib import Path
import importlib.util,tempfile,unittest
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('guard',root/'tools/wii/check_build.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class StackGuardTests(unittest.TestCase):
 def test_main_frame_budget(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'main.cpp.su'
   for size,kind,good in [(232,'static',True),(522024,'static',False),(128,'dynamic',False)]:
    p.write_text(f'main.cpp:171:5:int main(int, char**)\t{size}\t{kind}\n')
    if good:self.assertEqual(m.check_main_stack(td),size)
    else:
     with self.assertRaises(ValueError):m.check_main_stack(td)
 def test_missing_report_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   with self.assertRaises(ValueError):m.check_main_stack(td)
if __name__=='__main__':unittest.main()
