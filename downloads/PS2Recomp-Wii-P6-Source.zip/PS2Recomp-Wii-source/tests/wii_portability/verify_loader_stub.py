#!/usr/bin/env python3
"""Exercise the actual relocated PPC copy stub, without pretending Wii boot."""
import argparse,struct,subprocess,random,json
from pathlib import Path
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import UC_PPC_REG_3,UC_PPC_REG_PC
p=argparse.ArgumentParser();p.add_argument('--elf',type=Path,required=True);p.add_argument('--nm',required=True);a=p.parse_args();b=a.elf.read_bytes()
symbols={parts[2]:int(parts[0],16) for l in subprocess.check_output([a.nm,str(a.elf)],text=True).splitlines() if len(parts:=l.split())==3}
start=symbols['ps2_loader_stub_start'];end=symbols['ps2_loader_stub_end'];off=struct.unpack_from('>I',b,32)[0];step,n=struct.unpack_from('>HH',b,46)
for i in range(n):
 s=struct.unpack_from('>10I',b,off+i*step)
 if s[3]<=start<end<=s[3]+s[5]:code=b[s[4]+start-s[3]:s[4]+end-s[3]];break
else:raise AssertionError('stub missing')
rng=random.Random(750)
for case in range(12):
 u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x1800000);u.mem_map(0x90000000,0x3400000)
 stage=0x91800000;stub=0x93300000;entry=0x80004000;header=bytearray(256);payload=bytearray();rows=[]
 for i in range(18):
  size=4 if i==0 else (0 if i%5==case%5 else rng.randrange(1,1536))
  addr=entry if i==0 else (0x90004000 if i%2 else 0x80008000)+i*0x1000+(case%4)
  offset=256+len(payload);data=bytes(rng.getrandbits(8) for _ in range(size));payload.extend(data)
  for base,value in [(0,offset),(0x48,addr),(0x90,size)]:struct.pack_into('>I',header,base+i*4,value)
  if size:rows.append((addr,data))
 bss=0x90040000+case;length=137+case;struct.pack_into('>III',header,0xd8,bss,length,entry)
 u.mem_write(stage,bytes(header+payload));u.mem_write(stub,code);u.mem_write(bss,b'\xa5'*length);u.reg_write(UC_PPC_REG_3,stage)
 u.emu_start(stub,entry,count=2000000);assert u.reg_read(UC_PPC_REG_PC)==entry
 for addr,data in rows:assert bytes(u.mem_read(addr,len(data)))==data
 assert bytes(u.mem_read(bss,length))==bytes(length)
 assert bytes(u.mem_read(stage,len(header+payload)))==bytes(header+payload)
 assert bytes(u.mem_read(stub,len(code)))==code
print(json.dumps(dict(cases=12,passed=True,scope='PPC relocation/copy/BSS/cache instructions/entry transfer; no IOS or hardware boot',stub_bytes=len(code),physical_wii=False)))
