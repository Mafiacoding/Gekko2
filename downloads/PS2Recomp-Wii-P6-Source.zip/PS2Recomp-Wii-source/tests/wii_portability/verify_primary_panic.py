#!/usr/bin/env python3
"""Execute actual PPC panic handler with bad backchains and mocked display sinks."""
import argparse,subprocess,struct,tempfile,json
from pathlib import Path
from unicorn import Uc,UC_ARCH_PPC,UC_MODE_PPC32,UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import UC_PPC_REG_1,UC_PPC_REG_3,UC_PPC_REG_4
root=Path(__file__).resolve().parents[2];p=argparse.ArgumentParser();p.add_argument('--devkitppc',type=Path,required=True);a=p.parse_args();cc=a.devkitppc/'bin/powerpc-eabi-gcc'
source='''#include <stdarg.h>
#include "ps2_wii_panic.c"
volatile unsigned result[8];
u32 VIDEO_GetCurrentTvMode(void){return VI_NTSC;}
void VIDEO_SetFramebuffer(void*p){(void)p;}
void __VIClearFramebuffer(void*p,u32 n,u32 c){(void)p;(void)n;(void)c;}
void __console_init(void*p,int x,int y,int w,int h,int stride){(void)p;(void)x;(void)y;(void)w;(void)h;(void)stride;}
void kprintf(const char*f,...){va_list v;va_start(v,f);
 if(f[0]=='P'&&f[1]=='C'){result[0]=va_arg(v,unsigned);result[1]=va_arg(v,unsigned);}
 if(f[0]=='E'){result[2]=va_arg(v,unsigned);(void)va_arg(v,unsigned);result[3]=va_arg(v,unsigned);}
 if(f[0]=='S')result[4]=1;
 va_end(v);}
void probe(unsigned c,PPCContext*p){primary_panic(c,p);}
'''
with tempfile.TemporaryDirectory() as td:
 d=Path(td);(d/'test.c').write_text(source);elf=d/'test.elf'
 subprocess.run([str(cc),'-Os','-DHW_RVL','-DGEKKO','-mcpu=750','-meabi','-msdata=none','-G0','-ffunction-sections','-fdata-sections','-I'+str(root/'ps2xRuntime/platform/wii'),'-I'+str(a.devkitppc.parent/'libogc/include'),str(d/'test.c'),'-nostdlib','-Wl,--gc-sections','-Wl,-e,probe','-Wl,-Ttext=0x80004000','-lc','-lgcc','-o',str(elf)],check=True)
 symbols={parts[2]:int(parts[0],16) for l in subprocess.check_output([str(a.devkitppc/'bin/powerpc-eabi-nm'),str(elf)],text=True).splitlines() if len(parts:=l.split())==3}
 b=elf.read_bytes();ph=struct.unpack_from('>I',b,28)[0];step,n=struct.unpack_from('>HH',b,42)
 for pointer,valid in [(0x90003000,1),(0x04444443,0),(0x933dfff0,0)]:
  u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
  for i in range(n):
   kind,off,addr,_,length,*_=struct.unpack_from('>8I',b,ph+i*step)
   if kind==1:u.mem_write(addr,b[off:off+length])
  ctx=bytearray(0x2c0);struct.pack_into('>4I',ctx,0,0x81234000,0x1030,0,0x80004200);struct.pack_into('>I',ctx,0x1c,0x04444443);u.mem_write(0x90003000,bytes(ctx))
  u.reg_write(UC_PPC_REG_1,0x801fe000);u.reg_write(UC_PPC_REG_3,3);u.reg_write(UC_PPC_REG_4,pointer)
  u.emu_start(symbols['probe'],0,count=50000)
  values=struct.unpack('>8I',u.mem_read(symbols['result'],32));assert values[2:5]==(3,valid,1),values
  assert values[:2]==((0x81234000,0x80004200) if valid else (0,0)),values
 print(json.dumps(dict(cases=3,passed=True,scope='actual PPC panic with corrupt SP, invalid context and border-crossing context; mocked video/text sinks',physical_wii=False)))
