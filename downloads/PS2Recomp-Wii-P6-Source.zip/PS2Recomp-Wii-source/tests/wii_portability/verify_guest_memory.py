#!/usr/bin/env python3
"""Run actual big-endian PPC guest helpers against independent byte/int models."""
import argparse, json, random, struct, subprocess, tempfile
from pathlib import Path
from unicorn import Uc, UC_ARCH_PPC, UC_MODE_PPC32, UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import UC_PPC_REG_1, UC_PPC_REG_3, UC_PPC_REG_4, UC_PPC_REG_LR, UC_PPC_REG_PC
root=Path(__file__).resolve().parents[2]
p=argparse.ArgumentParser();p.add_argument('--devkitppc',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=r'''
#include "ps2_runtime_macros.h"
#include "runtime/ps2_guest_record.h"
extern "C" void cases(const uint32_t *in,uint32_t *out){
 uint8_t bytes[64];for(unsigned i=0;i<64;i++)bytes[i]=uint8_t(i*37+11);
 auto emit=[&](__m128i v){for(unsigned i=0;i<4;i++)*out++=uint32_t(_mm_extract_epi32(v,i));};
 for(unsigned i=0;i<64;i++){
  *out++=Ps2GuestReadRing<uint16_t>(bytes,i,63);*out++=Ps2GuestReadRing<uint32_t>(bytes,i,63);
  uint64_t q=Ps2GuestReadRing<uint64_t>(bytes,i,63);*out++=uint32_t(q);*out++=uint32_t(q>>32);
  emit(Ps2GuestRead128Ring(bytes,i,63));
 }
 auto lo=_mm_set_epi32(in[3],in[2],in[1],in[0]);auto hi=_mm_set_epi32(in[7],in[6],in[5],in[4]);
 for(unsigned i=0;i<64;i++){
  for(unsigned j=0;j<64;j++)bytes[j]=uint8_t(j*37+11);
  Ps2GuestWrite128Ring(bytes,i,lo,63);
  Ps2GuestWriteRing<uint64_t>(bytes,i+19,uint64_t(in[4])|(uint64_t(in[5])<<32),63);
  Ps2GuestWriteRing<uint16_t>(bytes,i+29,uint16_t(in[6]),63);
  for(unsigned j=0;j<64;j++)*out++=bytes[j];
 }
 for(unsigned sa=0;sa<256;sa++)emit(ps2_qfsrv(hi,lo,sa));
 struct R32{uint32_t a;int32_t b;uint32_t c,d;};struct R64{uint64_t a,b;};
 auto x=Ps2GuestReadRecord<R32,uint32_t>(bytes);auto y=Ps2GuestReadRecord<R64,uint64_t>(bytes);
 *out++=x.a;*out++=uint32_t(x.b);*out++=x.c;*out++=x.d;
 *out++=uint32_t(y.a);*out++=uint32_t(y.a>>32);*out++=uint32_t(y.b);*out++=uint32_t(y.b>>32);
 Ps2GuestWriteRecord<R32,uint32_t>(bytes+16,x);Ps2GuestWriteRecord<R64,uint64_t>(bytes+32,y);
 for(unsigned i=16;i<48;i++)*out++=bytes[i];
}
'''
with tempfile.TemporaryDirectory(prefix='ps2-wii-memory-') as td:
 d=Path(td);(d/'test.cpp').write_text(source);elf=d/'test.elf'
 cmd=[str(a.devkitppc/'bin/powerpc-eabi-g++'),'-std=c++20','-Os','-mcpu=750','-meabi','-mno-altivec','-mno-vsx','-DPS2X_WII_SCALAR_SIMD','-DPS2X_WII','-DGEKKO','-DHW_RVL','-I'+str(a.devkitppc.parent/'libogc/include'),'-ffunction-sections','-fdata-sections','-I'+str(root/'ps2xRuntime/include'),'-I'+str(root/'ps2xIOP/include'),'-nostdlib','-Wl,--gc-sections','-Wl,-Ttext=0x80004000','-Wl,-e,cases',str(d/'test.cpp'),'-lc','-lgcc','-o',str(elf)]
 subprocess.run(cmd,check=True)
 b=elf.read_bytes();u=Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN);u.mem_map(0x80000000,0x200000);u.mem_map(0x90000000,0x20000)
 ph=struct.unpack_from('>I',b,28)[0];step,n=struct.unpack_from('>HH',b,42)
 for i in range(n):
  kind,off,addr,_,length,*_=struct.unpack_from('>8I',b,ph+i*step)
  if kind==1:u.mem_write(addr,b[off:off+length])
 entry=struct.unpack_from('>I',b,24)[0];rng=random.Random(0xEE750);vectors=[[0]*8,[0xffffffff]*8]+[[rng.getrandbits(32) for _ in range(8)] for _ in range(10)]
 total=0
 for words in vectors:
  expected=[];original=bytes((i*37+11)&255 for i in range(64))
  def ringread(i,n):return int.from_bytes(bytes(original[(i+j)&63] for j in range(n)),'little')
  for i in range(64):
   expected.extend([ringread(i,2),ringread(i,4)]);q=ringread(i,8);expected.extend([q&0xffffffff,q>>32]);q=ringread(i,16);expected.extend((q>>(32*j))&0xffffffff for j in range(4))
  for i in range(64):
   mem=bytearray(original)
   for off,data in [(i,struct.pack('<4I',*words[:4])),(i+19,struct.pack('<2I',*words[4:6])),(i+29,struct.pack('<H',words[6]&65535))]:
    for j,value in enumerate(data):mem[(off+j)&63]=value
   expected.extend(mem)
  q=int.from_bytes(struct.pack('<8I',*words),'little')
  for sa in range(256):expected.extend((q>>(sa+32*j))&0xffffffff for j in range(4))
  expected.extend(struct.unpack('<4I',mem[:16])*2);expected.extend(mem[:16]*2)
  u.mem_write(0x90000000,struct.pack('>8I',*words));u.reg_write(UC_PPC_REG_1,0x801fe000);u.reg_write(UC_PPC_REG_3,0x90000000);u.reg_write(UC_PPC_REG_4,0x90001000);u.reg_write(UC_PPC_REG_LR,0x80001000)
  u.emu_start(entry,0x80001000,count=4000000);assert u.reg_read(UC_PPC_REG_PC)==0x80001000,'execution budget exhausted'
  got=struct.unpack('>'+str(len(expected))+'I',u.mem_read(0x90001000,len(expected)*4))
  for i,(want,actual) in enumerate(zip(expected,got)):assert want==actual,(i,hex(want),hex(actual))
  total+=len(expected)
 report=dict(vectors=len(vectors),compared_words=total,wrap_offsets=64,qfsrv_shift_values=256,matched=True,physical_wii=False)
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
