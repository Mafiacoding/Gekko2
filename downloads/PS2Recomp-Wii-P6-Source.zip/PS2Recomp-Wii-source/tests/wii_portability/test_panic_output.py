#!/usr/bin/env python3
"""Check panic formatting uses direct console output, including bounded writes."""
from pathlib import Path
import ctypes,subprocess,tempfile,unittest
root=Path(__file__).resolve().parents[2]
class PanicOutputTests(unittest.TestCase):
 def test_direct_console_and_truncation(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td);(d/'sink.c').write_text('''#include <string.h>
#include <sys/types.h>
char capture[1024];size_t count;
void(*g_dietPrintFn)(const char*,size_t);
void probe_diet(const char*p,size_t n){g_dietPrintFn(p,n);}
ssize_t __console_write(void*r,void*f,const char*p,size_t n){(void)r;(void)f;count=n;memcpy(capture,p,n);capture[n]=0;return n;}
''')
   subprocess.run(['cc','-shared','-fPIC','-Wall','-Wextra','-Werror',str(root/'ps2xRuntime/platform/wii/ps2_wii_debug.c'),str(d/'sink.c'),'-o',str(d/'test.so')],check=True)
   lib=ctypes.CDLL(str(d/'test.so'));fn=getattr(lib,"__wrap_DEBUGPrint");fn.argtypes=[ctypes.c_int,ctypes.c_char_p]
   output=(ctypes.c_char*1024).in_dll(lib,'capture');count=ctypes.c_size_t.in_dll(lib,'count')
   fn(0,b'PC %08X LR %08X\n',ctypes.c_uint(0x81234560),ctypes.c_uint(0x80003f84))
   self.assertEqual(output.value,b'PC 81234560 LR 80003F84\n')
   fn(0,b'%s',ctypes.c_char_p(b'X'*2048));self.assertEqual(count.value,767);self.assertEqual(output.value,b'X'*767)
   fn(0,None);self.assertEqual(count.value,767)
   getattr(lib,"__SYS_PreInit")()
   lib.probe_diet.argtypes=[ctypes.c_char_p,ctypes.c_size_t]
   lib.probe_diet(b'Exception (DSI)',15);self.assertEqual(output.value,b'Exception (DSI)')
   lib.probe_diet(None,8);self.assertEqual(output.value,b' '*8)
if __name__=='__main__':unittest.main()
