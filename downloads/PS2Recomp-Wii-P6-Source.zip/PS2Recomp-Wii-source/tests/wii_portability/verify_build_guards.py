#!/usr/bin/env python3
"""Check both a built artifact and deliberate corruption of its layout."""
import argparse,importlib.util,json,struct,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('check_build',root/'tools/wii/check_build.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
p=argparse.ArgumentParser();p.add_argument('--elf',type=Path,required=True);p.add_argument('--dol',type=Path,required=True);a=p.parse_args();module.check(a.elf,a.dol)
elf=a.elf.read_bytes();dol=a.dol.read_bytes();tests=[]
def dolcase(name,offset,value):
    data=bytearray(dol);struct.pack_into('>I',data,offset,value);tests.append((name,elf,data))
dolcase('BSS beyond MEM1',0xd8,0x817ff000)
dolcase('overlapping data/text',0x64,struct.unpack_from('>I',dol,0x48)[0])
dolcase('entry outside text',0xe0,0x90000000)
data=bytearray(dol);data[struct.unpack_from('>I',data,0)[0]]^=1;tests.append(('corrupt instruction bytes',elf,data))
data=bytearray(elf);start=struct.unpack_from('>I',data,32)[0];step,count=struct.unpack_from('>HH',data,46)
for i in range(count):
    off=start+i*step;flags=struct.unpack_from('>I',data,off+8)[0]
    if flags&2:
        struct.pack_into('>I',data,off+8,flags|0x400);break
tests.append(('unsupported ELF TLS',data,dol))
with tempfile.TemporaryDirectory(prefix='ps2-wii-guards-') as td:
    e=Path(td)/'test.elf';d=Path(td)/'boot.dol'
    for name,edata,ddata in tests:
        e.write_bytes(edata);d.write_bytes(ddata)
        try:module.check(e,d)
        except ValueError:continue
        raise AssertionError('Invalid artifact accepted: '+name)
print(json.dumps(dict(valid_artifact_passed=True,invalid_artifacts_rejected=len(tests),physical_wii=False)))
