#!/usr/bin/env python3
import importlib.util,tempfile,unittest
from pathlib import Path
root=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('prepare_disc',root/'tools/wii/prepare_disc.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
def record(name,lba,size,directory=False):
 name=name.encode('ascii');length=(33+len(name)+1)&~1;b=bytearray(length);b[0]=length;b[2:6]=lba.to_bytes(4,'little');b[6:10]=lba.to_bytes(4,'big');b[10:14]=size.to_bytes(4,'little');b[14:18]=size.to_bytes(4,'big');b[25]=2 if directory else 0;b[28:32]=b'\x01\x00\x00\x01';b[32]=len(name);b[33:33+len(name)]=name;return b
def image(stride=2048,offset=0,badname=None):
 sectors=[bytearray(2048) for _ in range(24)];sectors[16][:7]=b'\x01CD001\x01';r=record('\0',20,2048,True);sectors[16][156:156+len(r)]=r
 cnf=b'BOOT2 = cdrom0:\\TEST.ELF;1\n';elf=b'\x7fELF\x01\x01'+bytes(58)
 records=record('\0',20,2048,True)+record('\1',20,2048,True)+record('SYSTEM.CNF;1',21,len(cnf))+record(badname or 'TEST.ELF;1',22,len(elf));sectors[20][:len(records)]=records;sectors[21][:len(cnf)]=cnf;sectors[22][:len(elf)]=elf
 result=bytearray(stride*24)
 for i,sector in enumerate(sectors):result[i*stride+offset:i*stride+offset+2048]=sector
 return result,elf
class PrepareDiscTests(unittest.TestCase):
 def test_supported_sector_layouts(self):
  for stride,offset in [(2048,0),(2352,16),(2352,24),(2336,8)]:
   with self.subTest(stride=stride,offset=offset),tempfile.TemporaryDirectory() as td:
    d=Path(td);raw,elf=image(stride,offset);(d/'disc').write_bytes(raw);disc=mod.Disc(d/'disc')
    try:
     report=disc.extract(d/'out');self.assertEqual((d/'out/game.elf').read_bytes(),elf);self.assertEqual(len(report['files']),2);self.assertFalse(report['compatible']);self.assertEqual(report['sector_offset'],offset)
    finally:disc.close()
 def test_unsafe_names_rejected(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td);raw,_=image(badname='../BAD;1');(d/'disc').write_bytes(raw);disc=mod.Disc(d/'disc')
   try:
    with self.assertRaisesRegex(ValueError,'Unsafe'):disc.extract(d/'out')
   finally:disc.close()
 def test_existing_data_preserved(self):
  with tempfile.TemporaryDirectory() as td:
   d=Path(td);raw,_=image();(d/'disc').write_bytes(raw);(d/'out').mkdir();(d/'out/keep').write_bytes(b'owner');disc=mod.Disc(d/'disc')
   try:
    with self.assertRaisesRegex(ValueError,'not be overwritten'):disc.extract(d/'out')
    self.assertEqual((d/'out/keep').read_bytes(),b'owner')
   finally:disc.close()
 def test_inconsistent_endian_extent_rejected(self):
  with self.assertRaisesRegex(ValueError,'Inconsistent'):
   raw=record('FILE',22,12);raw[6]^=1;mod.Disc.record(raw)
if __name__=='__main__':unittest.main()
