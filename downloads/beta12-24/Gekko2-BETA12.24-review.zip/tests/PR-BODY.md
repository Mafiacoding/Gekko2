Add BETA12.24 game diagnostics for Crash/Tekken progression failures: fixed 64-entry transport ring, per-path full GIF tags, XGKICK and SIGNAL transitions, distinct CSR/INTC acknowledgements, VIF wait reasons, pinned first eight unknown VU1 pairs and CPU wait snapshots. Producers do not write SD or fetch guest memory. Repeated stalled retries are deduplicated. Existing checkpoint logging drains bounded history and reports overflow. Title identity is a sanitized selected filename, not a guessed executable signature.

Retains BETA12.23 behavior and both experiment defaults. No new SIGNAL bypass, gameplay fix or FPS claim.

Validation: 47 host suites with tracing ON; independent ring/observational/pinned-history tests; real GIF SIGNAL test with 1000 retries and CSR W1C; parser checks; linked PPC VIF/UV/aspect, XGKICK/IPU/palette, VIF/GS and GX-fence checks. Wii DOL/ELF/MEM1 pass. See docs/BETA12.24-GAME-DIAGNOSTICS.md. No user logs, BIOS or discs included.
