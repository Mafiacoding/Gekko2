/*
 * R1335 NOTE: known RAM calls have an optional bounded bulk path.
 * Strict BIOS HLE fallback (off by default) passes unimplemented calls
 * to guest execution without altering pipeline/registers. The historical
 * generic-zero path remains only for compatibility; it is not PCSX2 parity.
 *
 * iop_hle_bios.h - IOP BIOS syscall trap (the "HLE BIOS replacement")
 *
 * IMPORTANT SCOPE NOTE, read this before extending or trusting this
 * file: this is NOT a port of PCSX2's actual IOP HLE. PCSX2's real
 * approach (pcsx2/IopBios.cpp, ~1500 lines) is far more involved than
 * what's implemented here - it lets the REAL IOP BIOS ROM execute far
 * enough to build its own internal data structures (loadcore's module
 * list, thread manager state, etc. - see IopBios.cpp's `loadcore::
 * GetModList`/`GetThreadList`, which literally parse the running
 * BIOS's in-memory structures), and only intercepts specific IRX
 * library import calls once those structures exist
 * (`irxImportTableAddr`/`irxImportHLE`/`irxImportExec`). That
 * approach fundamentally depends on having a real, working PS2 IOP
 * BIOS ROM to boot first - this project doesn't ship one (PS2 BIOS
 * ROMs are copyrighted Sony firmware, see docs/STATUS.md), and even
 * with one, faithfully replicating version-specific internal BIOS
 * structure layouts is out of reach without a verified reference this
 * project doesn't have.
 *
 * What IS implemented here instead is the older, much simpler, and
 * extremely well-established PS1-style BIOS call convention that the
 * PS2 IOP retains for backward compatibility: three fixed "trap"
 * addresses right at the bottom of the address space -
 *
 *   0x000000A0 - the "A0 table" (typically low-level kernel/memory
 *                functions on real PS1/PS2 hardware)
 *   0x000000B0 - the "B0 table" (typically higher-level kernel calls)
 *   0x000000C0 - the "C0 table" (typically exception/interrupt setup)
 *
 * Calling convention: the caller loads a function number into
 * register $t1 (r9) and jumps to one of these three addresses with
 * the return address in $ra (r31) - i.e. effectively `JAL 0xA0` (or
 * 0xB0/0xC0). Real hardware/BIOS ROM code AT those addresses reads
 * $t1 and dispatches through an internal jump table, eventually
 * returning via `JR $ra`. This three-vector mechanism is foundational
 * PS1/PS2 architecture (used by essentially every open-source PS1/PS2
 * emulator for BIOS HLE), not something invented for this project -
 * but the SPECIFIC function-number-to-behavior mapping for each
 * table (e.g. "function 0x3C on the A0 table does X") is NOT
 * something this project has a verified, citable reference for, and
 * is deliberately NOT guessed at here.
 *
 * What this file actually does: when the IOP core's PC reaches one of
 * the three trap addresses, iop_step() (in iop_core.c) calls
 * iop_hle_bios_try_handle() INSTEAD OF fetching/decoding a real
 * instruction there. The call is logged (table + function number),
 * $v0 is set to a generic default (0), and execution is redirected
 * straight to the return address in $ra - simulating "the call
 * happened and returned" without executing real BIOS-ROM bytes that
 * likely don't exist/aren't meaningful in this project's incomplete
 * BIOS images anyway. This turns what would otherwise be either an
 * infinite NOP loop (if the region reads as zero bytes, which decode
 * as valid MIPS NOPs) or a halt-on-garbage-opcode into forward
 * progress for whatever boot code issued the call - a real,
 * meaningful improvement even without knowing what any specific
 * function number "really" does, a legacy Gekko2 approximation. PCSX2 irxImportExec returns 0 to
 * decline an interception and continue guest execution, not to force a
 * generic guest return value. R1335 exposes strict fallback separately.
 *
 * ONE EXCEPTION to "every call gets a generic default": C(07h),
 * InstallExceptionHandlers - see the real-BIOS-testing investigation
 * in docs/STATUS.md. Real PS1/PS2 hardware/BIOS documents this
 * function's job precisely (community reference: psx-spx,
 * https://psx-spx.consoledev.net/kernelbios/, "BIOS Function
 * Summary" and "BIOS RAM Map" sections): it writes a small, fixed,
 * 4-instruction trampoline (LUI $k0,0 / ADDIU $k0,$k0,<addr> /
 * JR $k0 / NOP) to the CPU's hardware-mandated general exception
 * vector at RAM address 0x80 (mirrored to address 0, per that same
 * document's "Garbage Area" note). Confirmed via real-BIOS testing
 * that this project's generic default-return stub was exactly what
 * was leaving that vector empty, causing execution to eventually
 * wander into unrelated reserved memory and halt. Rather than
 * hardcoding the well-known template bytes from the public
 * documentation (which vary slightly by BIOS revision - the jump
 * target immediate differs), `iop_hle_bios_try_handle()` locates the
 * REAL 16-byte template already present in the loaded BIOS ROM image
 * itself (a distinctive, unambiguous byte signature - see
 * `find_exception_handler_template()`) and copies those exact,
 * version-correct bytes verbatim. If no such signature is found (a
 * different BIOS revision structures this differently, or no BIOS
 * ROM is loaded), this falls back to the same generic default as
 * every other function - no fabricated bytes are ever written.
 *
 * FURTHER EXCEPTIONS added this round (task: "IOP HLE stubs for
 * BIOS-boot-path modules"): the same psx-spx reference
 * (https://psx-spx.consoledev.net/kernelbios/, "A-Functions"/
 * "B-Functions" tables) also documents a set of A0-table calls that
 * are pure, fully-specified computation on IOP RAM/registers only -
 * no dependency on any real BIOS internal kernel structure (unlike
 * e.g. module loading, thread control blocks, or device drivers,
 * which this project still has no verified reference for - see
 * iop_hle_modules.h and docs/STATUS.md's "round 14" finding). These
 * are implemented for real below: ABS/LABS(0x0E/0x0F), STRCAT/
 * STRNCAT(0x15/0x16), STRCMP/STRNCMP(0x17/0x18), STRCPY/STRNCPY
 * (0x19/0x1A), STRLEN(0x1B), BCOPY/BZERO(0x27/0x28), MEMCPY/MEMSET/
 * MEMMOVE(0x2A/0x2B/0x2C), INITHEAP(0x39, bookkeeping only - no real
 * allocator, same "scaffold, not a port" caveat as
 * iop_hle_modules.c), FLUSHCACHE(0x44, a correct no-op - this project
 * has no cache model to flush), and EXIT/_EXIT(0x06/0x3A, which halts
 * the core with an honest, descriptive reason instead of silently
 * returning 0 and letting the caller proceed past a call that real
 * hardware never returns from).
 *
 * MEMMOVE is a deliberate exception to "implement it correctly":
 * psx-spx annotates A(2Ch) memmove as ";Bugged" on real hardware
 * (i.e. the real BIOS's memmove does NOT handle overlapping regions
 * safely, unlike a standard C memmove). This is implemented here as
 * a plain forward byte-copy (matching memcpy, NOT overlap-safe) to
 * match that documented real (buggy) behavior, rather than silently
 * "fixing" it to modern libc semantics no real IOP BIOS ever had.
 *
 * ANOTHER EXCEPTION added in Round 22 (see docs/STATUS.md): C(02h)/
 * C(03h), SysEnqIntRP/SysDeqIntRP - the real, byte-exact exception-
 * handler priority-chain manipulation mechanism rooted at RAM[0x100]
 * (see include/core/hw/iop_excb.h for the full citation trail and
 * implementation). This is the mechanism Round 19's real-BIOS trace
 * found being looked up with no handler ever registered - these two
 * C-functions are how a real BIOS registers/unregisters one. Only the
 * container/mechanism is real here, not the real default handler
 * bodies (EnqueueSyscallHandler/EnqueueTimerAndVblankIrqs/InitDefInt
 * remain un-implemented, same rationale as everything else in this
 * file - see iop_excb.h's scope note).
 *
 * Still NOT implemented (same rationale as the rest of this file):
 * anything touching files/devices (open/read/write/close/ioctl),
 * heap allocation (malloc/free/calloc/realloc - InitHeap is recorded
 * but nothing actually allocates from it), threads/events (SetConf/
 * EnqueueCdIntr/etc.), or any CD-ROM/memory-card function - all of
 * these depend on internal BIOS kernel structures (TCBs, EvCBs, file
 * control blocks) this project has never modeled and has no verified
 * layout for.
 */
#ifndef PCSX2_WII_IOP_HLE_BIOS_H
#define PCSX2_WII_IOP_HLE_BIOS_H

#include <stdint.h>
#include "core/iop/iop_core.h"

#define IOP_HLE_TABLE_A0 0x000000A0u
#define IOP_HLE_TABLE_B0 0x000000B0u
#define IOP_HLE_TABLE_C0 0x000000C0u

/* C0-table function numbers this project also implements for real -
 * see iop_excb.h. Real, byte-exact chain-manipulation mechanism
 * (including the documented SysDeqIntRP bug), NOT the real default
 * handler contents (see iop_excb.h's scope note). */
#define IOP_HLE_C0_SYSENQINTRP 0x02u
#define IOP_HLE_C0_SYSDEQINTRP 0x03u

/* Round 29 continued (2nd fix this round): C(01h) EnqueueSyscallHandler
 * (priority) - psx-spx: "Internally used to add some default IRQ and
 * Exception handlers", used with priority=0. Live tracing against the
 * user's real SCPH-10000 dump (docs/STATUS.md's "Round 29 continued"
 * section) found the real BIOS calls this EXACT function right after
 * B(00h) successfully allocates the ExCB table - confirming this is
 * genuinely on the real boot path, not a hypothetical. Unlike
 * SysEnqIntRP/SysDeqIntRP (whose CHAIN-MANIPULATION mechanism psx-spx
 * documents byte-exactly), psx-spx does NOT give byte-level semantics
 * for what "internal default handler" C(01h) installs - so instead of
 * fabricating an address, this project installs a REAL, position-
 * independent MIPS machine-code trampoline (assembled by hand,
 * verified via Capstone round-trip and cross-checked against the
 * ACTUAL, live-disassembled real dispatcher/ReturnFromException code
 * found this round - see iop_hle_bios.c's g_syscall_handler_code and
 * the IOP_RFE_TRAMPOLINE_TARGET comment) that implements psx-spx's
 * own word-for-word documented SYS(01h)/SYS(02h) behavior:
 *   "SYS(01h) EnterCriticalSection(): Disables interrupts by clearing
 *    SR (cop0r12) Bit 2 and 10 ... Returns 1 if both bits were set"
 *   "SYS(02h) ExitCriticalSection(): Enables interrupts by set SR
 *    (cop0r12) Bit 2 and 10 ... no return value"
 * and ends by jumping to the REAL ReturnFromException entry point
 * (address 0x00000f30, confirmed via live disassembly of the user's
 * own real BIOS's resident kernel image this round - see
 * docs/STATUS.md), exactly matching real hardware's own documented
 * behavior ("the handler may execute ReturnFromException to abort
 * further exception handling"). The trampoline's bytes are executed
 * by the ordinary IOP interpreter like any other code - this is NOT
 * a 4th special HLE trap PC, it is genuine, position-independent
 * MIPS machine code placed into the real Kernel Memory region via the
 * same real B(00h)-style bump allocator. */
#define IOP_HLE_C0_ENQUEUESYSCALLHANDLER 0x01u

/* B(18h) ResetEntryInt() - psx-spx: "Applies the default 'Exit'
 * structure (which consists of a pointer to ReturnFromException, and
 * the Kernel's exception stacktop (minus 4), and zeroes for
 * R16..R23,R28,R30). Returns the address of that structure." Live
 * disassembly this round found that the REAL BIOS's own resident
 * kernel image ALREADY has this exact default structure correctly
 * pre-populated at address 0x00006C34 (ra field == 0x00000f30, the
 * real ReturnFromException address; sp field == 0x00008524, matching
 * "exception stacktop minus 4" against the real RAM[0x6c30]=0x8528
 * stack-top value) - confirmed byte-for-byte via a live RAM snapshot
 * (see docs/STATUS.md's "Round 29 continued" section). The ONLY part
 * of ResetEntryInt's job this project's boot path doesn't already do
 * for free is resetting the POINTER VARIABLE at RAM[0x00007520] (read
 * by the real dispatcher's post-priority-chain fallback code, live-
 * disassembled at ROM-resident address 0x00000e44) back to that
 * struct's address - which stays 0 (a real, confirmed gap; the struct
 * CONTENTS are real and already correct, but nothing currently sets
 * the pointer TO them) until this function runs. This constant
 * (0x00006C34) is not a guess - it is the literal immediate value
 * (`addiu $v0,$v0,0x6c34`) the real ROM-resident code itself uses. */
#define IOP_HLE_B0_RESET_ENTRY_INT 0x18u
#define IOP_JMPBUF_DEFAULT_PTR_ADDR    0x00007520u
#define IOP_JMPBUF_DEFAULT_STRUCT_ADDR 0x00006C34u

/* B(19h) HookEntryInt(addr) - psx-spx's function summary table lists
 * this as taking a single "addr" argument, immediately following
 * B(18h) ResetEntryInt() in the table and sharing its exact
 * mechanism: both write the POINTER VARIABLE at RAM[0x00007520] that
 * the real dispatcher's post-priority-chain fallback code reads (see
 * IOP_HLE_B0_RESET_ENTRY_INT's comment above for the live-disassembly
 * citation of that fallback code at ROM 0x00000e44) - ResetEntryInt
 * resets it back to the kernel's own default struct address
 * (0x00006C34); HookEntryInt installs the CALLER's own address
 * instead, letting BIOS/application code supply its own "resume here
 * if nothing claims this exception" struct rather than the kernel
 * default. Round 29 continued (5th finding): live call-tracing this
 * session found the real BIOS calls A(13h) setjmp(buf) immediately
 * followed by B(19h) HookEntryInt(addr) with the SAME address in
 * both calls (confirmed: both saw a0=0x8004fd50 at IOP instr
 * 3054696/3054708 in a live host-native trace) - exactly the
 * standard "set up my own recovery point, then register it as the
 * fallback" idiom this pairing exists for. Because this project did
 * not previously implement either call, RAM[0x7520] was silently
 * left at the default struct address, so the real BIOS's own,
 * intended recovery point was never actually installed - the
 * dispatcher's fallback kept resuming the kernel default struct
 * instead, which is what produced the steady 3-instruction spin loop
 * observed at IOP RAM 0x101280-0x101288. Return-value convention
 * mirrors ResetEntryInt's documented "returns the address of that
 * structure" - HookEntryInt returns the same addr it just installed. */
#define IOP_HLE_B0_HOOK_ENTRY_INT 0x19u

/* A(13h) setjmp(buf) - psx-spx: saves the caller's registers into a
 * caller-supplied buffer so a later longjmp-style restore (in this
 * kernel's case, the dispatcher's own priority-chain-exhausted
 * fallback, which does a manual, inlined restore rather than calling
 * a real longjmp function) can resume execution there. The buffer
 * layout is the same 12-word (48-byte) ra/sp/fp/s0-7/gp struct this
 * project already reverse-engineered from the kernel's own default
 * struct at 0x00006C34 (see IOP_HLE_B0_RESET_ENTRY_INT's comment) -
 * word 0 = $ra, word 1 = $sp, word 2 = $fp ($s8), words 3-10 =
 * $s0-$s7, word 11 = $gp. Real MIPS o32 setjmp returns 0 on the
 * direct call, matching standard C setjmp() semantics; this project
 * has no real longjmp call site (the dispatcher's fallback restores
 * registers inline rather than jumping back into a setjmp() call
 * frame), so the "returns nonzero after longjmp" half of the contract
 * is not modeled - only the save, which is the half needed to fix the
 * HookEntryInt pairing above. */
#define IOP_HLE_A0_SETJMP 0x13u
#define IOP_JMPBUF_OFF_RA  0x00u
#define IOP_JMPBUF_OFF_SP  0x04u
#define IOP_JMPBUF_OFF_FP  0x08u
#define IOP_JMPBUF_OFF_S0  0x0Cu  /* s0..s7 occupy 0x0C..0x28, 4 bytes each */
#define IOP_JMPBUF_OFF_GP  0x2Cu

/* A0-table function numbers this round implements for real - see the
 * header comment above and psx-spx's "A-Functions" table. */
#define IOP_HLE_A0_EXIT       0x06u
#define IOP_HLE_A0_ABS        0x0Eu
#define IOP_HLE_A0_LABS       0x0Fu
#define IOP_HLE_A0_STRCAT     0x15u
#define IOP_HLE_A0_STRNCAT    0x16u
#define IOP_HLE_A0_STRCMP     0x17u
#define IOP_HLE_A0_STRNCMP    0x18u
#define IOP_HLE_A0_STRCPY     0x19u
#define IOP_HLE_A0_STRNCPY    0x1Au
#define IOP_HLE_A0_STRLEN     0x1Bu
#define IOP_HLE_A0_BCOPY      0x27u
#define IOP_HLE_A0_BZERO      0x28u
#define IOP_HLE_A0_MEMCPY     0x2Au
#define IOP_HLE_A0_MEMSET     0x2Bu
#define IOP_HLE_A0_MEMMOVE    0x2Cu
#define IOP_HLE_A0_INITHEAP   0x39u
#define IOP_HLE_A0__EXIT      0x3Au
#define IOP_HLE_A0_FLUSHCACHE 0x44u

/* A(96h) AddCDROMDevice() and A(97h) AddMemCardDevice() - psx-spx's
 * function summary table lists both as taking no arguments; per the
 * same doc's "add_device B(47h) (and all add_xxx_device functions)"
 * note, these built-in Add*Device functions internally call the
 * generic B(47h) AddDrv(device_info) with a hardcoded, ROM-resident
 * device_info describing the device's name and its open/close/read/
 * write/etc. function pointers, then register that into the fixed
 * DCB (Device Control Block) table documented in psx-spx's BIOS RAM
 * Map ("00000150h DCB Device Control Blocks (addr=fixed, size=0Ah*50h)").
 * This project has not found a citable, byte-exact DCB entry layout
 * (name/flags/function-pointer field order and offsets) - psx-spx
 * documents the table's address and total size but not its per-entry
 * internal format, and no live disassembly of this project's own
 * real BIOS dump has targeted that specific structure yet. Writing
 * fabricated bytes into real emulated RAM using a GUESSED struct
 * layout would be worse than not implementing this at all (any real
 * BIOS code that later reads the table with the REAL layout would
 * misbehave in a new, harder-to-diagnose way) - so, matching this
 * project's own established practice of only writing struct layouts
 * to real addresses once THIS project has directly confirmed them
 * (see the jmp_buf and ExCB chain-node formats elsewhere in this
 * file), this implementation models the REAL, user-visible effect of
 * calling these functions - the device becoming genuinely registered
 * and available - as real internal emulator state (not a demo/no-op
 * stub: the registered flag is real, persists, and is queryable) but
 * does not yet fabricate an unverified in-RAM DCB byte layout. Empirical
 * note: live call-tracing this session (see docs/STATUS.md's "Round 29
 * continued (5th finding)" section) found neither function is called
 * anywhere in this real BIOS dump's traced boot-to-panic-loop window,
 * so this is real, additional BIOS-function coverage requested
 * directly by the user, not (by itself) expected to change that
 * specific steady-state outcome. */
#define IOP_HLE_A0_ADDCDROMDEVICE   0x96u
#define IOP_HLE_A0_ADDMEMCARDDEVICE 0x97u

/* B-table function this round (Round 29 continuation) implements for
 * real - see psx-spx's "B-Functions" table and its BIOS RAM Map's
 * "0000E000h 2000h Kernel Memory; ExCBs, EvCBs, and TCBs allocated
 * via B(00h)" note. B(00h) alloc_kernel_memory(size) is a real,
 * fully-specified bump allocator over that documented 0x2000-byte
 * region - implemented for real here (not fabricated) because live
 * tracing against the user's own real SCPH-10000 dump (docs/
 * STATUS.md's "Round 29" section) found the REAL BIOS ROM's own
 * ExCB/EvCB/PCB/TCB allocation routines (genuine, executing code at
 * ROM addresses ~0xbfc4ff90-0xbfc501f8, confirmed via live Capstone
 * disassembly) call exactly this function via the standard "thunk to
 * 0xB0 with $t1=0" mechanism, and - because this project previously
 * had no real implementation for it - always received the generic
 * default return value of 0 (i.e. "allocation failed"), which is why
 * RAM[0x100] (the ExCB table address) was never actually populated
 * even though the real BIOS code responsible for populating it is
 * demonstrably present and running. Implementing the allocator lets
 * that already-real BIOS code succeed on its own terms - this is
 * real BIOS behavior unlocked, not new fabricated behavior. */
#define IOP_HLE_B0_ALLOC_KERNEL_MEMORY 0x00u

typedef struct {
    uint64_t calls_seen;
    uint32_t last_table;     /* one of the IOP_HLE_TABLE_* constants */
    uint32_t last_function;  /* value of $t1 at the time of the last call */
    char     last_call_desc[64];

    /* InstallExceptionHandlers (C0h/0x07) real-behavior tracking -
     * see the header comment above. */
    uint8_t  exception_handler_template_found; /* 1 if the 16-byte
                                                 * signature was
                                                 * located in the
                                                 * loaded BIOS ROM */
    uint8_t  exception_handler_installed;      /* 1 once the template
                                                 * has actually been
                                                 * written to RAM */

    /* Real-behavior A0-table calls added this round - see the header
     * comment above. */
    uint64_t known_calls_handled; /* count of calls that got real
                                    * behavior (not the generic
                                    * default) - includes C(07h) and
                                    * every IOP_HLE_A0_* function
                                    * below */
    uint32_t heap_addr, heap_size; /* InitHeap(0x39) bookkeeping only -
                                     * no real allocator, see header */
    uint8_t  heap_initialized;
    uint8_t  exited;               /* 1 once EXIT/_EXIT has halted the core */
    uint32_t exit_code;

    /* B(00h) alloc_kernel_memory(size) - real bump allocator, see the
     * IOP_HLE_B0_ALLOC_KERNEL_MEMORY comment above. kmem_bump_next
     * starts at IOP_EXCB_ARRAY_ADDR (0xE000, the documented "Kernel
     * Memory" region base) and only ever increases; kmem_alloc_calls
     * is a plain diagnostic counter. */
    uint32_t kmem_bump_next;
    uint64_t kmem_alloc_calls;
    uint64_t kmem_alloc_failures; /* count of calls that returned 0
                                    * because the request would exceed
                                    * the documented 0x2000-byte region */

    /* Round 29 continued: C(01h) EnqueueSyscallHandler real trampoline
     * - see IOP_HLE_C0_ENQUEUESYSCALLHANDLER's header comment.
     * syscall_handler_code_addr is where the real machine-code
     * trampoline was written (0 until the first C(01h) call installs
     * it - only installed once, reused on subsequent calls).
     * syscall_handler_installs counts how many times C(01h) actually
     * ran (each one enqueues a fresh chain node at whatever priority
     * was requested, but only allocates the shared code ONCE). */
    uint32_t syscall_handler_code_addr;
    uint64_t syscall_handler_installs;

    /* Round 29 continued: B(18h) ResetEntryInt - see
     * IOP_HLE_B0_RESET_ENTRY_INT's header comment. Plain diagnostic
     * counter, no other state needed since the real fix is just
     * writing a well-evidenced constant to a fixed RAM address. */
    uint64_t reset_entry_int_calls;

    /* Round 29 continued (5th finding): B(19h) HookEntryInt and
     * A(13h) setjmp - see their header comments above. Plain
     * diagnostic counters. */
    uint64_t hook_entry_int_calls;
    uint64_t setjmp_calls;

    /* Round 29 continued (6th change): A(96h) AddCDROMDevice() and
     * A(97h) AddMemCardDevice() - see their header comments above.
     * Real, queryable registration state (not demo/no-op stubs): the
     * flags genuinely flip from 0 to 1 the first time each function
     * is called, and stay 1 afterwards (matching real hardware's own
     * idempotent "device already registered" behavior, per psx-spx's
     * B(59h) testdevice() note that re-registering an existing device
     * is a safe no-op). */
    uint8_t  cdrom_device_registered;
    uint8_t  memcard_device_registered;
    uint64_t add_cdrom_device_calls;
    uint64_t add_memcard_device_calls;
} iop_hle_bios_state_t;

void iop_hle_bios_init(void);
uint64_t iop_hle_bios_route_stat(unsigned n);

/* Returns 1 if `pc` is one of the three trap addresses (in which case
 * the call has been fully "handled" - st->pc/st->next_pc have already
 * been redirected to the return address, and the caller should NOT
 * also fetch/decode a real instruction for this step), 0 otherwise. */
int iop_hle_bios_try_handle(iop_state_t *st, uint32_t pc);

iop_hle_bios_state_t *iop_hle_bios_get_state(void);

#endif
