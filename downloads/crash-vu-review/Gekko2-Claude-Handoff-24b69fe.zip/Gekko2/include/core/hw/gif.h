#ifndef PCSX2WII_GIF_H
#define PCSX2WII_GIF_H

#include <stdint.h>
#include "core/hw/dma.h"

/*
 * GIF (Graphics Interface) packet parser - the first component that
 * actually consumes DMA-delivered data and turns it into GS memory
 * writes, rather than just moving bytes around. This is what makes
 * the DMA chain engine (source/hw/dma.c) and GS memory model
 * (source/hw/gs_mem.c) actually connect to each other.
 *
 * Scope (deliberately limited - see docs/ROADMAP.md):
 *   - PACKED transfer mode only (FLG=0). REGLIST and IMAGE modes are
 *     not implemented.
 *   - Registers handled: PRIM, RGBAQ, XYZ2, UV, TEX0_1, and A+D
 *     (address+data) writes to PRIM/RGBAQ/XYZ2/UV/TEX0_1/FRAME_1/
 *     XYOFFSET_1/ZBUF_1/TEST_1 (ZBUF_1/TEST_1 added task #89 - real
 *     Z-buffer storage + depth test for triangles/SPRITE, see
 *     rasterize_triangle()/rasterize_sprite()). Everything else
 *     (alpha blending/test, CLAMP/scissor beyond basic XY offset,
 *     contexts 2, CLUT/paletted textures, mipmaps, ...) is ignored.
 *   - Primitive types: SPRITE (a filled, flat-color or - as of task
 *     #88 - texture-mapped axis-aligned rectangle from 2 vertices,
 *     always flat-shaded like real hardware; see gif.c's
 *     rasterize_sprite() for its simplified, explicitly-noted texture-
 *     coordinate approximation, distinct from triangles' full
 *     per-pixel perspective correction) and TRIANGLE/TRIANGLE_STRIP/
 *     TRIANGLE_FAN (types 3/4/5), which respect PRIM's real IIP bit
 *     (bit 3, flat vs. Gouraud shading), TME bit (bit 4, flat/Gouraud
 *     color vs. texture-mapped), and - as of task #88 - FST bit (bit
 *     8: 1 = UV fixed-point texel coordinates, 0 = ST+Q floating-point
 *     perspective-correct coordinates) - see gif.c's
 *     rasterize_triangle(). Color interpolation (Gouraud) always uses
 *     plain affine (screen-space) barycentric weighting. Texture-
 *     coordinate interpolation (when TME=1) uses plain affine
 *     interpolation when FST=1 (UV mode, matching real hardware) but
 *     genuine perspective-correct (1/Q) interpolation when FST=0
 *     (ST+Q mode, added this round - see rasterize_triangle()'s S/Q,
 *     T/Q, 1/Q barycentric interpolation, matching the standard
 *     perspective-texture-mapping algorithm real GS hardware uses).
 *     Texture sampling is nearest-neighbor from GS memory (PSMCT32
 *     only, matching gs_mem's existing format limitation) with no
 *     CLAMP/wrap modeling (negative interpolated coordinates are
 *     clamped to 0 as a defensive simplification, not real repeat/
 *     clamp semantics). TFX DECAL replaces color with the texture
 *     sample; MODULATE (and, simplified, HIGHLIGHT/HIGHLIGHT2 too)
 *     blends texture and shaded color as (tex*color)/128 per channel,
 *     the standard GS modulate formula. POINT (type 0) and LINE/
 *     LINE_STRIP (types 1/2, task: "GS coverage breadth") are now
 *     implemented too - see gif.c's rasterize_point()/
 *     rasterize_line(). POINT is a single flat-color, non-
 *     interpolated pixel write (real hardware: no interpolation of
 *     any kind for a single vertex). LINE/LINE_STRIP support real
 *     IIP-bit Gouraud shading (flat shading uses the LAST vertex's
 *     color, same convention as triangles/sprites - cross-checked
 *     against PCSX2's `GSDrawScanline::CSetupPrim`, which selects
 *     `last=1` for `GS_LINE_CLASS`) and real linear (not
 *     perspective-corrected - Z has already been through the
 *     perspective projection by the time it reaches the rasterizer,
 *     same as triangles) Z interpolation along the segment, ported
 *     from PCSX2's `GSRasterizer::DrawEdgeLine` DDA algorithm (walk
 *     the major axis one pixel at a time, step every interpolated
 *     attribute - color, Z - linearly per major-axis pixel). No
 *     texture mapping (real GS hardware does not texture-map POINT/
 *     LINE - only SPRITE/TRIANGLE support TME).
 *   - Register field bit positions (GIFTag, PRIM, RGBAQ PACKED
 *     layout, XYZ2 PACKED layout, FRAME, XYOFFSET) are cross-checked
 *     against PCSX2's GS/GSRegs.h and Gif.h, not guessed. The triangle
 *     rasterizer itself (edge-function-based scanline fill) is plain,
 *     well-known 2D geometry, not real-hardware-specific behavior, so
 *     it doesn't need the same kind of external verification the
 *     register layouts do.
 *
 * This is genuinely enough to draw simple flat-colored rectangles and
 * flat-shaded triangles (a BIOS/OSD background bar or a simple 3D
 * wireframe-filled shape, for instance) if real EE code drives it
 * through the DMA chain - it is NOT anywhere near real GS
 * rasterization (no textures, no blending, no Z test, no per-vertex
 * color/perspective).
 */

/* GIF register codes (PACKED mode descriptor nibbles / A+D addresses)
 * and PRIM primitive-type/IIP values - cross-checked against PCSX2's
 * GS/GSRegs.h GIF_A_D_REG enum and GIFRegPRIM bitfield layout. Public
 * (not just gif.c-internal) so any real GIF-packet producer - e.g.
 * main.c's demo, or a future VIF passthrough - can build a well-formed
 * packet without duplicating these constants. */
#define GIF_REG_PRIM      0x00
#define GIF_REG_RGBAQ     0x01
#define GIF_REG_XYZ2      0x05
#define GIF_REG_AD        0x0E
#define GIF_REG_NOP       0x0F
/* Round 97 (138th finding, task #254 - vertex-register parity):
 * XYZF2 (X/Y/Z + Fog coefficient, WITH drawing kick), XYZF3/XYZ3
 * (vertex-queue-advance-only variants, no drawing kick), and FOG (a
 * standalone "current fog value" register, same "latched, then read
 * at vertex kick" pattern as ST/UV - see gif.h's cur_fog field
 * comment below). Real PACKED-mode tag nibbles, cross-checked against
 * the official Sony GS Users Manual's "7.3 Register List in Address
 * Order" (0x04=XYZF2, 0x0a=FOG, 0x0c=XYZF3, 0x0d=XYZ3) - the same
 * legitimately public, citable source as Round 96's SCISSOR_1/2. */
#define GIF_REG_XYZF2     0x04
#define GIF_REG_FOG       0x0A
#define GIF_REG_XYZF3     0x0C
#define GIF_REG_XYZ3      0x0D

#define GS_REG_PRIM       0x00
#define GS_REG_RGBAQ      0x01
#define GS_REG_ST         0x02
#define GS_REG_UV         0x03
#define GS_REG_XYZ2       0x05
#define GS_REG_XYZF2      0x04
#define GS_REG_XYZF3      0x0C
#define GS_REG_XYZ3       0x0D
#define GS_REG_FOG        0x0A
#define GS_REG_TEX0_1     0x06
#define GS_REG_FRAME_1    0x4C
#define GS_REG_XYOFFSET_1 0x18
/* Z-buffer/depth-test registers (task #89) - cross-checked
 * against a live fetch of PCSX2's GS/GSRegs.h GIF_A_D_REG enum. */
#define GS_REG_TEST_1     0x47
#define GS_REG_ZBUF_1     0x4E
/* Round 96: SCISSOR_1/2 (clipping) - real, well-known GS register
 * addresses, cross-checked this round against the official Sony
 * GS Users Manual ("7.3 Register List in Address Order": 0x40=
 * SCISSOR_1, 0x41=SCISSOR_2), a genuine primary-source citation
 * (not the session-limited-research caveat noted on Rounds 24-28
 * below - this round had the real manual available). Previously
 * explicitly flagged as unmodeled (see the Round 28 comment
 * above: "CLAMP/TEX2/SCISSOR/FBA remain entirely unmodeled"). */
#define GS_REG_SCISSOR_1  0x40
#define GS_REG_SCISSOR_2  0x41
/* ALPHA_1 (Round 23: alpha blending) - cross-checked against a live
 * research pass over PCSX2's GS/GSRegs.h GIF_A_D_REG enum. */
#define GS_REG_ALPHA_1    0x42

/* BITBLTBUF/TRXPOS/TRXREG/TRXDIR configure GS transfers. BETA12.9
 * implements XDIR=2 (local-to-local) for matching known PSM layouts,
 * including directional overlapping moves. XDIR=0 host uploads retain
 * their established behavior. XDIR=1 local-to-host remains unsupported;
 * unsupported format conversions are declined, never fabricated. */
/* Round 27: GS Context 2 (dual-context support). Real hardware has
 * TWO independent rendering contexts, each with its own full set of
 * FRAME/ZBUF/XYOFFSET/TEX0/TEST/ALPHA (and more this project doesn't
 * model - CLAMP/TEX1/TEX2/SCISSOR/FBA/MIPTBP - see the scope note on
 * gif_state_t's ctx1_xxx/ctx2_xxx fields below). PRIM's CTXT bit
 * (bit 9) selects which context's already-configured state applies
 * to the NEXT primitive - context 2's registers are all at address
 * (context-1 address + 1), a clean, well-established real GS register
 * table pattern (already independently confirmed self-consistent by
 * this project's own prior-round additions: TEX0_1=0x06/TEX0_2=0x07,
 * XYOFFSET_1=0x18/XYOFFSET_2=0x19, TEST_1=0x47/TEST_2=0x48,
 * ALPHA_1=0x42/ALPHA_2=0x43, FRAME_1=0x4C/FRAME_2=0x4D,
 * ZBUF_1=0x4E/ZBUF_2=0x4F). Same session-limited-research caveat as
 * Rounds 24-26 applies to this round's specific field/address
 * details, mitigated here by that internal +1 consistency check. */
#define GS_REG_FRAME_2    0x4D
#define GS_REG_XYOFFSET_2 0x19
#define GS_REG_TEX0_2     0x07
#define GS_REG_TEST_2     0x48
#define GS_REG_ALPHA_2    0x43
#define GS_REG_ZBUF_2     0x4F
#define PRIM_CTXT_MASK    0x200u /* PRIM bit 9: 0=context1, 1=context2 */

/* Round 28: mipmaps - TEX1 (LOD calculation params) and MIPTBP1/
 * MIPTBP2 (per-level texture base pointers, levels 1-6). Real
 * addresses (well-known GS register set, same session-limited-
 * research caveat as Rounds 24-27 - see docs/STATUS.md's "GS Round
 * 28" section). Round 29 continued (15th change) closes the
 * context-2 half of the "CLAMP/TEX1/TEX2/SCISSOR/FBA/MIPTBP
 * unmodeled for either context" gap Round 27 explicitly left open:
 * TEX1/MIPTBP1/MIPTBP2 are now genuinely per-context, using the same
 * real _2 register addresses (base+1, the same convention every
 * other _1/_2 pair in this file already follows) and the same
 * ctx1_xxx/ctx2_xxx permanent-storage + gs_activate_context()
 * pattern Round 27 established for FRAME/XYOFFSET/TEX0/ZBUF/TEST/
 * ALPHA. CLAMP/TEX2/SCISSOR/FBA remain entirely unmodeled (for either
 * context) - a separate, larger gap (these registers don't exist in
 * this codebase at all yet, unlike TEX1/MIPTBP which already had a
 * context-1 implementation to extend). */
#define GS_REG_TEX1_1     0x14
#define GS_REG_MIPTBP1_1  0x34
#define GS_REG_MIPTBP2_1  0x36
#define GS_REG_TEX1_2     0x15
#define GS_REG_MIPTBP1_2  0x35
#define GS_REG_MIPTBP2_2  0x37
/* Round 99 (140th finding, task #254 - GS gap follow-up 3/N): PRMODECONT
 * / PRMODE - real addresses 0x1a/0x1b per the official GS Users Manual
 * ("PRMODE : Setting for Attributes of Drawing Primitives" / "PRMODECONT
 * : Specification of Primitive Attribute Setting Method"). PRMODECONT.AC
 * selects which register supplies the 8 mirrored drawing-attribute bits
 * (IIP/TME/FGE/ABE/AA1/FST/CTXT/FIX, bits 3-10 - PRIM's own bits 0-2,
 * the primitive TYPE field, are NEVER sourced from PRMODE, per the
 * manual's own field list for PRMODE, which omits bits 0-2 entirely):
 * AC=1 -> use PRIM's own attribute bits (the default/normal case, and
 * this project's chosen safety-gate default so pre-existing tests never
 * touch PRMODECONT and thus see identical behavior to every prior
 * round); AC=0 -> use PRMODE's mirrored attribute bits instead. */
#define GS_REG_PRMODECONT 0x1A
#define GS_REG_PRMODE     0x1B
#define PRIM_ATTR_MASK    0x7F8u /* bits 3-10: IIP,TME,FGE,ABE,AA1,FST,CTXT,FIX */
/* Round 100 (141st finding, task #254 - GS gap follow-up 4/N): TEX2_1/
 * TEX2_2 - real addresses 0x16/0x17 per the official GS Users Manual
 * ("TEX2_1 / TEX2_2 : Texture Information Setting" - "These registers
 * set texture information. They are subsets of the TEX0 register.").
 * TEX2 shares TEX0's exact same PSM/CBP/CPSM/CSM/CSA/CLD bit positions
 * (data_lo bits 20-25 for PSM; data_hi bits 5-31 for CBP/CPSM/CSM/CSA/
 * CLD - see apply_ad_write's existing GS_REG_TEX0_1/2 case) but the
 * manual's own BIT ASSIGN diagram for TEX2 leaves bits 0-19 entirely
 * unlabeled/reserved - i.e. TEX2 has NO TBP0/TBW/TW/TH/TCC/TFX fields
 * of its own at all. Writing TEX2 therefore updates only the CLUT-
 * related subset (PSM/CBP/CPSM/CSA/CLD - CSM is parsed but, like
 * TEX0's own CSM handling, not separately modeled: only CSM1 is
 * supported, per this file's pre-existing TEX0 CLUT scope note),
 * leaving TBP0/TBW/TW/TH/TCC/TFX exactly as the most recent TEX0
 * write left them - the real hardware use case (per the manual) is
 * swapping which CLUT a texture uses without re-specifying its
 * buffer/size/format. */
#define GS_REG_TEX2_1 0x16
#define GS_REG_TEX2_2 0x17
/* Round 101 (142nd finding, task #254 - GS gap follow-up 5/N): COLCLAMP -
 * real address 0x46 per the official GS Users Manual ("COLCLAMP : Color
 * Clamp Control"). A single, shared (not per-context) 1-bit register:
 * CLAMP=1 clamps the final RGB pixel value to [0,255] (this project's
 * pre-existing hardcoded behavior at every color-computation site -
 * see gs_finish_pixel()'s alpha-blend comment, which explicitly flagged
 * this as a known, deliberately un-modeled gap before this round);
 * CLAMP=0 (MASK) instead wraps via the low 8 bits, a real, documented
 * hardware behavior some effects rely on (e.g. intentional color
 * "wraparound" glitch effects). Defaults to CLAMP=1 (colclamp=1,
 * colclamp_configured=0) in gif_init() - the established safety-gate
 * convention, so this is a no-op for every pre-existing test/demo
 * unless it actually writes COLCLAMP. */
#define GS_REG_COLCLAMP 0x46

/* Round 102 (143rd finding, task #254 - GS gap follow-up 6/N): TEXFLUSH
 * (0x3f) / DTHE (0x45) / DIMX (0x44) - real addresses per the official
 * GS Users Manual. TEXFLUSH ("Texture Page Buffer Disabling") is a
 * genuine hardware no-op for this codebase: real hardware caches
 * texture reads in a "texture page buffer" that must be explicitly
 * invalidated after Host/Local or Local/Local transfers write new
 * texture data, but this codebase's gs_sample_texel()/gs_sample_clut()
 * always read directly and freshly from gs_mem on every single texel
 * fetch (no caching layer exists at all) - so there is nothing to
 * flush, and the manual's own "Any data can be written" note confirms
 * real hardware places no constraint on the write value either. DTHE
 * (dithering on/off) and DIMX (the 4x4 dither matrix, 16 signed 3-bit
 * entries, int1:2:0 = range -4..3) implement the manual's own
 * documented formula ("3.6.1 Dithering": Rout=Rin+DIMX[Y%4][X%4], same
 * offset added to R/G/B identically) as the final RGB transform before
 * COLCLAMP, right before the pixel is written to the frame buffer.
 * Neither DTHE nor DIMX is per-context (single shared registers, no
 * _1/_2 suffix). Defaults: dthe=0 ("not performed") and all 16 dimx
 * entries=0 - the established safety-gate convention, so this is a
 * genuine no-op for every pre-existing test/demo unless it actually
 * writes DTHE=1. */
#define GS_REG_TEXFLUSH 0x3F
#define GS_REG_DTHE     0x45
#define GS_REG_DIMX     0x44

/* Round 103 (144th finding, task #254 - GS gap follow-up 7/N): FBA_1/
 * FBA_2 - real addresses 0x4a/0x4b per the official GS Users Manual
 * ("FBA_1 / FBA_2 : Alpha Correction Value" - "The OR of the fixed
 * value set by this register and the most significant bit of the
 * Alpha value of the pixel is written to the frame buffer."). Real
 * formula for RGBA32 mode (this project's only supported framebuffer
 * format): A = As | (FBA<<7) - i.e. FBA=1 forces bit 7 (the MSB) of
 * the written alpha on, regardless of what the fragment's own alpha
 * already was; FBA=0 is a pure pass-through. Per-context (FBA_1 sets
 * Context 1, FBA_2 sets Context 2), applied as the absolute final
 * transform on the alpha channel in gs_finish_pixel() - after alpha
 * blending, after the AFAIL=RGB_ONLY old-alpha-preservation case -
 * since the manual describes this as happening at the moment of the
 * actual frame buffer write, unconditionally. Defaults to fba=0 (not
 * configured) - the established safety-gate convention, so this is a
 * genuine no-op for every pre-existing test/demo unless it actually
 * writes FBA_1/2. */
#define GS_REG_FBA_1 0x4A
#define GS_REG_FBA_2 0x4B

/* Round 104 (145th finding, task #254 - GS gap follow-up 8/N): PABE -
 * real address 0x49 per the official GS Users Manual ("PABE : Alpha
 * Blending Control in Units of Pixels" - "0: Alpha blending is not
 * performed in pixel units. 1: Alpha blending is performed in pixel
 * units."). Real semantics: when PABE=1, alpha blending (normally
 * gated only by PRIM/PRMODE's ABE bit) is additionally gated
 * per-pixel by the fragment's own alpha MSB (bit 7) - blending only
 * actually happens for a pixel whose alpha's MSB is 1; pixels with
 * MSB=0 skip blending entirely (write their fragment color directly)
 * even when ABE is otherwise enabled. PABE=0 (default) means no
 * per-pixel gating - ABE's own bit is the sole condition, exactly as
 * every pre-existing round already implements. Not per-context (a
 * single shared 1-bit field, no _1/_2 suffix per the manual's own bit
 * assignment). Defaults to pabe=0 - the established safety-gate
 * convention, so this is a genuine no-op for every pre-existing
 * test/demo unless it actually writes PABE=1. */
#define GS_REG_PABE 0x49

/* Round 105 (146th finding, task #254 - GS gap follow-up 9/N): TEXCLUT
 * - real address 0x1c per the official GS Users Manual ("TEXCLUT :
 * CLUT Position Specification" - "This register specifies the CLUT
 * position in the buffer when the CLUT storage mode is CSM=1 (CSM2
 * mode). It is disabled when CSM=0 (CSM1 mode)."). Real bit layout:
 * CBW (bits 5:0, CLUT buffer width in units of 64px), COU (bits
 * 11:6, CLUT U offset in units of 16px), COV (bits 21:12, CLUT V
 * offset in units of 1px). This codebase's CLUT support is CSM1-only
 * (see the pre-existing Round 24 scope note and TEX0/TEX2's own CSM
 * handling above) - CSM2's separate "load CLUT from an offset inside
 * an arbitrary texture page buffer" addressing mode is a documented,
 * unsupported gap, so per the manual's own words this register is
 * genuinely inert for every draw this codebase can perform. Parsed
 * and stored (so a real TEXCLUT write is never silently dropped as
 * an unknown register) but intentionally does not feed into
 * gs_sample_clut()'s CSM1-only addressing math - honestly scoped,
 * same convention as GS_REG_TEXFLUSH above. */
#define GS_REG_TEXCLUT 0x1C

/* Round 106 (147th finding, task #254 - GS gap follow-up 10/N):
 * SCANMSK - real address 0x22 per the official GS Users Manual
 * ("SCANMSK : Raster Address Mask Setting" - "This register sets
 * whether drawing is performed only to odd or even row by the row
 * address of the frame buffer... The mask is only effective for
 * drawing primitives."). Real 2-bit MSK field: 00=normal (no
 * masking, this codebase's pre-existing behavior); 01=reserved
 * (treated as normal - the manual gives it no defined meaning);
 * 10=drawing prohibited for pixels with an EVEN Y coordinate;
 * 11=drawing prohibited for pixels with an ODD Y coordinate. Unlike
 * TEXCLUT/TEXA, this has a genuine, directly testable effect: gated
 * via a new scanmsk_allows_y() helper called from gs_finish_pixel()
 * right alongside the existing scissor_test() check, so it applies
 * uniformly across all 4 rasterizers (triangle/sprite/point/line)
 * without needing per-rasterizer changes. Not per-context (single
 * shared 2-bit field, no _1/_2 suffix). Defaults to msk=0 (normal
 * drawing) - the established safety-gate convention, so this is a
 * genuine no-op for every pre-existing test/demo unless it actually
 * writes SCANMSK with MSK=2 or 3. */
#define GS_REG_SCANMSK 0x22

/* Round 107 (148th finding, task #254 - GS gap follow-up 11/N):
 * TEXA - real address 0x3b per the official GS Users Manual ("TEXA :
 * Texture Alpha Value Setting" - "This register sets the Alpha value
 * to be referred to when the Alpha value of the texture is not an
 * 8-bit value."). Real fields: TA0 (bits 7:0, the "As" value used
 * when RGBA16's A=0, or for RGB24 which has no alpha at all), AEM
 * (bit 15, alpha-expansion method - when 1, R=G=B=0 texels are
 * treated as fully transparent regardless of TA0/TA1), TA1 (bits
 * 39:32, the "As" value used when RGBA16's A=1). This register is
 * only ever consulted for texture formats that lack a full 8-bit
 * alpha channel: RGBA16(S) and RGB24. This codebase's texture
 * sampler only supports PSMCT32/PSMT8/PSMT4 (see the pre-existing
 * scope note above) - PSMCT32 carries its own real 8-bit alpha and
 * PSMT8/PSMT4 resolve through a CLUT entry that itself carries real
 * alpha, so TEXA's substitute-alpha logic never has anywhere to
 * apply. RGBA16/RGB24 texture support is a documented, unsupported
 * gap (same as TEX2's CSM2 gap, TEXCLUT's CSM2 gap). Parsed and
 * stored for completeness (so a real TEXA write is never silently
 * dropped as an unknown register) but deliberately not consumed by
 * gs_sample_texel() - same honest no-op convention as TEXFLUSH/
 * TEXCLUT above. */
#define GS_REG_TEXA 0x3B

/* Round 108 (149th finding, task #254 - GS gap follow-up 12/N,
 * FINAL): SIGNAL (0x60) / FINISH (0x61) / LABEL (0x62) - the last 3
 * confirmed-missing GS registers from the 137th finding, closing
 * task #254. Real semantics per the official GS Users Manual:
 *
 * - SIGNAL: "This register generates the SIGNAL event and updates
 *   the value of the SIGLBLID register. The ID field is composed of
 *   32 bits, and SIGLBLID is updated only in the bit position where
 *   the bit value corresponding to IDMSK is 1." Real formula:
 *   SIGLBLID.SIGID = (old_SIGID & ~IDMSK) | (ID & IDMSK).
 * - LABEL: identical masked-update formula, but targets SIGLBLID's
 *   LBLID subfield instead of SIGID.
 * - FINISH: "When the drawing process currently being performed is
 *   completed, this register makes a request for the occurrence of
 *   the FINISH event. Any data can be written." - a genuine no-op
 *   for this codebase, same reasoning as GS_REG_TEXFLUSH above (no
 *   drawing-completion event/interrupt infrastructure exists here to
 *   request against).
 *
 * SIGLBLID itself (real address 0x48, a privileged r/w register per
 * the manual's "7.2. Privileged Registers" section) is modeled here
 * as plain internal state (siglblid_sigid/siglblid_lblid fields,
 * inspectable via gif_get_state() exactly like every other register
 * this codebase tracks) rather than a full readable-by-the-EE
 * register path, since no such privileged-register read mechanism
 * exists anywhere in this codebase yet.
 *
 * Honestly scoped: this implements genuine SIGLBLID storage +
 * masked-update semantics (the actual, observable register-level
 * behavior), but does NOT wire SIGNAL/FINISH/LABEL into the EE/IOP
 * interrupt controller - no GS_CSR/GS_IMR/vsync-style interrupt
 * infrastructure exists in gif.c/gif.h to hook into (confirmed via
 * grep - zero hits for GS_CSR/gs_csr/GS_IMR/gs_imr anywhere in this
 * file), and building that cross-subsystem delivery path is a
 * substantially larger undertaking than the GS-local-state modeling
 * this round is scoped to (consistent with how VSYNC interrupt
 * delivery already lives in a separate subsystem - ee_timers.c/
 * ee_intc.c - rather than in gif.c itself, per Round 87's earlier
 * work). */
#define GS_REG_SIGNAL 0x60
#define GS_REG_FINISH 0x61
#define GS_REG_LABEL  0x62

/* Round 98 (139th finding, task #254, GS gap follow-up 2/N): CLAMP_1/2
 * (real texture wrap-mode registers) - addresses cross-checked against
 * the official GS Users Manual's "7.3 Register List in Address Order"
 * (0x08=CLAMP_1, 0x09=CLAMP_2). Previously entirely unmodeled (flagged
 * since Round 28: "CLAMP/TEX2/SCISSOR/FBA remain entirely unmodeled",
 * confirmed again in Round 96's manual audit). */
#define GS_REG_CLAMP_1    0x08
#define GS_REG_CLAMP_2    0x09

/* CLAMP's WMS/WMT wrap-mode field values (real hardware, manual's own
 * "FIELD" table) - REPEAT wraps via bitmask (real hardware requires
 * power-of-2 texture sizes, matching this project's existing TW/TH
 * log2-size fields); CLAMP clamps to [0, size-1]; REGION_CLAMP clamps
 * to an explicit [MINU,MAXU]/[MINV,MAXV] sub-rectangle; REGION_REPEAT
 * masks with MINU/MINV (UMSK/VMSK) then ORs in MAXU/MAXV (UFIX/VFIX). */
#define GS_CLAMP_REPEAT        0u
#define GS_CLAMP_CLAMP         1u
#define GS_CLAMP_REGION_CLAMP  2u
#define GS_CLAMP_REGION_REPEAT 3u

/* TEX1's MMIN field (3 bits) - real hardware distinguishes several
 * NEAREST/LINEAR x MIPMAP_NEAREST/MIPMAP_LINEAR combinations (values
 * 0-5); this project does not implement trilinear/bilinear filtering
 * at all (nearest-neighbor sampling only, an existing, established
 * limitation - see gif.h's top-of-file scope comment), so the only
 * distinction this round actually needs is "mipmapping engaged or
 * not": MMIN 0-1 = no mipmap (real values NEAREST/LINEAR), MMIN 2-5 =
 * mipmap engaged (some NEAREST_MIPMAP_x/LINEAR_MIPMAP_x combination -
 * this round does not distinguish between them further, since single-
 * level nearest selection is used regardless of which one is set, a
 * deliberate simplification consistent with not modeling trilinear
 * blending). */
#define GS_MMIN_MIPMAP_THRESHOLD 2u /* MMIN >= this value means "mipmapping is engaged" */

#define GS_REG_BITBLTBUF  0x50
#define GS_REG_TRXPOS     0x51
#define GS_REG_TRXREG     0x52
#define GS_REG_HWREG 0x54
#define GS_REG_TRXDIR     0x53

#define TRXDIR_HOST_TO_LOCAL  0u
#define TRXDIR_LOCAL_TO_HOST  1u
#define TRXDIR_LOCAL_TO_LOCAL 2u
#define TRXDIR_OFF            3u

/* POINT/LINE/LINE_STRIP (task: "GS coverage breadth", item 5) -
 * cross-checked against a live fetch of PCSX2's GS/GSRegs.h `enum
 * GS_PRIM` (GS_POINTLIST=0, GS_LINELIST=1, GS_LINESTRIP=2,
 * GS_TRIANGLELIST=3, ...) - these are real 3-bit PRIM.PRIM hardware
 * field values, not emulator convention. */
#define PRIM_TYPE_POINT          0
#define PRIM_TYPE_LINE           1
#define PRIM_TYPE_LINE_STRIP     2
#define PRIM_TYPE_TRIANGLE       3
#define PRIM_TYPE_TRIANGLE_STRIP 4
#define PRIM_TYPE_TRIANGLE_FAN   5
#define PRIM_TYPE_SPRITE         6

/* PRIM bit 3 (IIP): 0 = flat shading, 1 = Gouraud (per-vertex color
 * interpolation). PRIM bit 4 (TME): 0 = untextured (flat/Gouraud
 * color only), 1 = texture-mapped - see gif.c's rasterize_triangle().
 * Both cross-checked against PCSX2's own GS/GSRegs.h GIFRegPRIM
 * bitfield layout. */
#define PRIM_IIP_MASK 0x8u
#define PRIM_TME_MASK 0x10u
/* PRIM bit 8 (FST): 1 = UV fixed-point texel coordinates (this
 * project's original, still-supported mode), 0 = ST+Q floating-point
 * perspective-correct coordinates (task #88) - cross-checked against
 * PCSX2's own GS/GSRegs.h GIFRegPRIM bitfield (PRIM:3,IIP:1,TME:1,
 * FGE:1,ABE:1,AA1:1,FST:1,... - FST is the 7th field, bit offset 8). */
#define PRIM_FST_MASK 0x100u
/* PRIM bit 6 (ABE) - real GIFRegPRIM bitfield: PRIM:3,IIP:1,TME:1,
 * FGE:1,ABE:1,AA1:1,FST:1,CTXT:1,FIX:1 (cross-checked against
 * PCSX2's GS/GSRegs.h). Gates real alpha blending (Round 23, see
 * ALPHA_1 below) - matches this file's existing bit-position-
 * comment style for IIP/TME/FST above. */
#define PRIM_ABE_MASK 0x40u
/* PRIM bit 5 (FGE) - real GIFRegPRIM bitfield (see PRIM_ABE_MASK's own
 * comment for the full field ordering: PRIM:3,IIP:1,TME:1,FGE:1,
 * ABE:1,AA1:1,FST:1,CTXT:1,FIX:1). Gates the Round 97 Fog effect
 * (task #254, 138th finding) - see gs_finish_pixel()'s fog-blend step
 * in gif.c and the GS_REG_FOGCOL/cur_fog comments below. */
#define PRIM_FGE_MASK 0x20u
/* FOGCOL (Round 97, task #254): the "distant fog color" (Rfc,Gfc,Bfc)
 * blended against per-pixel Fog coefficient F, per the official GS
 * Users Manual's "3.5. Fog Effect" formula:
 *   R = F*Rv + (0xff-F)*Rfc  (and likewise G, B; A is left untouched)
 * Real, well-known GS register address (manual's "7.3 Register List
 * in Address Order": 0x3d=FOGCOL). */
#define GS_REG_FOGCOL 0x3D

/* GIFRegTEST bitfield (task #89, extended Round 23) - cross-checked
 * against PCSX2's GS/GSRegs.h GIFRegTEST: ATE:1,ATST:3,AREF:8,
 * AFAIL:2,DATE:1,DATM:1,ZTE:1,ZTST:2 (all in word0; word1 unused).
 * ATE/ATST/AREF/AFAIL (real alpha test) are now modeled (Round 23) -
 * see gs_finish_pixel() in gif.c. DATE/DATM (destination-alpha test,
 * a real but distinct/rarer GS feature used for certain stencil-like
 * tricks) remain unmodeled - a deliberate, separate, still-open gap. */
#define TEST_ATE_MASK    0x1u
#define TEST_ATST_SHIFT  1u
#define TEST_ATST_MASK   0x7u
#define TEST_AREF_SHIFT  4u
#define TEST_AREF_MASK   0xFFu
#define TEST_AFAIL_SHIFT 12u
#define TEST_AFAIL_MASK  0x3u
#define TEST_ZTE_MASK   0x10000u
#define TEST_ZTST_SHIFT 17u
#define TEST_ZTST_MASK  0x3u

/* GS_ZTST enum - cross-checked against PCSX2's GS/GSRegs.h GS_ZTST
 * (real, literal hardware semantics: NEVER = every fragment fails,
 * ALWAYS = every fragment passes regardless of Z, GEQUAL/GREATER =
 * compare the new fragment's Z against the value already stored in
 * the Z buffer). */
#define GS_ZTST_NEVER   0u
#define GS_ZTST_ALWAYS  1u
#define GS_ZTST_GEQUAL  2u
#define GS_ZTST_GREATER 3u

/* GS_ATST enum (Round 23) - cross-checked against PCSX2's GS/GSRegs.h
 * GS_ATST: real, literal per-fragment alpha-value compare modes
 * against the 8-bit AREF reference value. */
#define GS_ATST_NEVER    0u
#define GS_ATST_ALWAYS   1u
#define GS_ATST_LESS     2u
#define GS_ATST_LEQUAL   3u
#define GS_ATST_EQUAL    4u
#define GS_ATST_GEQUAL   5u
#define GS_ATST_GREATER  6u
#define GS_ATST_NOTEQUAL 7u

/* GS_AFAIL enum (Round 23) - cross-checked against PCSX2's GS/
 * GSRegs.h GS_AFAIL: what happens to a fragment that FAILS the
 * alpha test above. KEEP discards the fragment entirely (no color,
 * no Z write); FB_ONLY still writes color but suppresses the Z
 * write; ZB_ONLY still writes Z but suppresses the color write;
 * RGB_ONLY writes RGB but preserves the framebuffer's OLD alpha byte
 * (real hardware detail: on a genuine 32-bit-alpha target, which is
 * the only format this project's simplified gs_mem models anyway -
 * see gs_mem.h - so the real "downgrade to FB_ONLY for non-32bit
 * formats" special case PCSX2 documents never applies here). */
#define GS_AFAIL_KEEP     0u
#define GS_AFAIL_FB_ONLY  1u
#define GS_AFAIL_ZB_ONLY  2u
#define GS_AFAIL_RGB_ONLY 3u

/* GIFRegALPHA bitfield (Round 23) - cross-checked against PCSX2's
 * GS/GSRegs.h GIFRegALPHA: A:2,B:2,C:2,D:2 (word0 low byte), FIX:8
 * (word0's top byte, bits 32-39 of the 64-bit register - i.e. byte 4
 * of the 8-byte register). A/B/D select a COLOR input for the blend
 * equation (0=Cs source/fragment color, 1=Cd destination/framebuffer
 * color, 2=black/zero); C selects the blend COEFFICIENT (0=As source
 * alpha, 1=Ad destination alpha, 2=Af, the fixed FIX value). Real
 * blend equation (see gs_finish_pixel() in gif.c): Color = ((A-B)*C)
 * >>7 + D - a plain truncating shift, no rounding bias, cross-checked
 * against PCSX2's GSDrawScanline.cpp AlphaBlend path. The written
 * alpha channel is always the fragment's own source alpha (As) -
 * blending only ever affects RGB on real hardware. */
#define ALPHA_A_SHIFT 0u
#define ALPHA_B_SHIFT 2u
#define ALPHA_C_SHIFT 4u
#define ALPHA_D_SHIFT 6u
#define ALPHA_ABCD_MASK 0x3u
/* FIX occupies bits 32-39 of the 64-bit register, i.e. the LOW byte
 * of word1 (this project's "data_hi" 32-bit half in apply_ad_write) -
 * extracted as `data_hi & ALPHA_FIX_MASK` directly, no shift needed
 * (see apply_ad_write's GS_REG_ALPHA_1 case in gif.c). */
#define ALPHA_FIX_MASK  0xFFu
#define GS_ALPHA_CS 0u
#define GS_ALPHA_CD 1u
#define GS_ALPHA_ZERO 2u
#define GS_ALPHA_AS 0u
#define GS_ALPHA_AD 1u
#define GS_ALPHA_AFIX 2u

/* TEX0's four TFX modes; arithmetic follows the provided PCSX2
 * GSDrawScanline.cpp AlphaTFX/ColorTFX reference. */
#define TEX_TFX_MODULATE  0u
#define TEX_TFX_DECAL     1u
#define TEX_TFX_HIGHLIGHT 2u
#define TEX_TFX_HIGHLIGHT2 3u

/* TEX0's PSM field (6 bits, word0 bits 20-25) - real GS pixel storage
 * mode enum values (well-known, widely-published PS2 GS constants -
 * cross-referenced against this project's prior TEX0/FRAME/ZBUF work
 * and general PS2 GS documentation; this round's live source-fetch
 * research pass hit a session limit before it could run, so these
 * are sourced from established knowledge rather than a fresh citation
 * trail - flagged here per this project's citation-honesty policy).
 * This project's gs_mem is PSMCT32-storage-only (see gs_mem.h), so
 * only PSMCT32/PSMT8/PSMT4 are actually supported by the sampler
 * below; the other real values are listed for documentation and to
 * make an unsupported-PSM texture fail loudly (falls back to
 * PSMCT32 sampling) rather than silently - a deliberate, documented
 * gap, not a claim of full PSM coverage. */
#define TEX_PSM_PSMCT32  0x00u
#define TEX_PSM_PSMCT24  0x01u
#define TEX_PSM_PSMCT16  0x02u
#define TEX_PSM_PSMCT16S 0x0Au
#define TEX_PSM_PSMT8    0x13u
#define TEX_PSM_PSMT4    0x14u
#define TEX_PSM_PSMT8H   0x1Bu
#define TEX_PSM_PSMT4HL  0x24u
#define TEX_PSM_PSMT4HH  0x2Cu

/* CLUT geometry constants (Round 24, CLUT/paletted textures). Real
 * hardware's CSM1 CLUT storage addresses palette entries in units of
 * 16 ("CSA units") regardless of whether the texture is PSMT8 (256
 * entries = 16 CSA units) or PSMT4 (16 entries = 1 CSA unit, letting
 * up to 32 different 4-bit palettes share the same CLUT storage
 * region at different CSA offsets). This project models the CLUT as
 * its own small gs_mem region addressed via the existing bp/bw
 * convention, with a fixed row width of 16 entries/row
 * (CLUT_ROW_WIDTH) - consistent with the real 16-entries-per-CSA-unit
 * granularity. Only CPSM=PSMCT32 (32-bit RGBA CLUT entries) is
 * supported - CPSM=PSMCT16/PSMCT16S (16-bit CLUT entries) is a
 * documented, unsupported gap (this project's gs_mem has no PSMCT16
 * storage format at all, see gs_mem.h). */
#define CLUT_ROW_WIDTH   16u
#define CLUT_CSA_UNIT    16u

void gif_init(void);
/* GS->EE readback FIFO used by VIF1 reverse DMA (BUSDIR=1). */
uint32_t gif_read_local_fifo(uint8_t *out, uint32_t qwc);
uint64_t gif_local_host_stat(unsigned which);


/* Real GIF hardware transfer-path identifiers (APATH source paths).
 * Values match PCSX2's own 0-indexed GIF_PATH enum (Gif_Unit.h)
 * exactly, on purpose: DMA_CHANNEL_GIF (dma.h, =2) then already
 * equals GIF_PATH_3 below with no translation needed, because the
 * GIF DMA channel is, by hardware definition, always real PATH3
 * (GS packet data arriving via the DMAC rather than via VIF1 DIRECT/
 * DIRECTHL forwarding or a VU1 XGKICK). See Gif.h's GIF_TRANSFER_TYPE
 * comment ("lower byte contains path minus 1") for the same
 * convention in PCSX2's own transfer-type enum. */
#define GIF_PATH_1 0u /* VU1 XGKICK; log indices are zero based (0=PATH1,1=PATH2,2=PATH3). */
#define GIF_PATH_2 1u /* VIF1 DIRECT/DIRECTHL forwarding - see vif.c's VIF_CMD_DIRECT/DIRECTHL case */
#define GIF_PATH_3 2u /* GIF DMA channel (=DMA_CHANNEL_GIF) - real disc/DMA GS packet delivery */

/* Real GIF register block addresses (PCSX2's GIFregisters struct,
 * Gif.h - each field padded to a 0x10-byte stride from base
 * 0x10003000, matching real hardware's MMIO layout exactly). */
#define GIF_CTRL_ADDR  0x10003000u
#define GIF_MODE_ADDR  0x10003010u
#define GIF_STAT_ADDR  0x10003020u
#define GIF_TAG0_ADDR  0x10003040u
#define GIF_TAG1_ADDR  0x10003050u
#define GIF_TAG2_ADDR  0x10003060u
#define GIF_TAG3_ADDR  0x10003070u
#define GIF_CNT_ADDR   0x10003080u
#define GIF_P3CNT_ADDR 0x10003090u
#define GIF_P3TAG_ADDR 0x100030A0u

/* Matches dma_sink_fn - register with dma_set_sink(DMA_CHANNEL_GIF, gif_process_quadwords).
 * `channel` is a real GIF_PATH_1/2/3 value (see above), NOT an
 * arbitrary/ignored token - it selects which real APATH register
 * state (GIF_TAG0-3/CNT, and for PATH3 only, also P3CNT/P3TAG) gets
 * updated by the tag this call parses. Round 542: previously this
 * parameter was accepted but completely unused (`(void)channel;`) -
 * now it drives the real transfer-arbitration register model added
 * this round (see gif_mmio_read32/write32 below). */
void gif_process_quadwords(int channel, const uint8_t *data, uint32_t qwc);
/* Complete bounded synchronous VU1 XGKICK, not a DMA fragment. */
void gif_process_xgkick(const uint8_t *data, uint32_t qwc);
/* Fragment calls preserve PATH1 state until the bounded kick ends. */
void gif_begin_xgkick(void);
void gif_process_xgkick_fragment(const uint8_t *data, uint32_t qwc);
void gif_end_xgkick(void);

/* Real GIF MMIO register read/write, for wiring into the EE bus
 * dispatch chain (ee_core.c's ee_mem_read32/write32), same pattern
 * as dma_mmio_read32/write32 etc. Returns 1 if addr was a real GIF
 * register (value written to *out_val / consumed from val), 0 if
 * addr is outside the GIF register block (caller should fall
 * through to the next handler in the chain). */
int gif_mmio_read32(uint32_t addr, uint32_t *out_val);
int gif_mmio_write32(uint32_t addr, uint32_t val);

typedef struct {
    uint32_t remaining,index,nreg,mode,regs_lo,regs_hi,eop;
} gif_register_carry_t;

/* Exposed for tests: current parser state. */
typedef struct {
    uint32_t prim;         /* current PRIM register value (bits 0-2 = primitive type) */
    uint32_t rgba;         /* current color, packed as 0xAABBGGRR (matches gs_mem convention) */
    uint32_t fbp, fbw;      /* current draw target, in OUR gs_mem bp/bw convention (see gs_mem.h) */
    uint32_t xyoffset_x, xyoffset_y; /* raw 12.4 fixed-point offset (real units) */

    /* Current TEX0 texture: TBP0 in 256-byte blocks, TBW in pixels;
     * native VRAM addressing and indexed palette sampling are modeled. */
    uint32_t tex_tbp0, tex_tbw;
    uint32_t tex_tfx;
    /* TEX0's TW/TH fields (log2 texture width/height, real hardware
     * bitfield - TW is 4 bits within word0 alone (bits 26-29); TH is
     * a 4-bit field that straddles the 64-bit register's word
     * boundary (2 bits from word0's top, bits 30-31, plus 2 bits from
     * word1's bottom, bits 0-1) - cross-checked against PCSX2's own
     * GS/GSRegs.h GIFRegTEX0's union of two overlapping bitfield
     * layouts. Needed (added task #88) to scale normalized ST+Q
     * texture coordinates (0.0-1.0 range) into texel space - UV mode
     * (FST=1) doesn't need these, since UV is already in texel units. */
    uint32_t tex_tw, tex_th;

    /* PSM/CLUT fields (Round 24, CLUT/paletted textures). tex_psm is
     * TEX0's real 6-bit PSM field (see TEX_PSM_* above) - only
     * PSMT8/PSMT4 engage the CLUT path below, anything else
     * (including the PSMCT32 default) uses the pre-existing direct
     * gs_mem sample. tex_cbp/tex_cpsm/tex_csa/tex_cld are TEX0's
     * CLUT fields - cbp is used directly as OUR gs_mem bp convention
     * for the CLUT's storage location (exactly like tex_tbp0 for the
     * texture itself); cpsm is checked but only PSMCT32 (0) is
     * actually supported (see CLUT_ROW_WIDTH's comment); csa selects
     * a 16-entry-unit offset within the CLUT storage; cld (CLUT load
     * control) is parsed but not acted on - this emulator has no
     * CLUT cache to manage, so every texture sample simply re-reads
     * the CLUT fresh from gs_mem each time, which is always correct
     * (just not a claim of matching real hardware's CLUT-cache
     * timing/behavior). */
    uint32_t tex_psm;
    uint32_t tex_cbp, tex_cpsm, tex_csa, tex_cld;

    /* BETA12.9: both source and destination transfer registers.
     * Host-to-local IMAGE uses the existing destination cursor;
     * local-to-local TRXDIR=2 executes a synchronous GS memory move. */
    uint32_t trx_sbp, trx_sbw, trx_spsm;
    uint32_t trx_ssax, trx_ssay, trx_dirx, trx_diry;
    uint32_t trx_dbp, trx_dbw, trx_dpsm;
    uint32_t trx_dsax, trx_dsay;
    uint32_t trx_rrw, trx_rrh;
    uint32_t trx_xdir;
    int trx_active;
    uint32_t trx_cur_x, trx_cur_y;
    uint32_t trx_partial_pixel, trx_partial_bytes;

    /* Diagnostic view of the current path's remaining IMAGE qwords.
     * The three image_carry_path counters retain full 15-bit NLOOP spans,
     * including padding after a target rectangle has completed. */
    uint32_t image_carry_remaining_qwords;

    /* Z-buffer / depth-test state (task #89). zbp is the Z buffer's
     * base pointer, in OUR gs_mem bp convention (see gs_mem.h) - real
     * hardware's ZBUF register (GIFRegZBUF: ZBP:9, PSM:6, ZMSK:1) has
     * NO separate width field, matching this model, which reuses fbw
     * for Z-buffer addressing too. zbuf_configured is this project's
     * OWN safety gate (not a real hardware concept): it stays 0 until
     * an explicit ZBUF_1 A+D write happens, so that pre-existing tests/
     * demos that never configure a Z buffer keep drawing exactly as
     * before (zbp defaults to 0, same as fbp's own default - without
     * this gate, an unconfigured Z buffer would silently alias and
     * corrupt the color buffer). zte/ztst mirror TEST_1's real ZTE/
     * ZTST fields (see TEST_ZTE_MASK/TEST_ZTST_* above). PSM/CLUT-
     * equivalent Z formats (PSMZ32/24/16) are not modeled - Z is
     * always stored as a plain 32-bit word via gs_mem's existing
     * PSMCT32-shaped helpers, matching gs_mem.h's own documented
     * linear-addressing simplification. */
    uint32_t zbp;
    int zmsk;
    int zbuf_configured;
    int zte;
    int ztst;

    /* Real alpha test (Round 23) - TEST_1's ATE/ATST/AREF/AFAIL
     * fields, see TEST_ATE_MASK/etc and GS_ATST_xxx && GS_AFAIL_xxx constants above. */
    int ate;
    int atst;
    uint32_t aref;
    int afail;

    /* Real alpha blending (Round 23) - ALPHA_1's A/B/C/D/FIX fields,
     * see ALPHA_*_SHIFT/GS_ALPHA_* above. Gated at draw time by
     * PRIM's own ABE bit (PRIM_ABE_MASK), matching real hardware
     * (the ALPHA register's values are latched independently of
     * whether blending is currently enabled - only PRIM.ABE decides
     * whether they're actually used for a given draw). */
    uint32_t alpha_a, alpha_b, alpha_c, alpha_d;
    uint32_t alpha_fix;

    /* Round 96: SCISSOR_1/2 - real scissoring/clip rectangle, per
     * GS Users Manual "SCISSOR_1/SCISSOR_2: Setting for Scissoring
     * Area": SCAX0/SCAY0 = upper-left, SCAX1/SCAY1 = lower-right,
     * inclusive, in the same window coordinate system as XYZ2's
     * screen coordinates (i.e. directly comparable to this
     * project's own rasterizer x/y values, no extra scaling).
     * scissor_configured follows the same established "safety
     * gate" pattern as zbuf_configured above: real hardware
     * defaults SCISSOR to (0,0)-(0,0) (which would clip away
     * everything), but this project defaults to "not configured =
     * no clipping applied" so every pre-existing test/demo that
     * never writes SCISSOR keeps drawing exactly as before. */
    uint32_t scissor_x0, scissor_x1, scissor_y0, scissor_y1;
    int scissor_configured;

    /* Round 27: GS Context 2 (dual-context support) - see
     * PRIM_CTXT_MASK/GS_REG_FRAME_2/etc above for the register-
     * address side. The flat fields above (fbp, fbw, xyoffset_x/y,
     * tex_tbp0, tex_tbw, tex_tfx, tex_tw, tex_th, tex_psm, tex_cbp,
     * tex_cpsm, tex_csa, tex_cld, zbp, zmsk, zbuf_configured, zte,
     * ztst, ate, atst, aref, afail, alpha_a/b/c/d, alpha_fix) now
     * serve as the CURRENTLY ACTIVE context's view - refreshed by
     * gs_activate_context() (called at the top of each rasterizer,
     * right before a primitive is actually drawn) from whichever of
     * the two permanent per-context storage banks below PRIM's CTXT
     * bit currently selects. Every A+D write to a _1 register (e.g.
     * FRAME_1) updates BOTH the matching ctx1_xxx permanent field AND
     * the flat field directly (so code that reads the flat fields
     * immediately after a register write, without an intervening
     * primitive draw - as several pre-existing tests do - keeps
     * seeing correct, unchanged behavior); a _2 register write (e.g.
     * FRAME_2) updates ONLY the ctx2_xxx permanent field, since
     * context 2 only becomes "live" in the flat fields once a
     * primitive is actually drawn with PRIM.CTXT=1 selected. This
     * design deliberately avoids touching gs_finish_pixel()/
     * gs_sample_texel()/gs_sample_clut()'s existing internals at all
     * (they keep reading the flat fields exactly as before this
     * round) - only apply_ad_write() (new _2 cases + mirroring the
     * _1 cases) and the 4 rasterizers (one new gs_activate_context()
     * call each, at the very top) change. */
    uint32_t ctx1_fbp, ctx1_fbw;
    uint32_t ctx1_xyoffset_x, ctx1_xyoffset_y;
    uint32_t ctx1_tex_tbp0, ctx1_tex_tbw, ctx1_tex_tfx, ctx1_tex_tw, ctx1_tex_th;
    uint32_t ctx1_tex_psm, ctx1_tex_cbp, ctx1_tex_cpsm, ctx1_tex_csa, ctx1_tex_cld;
    uint32_t ctx1_zbp;
    int ctx1_zmsk, ctx1_zbuf_configured, ctx1_zte, ctx1_ztst;
    int ctx1_ate, ctx1_atst, ctx1_afail;
    uint32_t ctx1_aref;
    uint32_t ctx1_alpha_a, ctx1_alpha_b, ctx1_alpha_c, ctx1_alpha_d, ctx1_alpha_fix;
    uint32_t ctx1_scissor_x0, ctx1_scissor_x1, ctx1_scissor_y0, ctx1_scissor_y1;
    int ctx1_scissor_configured;

    uint32_t ctx2_fbp, ctx2_fbw;
    uint32_t ctx2_xyoffset_x, ctx2_xyoffset_y;
    uint32_t ctx2_tex_tbp0, ctx2_tex_tbw, ctx2_tex_tfx, ctx2_tex_tw, ctx2_tex_th;
    uint32_t ctx2_tex_psm, ctx2_tex_cbp, ctx2_tex_cpsm, ctx2_tex_csa, ctx2_tex_cld;
    uint32_t ctx2_zbp;
    int ctx2_zmsk, ctx2_zbuf_configured, ctx2_zte, ctx2_ztst;
    int ctx2_ate, ctx2_atst, ctx2_afail;
    uint32_t ctx2_aref;
    uint32_t ctx2_alpha_a, ctx2_alpha_b, ctx2_alpha_c, ctx2_alpha_d, ctx2_alpha_fix;
    uint32_t ctx2_scissor_x0, ctx2_scissor_x1, ctx2_scissor_y0, ctx2_scissor_y1;
    int ctx2_scissor_configured;

    /* Round 28: mipmaps (TEX1 + MIPTBP1/MIPTBP2) - see
     * GS_REG_TEX1_1/MIPTBP1_1/MIPTBP2_1's header comment for the
     * field-layout scope note. TEX1's fields: tex1_lcm (LOD
     * Calculation Method: 0=computed from texture/screen size ratio,
     * 1=fixed from K), tex1_mxl (Max LOD level, 0-6), tex1_mmag/
     * tex1_mmin (real filter mode fields - only tex1_mmin is actually
     * used, to decide whether mipmapping is engaged at all, per
     * GS_MMIN_MIPMAP_THRESHOLD's comment), tex1_mtba (Mipmap Texture
     * Base Auto - only MTBA=0, explicit MIPTBP1/2 lookup, is
     * implemented; MTBA=1's automatic per-level address formula is a
     * documented, unimplemented gap - falls back to level 0 always),
     * tex1_l (parsed and stored but NOT applied to the LOD formula
     * this round - a documented, explicit simplification, not a
     * fabricated formula detail), tex1_k (signed 12-bit LOD bias,
     * 1/16 units - applied when tex1_lcm=1). tex_mip_tbp/tex_mip_tbw
     * hold levels 1-6's base pointer/width (index 0 = level 1, index
     * 5 = level 6), parsed from MIPTBP1_1 (levels 1-3) and
     * MIPTBP2_1 (levels 4-6) - level 0 itself continues to use the
     * existing tex_tbp0/tex_tbw fields, unchanged. These are the
     * "flat/active" fields gs_activate_context() refreshes at the top
     * of each rasterizer (Round 29 continued, 15th change) from
     * whichever of ctx1_tex1_xxx/ctx2_tex1_xxx below PRIM's CTXT bit
     * currently selects - same pattern as fbp/tex_tbp0/alpha_a/etc. */
    int tex1_lcm;
    uint32_t tex1_mxl;
    int tex1_mmag;
    uint32_t tex1_mmin;
    int tex1_mtba;
    uint32_t tex1_l;
    int32_t tex1_k;
    uint32_t tex_mip_tbp[6], tex_mip_tbw[6];

    /* Round 29 continued (15th change): per-context permanent storage
     * for the TEX1/MIPTBP fields above - see this file's
     * GS_REG_TEX1_2/MIPTBP1_2/MIPTBP2_2 comment for the scope. */
    int ctx1_tex1_lcm;
    uint32_t ctx1_tex1_mxl;
    int ctx1_tex1_mmag;
    uint32_t ctx1_tex1_mmin;
    int ctx1_tex1_mtba;
    uint32_t ctx1_tex1_l;
    int32_t ctx1_tex1_k;
    uint32_t ctx1_tex_mip_tbp[6], ctx1_tex_mip_tbw[6];

    int ctx2_tex1_lcm;
    uint32_t ctx2_tex1_mxl;
    int ctx2_tex1_mmag;
    uint32_t ctx2_tex1_mmin;
    int ctx2_tex1_mtba;
    uint32_t ctx2_tex1_l;
    int32_t ctx2_tex1_k;
    uint32_t ctx2_tex_mip_tbp[6], ctx2_tex_mip_tbw[6];

    /* Round 98 (139th finding, task #254): CLAMP_1/2 texture wrap mode
     * - wms/wmt hold the real 2-bit wrap-mode field (GS_CLAMP_* above)
     * for S/T independently; minu/maxu/minv/maxv hold the real 10-bit
     * region parameters (meaning depends on wms/wmt - see GS_CLAMP_*
     * comment). Applied in the texture-sampling step of
     * rasterize_triangle()/rasterize_sprite() (gs_apply_clamp_wrap()
     * in gif.c) - previously coordinates were only naively clamped to
     * 0 on the low side with no real wrap/region semantics at all (see
     * this file's top-of-file scope comment, "No CLAMP register
     * modeling"). Same "flat + per-context, refreshed by
     * gs_activate_context()" pattern as tex1_xxx above. */
    uint32_t clamp_wms, clamp_wmt;
    uint32_t clamp_minu, clamp_maxu, clamp_minv, clamp_maxv;
    /* Safety gate (this project's established convention, same as
     * zbuf_configured/scissor_configured): real hardware defaults
     * WMS/WMT to REPEAT, but this project defaults to "not configured
     * = exactly this codebase's pre-existing behavior" (naive clamp-
     * to-0 on the low side, gs_sample_texel()'s own out-of-range-
     * returns-0 on the high side) so every pre-existing texture test
     * keeps sampling exactly as before this round unless it opts in
     * by actually writing CLAMP_1/2. */
    int clamp_configured;
    /* Round 99: PRMODECONT/PRMODE - see the GS_REG_PRMODECONT/GS_REG_PRMODE
     * comment above. prmodecont_ac defaults to 1 ("use PRIM", the
     * pre-existing behavior) in gif_init() so this is a genuine no-op
     * for every prior round's test/demo unless it actually writes
     * PRMODECONT. Not per-context: real hardware has exactly one
     * PRMODECONT/PRMODE pair, shared across both contexts. */
    uint32_t prmodecont_ac;
    uint32_t prmode;
    /* Round 101 (142nd finding, task #254): COLCLAMP - see the
     * GS_REG_COLCLAMP comment above. Not per-context (single shared
     * register). colclamp defaults to 1 (CLAMP) with colclamp_configured
     * defaulting to 0, matching this project's pre-existing hardcoded
     * clamp-to-[0,255] behavior at every RGB-computation site. */
    uint32_t colclamp;
    int colclamp_configured;
    /* Round 102 (143rd finding, task #254): DTHE/DIMX - see the
     * GS_REG_DTHE/GS_REG_DIMX comment above. Not per-context. dimx is
     * stored as already-sign-extended int32_t values for direct use
     * in the Rout=Rin+DIMX[y%4][x%4] formula. */
    uint32_t dthe;
    int32_t dimx[4][4];
    /* Round 103 (144th finding, task #254): FBA_1/FBA_2 - see the
     * GS_REG_FBA_1/GS_REG_FBA_2 comment above. Per-context, mirrored
     * by gs_activate_context() exactly like every other _1/_2
     * register pair in this struct. fba defaults to 0 (pass-through)
     * with fba_configured defaulting to 0 - safety-gate convention. */
    uint32_t fba;
    int fba_configured;
    uint32_t ctx1_fba;
    int ctx1_fba_configured;
    uint32_t ctx2_fba;
    int ctx2_fba_configured;
    /* Round 104 (145th finding, task #254): PABE - see GS_REG_PABE's
     * comment above. Single 1-bit field, not per-context. Defaults
     * to 0 (no per-pixel gating) - safety gate. */
    uint32_t pabe;
    /* Round 105 (146th finding, task #254): TEXCLUT - see
     * GS_REG_TEXCLUT's comment above. Stored for completeness but
     * intentionally not consumed anywhere (CSM1-only scope, same
     * honest-inert convention as TEXFLUSH). */
    uint32_t texclut_cbw, texclut_cou, texclut_cov;
    /* Round 106 (147th finding, task #254): SCANMSK.MSK (2 bits) -
     * see GS_REG_SCANMSK's comment above. Not per-context. Defaults
     * to 0 (normal drawing, no masking) - safety gate. */
    uint32_t scanmsk;
    /* Round 107 (148th finding, task #254): TEXA - see
     * GS_REG_TEXA's comment above. Stored for completeness but
     * intentionally not consumed anywhere (this codebase's texture
     * sampler is PSMCT32/PSMT8/PSMT4-only, none of which need a
     * substitute alpha - same honest-inert convention as TEXCLUT). */
    uint32_t texa_ta0, texa_aem, texa_ta1;
    /* Round 108 (149th finding, task #254): SIGLBLID storage - see
     * GS_REG_SIGNAL/FINISH/LABEL's comment above. SIGID is updated
     * (masked) by SIGNAL; LBLID is updated (masked) by LABEL.
     * finish_pending counts outstanding FINISH requests purely for
     * test-observability - genuinely inert otherwise, since no
     * drawing-completion tracking/interrupt path consumes it. */
    uint32_t siglblid_sigid, siglblid_lblid;
    uint32_t finish_pending;
    uint32_t ctx1_clamp_wms, ctx1_clamp_wmt;
    uint32_t ctx1_clamp_minu, ctx1_clamp_maxu, ctx1_clamp_minv, ctx1_clamp_maxv;
    int ctx1_clamp_configured;
    uint32_t ctx2_clamp_wms, ctx2_clamp_wmt;
    uint32_t ctx2_clamp_minu, ctx2_clamp_maxu, ctx2_clamp_minv, ctx2_clamp_maxv;
    int ctx2_clamp_configured;

    /* Current UV register value (real hardware's 12.4 fixed-point
     * texel coordinate "FST=1" mode - see gif.h's scope comment),
     * already converted to integer texels exactly like XYZ2's own
     * >>4 conversion. */
    double cur_u, cur_v; /* Exact 10.4 UV decoded to texel units. */

    /* Current ST+Q state (real hardware's "FST=0" perspective-correct
     * mode, task #88): S/T are real IEEE-754 floats (normalized
     * texture-space coordinates, 0.0-1.0 typically), latched by either
     * an A+D ST write (GS_REG_ST - S,T only, no Q) or a PACKED STQ tag
     * (S,T,Q together - not yet implemented as a distinct PACKED
     * register path, see below). Q is a real float too, latched
     * together with RGBAQ on real hardware (GIFRegRGBAQ's layout:
     * R/G/B/A bytes in word0, Q as a float in word1) - cross-checked
     * against PCSX2's own GS/GSRegs.h. */
    float cur_s, cur_t, cur_q;

    /* Round 97 (138th finding, task #254): "current fog value" -
     * exactly the same latch-then-read-at-vertex-kick pattern this
     * file already uses for cur_u/cur_v (UV) and cur_s/cur_t (ST):
     * a standalone FOG register write (GS_REG_FOG, either PACKED tag
     * 0x0a or the A+D address) sets this; the combined XYZF2/XYZF3
     * vertex-kick registers ALSO set it directly from their own
     * embedded F field in PACKED mode (see apply_xyz2_kick() in
     * gif.c). Plain XYZ2/XYZ3 (no F field) leave it unchanged, so a
     * fog value set once persists across subsequent XYZ2-only
     * vertices - real hardware behavior for an internal GS register.
     * Default 0xFF (per the GS Users Manual's "3.5. Fog Effect":
     * F=255 is "the fog effect is at the minimum", i.e. the vertex's
     * own color passes through unmodified) - this project's usual
     * safety-gate convention so pre-existing tests/demos that never
     * touch FOG/XYZF2 keep drawing exactly as before this round even
     * if a future round mistakenly left FGE-gating off somewhere. */
    uint32_t cur_fog;
    /* FOGCOL (Round 97) - packed as R in bits 0-7, G in 8-15, B in
     * 16-23 (alpha byte unused/0), matching this file's existing
     * rgba_pack() channel convention for consistency, even though
     * FOGCOL itself has no alpha field on real hardware. */
    uint32_t fogcol;

    int has_vertex0;
    int32_t v0x, v0y;
    /* SPRITE's first-vertex texture coordinates (task #88 - SPRITE
     * texturing), captured alongside v0x/v0y so rasterize_sprite()
     * can interpolate between the two corners. */
    double v0u, v0v;
    float v0s, v0t, v0q;
    /* SPRITE's first-vertex Z (task #89) - see tri_z's comment
     * below for the same A+D-vs-PACKED scope caveat. */
    uint32_t v0z;
    /* SPRITE's first-vertex Fog coefficient (Round 97, task #254) -
     * latched from cur_fog at the same moment v0z is (see
     * apply_xyz2_kick()'s vertex-kick logic in gif.c). */
    uint32_t v0f;

    /* Triangle vertex accumulation (TRIANGLE/TRIANGLE_STRIP/
     * TRIANGLE_FAN, prim types 3/4/5). tri_vseq counts vertices
     * received since the primitive type last changed (reset on every
     * PRIM write, matching real hardware starting a fresh vertex
     * sequence). tri_x/tri_y/tri_rgba/tri_u/tri_v[0..2] is a rolling
     * buffer of the most recent up to 3 vertices (position + the
     * RGBAQ color + the UV texture coordinate active when that vertex
     * was kicked) - for TRIANGLE_FAN, slot 0 is instead a fixed anchor
     * (never overwritten once set) rather than rolling. tri_rgba
     * enables real per-vertex Gouraud shading (PRIM register bit 3,
     * IIP); tri_u/tri_v enable real per-vertex texture-coordinate
     * interpolation (PRIM register bit 4, TME) - both confirmed
     * against PCSX2's own GS/GSRegs.h GIFRegPRIM layout. */
    int tri_vseq;
    int32_t tri_x[3], tri_y[3];
    uint32_t tri_rgba[3];
    double tri_u[3], tri_v[3];
    /* Per-vertex ST+Q (task #88) - captured alongside tri_u/tri_v at
     * every vertex kick regardless of FST (harmless when unused);
     * rasterize_triangle() picks UV (affine) or ST+Q (perspective-
     * correct) interpolation based on PRIM's real FST bit. */
    float tri_s[3], tri_t[3], tri_q[3];
    /* Per-vertex Z from the real PACKED or 64-bit A+D/REGLIST XYZ value. */
    uint32_t tri_z[3];
    /* Per-vertex Fog coefficient (Round 97, task #254) - latched from
     * cur_fog at every vertex kick, same shape/rolling-window rules
     * as tri_z above; interpolated the same plain-affine barycentric
     * way as Z in rasterize_triangle() (the GS Users Manual's "3.5.
     * Fog Effect" describes F as linearly interpolated per vertex,
     * with no mention of the 1/Q perspective correction ST/UV need -
     * matching Z's own already-post-projection screen-space-linear
     * behavior, not independently re-derived here). */
    uint32_t tri_f[3];

    /* LINE/LINE_STRIP vertex accumulation (task: "GS coverage
     * breadth", item 5) - a 2-slot rolling window, the same shape as
     * TRIANGLE_STRIP's 3-slot one above. line_vseq counts vertices
     * received since PRIM last changed (reset on every PRIM write,
     * same as tri_vseq). Real hardware: LINE draws one segment per
     * PAIR of vertices (no reuse - matches PCSX2's `NumIndicesForPrim`
     * returning 2 for both LINELIST/LINESTRIP); LINE_STRIP instead
     * keeps the most recent vertex as the next segment's start,
     * giving a connected polyline - same "rolling window" shape as
     * TRIANGLE_STRIP, just 2 slots instead of 3. No texture-
     * coordinate fields: real GS hardware does not texture-map
     * POINT/LINE primitives (only SPRITE/TRIANGLE support TME) - not
     * modeled here since there's nothing to model. */
    int line_vseq;
    int32_t line_x[2], line_y[2];
    uint32_t line_rgba[2];
    uint32_t line_z[2];
    /* Per-vertex Fog coefficient (Round 97, task #254) - same rolling
     * 2-slot shape as line_z above. */
    uint32_t line_f[2];

    uint64_t quadwords_seen;
    uint64_t sprites_drawn;
    uint64_t triangles_drawn;
    uint64_t lines_drawn;   /* task: "GS coverage breadth" */
    uint64_t points_drawn;  /* task: "GS coverage breadth" */
    uint64_t unsupported_prims_seen;
    uint64_t pixels_ztest_failed; /* task #89 - counts fragments rejected by the Z test, for test visibility */
    uint64_t pixels_atest_failed; /* Round 23 - counts fragments rejected by the alpha test, for test visibility */

    /* Round 542: real GIF hardware register block (GIF_CTRL/MODE/
     * STAT/TAG0-3/CNT/P3CNT/P3TAG, addresses 0x10003000-0x100030A0 -
     * see Gif.h's tGIF_CTRL/tGIF_MODE/tGIF_STAT/tGIF_TAG0/tGIF_TAG1/
     * tGIF_CNT/tGIF_P3CNT/tGIF_P3TAG unions, fetched verbatim from
     * PCSX2's own source this round). gif_ctrl/gif_mode store exactly
     * what software last wrote (RST is a self-clearing action, not
     * stored - see gif_mmio_write32()). gif_stat is NOT independently
     * stored: per real hardware (and PCSX2's Gif_Unit::Execute()/
     * CanDoPath1/2/3(), read this round), STAT's dynamic bits
     * (APATH/OPH/DIR/IP3/P1Q/P2Q/P3Q/FQC) are live outputs of the
     * transfer-arbitration engine, not readable/writable storage -
     * gif_mmio_read32() derives GIF_STAT's static bits (M3R/IMT
     * mirror MODE, PSE mirrors CTRL) on the fly instead. M3P (VIF1's
     * own PATH3-mask-request bit) is an honest, documented gap: this
     * project's VIF1 model (vif.c) doesn't yet track a mask request
     * separately from the MSKPATH3 register, so M3P always reads 0 -
     * not fabricated, matches the real idle/no-mask-pending state.
     * The dynamic APATH/OPH/DIR/IP3/PxQ/FQC bits all read 0 too: this
     * project's transfers complete synchronously/atomically within a
     * single gif_process_quadwords() call (no queued/in-flight state
     * ever persists across calls), so "idle, nothing in flight" (all
     * zero) is the real, correct value at every point software could
     * observe it - not a shortcut. */
    uint32_t gif_ctrl;   /* GIF_CTRL: only PSE (bit 3) is retained; RST (bit 0) is a self-clearing action */
    uint32_t gif_mode;   /* GIF_MODE: M3R (bit 0), IMT (bit 2) */
    /* GIF_TAG0-3: raw snapshot of the last GIF tag parsed on ANY
     * path (real hardware: one shared tag-latch register set, not
     * per-path - see Gif.h, only P3TAG/P3CNT below are PATH3-
     * specific shadow copies). */
    uint32_t gif_tag0, gif_tag1, gif_tag2, gif_tag3;
    uint32_t gif_cnt;    /* GIF_CNT: LOOPCNT (last tag's NLOOP) / REGCNT (last tag's NREG) / VUADDR (always 0 - real hardware tracks VU1 micromem write offset during an in-flight PATH1 transfer; this project's transfers complete synchronously within one gif_process_quadwords() call, so there is never an in-flight offset to report - see gif_path1_transfers below for the real, non-simplified way to observe PATH1 activity) */
    /* GIF_P3CNT/GIF_P3TAG: PATH3-specific shadow of LOOPCNT/EOP, only
     * updated when the parsed tag arrived via GIF_PATH_3 (real
     * hardware: these two registers exist specifically to let
     * software monitor PATH3 progress independent of whatever else
     * is using the shared tag latch - see Gif.h's tGIF_P3CNT/
     * tGIF_P3TAG comments). */
    uint32_t gif_p3cnt, gif_p3tag;

    /* Round 641 (task #536): internal (non-hardware-register) flag -
     * mirrors the EOP (End Of Packet) bit of the most recently parsed
     * GIF tag, on ANY path. Real hardware terminates a PATH1/2/3
     * transfer at the first tag with EOP=1, regardless of how much
     * more buffer/qwc the caller made available - see Gif.h's
     * tGIF_TAG0::EOP and PCSX2's own GIF unit transfer loop, which
     * checks tag.EOP after every packet. Added because vu.c's XGKICK
     * handler (Round 571) intentionally passes a generous upper-bound
     * qwc (everything from the kick address to the end of VU1 local
     * memory - real hardware doesn't know the real length in advance
     * either) and relies on the GIF-side parser to stop at the real
     * transfer's actual end. Before this round, gif_process_quadwords()
     * had no such stop condition and kept parsing tag after tag
     * through whatever unrelated/stale data happened to sit in VU1
     * memory past the real transfer's end, corrupting later register
     * writes (see docs/STATUS.md Round 641 for the full writeup). */
    uint32_t gif_last_eop;

    /* Round 577 (task #551): real diagnostic counter, not a hardware
     * register - counts every gif_process_quadwords(GIF_PATH_1, ...)
     * call (i.e. every real VU1 XGKICK that actually reached the GIF,
     * per Round 571's vu.c implementation). Added specifically so
     * host-native survey drivers can tell, without extra scratch
     * instrumentation, whether a given boot/run window ever issued a
     * real XGKICK - see tools/round577-tekken-discboot/driver.c. */
    uint64_t gif_path1_transfers;
    uint32_t zpsm, ctx1_zpsm, ctx2_zpsm;
    uint32_t image_carry_path[3];
    uint32_t tex_tcc, ctx1_tex_tcc, ctx2_tex_tcc;
    gif_register_carry_t register_carry_path[3];
    uint32_t tex_csm, ctx1_tex_csm, ctx2_tex_csm;
    uint32_t clut_cbp0, clut_cbp1, clut_cache[512];
    /* FRAME write protection and framebuffer storage format. */
    uint32_t fbmask, ctx1_fbmask, ctx2_fbmask;
    uint32_t frame_psm, ctx1_frame_psm, ctx2_frame_psm;
    /* R1297: first SPRITE vertex before fractional coordinate loss.
     * Appended for backward-compatible checkpoint restoration. */
    uint64_t sprite_pos16;
    /* Appended to preserve existing diagnostic/fixture offsets. */
    int date, datm, ctx1_date, ctx1_datm, ctx2_date, ctx2_datm;
    /* Appended so older GIF checkpoint field offsets remain stable. */
    uint8_t image_eop_path[3];
    uint8_t arb_owner,arb_eop[3],arb_pending,arb_m3p;
    uint8_t fifo[16][16],fifo_head,fifo_count;
    /* GIF temporary Q: low IEEE-754 word, separate from GS RGBAQ.Q.
     * uint64 alignment appends after the complete legacy checkpoint prefix. */
    uint64_t gif_q_bits;
    /* Shared temporary CLUT halfwords; upper room bounds offset I8 loads.
     * clut_cache remains the legacy checkpoint/injection view. A real load
     * makes these words authoritative across CPSM changes without reload. */
    uint16_t clut_words[1024];
    uint32_t clut_words_valid,clut_write_csm;
} gif_state_t;

gif_state_t *gif_get_state(void);
/* Per-draw overlapping state reasons 0..9; cached sprites=10, fast rows=11. */
uint64_t gif_get_render_work(unsigned index);

/* R1330-K: triangle/Gouraud accounting.  Every counter is incremented once per
 * rasterize_triangle() call and the groups below are mutually exclusive:
 *   submitted == degenerate + offscreen + visible          (IIP triangles)
 *   visible   == gx + software                              (IIP triangles)
 *   software  == sum(GIF_GFB_*)                             (first blocking reason)
 * "degenerate" means integer-pixel edge() area == 0 (the software rasterizer
 * draws nothing).  "offscreen" means non-degenerate but the scissor/clip box is
 * empty.  GX acceptance means the triangle was handled by a GX path; CPU work
 * that still remains for that triangle is reported in the GIF_GCPU_* group. */
enum {
    GIF_GOURAUD_SUBMITTED=0, GIF_GOURAUD_DEGENERATE, GIF_GOURAUD_OFFSCREEN,
    GIF_GOURAUD_VISIBLE, GIF_GOURAUD_GX, GIF_GOURAUD_SOFTWARE,
    GIF_GOURAUD_DEG_IDENTICAL3, GIF_GOURAUD_DEG_TWO_SAME, GIF_GOURAUD_DEG_COLLINEAR,
    GIF_GOURAUD_DEG_ORIGIN,         /* degenerate and every vertex x,y == 0,0 */
    GIF_GOURAUD_FLAT_SUBMITTED,     /* non-IIP triangles, for context */
    GIF_GOURAUD_FLAT_DEGENERATE,
    GIF_GOURAUD_SW_BBOX_PIXELS,     /* sum of clipped bbox pixels left in software */
    GIF_GOURAUD_GX_BBOX_PIXELS,     /* same for GX-accepted */
    GIF_GOURAUD_GX_HYBRID,          /* GX shaded, CPU finished raster-ops per pixel */
    GIF_GOURAUD_GX_DEFERRED,        /* GX shaded, deferred VRAM import (no CPU raster-ops) */
    GIF_GOURAUD_GX_CPU_PIXELS,      /* pixels visited by the CPU after GX shading */
    GIF_GOURAUD_STAT_COUNT
};
enum {
    GIF_GFB_NONE=0, GIF_GFB_GX_INACTIVE, GIF_GFB_BUILD_DISABLED, GIF_GFB_SMALL,
    GIF_GFB_LARGE, GIF_GFB_TEXTURE, GIF_GFB_ALPHA_TEST, GIF_GFB_DITHER_FBA, GIF_GFB_FBMASK,
    GIF_GFB_DEPTH, GIF_GFB_BLEND, GIF_GFB_FOG, GIF_GFB_PSM, GIF_GFB_SCANMSK_OR_FIELD,
    GIF_GFB_GX_REJECTED, GIF_GFB_ALPHA_VARIES, GIF_GFB_COUNT
};
uint64_t gif_date_stat(unsigned index); /* tested, rejected */
/* Production try-process backpressure calls on an uncleared second SIGNAL. */
uint64_t gif_signal_stall_count(void);
uint64_t gif_get_triangle_texture_cache_draws(void);
uint64_t gif_get_gouraud_stat(unsigned index);
uint64_t gif_get_gouraud_fallback(unsigned index);
const char *gif_gouraud_fallback_name(unsigned index);
/* Small ring of the first degenerate IIP triangles (x0,y0,x1,y1,x2,y2,prim). */
unsigned gif_get_degenerate_sample(unsigned index,int32_t *xy6,uint32_t *prim);
/* Visible-state histogram: key bits 0 TME,1 ABE,2 ZWRITE,3 ZTEST,4 FGE,5 ATE,
 * 6 DTHE|FBA,7 FBMASK,8-9 PSM(0 CT32,1 CT24,2 CT16/16S,3 other),10 Z varies,
 * 11-12 TFX,13 texture linear filter,14 FST. Returns count or 0 past the end. */
unsigned gif_get_gouraud_state(unsigned index,uint32_t *key,uint64_t *count);
uint64_t gif_get_gouraud_state_overflow(void);

unsigned gif_get_vertex_source(unsigned index,uint32_t out[10]);

/* Partial consumption: callers retain unaccepted bytes and retry. */
uint32_t gif_try_process_quadwords(int path,const uint8_t *data,uint32_t qwc);
void gif_set_path3_mask(int masked);
int gif_fifo_write(const uint8_t *quadword);
void gif_fifo_service(void);

/* Stable read-only scheduler views. Point at the same state as getters;
 * no cached activity flags to invalidate after MMIO or checkpoint restore. */
extern const gif_state_t * const gif_scheduler_view;
/* GS Local-to-Local transfer counters (success, declines, pixels). */
uint64_t gif_local_copy_stat(unsigned which);
#endif
