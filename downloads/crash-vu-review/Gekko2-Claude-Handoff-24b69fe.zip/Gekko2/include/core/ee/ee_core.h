#ifndef PCSX2WII_EE_CORE_H
#define PCSX2WII_EE_CORE_H

#include <stdint.h>
#include "core/bios_loader.h"
#include "core/hw/vu.h"

/* Internal TLB fault classification shared by the EE memory/exception path
 * and white-box regression tests. Keep these values aligned with
 * ee_mem_ptr()'s mem_tlb_miss encoding. */
enum {
    EE_TLB_FAULT_NONE = 0,
    EE_TLB_FAULT_MISS = 1,
    EE_TLB_FAULT_INVALID = 2,
    EE_TLB_FAULT_MODIFIED = 3
};

/*
 * Emotion Engine (R5900) CPU state.
 *
 * GPRs and HI/LO are modeled as full 128 bits (two 64-bit halves,
 * "ud0"/"ud1" matching PCSX2's own UD[0]/UD[1] naming) because the MMI
 * (multimedia/SIMD) instruction set operates on all 128 bits as packed
 * lanes, and PCSX2 itself models HI/LO as 128-bit registers too (used
 * by the "pipeline 1" MMI multiply/divide variants: MULT1/DIV1/etc).
 *
 * Opcode semantics in ee_core.c (sign-extension rules, lane packing
 * for MMI ops, HI/LO handling, etc.) are ported from PCSX2's own
 * interpreter reference (pcsx2/R5900OpcodeImpl.cpp and pcsx2/MMI.cpp,
 * GPL-3.0) rather than reinvented, so this project is GPL-3.0
 * licensed as a whole - see /COPYING.GPLv3.
 */
typedef struct {
    uint64_t ud0; /* low 64 bits  (what plain 64-bit MIPS ops read/write) */
    uint64_t ud1; /* high 64 bits (only touched by MMI ops) */
} ee_reg128_t;

typedef struct {
    ee_reg128_t gpr[32];
    /* Round 890 (task #874): hi/lo moved to sit IMMEDIATELY after gpr[32]
     * (they used to come after pc/next_pc below) so that ppc_dynarec.c's
     * context pointer - which is just `&gpr[0]` cast to its own
     * ppc_dynarec_gpr128_t*, per ee_jit.c's `fn((ppc_dynarec_gpr128_t
     * *)&st->gpr[0])` call - can address HI/LO as if they were simply
     * MIPS pseudo-registers 32/33 in the same flat, contiguous array,
     * reusing 100% of the existing REG_SLOT/REG_HI/REG_LO addressing
     * macros with zero new addressing logic (see ppc_dynarec.c's
     * HI_IDX/LO_IDX). This is the ONLY reason for this field's exact
     * position: every other access in this codebase goes through the
     * `->hi`/`->lo` field names, not raw offsets, so reordering it here
     * is otherwise inert (checkpoint.c's save/load round-trips the
     * whole struct as one opaque `sizeof(ee_state_t)` blob via
     * fwrite/fread, not a byte-stable cross-version format, so it does
     * not care about field order either). ppc_dynarec.c itself still
     * does NOT #include this header - it only knows "gpr[32] followed
     * immediately by two more 16-byte slots" as a documented contract,
     * verified by the _Static_assert in ee_jit.c right next to the
     * `fn(...)` call site that actually relies on it. */
    ee_reg128_t hi, lo;
    uint32_t pc;
    uint32_t next_pc;       /* branch delay slot handling */
    /* Task #177: the R5900's dedicated 32-bit "SA" (Shift Amount)
     * control register - real, documented R5900-specific CPU state
     * (ps2tek's SPECIAL opcode table: funct 0x28=MFSA, 0x29=MTSA),
     * distinct from any single instruction's 5-bit shift-amount
     * field. Used by QFSRV (not yet implemented) to control a
     * variable-width quadword funnel-shift; MFSA/MTSA just need
     * somewhere real to read/write it. Named sa_reg, not sa, to avoid
     * clashing with ee_step()'s local per-instruction shift-amount
     * decode variable of the same short name. */
    uint32_t sa_reg;
    uint32_t cop0[32];      /* status/cause/EPC/config subset only */

    /* Set to 1 by whichever instruction executes right before a
     * branch-delay-slot instruction (any taken-or-not regular branch/
     * jump, or a taken Branch Likely - see the BRANCH_TO() macro and
     * the manual sets on BEQ/BNE/BLEZ/BGTZ/BLTZ/BGEZ/BLTZAL/BGEZAL/
     * BC1F/BC1T in ee_core.c), consumed and cleared at the top of the
     * NEXT ee_step() call. That next instruction's "am I in a delay
     * slot" status is what determines the Cause.BD bit and EPC value
     * (EPC = branch pc, not delay-slot pc) if IT raises an exception -
     * see ee_raise_exception() in ee_core.c, ported from PCSX2's own
     * cpuException() in R5900.cpp. */
    uint8_t  branch_pending;

    /* Real R5900 TLB (48 entries), ported from PCSX2's COP0.cpp
     * "tlbs" struct. Written/read by TLBWI/TLBWR/TLBR/TLBP (see
     * ee_core.c). Address translation IS wired into ee_mem_ptr() (via
     * ee_tlb_translate()) for any KUSEG address (<0x80000000) - see
     * docs/STATUS.md's "round 6". A KUSEG TLB miss now raises a real
     * TLB Refill exception (see ee_raise_exception()/
     * ee_raise_tlb_exception()) instead of silently reading as zero,
     * ported from PCSX2's cpuException()/cpuTlbMiss() in R5900.cpp -
     * see docs/STATUS.md's exception-delivery section for the full
     * story. */
    struct {
        uint32_t page_mask;
        uint32_t entry_hi;
        uint32_t entry_lo0;
        uint32_t entry_lo1;
    } tlb[48];

    /* Transient, per-instruction scratch state used only by the
     * exception-raising path (ee_raise_exception() and callers in
     * ee_core.c). Set once at the top of each ee_step() call (before
     * the instruction fetch, which can itself fault) so that any
     * memory-access helper deep in that instruction's execution
     * (ee_mem_read32(), ee_mem_write8(), etc.) can raise a correctly
     * addressed exception (right EPC / Cause.BD) without every one of
     * those functions needing extra parameters threaded through. Not
     * meaningful outside of an in-progress ee_step() call. */
    uint32_t exc_this_pc;         /* address of the instruction currently executing */
    uint8_t  exc_in_delay_slot;   /* was exc_this_pc itself a branch-delay-slot instruction? */
    uint8_t  exc_raised_this_step;/* guards against double-faulting once per instruction -
                                    * e.g. SWL/SWR do a read then a write of the SAME address,
                                    * both of which would otherwise independently detect the
                                    * same TLB miss and each try to vector away, corrupting the
                                    * second call's Cause/EPC bookkeeping (see ee_raise_tlb_exception()) */
    uint8_t  mem_tlb_miss;        /* set by ee_mem_ptr() itself: 1 if its most recent NULL
                                    * return was specifically a KUSEG TLB miss (exception-
                                    * worthy), 0 for every other outcome (success, or a
                                    * kseg0/kseg1 address with no backing ROM/RAM, which is
                                    * architecturally NOT a TLB fault and still just reads-as-
                                    * zero/no-ops as before - see ee_mem_ptr()'s own comments) */

    /* COP1 (FPU) - single-precision only. Raw IEEE-754 bit patterns,
     * not C floats, so bit-level ops (ABS_S/MOV_S/NEG_S, and the
     * denormal/infinity handling PS2's FPU does that plain IEEE float
     * math doesn't) match real hardware exactly. Semantics ported
     * from PCSX2's pcsx2/FPU.cpp. */
    uint32_t fpr[32];
    uint32_t fcr31;
    uint32_t acc;   /* FPU accumulator - MADDA.S/MSUBA.S/MULA.S/ADDA.S/
                     * SUBA.S write it, MADD.S/MSUB.S read it. Same raw
                     * IEEE-754 bit-pattern representation as fpr[]. */

    /* COP2 (VU0 in "macro mode") - control-register file only. Added
     * round 12 to get past a real BIOS init sequence
     * (cfc2/ori/ctc2 read-modify-write on FBRST, control register 28)
     * that halted with "unimplemented primary opcode 0x12" once round
     * 11's fixes let boot progress far enough to reach it. This
     * project does NOT model VU0's actual vector datapath (VF/VI
     * register files, the vector arithmetic opcode family - ADD/SUB/
     * MUL/MAC pipelines etc.) - only the 32-bit control-register
     * transfer instructions (MFC2/CFC2/MTC2/CTC2) real BIOS/kernel
     * init code uses to read/write control state like FBRST. Real
     * FBRST semantics (bit 0x2 = VU0 reset, bit 0x200 = VU1 reset,
     * bits 0x1/0x100 = force-break - ported from PCSX2's own
     * VU0.cpp CTC2() handler) aren't modeled beyond plain storage,
     * since no VU0/VU1 execution state exists yet to actually reset -
     * an honest simplification, not a fabricated one (matches this
     * project's existing SIF CTRL register precedent: real documented
     * side effects noted, not modeled, when the dependent subsystem
     * doesn't exist yet). See docs/STATUS.md's "round 12" section. */
    uint32_t cop2_ctrl[32];

    /* VU0 vector datapath (round 13): the actual VF (vector float,
     * 32 x 128-bit) register file and VU0's small local data memory,
     * added to get past a real BIOS VU0 init/self-test sequence
     * (viswr/vsqi/vsub.xyzw/qmfc2/qmtc2) that halted with
     * "unimplemented COP2 sub-opcode" once round 12's control-
     * register transfers let boot progress far enough to reach it.
     * Each VF register is stored as 4 raw 32-bit lanes (index
     * 0=x,1=y,2=z,3=w - float bit patterns, not converted) matching
     * PCSX2's own VECTOR union layout (pcsx2/VU.h). VF00 is hardwired
     * on real hardware to (0,0,0,1.0f) and VI0 (cop2_ctrl[0]) is
     * hardwired to 0 - both enforced via helpers in ee_core.c
     * (vu0_vf_read_lane/vu0_vf_write_lane/vu0_vi_read/vu0_vi_write),
     * not by special-casing every call site.
     *
     * vu0_mem is VU0's real 4KB local data memory (256 quadwords),
     * addressed by ILW/ISW/LQI/SQI-family instructions using a VI
     * register as a quadword index (byte_addr = VI*16 + lane*4).
     * Size confirmed as a standard, widely-documented PS2 VU0
     * property (VU0: 4KB data mem / VU1: 16KB - see PS2Tek and
     * PCSX2's vuMemAllocate()). Address wraparound is modeled as a
     * simple 8-bit quadword-index mask (& 0xFF) - an honest
     * simplification if real hardware's exact out-of-range behavior
     * differs, noted the same way gs_mem.h flags its own linear-
     * addressing simplification. See docs/STATUS.md's "round 13"
     * section. */
    uint32_t vu0_vf[32][4];
    uint8_t vu0_mem[4096];

    /* VU0 "micro mode" (task: "VU0/VU1 data memory + VU microcode
     * interpreter") - a COMPLETELY SEPARATE thing from the VU0 macro-
     * mode (COP2) state directly above, sharing only the same
     * physical VF/VI register file and data memory, exactly like real
     * hardware - see include/core/hw/vu.h's header comment for the
     * full explanation and citations. vu0_micro is VU0's real 4KB
     * micro-instruction memory (PCSX2's VU0_PROGSIZE); the TPC/
     * branch/E-bit fields below are transient execution-control state
     * (not real architectural registers, matching how PCSX2's own
     * VURegs struct also keeps `branch`/`branchpc`/`ebit` alongside
     * its real VI[] array) - VU0's real TPC register itself is
     * cop2_ctrl[26] (REG_TPC per PCSX2's VU.h VURegFlags enum, the
     * same generic CTC2/CFC2-addressable register file round 12
     * already implemented) and is kept in sync by vu0_exec_micro() in
     * ee_core.c. */
    uint8_t  vu0_micro[4096];
    uint32_t vu0_branch_delay, vu0_branch_target;
    uint32_t vu0_ebit_delay;
    uint8_t  vu0_running;
    uint64_t vu0_instructions_executed;
    uint64_t vu0_unimplemented_opcodes_seen;

    /* VU micro-mode accumulator vector (task #94, real VU opcode
     * table) - a real, separate 4-lane vector register used by MADD/
     * MSUB (Fd = ACC (+/-) Fs*Ft) and written by the ADDA/SUBA/MADDA/
     * MSUBA "accumulate" family - NOT one of the 32 VF registers and
     * NOT part of the VI/cop2_ctrl file. Raw float bit patterns, same
     * storage convention as vu0_vf[][]. See source/hw/vu_opcodes.h for
     * the full citation trail (Sony's VU Users' Manual). */
    uint32_t vu0_acc[4];

    uint8_t *ram;           /* 32MB emulated EE RAM */
    uint32_t ram_size;

    /* R5900 Scratchpad RAM (SPR): a real, dedicated 16KB on-chip
     * memory hardwired to the fixed virtual range 0x70000000-
     * 0x70003FFF (KUSEG). This is NOT ordinary TLB-mapped memory -
     * real hardware bypasses the TLB entirely for this fixed address
     * window (confirmed both by a live PCSX2 trace and PCSX2's own
     * source: pcsx2/Memory.cpp literally comments "0x70000000-
     * 0x70003fff scratch pad", pcsx2/MemoryTypes.h's
     * Ps2MemSize::Scratch = 16KB, and pcsx2/COP0.cpp's MapTLB()
     * special-cases isSPR() entries to route straight to a dedicated
     * Scratch buffer instead of normal PFN-based physical translation).
     * Round 7's real TLB implementation initially tried to translate
     * this range through the normal KUSEG TLB path like any other
     * address, which - since the BIOS's stack pointer lands in the
     * upper 8KB half of this window, past the one narrow TLB entry
     * that happened to be installed - produced a genuine, unresolvable
     * TLB Refill exception loop (see docs/STATUS.md's "round 8").
     * ee_mem_ptr() now intercepts this fixed range unconditionally,
     * before any TLB lookup, exactly matching real hardware. */
    uint8_t scratch[16 * 1024];

    const bios_image_t *bios;

    uint64_t instructions_executed;
    uint8_t  halted;
    char     halt_reason[128];

    /* Round 855 (task #855, user's "1 dann 2 dann 3" step 3): real,
     * live-reproduced bug fix - see tools/round855-idle-scheduler/
     * r855_repro.c and docs/STATUS.md's Round 855 writeup for the
     * full evidence trail. reschedule() (source/core/ee/
     * ee_hle_thread.c)'s own "nothing ready" branch used to just
     * leave the live register file exactly as-is when a thread
     * self-blocked (e.g. SleepThread()) and no other thread was
     * ready - but SleepThread's self-block path calls EE_ADVANCE()
     * BEFORE reschedule(), unlike WaitSema's own deliberate "pin pc
     * at the syscall itself" park convention (Round 569/781). With
     * nothing to switch to, that advanced pc was simply left live,
     * so ee_step() kept fetching/decoding/executing the SLEEPING
     * thread's own subsequent code forever - a real, confirmed
     * correctness bug (proved by r855_repro.c: a single self-blocked
     * thread's own marker instruction, placed right after its
     * SleepThread() call, executed despite the thread's status
     * reading EE_THS_WAIT the whole time).
     *
     * Fix mirrors this project's own already-accepted, already-cited
     * IOP-side `idle` mechanism (include/core/iop/iop_core.h) exactly:
     * when reschedule() finds nothing ready AND the thread that was
     * just live is no longer actually RUN, set `idle` instead of
     * leaving the stale context to be replayed. ee_step() then skips
     * real fetch/decode/execute entirely while idle (this project's
     * own standing discipline forbids fabricating specific "idle
     * loop" instruction bytes real hardware might contain), but still
     * runs the exact same real hardware-tick sequence
     * ee_core_park_tick() already runs for the Round 630/782 null-
     * jalr-guard's own dead-thread case (VBLANK/timers/DMAC/INTC/SIF/
     * RPC/CDVD-pending) every single call, then re-invokes the real
     * scheduler (ee_hle_thread_reschedule_kick()) so a thread made
     * READY by any of that (e.g. a real interrupt handler calling
     * WakeupThread/SignalSema) gets loaded in immediately, clearing
     * `idle` itself. Defaults to 0 (never idle) for every existing
     * test/boot path that never hits this exact self-block-with-
     * nothing-ready condition - a no-op everywhere else. */
    uint8_t  idle;
    /* HLE MCSERV reports metadata from requested real IOP modules,
     * not invented versions. Saved/reset with the EE state. */
    uint16_t mcserv_module_version, mcman_module_version;
    /* Native resident copies are invalid after an external GPR mutation. */
    uint32_t gpr_generation;
    vu_pipeline_t vu0_pipeline;
    /* Literal returned by the selected real LOADFILE legacy RPC getter;
     * zero means no verified provider. Cold-boot/reset/checkpoint state. */
    uint32_t loadfile_rpc_version;
    vu_timing_t vu0_timing;
    /* Selected real FILEIO provider's legacy RPC 0xff literal;
     * unknown/absent providers return zero, never synthetic success. */
    uint32_t fileio_rpc_version;
} ee_state_t;

void vu0_sync_macro(ee_state_t *st);
int  ee_core_init(const bios_image_t *bios);
void ee_core_run(const bios_image_t *bios);
void ee_core_rebind_dma_sinks(void); /* Round 449 - checkpoint-resume-safe DMA sink re-registration, see .c citation */

/* Round 736 (task #447 continuation): purely observational log of every
 * real AddIntcHandler(cause, handler_func, next) call (sysnum 16). Does
 * NOT change how the syscall is handled - see ee_core.c's own comment on
 * the sysnum==16||17 block for why this project lets AddIntcHandler
 * vector as a real exception rather than emulating it in software.
 * Exists to answer, for a given boot trace, whether any code ever
 * registers a handler pointing at a specific address range (e.g.
 * Round 735's GT3 job-queue module) without needing further guesswork. */
uint32_t ee_core_get_addintc_log_count(void);
int ee_core_get_addintc_log_entry(uint32_t idx, uint32_t *cause, uint32_t *handler_addr,
                                   uint32_t *next, uint32_t *call_pc);

/* Round 957 (task #950, SCPH-50004 forward-trace): plain running counter
 * of every real, SUCCESSFUL rom0:-device LF_F_ELF_LOAD RPC_CALL reply
 * this project's own sif_loadfile_elf_load() delivers (i.e. incremented
 * exactly where ee_arm_rpc_call_pending(call_cd) fires for that case).
 * Same always-on-counter convention as iop_cdvd_get_scmd_call_count() -
 * cheap, not gated behind an #ifdef, not part of savestate (diagnostic
 * only). Lets a driver detect "next LOADFILE reply just fired" without
 * needing a separate #ifdef-gated stderr trace parsed out-of-band. */
uint64_t ee_core_get_loadfile_reply_count(void);

/* Single-step entry point, for the interleaved EE/IOP scheduler
 * in core/system.h. See its definition in ee_core.c for details. */
int ee_core_step(void);
/* Execute at most n EE scheduler slots, preserving each step's epilogue.
 * Idle park ticks and scalar fault/redirect attempts consume slots without
 * fabricating retirements. Returns guest instructions actually retired. */
unsigned ee_core_step_n(unsigned n);
/* Wii scheduler: after eight EE slots (including idle), service one IOP tick.
 * The callback returns zero to end this grant (e.g. IOP halted).
 * Native blocks cannot straddle a quantum; native chains may span quanta. */
unsigned ee_core_step_interleaved_n(unsigned quanta,int (*after_quantum)(void));
extern unsigned ee_core_interleave_quantum; /* UINT32_MAX outside a grant. */
static inline unsigned ee_core_interleave_limit(unsigned budget)
{return budget<ee_core_interleave_quantum?budget:ee_core_interleave_quantum;}
void ee_core_interleave_account(unsigned slots);
unsigned ee_core_step_event_n(unsigned quanta,unsigned width,int (*catch_up)(unsigned));
/* Re-evaluate external deadlines after each catch-up, before admitting another
 * EE window. The limiter returns EE slots and cannot enlarge the EE deadline.
 * NULL preserves the standalone EE scheduler API above. */
unsigned ee_core_step_event_bounded_n(unsigned quanta,unsigned width,
    int (*catch_up)(unsigned),unsigned (*limit_window)(unsigned));
void ee_core_event_sync(void);
void ee_core_event_notify(void);
unsigned ee_core_native_window_begin_cached(ee_state_t *,uint32_t,const uint32_t *,unsigned,unsigned,uint32_t);
unsigned ee_core_native_window_begin_aot(ee_state_t *,uint32_t,const uint32_t *,unsigned,unsigned);
unsigned ee_core_event_distance(unsigned maximum);
uint64_t ee_core_event_deadline_stat(unsigned reason);
void ee_core_shutdown(void);

/* Round 781 (task #803): real elapsed-hardware-time tick, for use by
 * ee_hle_thread.c's WaitSema park branch (and any future genuine
 * blocking-wait branch with the same shape). See ee_core.c's
 * definition site for the full citation trail - in short, real
 * VBLANK/timer/DMAC/INTC interrupt sources keep firing on real
 * elapsed hardware time regardless of whether any specific EE thread
 * is CPU-blocked in a syscall, but this project's normal per-
 * instruction epilogue (which drives all of that) is skipped whenever
 * ee_hle_thread_try_handle() returns 1 - fine for one-shot syscalls
 * (a single skipped tick is cosmetic), fatal for WaitSema's
 * re-executes-forever park (permanently starves every interrupt
 * source for as long as the park lasts). Call this once per parked
 * step to keep real hardware time - and therefore interrupt delivery
 * - flowing during a park, without touching the main per-instruction
 * path at all. */
void ee_core_park_tick(ee_state_t *st);

/* Task #172 continued: optional bridge so the SIF DMA-copy syscall
 * handler (sceSifSetDma) can write into IOP memory without ee_core.c
 * gaining a hard link-time dependency on iop_core.c - see the
 * definition site in ee_core.c for the full rationale. Callers that
 * link both cores together (main.c, combined diagnostics) should call
 * this once after both ee_core_init() and iop_core_init(); EE-only
 * tests simply never call it. */
void ee_core_set_iop_write8_bridge(void *iop_ctx, void (*write8_fn)(void *ctx, uint32_t addr, uint8_t val));

/* Round 1042 (task #447/#536 continuation, real LF_F_GET_ADDR/
 * SifIopGetVal RPC): the same link-time-isolation problem as the
 * write8 bridge above, but for reading IOP memory (real ee/kernel/
 * src/loadfile.c's SifIopGetVal() peeks a byte/short/long directly
 * out of IOP RAM via the real IOP-side loadfile_getaddr() handler -
 * see the SIF_SID_LOADFILE rpc_number==3 branch in ee_core.c for the
 * full citation). Mirrors the write8 bridge's optional-pointer
 * design exactly: NULL until a combined-core caller wires it via
 * system_init()/system_rebind_iop_bridge(), so EE-only tests are
 * unaffected. */
void ee_core_set_iop_read_bridge(void *iop_ctx, uint32_t (*read_fn)(void *ctx, uint32_t addr, int width));

/* Exposed for the recompiler PoC (source/core/recompiler) to share
 * register state layout / memory access helpers. */
void ee_core_get_r1189_exception_diag(uint64_t *exc, uint64_t *nested, uint64_t *eret,
                                      uint32_t *pc, uint32_t *va, uint32_t *iw,
                                      uint32_t *rs, uint32_t *rv, uint32_t *ea);
ee_state_t *ee_core_get_state(void);
/* BETA12.5: read-only transport diagnostics, not part of guest EE state. */
typedef struct {
    uint64_t version_calls, open_calls, open_success, open_fail;
    uint64_t read_calls, read_bytes, close_calls;
    uint64_t font_open_calls, font_open_success, font_open_fail;
    uint64_t font_read_calls, font_read_bytes;
    uint32_t last_read_fd, last_read_requested, last_read_returned;
    int32_t last_open_result;
    uint32_t last_open_offset;
    char last_open_path[112], last_font_path[112];
} ee_fileio_trace_t;
void ee_core_fileio_trace(ee_fileio_trace_t *out);


uint8_t  ee_mem_read8(ee_state_t *st, uint32_t addr);
uint16_t ee_mem_read16(ee_state_t *st, uint32_t addr);
uint32_t ee_mem_read32(ee_state_t *st, uint32_t addr);
uint64_t ee_mem_read64(ee_state_t *st, uint32_t addr);
void     ee_mem_write8(ee_state_t *st, uint32_t addr, uint8_t val);
void     ee_mem_write16(ee_state_t *st, uint32_t addr, uint16_t val);
void     ee_mem_write32(ee_state_t *st, uint32_t addr, uint32_t val);
void     ee_mem_write64(ee_state_t *st, uint32_t addr, uint64_t val);
/* Whole guest quadword access: interpreter and scalar JIT share MMIO semantics.
 * Values use host register representation; FIFO bytes are guest little-endian. */
void ee_mem_read128(ee_state_t *st, uint32_t addr, ee_reg128_t *out);
void ee_mem_write128(ee_state_t *st, uint32_t addr, const ee_reg128_t *value);

/* VU0 micro mode (see this struct's vu0_micro comment above and
 * include/core/hw/vu.h) - called from vif.c's VIF0 MPG/MSCAL/MSCNT/
 * MSCALF handling. */
void vu0_micro_write32(ee_state_t *st, uint32_t addr, uint32_t value);
void vu0_exec_micro(ee_state_t *st, uint32_t start_addr);
void vu0_exec_micro_continue(ee_state_t *st); /* Round 576: real MSCNT semantics - see ee_core.c citation */

/* VU0 local DATA memory (see ee_core.c for the full comment) - called
 * from vif.c's VIF0 UNPACK handling. */
void vu0_mem_write32(ee_state_t *st, uint32_t addr, uint32_t value);

/* R1176 sampled ee_step Time Base profiler (1/4096 normal instructions). */
extern volatile uint64_t g_r1176_prof_samples;
extern volatile uint64_t g_r1176_prof_fetch_tb;
extern volatile uint64_t g_r1176_prof_jit_tb;
extern volatile uint64_t g_r1176_prof_epilogue_tb;
extern volatile uint64_t g_r1177_prof_base_tb;
extern volatile uint64_t g_r1177_prof_clock_tb;
extern volatile uint64_t g_r1177_prof_house_tb;
extern volatile uint64_t g_r1177_prof_irq_tb;
extern volatile uint64_t g_r1178_prof_latch_tb;
extern volatile uint64_t g_r1178_prof_vblank_tb;
extern volatile uint64_t g_r1178_prof_bootchecks_tb;
extern volatile uint64_t g_r1178_prof_gsvsync_tb;
extern volatile uint64_t g_r1178_prof_timers_tb;


void ee_core_get_r1190_sif_diag(uint64_t *itake, uint64_t *stake, uint64_t *hhit, uint64_t *rend, uint32_t *cd, uint32_t *sema);
uint64_t ee_core_get_r1191_tlbwr_count(void);
void ee_core_get_r1192_sif_flow(uint64_t *arms, uint64_t *isig, uint64_t *wait, uint32_t *count, uint32_t out[8]);
void ee_core_get_r1195_sif_calls(uint32_t idx, uint32_t out[8]);
void ee_core_get_r1197_rend_packet(uint32_t out[12], uint32_t *recvbuf, uint32_t *phys, uint32_t *inner);
void ee_core_get_r1198_rend_reads(uint32_t *count, uint32_t out[8][6]);
void ee_core_get_r1199_dma(uint32_t which, uint32_t out[9]);
void ee_core_get_r1201_writes(uint32_t *count, uint32_t out[6][4]);
void ee_core_get_r1202_corr(uint32_t *handler_rend, uint32_t out[3][5]);
void ee_core_get_r1204_dispatch(uint32_t *count, uint32_t out[8]);
void ee_core_get_r1205_hwreads(uint32_t *count, uint32_t out[8][3]);
void ee_core_get_r1206_steps(uint32_t *count, uint32_t out[24][4]);
void ee_core_get_r1207_steps(uint32_t *count, uint32_t out[24][6]);
void ee_core_get_r1210_probe(uint32_t out[7]);
void ee_core_get_r1212_pcs(uint32_t *count, uint32_t out[96][2]);
void ee_core_get_r1214_fb(uint32_t out[4][5], uint32_t *smflag);
void ee_core_get_r1217_trace(uint32_t *count, uint32_t out[64][4]);
void ee_core_get_r1230_trace(uint32_t *count, uint32_t out[128][4]);
void ee_core_get_r1234_trace(uint32_t *count, uint32_t out[512][3]);
void ee_core_get_r1235_trace(uint32_t *count, uint32_t out[128][8]);
void ee_core_get_r1236_census(uint64_t *steps, uint64_t outreg[5], uint32_t *tn, uint32_t *head, uint32_t out[16][6]);
void ee_core_get_r1237_kseg(uint32_t *en, uint32_t entry[128][2], uint64_t *samples,
                            uint32_t hotpc[8], uint32_t hotscore[8], uint32_t recent[8], uint32_t *rhead);
void ee_core_get_r1238_sink(uint32_t *head, uint32_t ring[16][4], uint32_t snap[12]);
void ee_core_get_r1239_jump(uint32_t out[16]);
void ee_core_get_r1240_flow(uint32_t *count, uint32_t out[40][7]);
void ee_core_get_r1241_raflow(uint32_t *count, uint32_t out[24][9]);
void ee_core_get_r1242_slot(uint32_t *armed, uint32_t *sp, uint32_t *slot, uint32_t *n, uint32_t w[16][8], uint32_t restore[8]);
void ee_core_get_r1243_spflow(uint32_t *count, uint32_t out[32][10]);
void ee_core_get_r1245_slottruth(uint32_t *hit, uint32_t snap[12]);
void ee_core_get_r1246_writer(uint32_t *hit, uint32_t snap[16]);
/* R1249 counts: repairs, continuation visits, LD visits, JR visits. */
void ee_core_get_r1249_repair(uint64_t counts[4], uint32_t last[6]);
void ee_core_get_r1218_syscalls(uint32_t *count, uint32_t out[12][7]);
void ee_core_get_r1219_sema2(uint32_t create2[7], uint32_t wait2[10], uint32_t *rn, uint32_t rend[8][4]);
void ee_core_get_r1223_sig2(uint32_t out[8]);
void ee_core_get_r1224_ncmd(uint32_t out[5]);
void ee_core_get_r1252_fault(uint32_t out[112]);

/* Host PADMAN DMA bindings are not guest registers and must survive
 * save/resume independently of ee_state_t's ABI-sensitive layout. */
typedef struct {
    uint32_t legacy_area[2];
    uint32_t new_area[2][4];
    uint32_t new_status;
} ee_pad_checkpoint_t;
/* Diagnostic actual emitted VBLANK edges since core reset; no guest effect. */
uint64_t ee_core_get_vblank_events(void);
uint64_t ee_core_vblank_fast_wait_stat(unsigned which);
void ee_core_pad_checkpoint_save(ee_pad_checkpoint_t *out);
void ee_core_pad_checkpoint_load(const ee_pad_checkpoint_t *in);

/* R1179 BC split profiler. */
extern volatile uint64_t g_r1179_prof_selfloop_tb;
extern volatile uint64_t g_r1179_prof_eeload_tb;
extern volatile uint64_t g_r1179_prof_escalate_tb;
extern volatile uint64_t g_r1179_prof_carousel_tb;
extern volatile uint64_t g_r1179_prof_sbus_tb;

/* R1181 SBUS guard/helper profiler. */
extern volatile uint64_t g_r1181_prof_sbus_guard_tb;
extern volatile uint64_t g_r1181_prof_sbus_helper_tb;
extern volatile uint64_t g_r1181_sbus_guard_match;
extern volatile uint64_t g_r1181_sbus_helper_calls;
extern volatile uint64_t g_r1181_sbus_unblocks;

/* R1262 INTC delivery scheduler; kept separate from EES1 ABI. The current
 * approximate core advances one timing tick per instruction or idle tick. */
typedef struct { uint32_t intc_delay; uint32_t intc_armed; } ee_irq_checkpoint_t;
void ee_core_irq_checkpoint_save(ee_irq_checkpoint_t *out);
void ee_core_irq_checkpoint_load(const ee_irq_checkpoint_t *in);
/* Independent display timing; optional ECLK checkpoint block. */
uint64_t ee_core_display_clock_save(void);
void ee_core_display_clock_load(uint64_t ticks);

/* Precise block-JIT callbacks; mapped code is reread at every boundary. */
int ee_core_block_peek(ee_state_t *st,uint32_t pc,uint32_t *word);
/* Returns UINT32_MAX for immutable BIOS source, otherwise the EE RAM 4 KiB page. */
int ee_core_block_source_page(ee_state_t *st,uint32_t pc,uint32_t *page);
unsigned ee_core_block_words(ee_state_t *st,uint32_t pc,uint32_t *words,unsigned limit);
int ee_core_block_prepare(ee_state_t *st,uint32_t pc,uint32_t instruction);
int ee_core_block_prepare_fetched(ee_state_t *st,uint32_t pc);
uint32_t ee_core_block_memory_resolve(const ee_state_t *st,uint32_t instruction);
uint32_t ee_core_block_memory_resolve_precise(const ee_state_t *st,uint32_t instruction);
uint32_t ee_core_block_prepare_memory_resolved(ee_state_t *st,uint32_t pc,uint32_t instruction);
int ee_core_block_memory_safe(const ee_state_t *st,uint32_t instruction);
int ee_core_block_prepare_memory(ee_state_t *st,uint32_t pc,uint32_t instruction);
uint32_t ee_core_block_prepare_delay(ee_state_t *st,uint32_t pc,uint32_t instruction);
void ee_core_block_commit(ee_state_t *st);
uint32_t ee_core_block_boundary(ee_state_t *,uint32_t,uint32_t);
uint32_t ee_core_block_memory_boundary(ee_state_t *,uint32_t,uint32_t);
uint32_t ee_core_block_delay_boundary(ee_state_t *,uint32_t,uint32_t);
uint64_t ee_core_get_fused_boundaries(void);
void ee_core_raise_trap(ee_state_t *st);
void ee_core_raise_reserved(ee_state_t *st);
void ee_core_raise_overflow(ee_state_t *st);


/* R1331: mapping cache lifecycle; any external TLB writer must invalidate. */
void ee_fastmem_invalidate(void);
uint64_t ee_fastmem_stat(unsigned n);
unsigned ee_core_native_window_begin(ee_state_t *,uint32_t,const uint32_t *,unsigned,unsigned);
unsigned ee_core_native_window_begin_with_addresses(ee_state_t *,uint32_t,const uint32_t *,unsigned,unsigned,uint32_t);
uint64_t ee_core_vu_window_stat(unsigned);
uint64_t ee_core_cpu_fifo_stat(unsigned);
uint64_t ee_core_native_window_stat(unsigned);
uint64_t ee_core_arm_boot_stat(unsigned);
extern uint32_t ee_native_window_memory[32];
/* Scheduler/idle admission used by the optional BETA11 paths. */
unsigned ee_core_idle_active(void);
#ifdef GEKKO2_IDLE_SKIP
int ee_core_idle_pc(uint32_t pc);
#endif
#endif
