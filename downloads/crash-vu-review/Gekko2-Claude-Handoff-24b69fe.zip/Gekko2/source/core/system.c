#include "core/runtime_profile.h"
#include "core/recompiler/dynarec_config.h"
/*
 * system.c - interleaved EE/IOP scheduler. See system.h for the
 * rationale and current known simplifications (EE_IOP_STEP_RATIO
 * instructions per slice on the EE side per 1 on the IOP side - a
 * ratio-aware, but still not cycle-accurate, approximation of real
 * hardware's ~8:1 clock difference; see system.h).
 */
#include "core/system.h"
#include "core/hw/cdvd_config.h"
#include "core/ee/ee_core.h"
#include "core/iop/iop_core.h"
#include "core/hw/arm_worker.h"
#include "core/hw/arm_ram.h"
#include "core/hw/ipu.h"
#include "core/hw/iop_spu2.h"
#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>

/* Round 448 (task #247 continued): real, confirmed root cause of the
 * checkpoint/resume SIGSEGV that iop_heap.c's fix and the SIF-bridge
 * re-bind did not resolve on their own. Bisected via a host-native
 * backtrace (driver_r313.c's own crash handler, once its earlier
 * secondary-fault issue was worked around by testing smaller slice
 * counts): the fault is INSIDE __printf_chk, called from this file's
 * plain printf() calls below - confirming driver_r313.c's own long-
 * standing, previously-unexplained comment ("stdio reliably crashes
 * on any call made after this checkpoint format's raw restore, for
 * reasons not fully root-caused" - see driver_r313.c's r313_safe_
 * printf()) applies here too. r313_safe_printf() already worked
 * around this in the test driver by formatting via vsnprintf() into
 * a stack buffer and writing it with a raw write() syscall, entirely
 * bypassing FILE-stream/PLT-mediated stdio machinery - this is the
 * exact same technique, ported into system.c itself since
 * system_run_interleaved() is real, shared source (used by main.c on
 * the actual Wii/Dolphin target too, not just the test driver) and
 * its diagnostic prints are worth keeping working everywhere, not
 * just deleting them. This does not change any real Wii/Dolphin
 * behavior - the printed bytes are identical, only the mechanism
 * that emits them changed. */
static void system_safe_printf(const char *fmt, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n > 0) {
        if (n > (int)sizeof(buf)) n = sizeof(buf);
        ssize_t w = write(1, buf, (size_t)n);
        (void)w;
    }
}

/* Real EE clock (~294.912 MHz) vs real IOP clock (~36.864 MHz) is
 * roughly 8:1 - already documented as this project's target ratio in
 * system.h/docs/ROADMAP.md before this was implemented. This does NOT
 * make the scheduler cycle-accurate (different MIPS instructions take
 * different real cycle counts on both cores, none of which is
 * modeled) - it just steps the EE 8 real instructions for every 1 IOP
 * instruction per slice, instead of the previous 1:1, so a given wall-
 * clock-equivalent slice count gives each core roughly the right
 * SHARE of total instructions executed. An honest, noted
 * approximation, not a claim of real timing fidelity. */
#define EE_IOP_STEP_RATIO 8

/* Task #172 continued: adapts iop_mem_write8()'s real signature to
 * the generic (void *ctx, addr, val) shape ee_core.c's optional SIF
 * DMA-copy bridge expects - see ee_core.h's ee_core_set_iop_write8_
 * bridge() comment for why this indirection exists (keeping ee_core.c
 * free of a hard link-time dependency on iop_core.c). */
static void system_iop_write8_adapter(void *ctx, uint32_t addr, uint8_t val)
{
    system_shared_sync_reason(17u);
    iop_mem_write8((iop_state_t *)ctx, addr, val);
}

/* Round 1042 (task #447/#536): read-side counterpart to
 * system_iop_write8_adapter() above, for ee_core.c's real
 * LF_F_GET_ADDR (SIF_SID_LOADFILE rpc_number==3) handler - see
 * ee_core_set_iop_read_bridge()'s citation in ee_core.h for the full
 * rationale. width is 1/2/4 bytes. */
static uint32_t system_iop_read_adapter(void *ctx, uint32_t addr, int width)
{
    system_shared_sync_reason(16u);
    iop_state_t *iop = (iop_state_t *)ctx;
    switch (width) {
        case 1: return (uint32_t)iop_mem_read8(iop, addr);
        case 2: return (uint32_t)iop_mem_read16(iop, addr);
        case 4: return iop_mem_read32(iop, addr);
        default: return 0u;
    }
}

static uint64_t g_event_stats[5];
static uint64_t g_sync_reasons[19];

#include "core/hw/ps2_mc_files.h"
int system_init(const bios_image_t *ee_bios, const bios_image_t *iop_bios)
{
    ps2_mc_fs_reset();
    for(unsigned i=0;i<5u;i++)g_event_stats[i]=0;
    for(unsigned i=0;i<19u;i++)g_sync_reasons[i]=0;
    arm_worker_begin_session();
    arm_ram_reset();
    arm_worker_reset(); /* Connect before the EE cold-boot RAM calibration. */
    cdvd_config_reset();
    if (ee_core_init(ee_bios) != 0) {
        printf("[!] system_init: EE core init failed\n");
        return -1;
    }
    if (iop_core_init(iop_bios) != 0) {
        printf("[!] system_init: IOP core init failed\n");
        return -1;
    }
    ee_core_set_iop_write8_bridge(iop_core_get_state(), system_iop_write8_adapter);
    ee_core_set_iop_read_bridge(iop_core_get_state(), system_iop_read_adapter);
    return 0;
}

/* Round 448 (task #247 continued): see system.h's citation on why
 * this exists separately from system_init(). */
void system_rebind_iop_bridge(void)
{
    ee_core_set_iop_write8_bridge(iop_core_get_state(), system_iop_write8_adapter);
    ee_core_set_iop_read_bridge(iop_core_get_state(), system_iop_read_adapter);
}

/* Round 1017 (task #994, user's explicit instruction: "Nimm alle
 * Pmode Hacks raus und lasse den Bios den Pmode und Disp2 aufwecken"
 * - remove all PMODE hacks, let the BIOS wake PMODE/DISP2 itself):
 * the Round 940/941 synthetic PMODE/SMODE2/DISPFB2/DISPLAY2 force-
 * override (system_r940_force_display_if_needed()) has been REMOVED
 * entirely. PMODE and the GS display registers are now only ever
 * written by genuine BIOS/game code via the normal GS MMIO path
 * (source/hw/gs.c) - nothing in system.c synthesizes display state
 * anymore. See docs/STATUS.md Round 1017 for the removal rationale
 * and the fresh organic-boot survey this enabled. */

/* Sample at pseudo-random intervals averaging about 256 interleaved
 * pairs, avoiding a fixed phase against short BIOS loops. Profiling never
 * skips instructions or changes EE/IOP interleave. */
static system_profile_t g_profile;
static uint32_t g_profile_remaining=256,g_profile_rng=0x12810003u;
__attribute__((noinline)) uint32_t system_profile_clock(void)
{
#ifdef __PPC__
    uint32_t ticks;__asm__ volatile("mftb %0":"=r"(ticks));return ticks;
#else
    return 0;
#endif
}
void system_profile_reset(void)
{
    gekko2_profile_reset();g_profile=(system_profile_t){0};g_profile_remaining=256;g_profile_rng=0x12810003u;
}
void system_profile_get(system_profile_t *out){if(out)*out=g_profile;}

/* EE still runs eight scheduler slots before EVERY IOP tick, including
 * native block slots, HLE interception, idle and scalar recovery. Grouping
 * host calls does not grant either guest CPU extra execution time. */
static unsigned g_iop_sample_pending,g_iop_sample_has_middle;
/* Both core states are stable objects. Refresh per frontend invocation,
 * including restored checkpoints; callbacks need no repeated getter calls. */
static ee_state_t *g_scheduler_ee;
static iop_state_t *g_scheduler_iop;
static int g_scheduler_service_fast;
static uint32_t g_iop_sample_begin,g_iop_sample_middle;
static void system_finish_iop_sample(void)
{
    if(!g_iop_sample_pending)return;
    gekko2_profile_stop();
    uint32_t end=system_profile_clock();
    if(!g_iop_sample_has_middle)g_iop_sample_middle=end;
    g_profile.ee_ticks+=(uint32_t)(g_iop_sample_middle-g_iop_sample_begin);
    g_profile.iop_ticks+=(uint32_t)(end-g_iop_sample_middle);
    g_profile.samples++;
    g_iop_sample_pending=0;g_iop_sample_has_middle=0;
}
static void system_before_iop_tick(void)
{
    system_finish_iop_sample();
    ee_state_t *ee=g_scheduler_service_fast?g_scheduler_ee:ee_core_get_state();
    if(--g_profile_remaining==0) {
        g_iop_sample_begin=system_profile_clock();gekko2_profile_start(GP_EE);
        if(!ee->halted)ee_core_step_n(EE_IOP_STEP_RATIO);
        gekko2_profile_enter(GP_IOP);g_iop_sample_middle=system_profile_clock();g_iop_sample_has_middle=1;
        g_iop_sample_pending=1;
        uint32_t rng=g_profile_rng;rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;
        g_profile_rng=rng;g_profile_remaining=128+(rng&255u);
    } else if(!ee->halted)ee_core_step_n(EE_IOP_STEP_RATIO);
}

#if GEKKO2_SCHEDULER_QUANTA_ENABLED
static unsigned system_quantum_grant;
static void system_begin_ee_quantum(void)
{
 if(g_iop_sample_pending)return;
 if(--g_profile_remaining==0u) {
  g_iop_sample_begin=system_profile_clock();g_iop_sample_middle=g_iop_sample_begin;g_iop_sample_has_middle=0;
  gekko2_profile_start(GP_EE);g_iop_sample_pending=1u;
  uint32_t rng=g_profile_rng;rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;
  g_profile_rng=rng;g_profile_remaining=128u+(rng&255u);
 }
}
static int system_after_ee_quantum(void)
{
 if(g_iop_sample_pending){gekko2_profile_enter(GP_IOP);g_iop_sample_middle=system_profile_clock();g_iop_sample_has_middle=1;}
 iop_state_t *iop=g_scheduler_service_fast?g_scheduler_iop:iop_core_get_state();
 if(!iop->halted) {
  if(g_scheduler_service_fast)iop_core_step_one_native();else iop_core_step_n(1u);
 }
 system_finish_iop_sample();
 if(--system_quantum_grant&&!iop->halted)system_begin_ee_quantum();
 return !iop->halted;
}
#endif


static unsigned g_event_active,g_event_syncing;
static int g_event_iop_blocks;
uint64_t system_event_stat(unsigned index){return index<5u?g_event_stats[index]:0u;}
uint64_t system_sync_reason_stat(unsigned reason){return reason<19u?g_sync_reasons[reason]:0u;}
void system_shared_sync_reason(unsigned reason)
{
 if(!g_event_active||g_event_syncing)return;
 g_event_stats[2]++;g_sync_reasons[reason<19u?reason:18u]++;
 ee_core_event_sync();ee_core_event_notify();
}
void system_shared_sync(void){system_shared_sync_reason(18u);}
#if GEKKO2_SCHEDULER_QUANTA_ENABLED
static unsigned system_event_window_limit(unsigned width)
{
 /* IOP catch-up can arm timers, thread alarms or interrupt sources. Refresh
  * their horizon at every EE admission, not just once per frontend grant. */
 unsigned ticks=iop_core_event_distance(width/8u);
 return ticks<width/8u?ticks*8u:width;
}
static int system_event_catch_up(unsigned ticks)
{
 g_event_syncing=1u;
 if(g_iop_sample_pending){gekko2_profile_enter(GP_IOP);g_iop_sample_middle=system_profile_clock();g_iop_sample_has_middle=1;}
 unsigned done=0;
 /* Keep the warmed one-tick IOP owners while changing EE granularity.
  * Re-forming IOP blocks for every catch-up remainder adds translation
  * variants. Parked cores still use the deadline-safe bulk path. */
 while(done<ticks&&!g_scheduler_iop->halted) {
#ifdef GEKKO2_IDLE_SKIP
  { unsigned sk=iop_core_spin_skip(ticks-done); if(sk){done+=sk;continue;} }
#endif
  if(g_event_iop_blocks){unsigned n=iop_core_step_n(ticks-done);done+=n;if(!n)break;}
  else if(g_scheduler_service_fast&&!g_scheduler_iop->idle)done+=iop_core_step_one_native();
  else {unsigned n=iop_core_step_n(ticks-done);done+=n;if(!n)break;}
 }
 g_event_stats[1]+=done;g_event_stats[3]++;
 system_finish_iop_sample();g_event_syncing=0u;
 if(!g_scheduler_iop->halted)system_begin_ee_quantum();
 return !g_scheduler_iop->halted;
}
#endif
#ifndef GEKKO2_FORCE_EVENT
#define GEKKO2_FORCE_EVENT_ON 0
#endif
int system_run_interleaved(uint64_t max_slices)
{
    ee_state_t  *ee  = ee_core_get_state();
    iop_state_t *iop = iop_core_get_state();
    g_scheduler_ee=ee;g_scheduler_iop=iop;
    /* Options apply only at cold boot. Sample once per frontend call,
     * including checkpoint restores, instead of every IOP boundary. */
    g_scheduler_service_fast=gekko2_opt_enabled(GEKKO2_OPT_EE_SERVICES);
    g_event_iop_blocks=gekko2_opt_enabled(GEKKO2_OPT_IOP_CATCHUP_BLOCKS);
#if GEKKO2_SCHEDULER_QUANTA_ENABLED
    #ifdef GEKKO2_FORCE_EVENT
#define GEKKO2_FORCE_EVENT_ON 1
    const int ee_native_schedule=1;
#else
    const int ee_native_schedule=gekko2_opt_enabled(GEKKO2_OPT_EE_JIT)&&gekko2_opt_enabled(GEKKO2_OPT_EE_BLOCKS);
#endif
#endif

    uint64_t slice = 0;
    /* Wake once per frontend timeslice, outside the EE/IOP hot loop. */
    if(arm_worker_completion_ready())ipu_service();
    for (;;) {
        /* R1346: one host plan, with native admission capped internally
         * at the original64 EE slots. Per-IOP callbacks are never deferred. */
        unsigned grant=g_scheduler_service_fast?64u:8u,done;
        if(max_slices && max_slices-slice<grant)grant=(unsigned)(max_slices-slice);
        if(!iop->halted) {
#if GEKKO2_SCHEDULER_QUANTA_ENABLED
            if(ee_native_schedule&&(GEKKO2_FORCE_EVENT_ON||gekko2_opt_enabled(GEKKO2_OPT_EVENT_SCHEDULER))) {
                unsigned width=ee_core_idle_active()?512u:64u;
                g_event_stats[0]++;g_event_stats[4]+=width;
                g_event_active=1u;system_begin_ee_quantum();
                done=ee_core_step_event_bounded_n(grant,width,system_event_catch_up,
                                                 system_event_window_limit);
                g_event_active=0u;
            } else if(ee_native_schedule) {
                system_quantum_grant=grant;system_begin_ee_quantum();
                done=ee_core_step_interleaved_n(grant,system_after_ee_quantum);
            } else done=iop_core_step_interleaved_n(grant,system_before_iop_tick);
#else
            done=iop_core_step_interleaved_n(grant,system_before_iop_tick);
#endif
        } else {
            system_before_iop_tick();done=1;
        }
        system_finish_iop_sample();
        iop_spu2_sync(iop->sched_ticks);

        if (ee->halted && iop->halted) {
            system_safe_printf("\n[+] system_run_interleaved: both cores halted after %llu slice(s)\n",
                   (unsigned long long)slice);
            system_safe_printf("    EE  halted at pc=0x%08lX after %llu instructions: %s\n",
                   (unsigned long)ee->pc, (unsigned long long)ee->instructions_executed,
                   ee->halt_reason[0] ? ee->halt_reason : "(unknown)");
            system_safe_printf("    IOP halted at pc=0x%08lX after %llu instructions: %s\n",
                   (unsigned long)iop->pc, (unsigned long long)iop->instructions_executed,
                   iop->halt_reason[0] ? iop->halt_reason : "(unknown)");
            return 1;
        }

        slice+=done;
        if (max_slices != 0 && slice >= max_slices) {
            /*
             * R1330-H: max_slices is the normal frontend timeslice quantum,
             * not an error/safety cap. main.c intentionally calls this
             * function repeatedly with an adaptive budget (typically a few
             * thousand IOP instructions) so input, presentation and logging
             * stay responsive. Printing three warning lines at every normal
             * quantum boundary floods the Wii video console and can visibly
             * alternate console text with the guest framebuffer.
             *
             * Keep the return value/EE:IOP scheduling exactly unchanged.
             * Explicit diagnostic builds can opt back into the old boundary
             * trace without making ordinary hardware builds spam every frame.
             */
#ifdef GEKKO2_TRACE_SLICE_BOUNDARIES
            system_safe_printf("\n[diag] system_run_interleaved: quantum complete (%llu)\n",
                   (unsigned long long)max_slices);
            system_safe_printf("    EE  halted=%d pc=0x%08lX\n", ee->halted, (unsigned long)ee->pc);
            system_safe_printf("    IOP halted=%d pc=0x%08lX\n", iop->halted, (unsigned long)iop->pc);
#endif
            return 0;
        }
    }
}
