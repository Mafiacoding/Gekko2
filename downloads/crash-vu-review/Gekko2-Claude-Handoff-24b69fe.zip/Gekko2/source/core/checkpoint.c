#include "core/hw/iop_spu2.h"
#include "core/hw/spu2_mixer.h"
#include "core/hw/rspu2_stream.h"
/*
 * checkpoint.c - see include/core/checkpoint.h for full format/scope
 * notes and the leak-prevention/known-limitation citations.
 */
#include "core/checkpoint.h"
#include "core/hw/iop_sio2.h"
#include "core/hw/ps2_memory_card.h"
#include "core/hw/ps2_mc_files.h"
#include "core/ee/ee_core.h"
#include "core/recompiler/ee_jit.h" /* R1317 checkpoint source/mapping invalidation */
#include "core/ee/ee_hle_thread.h"
#include "core/iop/iop_core.h"
#include "core/hw/dma.h"
#include "core/hw/ipu.h"
#include "core/hw/ee_intc.h"
#include "core/hw/ee_sio.h"
#include "core/hw/ee_timers.h"
#include "core/hw/gif.h"
#include "core/hw/gs.h"
#include "core/hw/gs_mem.h"
#include "core/hw/iop_dma.h"
#include "core/hw/iop_excb.h"
#include "core/hw/iop_hle_bios.h"
#include "core/hw/iop_hle_modules.h"
#include "core/hw/iop_hle_thread.h"
#include "core/hw/iop_module_loader.h"
#include "core/hw/iop_intc.h"
#include "core/hw/iop_hle_intr.h"
#include "core/hw/iop_timers.h"
#include "core/hw/iop_heap.h"
#include "core/hw/iop_cdrom_legacy.h"
#include "core/hw/iop_cdvd.h"
#include "core/hw/mch.h"
#include "core/hw/sif.h"
#include "core/hw/vif.h"
#include "core/hw/vu.h"
#include "core/system.h"
#include "core/hw/cdvd_config.h"

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

/* Mirrors ee_core.c's/iop_core.c's own private EE_RAM_SIZE/IOP_RAM_SIZE
 * #defines (32MB/2MB) - not exposed via any header, so re-stated here
 * under a distinct name to avoid a collision if a future round DOES
 * expose them. Scratch-buffer sizing only; the real authoritative
 * sizes always come from ee->ram_size/iop->ram_size at save time. */
#define EE_RAM_SIZE_CKPT  (32 * 1024 * 1024 + 65536)
#define IOP_RAM_SIZE_CKPT (2 * 1024 * 1024 + 65536)

static int write_block(FILE *f, const char tag[4], const void *data, uint32_t size)
{
    if (fwrite(tag, 1, 4, f) != 4) return -1;
    if (fwrite(&size, sizeof(size), 1, f) != 1) return -1;
    if (size > 0 && fwrite(data, 1, size, f) != size) return -1;
    return 0;
}

int checkpoint_save(const char *path)
{
    if(ps2_mc_present()&&(iop_sio2_transport_pending()||
       ((iop_dma_get_state()->ch[11].chcr|iop_dma_get_state()->ch[12].chcr)&0x01000000u)))return -1;
    if(!gs_mem_sync())return -1;
    iop_spu2_sync_now();
    FILE *f = fopen(path, "wb");
    if (!f) return -1;

    const char magic[4] = {'P', 'W', '2', 'K'};
    uint32_t version = 1;
    if (fwrite(magic, 1, 4, f) != 4) goto fail;
    if (fwrite(&version, sizeof(version), 1, f) != 1) goto fail;

    ee_state_t *ee = ee_core_get_state();
    iop_state_t *iop = iop_core_get_state();

    /* Fixed-layout structs, exposed via existing typed _get_state()
     * accessors (see checkpoint.h's module comment) - one block per
     * module, tag chosen to be readable in a hex dump. */
    if (write_block(f, "EES1", ee, sizeof(*ee)) < 0) goto fail;
    if (write_block(f, "ERAM", ee->ram, ee->ram_size) < 0) goto fail;
    if (write_block(f, "IOPS", iop, sizeof(*iop)) < 0) goto fail;
    if (write_block(f, "IRAM", iop->ram, iop->ram_size) < 0) goto fail;
    if (write_block(f, "DMA0", dma_get_state(), sizeof(*dma_get_state())) < 0) goto fail;
    if (write_block(f, "EINT", ee_intc_get_state(), sizeof(*ee_intc_get_state())) < 0) goto fail;
    if (write_block(f, "ESIO", ee_sio_get_state(), sizeof(*ee_sio_get_state())) < 0) goto fail;
    { ee_timers_state_t timers;ee_timers_snapshot(&timers);
      if (write_block(f, "ETMR", &timers, sizeof(timers)) < 0) goto fail; }
    if (write_block(f, "GIF0", gif_get_state(), sizeof(*gif_get_state())) < 0) goto fail;
    if (write_block(f, "GS00", gs_get_state(), sizeof(*gs_get_state())) < 0) goto fail;
    /* Round 649: GS local memory (the actual pixel/texture backing
     * store, separate from GS00's small register struct) was never
     * captured by any prior round - a real, evidenced gap found
     * while investigating why a resumed checkpoint showed non-zero
     * gif_state_t draw counters (sprites_drawn/etc, correctly
     * restored via GIF0) but a completely zeroed framebuffer: every
     * checkpoint_load() silently reset the entire 4MB gs_mem.c
     * buffer to zero because nothing ever wrote/read it. Saving it
     * here fixes that - draw counters and actual pixel content now
     * stay consistent across a save/resume boundary. */
    if (write_block(f, "GSM0", gs_mem_read_range(0,GS_MEM_SIZE), GS_MEM_SIZE) < 0) goto fail;
    if (write_block(f, "IDMA", iop_dma_get_state(), sizeof(*iop_dma_get_state())) < 0) goto fail;
    if (write_block(f, "IEXC", iop_excb_get_state(), sizeof(*iop_excb_get_state())) < 0) goto fail;
    if (write_block(f, "IBIO", iop_hle_bios_get_state(), sizeof(*iop_hle_bios_get_state())) < 0) goto fail;
    if (write_block(f, "IMOD", iop_hle_modules_get_state(), sizeof(*iop_hle_modules_get_state())) < 0) goto fail;
    if (write_block(f, "IINT", iop_intc_get_state(), sizeof(*iop_intc_get_state())) < 0) goto fail;
    /* Round 962 (task #887/937/938) fix: see iop_hle_intr.h's own
     * iop_hle_intr_get_checkpoint_blob() citation - this module's
     * static VBLANK/CDVD/DMA interrupt-handler registration table
     * (RegisterIntrHandler results) was never captured by any block
     * here before, silently resetting every real handler registration
     * back to "nothing registered" on every single checkpoint resume -
     * the exact same bug class as Round 649's GSM0 gap, Round 659's
     * ITHR gap, Round 750's ICDV gap, and Round 770's IMLD gap. */
    {
        uint32_t ihli_size = 0;
        void *ihli_blob = iop_hle_intr_get_checkpoint_blob(&ihli_size);
        if (write_block(f, "IHLI", ihli_blob, ihli_size) < 0) goto fail;
    }
    {
        iop_timers_state_t timers;iop_timers_snapshot(&timers);
        if (write_block(f,"ITMR",&timers,sizeof(timers))<0)goto fail;
    }
    /* Round 659: IOP HLE thread-scheduler state (source/hw/iop_hle_thread.c)
     * - see iop_hle_thread.h's iop_hle_thread_get_checkpoint_blob() header
     * comment for why this block was missing entirely before this round
     * (every IOP thread was silently reset to "0 threads" on every
     * checkpoint resume). */
    {
        uint32_t ithr_size = 0;
        void *ithr_blob = iop_hle_thread_get_checkpoint_blob(&ithr_size);
        if (write_block(f, "ITHR", ithr_blob, ithr_size) < 0) goto fail;
    }
    /* Round 750 (task #730) fix: see iop_cdvd.h's iop_cdvd_checkpoint_t
     * citation - this module's register/dispatch state (including the
     * disc-TYPE register) was never captured by any block here before,
     * silently resetting to fresh-init "no disc" defaults on every
     * single checkpoint resume regardless of what iop_cdvd_set_disc_
     * present() had set earlier. Same bug class as Round 649's GSM0 gap
     * and Round 659's ITHR gap directly above. */
    {
        iop_cdvd_checkpoint_t cdvd_ckpt;
        iop_cdvd_checkpoint_save(&cdvd_ckpt);
        if (write_block(f, "ICDV", &cdvd_ckpt, sizeof(cdvd_ckpt)) < 0) goto fail;
    }
    /* Round 770 (task #764) fix: see iop_module_loader.h's own
     * iop_module_loader_get_checkpoint_blob() citation - this file's
     * static `g` state (one-shot `attempted` flag, bump allocator
     * cursor, per-module entry points, trampoline/boot_info addresses)
     * was never captured by any block here before, silently resetting
     * to fresh-init "boot not yet attempted" defaults on every single
     * checkpoint resume - the exact same bug class as Round 649's GSM0
     * gap, Round 659's ITHR gap, and Round 750's ICDV gap. Confirmed
     * empirically this round: this gap caused chain_driver's "continue"
     * mode to spuriously re-run the entire one-time module-boot
     * dispatch (redispatching the IOP straight back to SYSMEM's entry
     * point) the first time IOP PC organically ran off the end of all
     * real, already-loaded module code - a checkpoint-chaining tooling
     * artifact previously misread as a real interrupt-storm/wander bug. */
    {
        uint32_t imld_size = 0;
        void *imld_blob = iop_module_loader_get_checkpoint_blob(&imld_size);
        if (write_block(f, "IMLD", imld_blob, imld_size) < 0) goto fail;
    }
    if (write_block(f, "MCH0", mch_get_state(), sizeof(*mch_get_state())) < 0) goto fail;
    if (write_block(f, "SIF0", sif_get_state(), sizeof(*sif_get_state())) < 0) goto fail;
    /* Round 771 (task #764 continuation): see sif.h's own
     * sif_get_checkpoint_extra_blob() citation - the SIF_STAT_BOOTEND
     * reassert flags were never part of sif_state_t/"SIF0" above and so
     * silently reset on every checkpoint-chained resume, permanently
     * disabling the real BOOTEND reassert mechanism mid-chain. */
    {
        uint32_t sifx_size = 0;
        void *sifx_blob = sif_get_checkpoint_extra_blob(&sifx_size);
        if (write_block(f, "SIFX", sifx_blob, sifx_size) < 0) goto fail;
    }
    if (write_block(f, "VIF0", vif0_get_state(), sizeof(*vif0_get_state())) < 0) goto fail;
    if (write_block(f, "VIF1", vif1_get_state(), sizeof(*vif1_get_state())) < 0) goto fail;
    if (write_block(f, "VU10", vu1_get_state(), sizeof(*vu1_get_state())) < 0) goto fail;

    /* Opaque blob (no typed accessor - see ee_hle_thread.h citation). */
    {
        void *blob; uint32_t blob_size;
        ee_hle_thread_get_checkpoint_blob(&blob, &blob_size);
        if (write_block(f, "EETH", blob, blob_size) < 0) goto fail;
    }

    /* IOP heap allocator: NOT a raw struct dump - g_alloclist is a
     * malloc()'d chain of nodes, so a raw byte copy would embed
     * this PROCESS's own heap pointers, which are meaningless (and
     * unsafe to dereference) in the resuming process. Use the
     * dedicated snapshot pair instead (see iop_heap.h's citation on
     * exactly why - this is the documented root cause of the
     * Round 307-447 "[R313-SIGSEGV]" resume failures this format is
     * designed to avoid repeating). */
    {
        uint32_t heap_size = iop_heap_snapshot_size();
        void *heap_buf = malloc(heap_size ? heap_size : 1);
        if (!heap_buf) goto fail;
        iop_heap_snapshot_save(heap_buf);
        int rc = write_block(f, "IHP1", heap_buf, heap_size);
        free(heap_buf);
        if (rc < 0) goto fail;
    }

    {
        uint8_t config[CDVD_CONFIG_SNAPSHOT_SIZE];cdvd_config_snapshot_save(config);
        if(write_block(f,"CNFG",config,sizeof config)<0)goto fail;
    }
    /* Optional trailing block preserves old version-1 checkpoints. */
    {
        ee_pad_checkpoint_t pad;
        ee_core_pad_checkpoint_save(&pad);
        if (write_block(f, "EEPD", &pad, sizeof(pad)) < 0) goto fail;
    }

    {
        ee_irq_checkpoint_t irq;
        ee_core_irq_checkpoint_save(&irq);
        if (write_block(f, "EIRQ", &irq, sizeof(irq)) < 0) goto fail;
    }
    {
        uint64_t ticks = ee_core_display_clock_save();
        unsigned char clock[8];
        for (unsigned n = 0; n < 8; n++) clock[n] = (unsigned char)(ticks >> (8u * n));
        if (write_block(f, "ECLK", clock, sizeof(clock)) < 0) goto fail;
    }
    if (write_block(f,"IPUS",ipu_get_state(),sizeof(ipu_state_t))<0)goto fail;
    {const rspu2_stream_state_t *stream=rspu2_stream_get_state();
     if(write_block(f,"RSPU",stream,sizeof *stream)<0)goto fail;}
    {iop_cdrom_legacy_checkpoint_t cdrom;iop_cdrom_legacy_checkpoint_save(&cdrom);
     if(write_block(f,"CDRL",&cdrom,sizeof cdrom)<0)goto fail;}
    {
      uint32_t n=iop_spu2_snapshot_size();void *blob=malloc(n);if(!blob)goto fail;
      iop_spu2_snapshot_save(blob);int result=write_block(f,"SPUS",blob,n);free(blob);
      if(result<0||write_block(f,"SPUR",spu2_mixer_get_ram(),SPU2_MIXER_RAM_SIZE)<0)goto fail;
    }
    {uint8_t protocol[IOP_PAD_PROTOCOL_BYTES];iop_sio2_pad_protocol_save(protocol);
     if(write_block(f,"PADP",protocol,sizeof protocol)<0)goto fail;}
    if(ps2_mc_present()){
        uint32_t bytes;const void *data=ps2_mc_snapshot(&bytes);
        if(write_block(f,"P2MC",data,bytes)<0)goto fail;
        data=ps2_mc_fs_snapshot(&bytes);if(write_block(f,"MCFS",data,bytes)<0)goto fail;
    }
    if (write_block(f, "END0", NULL, 0) < 0) goto fail;

    fclose(f);
    return 0;

fail:
    fclose(f);
    remove(path);
    return -1;
}

/* Reads one block's tag+size+payload. Returns 1 on success, 0 on
 * EOF/END0, -1 on I/O error or a size that doesn't fit in `cap`. */
static int read_block(FILE *f, char tag_out[4], void *buf, uint32_t cap, uint32_t *size_out)
{
    char tag[4];
    uint32_t size;
    if (fread(tag, 1, 4, f) != 4) return -1;
    if (fread(&size, sizeof(size), 1, f) != 1) return -1;
    memcpy(tag_out, tag, 4);
    *size_out = size;
    if (memcmp(tag, "END0", 4) == 0) return 0;
    if (size > cap) return -1; /* caller's buffer too small - corrupt/mismatched file */
    if (size > 0 && fread(buf, 1, size, f) != size) return -1;
    return 1;
}

int checkpoint_load(const char *path, const bios_image_t *ee_bios,
                     const bios_image_t *iop_bios, const char *iso_path)
{
    if(!gs_mem_sync())return -1;
    iop_spu2_sync_now();
    FILE *f = fopen(path, "rb");
    if (!f) return -1;

    char magic[4];
    uint32_t version;
    if (fread(magic, 1, 4, f) != 4 || memcmp(magic, "PW2K", 4) != 0) { fclose(f); return -1; }
    if (fread(&version, sizeof(version), 1, f) != 1 || version != 1) { fclose(f); return -1; }

    /* Validate the whole block sequence into scratch buffers first -
     * per checkpoint.h's contract, never partially apply a corrupt
     * file. EE/IOP RAM blocks are large (32MB/2MB), so allocate the
     * scratch buffers on the heap, not the stack. */
    ee_state_t *ee_scratch = malloc(sizeof(ee_state_t));
    iop_state_t *iop_scratch = malloc(sizeof(iop_state_t));
    uint8_t *era_scratch = malloc(EE_RAM_SIZE_CKPT);
    uint8_t *ira_scratch = malloc(IOP_RAM_SIZE_CKPT);
    uint8_t *spu_ram_scratch=NULL;
    uint8_t *mc_scratch=NULL;
    uint32_t mc_size=0;
    uint8_t *spu_state_scratch=malloc(iop_spu2_snapshot_size());
    uint8_t *gsm_scratch = malloc(GS_MEM_SIZE); /* Round 649: gs_mem.c's 4MB pixel/texture buffer - see checkpoint_save()'s citation */
    /* Peripheral scratch buffers - sized generously; read_block()
     * rejects any on-disk block that doesn't fit, so a mismatched
     * struct layout across builds fails safely instead of
     * overflowing. */
    static uint8_t generic[sizeof(vif_state_t) + 65536u];
    uint8_t eeth_blob[65536];
    uint8_t heap_blob[1 << 20];
    uint32_t era_size = 0, ira_size = 0, eeth_size = 0, heap_size = 0, gsm_size = 0;

    if (!ee_scratch || !iop_scratch || !era_scratch || !ira_scratch || !gsm_scratch || !spu_state_scratch) goto fail_alloc;

    char tag[4]; uint32_t size; int rc;

    #define EXPECT(TAGSTR, DEST, CAP, SIZEOUT) \
        do { \
            rc = read_block(f, tag, (DEST), (CAP), (SIZEOUT)); \
            if (rc <= 0 || memcmp(tag, (TAGSTR), 4) != 0) goto fail_close; \
        } while (0)

    uint32_t discard_size;
    memset(ee_scratch,0,sizeof(*ee_scratch));
    EXPECT("EES1", ee_scratch, sizeof(ee_state_t), &discard_size);
    if(discard_size<=((offsetof(ee_state_t,vu0_timing)+7u)&~7u))memset(&ee_scratch->vu0_timing,0,sizeof(ee_scratch->vu0_timing));
    EXPECT("ERAM", era_scratch, EE_RAM_SIZE_CKPT, &era_size);
    EXPECT("IOPS", iop_scratch, sizeof(iop_state_t), &discard_size);
    EXPECT("IRAM", ira_scratch, IOP_RAM_SIZE_CKPT, &ira_size);
    EXPECT("DMA0", generic, sizeof(generic), &size);
    if(size!=sizeof(dma_state_t)&&size!=offsetof(dma_state_t,vif_tag_pending)&&size!=offsetof(dma_state_t,gif_tag_pending)&&size!=offsetof(dma_state_t,gif_tag_pending)-8u)goto fail_close;
    memset(dma_get_state(),0,sizeof(dma_state_t));memcpy(dma_get_state(),generic,size);
    EXPECT("EINT", generic, sizeof(generic), &size); memcpy(ee_intc_get_state(), generic, size);
    EXPECT("ESIO", generic, sizeof(generic), &size); memcpy(ee_sio_get_state(), generic, size);
    EXPECT("ETMR", generic, sizeof(generic), &size); { ee_timers_state_t timers;ee_timers_snapshot(&timers);memcpy(&timers,generic,size);ee_timers_restore(&timers); }
    EXPECT("GIF0", generic, sizeof(generic), &size);
    uint32_t old_gif_size=offsetof(gif_state_t,image_eop_path);
    if(size!=sizeof(*gif_get_state()) && size!=offsetof(gif_state_t,clut_words) && size!=offsetof(gif_state_t,gif_q_bits) && size!=offsetof(gif_state_t,arb_owner) && size!=((offsetof(gif_state_t,arb_owner)+7u)&~7u) && size!=old_gif_size &&
       size!=old_gif_size-sizeof(uint64_t))goto fail_close;
    memset(gif_get_state(),0,sizeof(*gif_get_state()));
    memcpy(gif_get_state(),generic,size);
    if(size<=offsetof(gif_state_t,gif_q_bits))gif_get_state()->gif_q_bits=UINT32_C(0x3f800000);
    if(size==old_gif_size-sizeof(uint64_t)) {
        gif_state_t *gif=gif_get_state();
        gif->sprite_pos16=(uint64_t)(uint32_t)(gif->v0x*16)
            |((uint64_t)(uint32_t)(gif->v0y*16)<<32);
    }
    EXPECT("GS00", generic, sizeof(generic), &size); memcpy(gs_get_state(), generic, size);
    EXPECT("GSM0", gsm_scratch, GS_MEM_SIZE, &gsm_size);
    EXPECT("IDMA", generic, sizeof(generic), &size); memcpy(iop_dma_get_state(), generic, size);
    EXPECT("IEXC", generic, sizeof(generic), &size); memcpy(iop_excb_get_state(), generic, size);
    EXPECT("IBIO", generic, sizeof(generic), &size); memcpy(iop_hle_bios_get_state(), generic, size);
    EXPECT("IMOD", generic, sizeof(generic), &size); memcpy(iop_hle_modules_get_state(), generic, size);
    EXPECT("IINT", generic, sizeof(generic), &size); memcpy(iop_intc_get_state(), generic, size);
    {
        uint32_t ihli_cap = 0;
        void *ihli_dest = iop_hle_intr_get_checkpoint_blob(&ihli_cap);
        EXPECT("IHLI", generic, sizeof(generic), &size);
        if (size != ihli_cap) goto fail_close; /* struct-layout mismatch - fail safely, per this file's own documented contract */
        memcpy(ihli_dest, generic, size);
    }
    {
        iop_timers_state_t timers;
        EXPECT("ITMR",generic,sizeof(generic),&size);
        if(size!=sizeof(timers))goto fail_close;
        memcpy(&timers,generic,size);iop_timers_restore(&timers);
    }
    {
        uint32_t ithr_cap = 0;
        void *ithr_dest = iop_hle_thread_get_checkpoint_blob(&ithr_cap);
        EXPECT("ITHR", generic, sizeof(generic), &size);
        if (size != ithr_cap) goto fail_close; /* struct-layout mismatch - fail safely, per this file's own documented contract */
        memcpy(ithr_dest, generic, size);
    }
    EXPECT("ICDV", generic, sizeof(generic), &size);
    {
        iop_cdvd_checkpoint_t cdvd_ckpt;
        if (size != sizeof(cdvd_ckpt)) goto fail_close; /* struct-layout mismatch - fail safely, per this file's own documented contract */
        memcpy(&cdvd_ckpt, generic, size);
        iop_cdvd_checkpoint_load(&cdvd_ckpt);
    }
    {
        uint32_t imld_cap = 0;
        void *imld_dest = iop_module_loader_get_checkpoint_blob(&imld_cap);
        EXPECT("IMLD", generic, sizeof(generic), &size);
        if (size != imld_cap) goto fail_close; /* struct-layout mismatch - fail safely, per this file's own documented contract */
        memcpy(imld_dest, generic, size);
    }
    EXPECT("MCH0", generic, sizeof(generic), &size); memcpy(mch_get_state(), generic, size);
    EXPECT("SIF0", generic, sizeof(generic), &size); memcpy(sif_get_state(), generic, size);
    {
        uint32_t sifx_cap = 0;
        void *sifx_dest = sif_get_checkpoint_extra_blob(&sifx_cap);
        EXPECT("SIFX", generic, sizeof(generic), &size);
        if (size != sifx_cap) goto fail_close; /* struct-layout mismatch - fail safely, per this file's own documented contract */
        memcpy(sifx_dest, generic, size);
    }
    EXPECT("VIF0", generic, sizeof(generic), &size); if (size != sizeof(*vif0_get_state()) && size != offsetof(vif_state_t,direct_sent_words) && size != ((offsetof(vif_state_t,direct_sent_words)+7u)&~7u)) goto fail_close; memset(vif0_get_state(),0,sizeof(*vif0_get_state())); memcpy(vif0_get_state(), generic, size); if(size<sizeof(vif_state_t))vif0_get_state()->direct_sent_words=vif0_get_state()->direct_hl=0;
    EXPECT("VIF1", generic, sizeof(generic), &size); if (size != sizeof(*vif1_get_state()) && size != offsetof(vif_state_t,direct_sent_words) && size != ((offsetof(vif_state_t,direct_sent_words)+7u)&~7u)) goto fail_close; memset(vif1_get_state(),0,sizeof(*vif1_get_state())); memcpy(vif1_get_state(), generic, size); if(size<sizeof(vif_state_t))vif1_get_state()->direct_sent_words=vif1_get_state()->direct_hl=0;
    EXPECT("VU10", generic, sizeof(generic), &size);
    if(size>sizeof(*vu1_get_state()))goto fail_close;
    memset(vu1_get_state(),0,sizeof(*vu1_get_state()));
    memcpy(vu1_get_state(), generic, size);
    if(size<=((offsetof(vu1_state_t,timing)+7u)&~7u))memset(&vu1_get_state()->timing,0,sizeof(vu1_get_state()->timing));
    if(size<=offsetof(vu1_state_t,xgkick_last_cycle) && vu1_get_state()->xgkick_pending) {
        vu1_get_state()->xgkick_ring_qwords=VU1_MEM_SIZE/16u;
        vu1_get_state()->xgkick_cycle_credit=1u;
        vu1_get_state()->xgkick_last_cycle=vu1_get_state()->pipeline.cycle;
    }
    EXPECT("EETH", eeth_blob, sizeof(eeth_blob), &eeth_size);
    EXPECT("IHP1", heap_blob, sizeof(heap_blob), &heap_size);

    /* Old snapshots terminate here. Missing bindings stay disconnected
     * rather than inheriting host state from an unrelated running game. */
    ee_pad_checkpoint_t pad = {{0}, {{0}}, 0};
    ee_irq_checkpoint_t irq = {0, 0};
    uint64_t display_ticks = 0; /* Old snapshots have no recoverable independent phase. */
    uint8_t config[CDVD_CONFIG_SNAPSHOT_SIZE]={0};
    ipu_state_t ipu={0};
    static rspu2_stream_state_t stream;memset(&stream,0,sizeof stream);
    iop_cdrom_legacy_checkpoint_t cdrom={0};
    uint8_t protocol[IOP_PAD_PROTOCOL_BYTES]={0};
    unsigned seen = 0;
    uint8_t fs_scratch[4096] __attribute__((aligned(4)));uint32_t fs_size=0;
    for (;;) {
        static unsigned char extra[sizeof(rspu2_stream_state_t)>sizeof(ipu_state_t)?sizeof(rspu2_stream_state_t):sizeof(ipu_state_t)];
        long sound_pos=ftell(f);char sound_tag[4];
        if(sound_pos<0||fread(sound_tag,1,4,f)!=4||fseek(f,sound_pos,SEEK_SET))goto fail_close;
        if(!memcmp(sound_tag,"MCFS",4)){
          if(seen&2048u)goto fail_close;
          rc=read_block(f,tag,fs_scratch,sizeof fs_scratch,&fs_size);
          if(rc!=1||!ps2_mc_fs_snapshot_valid(fs_scratch,fs_size))goto fail_close;
          seen|=2048u;continue;
        }
        if(!memcmp(sound_tag,"P2MC",4)){
          if(seen&1024u)goto fail_close;
          mc_scratch=malloc(32u+PS2_MC_IMAGE_BYTES);if(!mc_scratch)goto fail_close;
          rc=read_block(f,tag,mc_scratch,32u+PS2_MC_IMAGE_BYTES,&mc_size);
          if(rc!=1||!ps2_mc_snapshot_valid(mc_scratch,mc_size))goto fail_close;
          seen|=1024u;continue;
        }
        if(!memcmp(sound_tag,"SPUR",4)){
          if(seen&128u)goto fail_close;
          spu_ram_scratch=malloc(SPU2_MIXER_RAM_SIZE);if(!spu_ram_scratch)goto fail_close;
          rc=read_block(f,tag,spu_ram_scratch,SPU2_MIXER_RAM_SIZE,&size);
          if(rc!=1||size!=SPU2_MIXER_RAM_SIZE)goto fail_close;seen|=128u;continue;
        }
        if(!memcmp(sound_tag,"SPUS",4)){
          if(seen&256u)goto fail_close;
          rc=read_block(f,tag,spu_state_scratch,iop_spu2_snapshot_size(),&size);
          if(rc!=1||size!=iop_spu2_snapshot_size()||!iop_spu2_snapshot_valid(spu_state_scratch,iop_scratch->sched_ticks,ira_size))goto fail_close;
          seen|=256u;continue;
        }
        rc = read_block(f, tag, extra, sizeof(extra), &size);
        if (rc <= 0) break;
        if (memcmp(tag, "EEPD", 4) == 0 && !(seen & 1u) && size == sizeof(pad)) {
            memcpy(&pad, extra, sizeof(pad)); seen |= 1u;
        } else if (memcmp(tag, "EIRQ", 4) == 0 && !(seen & 2u) && size == sizeof(irq)) {
            memcpy(&irq, extra, sizeof(irq)); seen |= 2u;
            if (irq.intc_delay > 4u || irq.intc_armed > 1u ||
                (!irq.intc_armed && irq.intc_delay)) goto fail_close;
        } else if (memcmp(tag, "ECLK", 4) == 0 && !(seen & 4u) && size == 8u) {
            for (unsigned n = 0; n < 8; n++) display_ticks |= (uint64_t)extra[n] << (8u * n);
            seen |= 4u;
        } else if (memcmp(tag,"CNFG",4)==0 && !(seen&8u) && size==sizeof config) {
            if(!cdvd_config_snapshot_valid(extra))goto fail_close;
            memcpy(config,extra,sizeof config);seen|=8u;
        } else if(memcmp(tag,"IPUS",4)==0&&!(seen&16u)&&size==sizeof ipu){
            memcpy(&ipu,extra,sizeof ipu);if(!ipu_state_valid(&ipu))goto fail_close;seen|=16u;
        } else if(memcmp(tag,"RSPU",4)==0&&!(seen&32u)&&size==sizeof stream){
            memcpy(&stream,extra,sizeof stream);if(!rspu2_stream_state_valid(&stream))goto fail_close;seen|=32u;
        } else if(memcmp(tag,"CDRL",4)==0&&!(seen&64u)&&size==sizeof cdrom){
            memcpy(&cdrom,extra,sizeof cdrom);if(!iop_cdrom_legacy_checkpoint_valid(&cdrom))goto fail_close;seen|=64u;
        } else if(memcmp(tag,"PADP",4)==0&&!(seen&512u)&&size==sizeof protocol){
            if(!iop_sio2_pad_protocol_valid(extra))goto fail_close;
            memcpy(protocol,extra,sizeof protocol);seen|=512u;
        } else goto fail_close;
    }
    if (rc != 0 || memcmp(tag, "END0", 4) != 0 || size != 0u) goto fail_close;

    if((seen&2048u)&&!(seen&1024u))goto fail_close;
    if(!!(seen&128u)!=!!(seen&256u))goto fail_close;
    if((seen&64u)&&cdrom.disc_mounted){iso_image_t probe;
        if(!iso_path||iso_open(iso_path,&probe))goto fail_close;iso_close(&probe);}
    fclose(f);

    /* All blocks read and size-validated - now safe to apply. Order
     * matters: raw struct copies first (this clobbers ee_scratch's/
     * iop_scratch's now-stale `ram`/`bios` pointer VALUES with
     * whatever they happened to be in the WRITING process - fine,
     * since we overwrite both fields explicitly right after), then
     * every _bind_*()/_rebind_*() call from include/core/system.h's
     * documented restore-time checklist. */
    if(mc_scratch){if(ps2_mc_snapshot_load(mc_scratch,mc_size))goto fail_alloc;free(mc_scratch);mc_scratch=NULL;}
    else if(ps2_mc_eject())goto fail_alloc;
    if((seen&2048u)&&ps2_mc_fs_snapshot_load(fs_scratch,fs_size))goto fail_alloc;
    ee_state_t *ee = ee_core_get_state();
    iop_state_t *iop = iop_core_get_state();
    memcpy(ee, ee_scratch, sizeof(*ee));
    memcpy(iop, iop_scratch, sizeof(*iop));
    free(ee_scratch);
    free(iop_scratch);

    ee->ram = era_scratch; /* ownership transferred - this becomes the live EE RAM buffer */
    ee->ram_size = era_size;
    ee->bios = ee_bios;
    /* R1317: process-local precise JIT stamps are not checkpoint state. */
    ee_jit_notify_physical_write(0u, ee->ram_size);
    ee_jit_notify_mapping_change();
    iop->ram = ira_scratch; /* ownership transferred - live IOP RAM buffer */
    iop->ram_size = ira_size;
    iop->bios = iop_bios;

    dma_bind_ee_ram(ee->ram, ee->ram_size);
    dma_bind_scratchpad(ee->scratch, sizeof(ee->scratch));
    iop_dma_bind_iop_ram(iop->ram, iop->ram_size);
    ee_core_rebind_dma_sinks();
    ee_core_pad_checkpoint_load(&pad);
    if(seen&512u)iop_sio2_pad_protocol_load(protocol);
    ee_core_irq_checkpoint_load(&irq);
    ee_core_display_clock_load(display_ticks);
    cdvd_config_snapshot_load(config);
    ipu_restore(&ipu);
    rspu2_stream_checkpoint_load(&stream);
    if(seen&256u){iop_spu2_snapshot_load(spu_state_scratch);memcpy(spu2_mixer_get_ram(),spu_ram_scratch,SPU2_MIXER_RAM_SIZE);}
    else iop_spu2_restore_legacy(iop->sched_ticks);
    free(spu_ram_scratch);free(spu_state_scratch);
    system_rebind_iop_bridge();
    if (iso_path) {
        if(!(seen&64u)||cdrom.disc_mounted)iop_cdrom_legacy_rebind_iso(iso_path);
        else iop_cdrom_legacy_unmount_iso();
        iop_cdvd_rebind_iso(iso_path);
    }

    {
        void *blob; uint32_t blob_cap;
        ee_hle_thread_get_checkpoint_blob(&blob, &blob_cap);
        if (blob_cap == eeth_size) memcpy(blob, eeth_blob, eeth_size);
    }
    if(seen&64u)iop_cdrom_legacy_checkpoint_load(&cdrom);
    iop_heap_snapshot_load(heap_blob, heap_size);
    if (gsm_size == GS_MEM_SIZE && !gs_mem_write_range(0,gsm_scratch,GS_MEM_SIZE)) goto fail_alloc;
    free(gsm_scratch);

    #undef EXPECT
    return 0;

fail_close:
    fclose(f);
fail_alloc:
    free(ee_scratch);
    free(iop_scratch);
    free(era_scratch);
    free(ira_scratch);
    free(gsm_scratch);
    free(spu_ram_scratch);free(spu_state_scratch);
    free(mc_scratch);
    return -1;
}
