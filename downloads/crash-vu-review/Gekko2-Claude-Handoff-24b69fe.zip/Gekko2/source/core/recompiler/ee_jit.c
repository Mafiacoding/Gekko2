#include "core/recompiler/cache_profile.h"
#include "core/recompiler/experimental_options.h"
#include "core/recompiler/ppc_code_cache.h"
#include "core/recompiler/dynarec_config.h"
/*
 * ee_jit.c - see include/core/recompiler/ee_jit.h for the full design
 * rationale and safety model. Short version: this compiles single
 * pure-ALU MIPS instructions into cached, natively-executing PPC750
 * machine code (via ppc_dynarec.c), keyed by instruction ENCODING
 * (not address, since none of the supported opcodes are memory- or
 * PC-dependent) so the same compiled block is reused for every future
 * occurrence of that exact instruction word anywhere in memory.
 */

#include "core/recompiler/ee_jit.h"
#include "core/recompiler/ppc_dynarec.h"
#include <stdlib.h>
#include <string.h>
#ifdef GEKKO2_SPEED_STUB
extern uint32_t ee_quiet_left;
#endif
#include <stddef.h> /* offsetof, for the _Static_assert layout checks below */

/* Round 890 (task #874): compile-time enforcement of the layout
 * contract ppc_dynarec.c's HI_IDX/LO_IDX (see that file) depends on:
 * `gpr[32]` must be the very FIRST field of ee_state_t (so `&st->gpr[0]`
 * is also byte offset 0 of the whole struct - this was already relied
 * on before this round, just never asserted), and `hi`/`lo` must sit
 * immediately after it with no padding, so that ppc_dynarec.c's flat
 * "register 32 = HI, register 33 = LO" addressing lands exactly on the
 * real fields. If ee_core.h's struct layout ever changes, this fires a
 * compile error here instead of silently corrupting HI/LO (or some
 * unrelated field) the next time a MULT/DIV/MFHI/MTHI/MFLO/MTLO
 * instruction gets JIT-compiled. */
_Static_assert(offsetof(ee_state_t,cop0)==556,"R1281 native COP0 prefix offset changed");
_Static_assert(offsetof(ee_state_t, gpr) == 0,
               "ppc_dynarec.c's context pointer is &st->gpr[0] - gpr must be ee_state_t's first field");
_Static_assert(offsetof(ee_state_t, hi) == sizeof(ee_reg128_t) * 32,
               "ppc_dynarec.c's HI_IDX (32) assumes hi sits immediately after gpr[32]");
_Static_assert(offsetof(ee_state_t, lo) == sizeof(ee_reg128_t) * 33,
               "ppc_dynarec.c's LO_IDX (33) assumes lo sits immediately after hi");

/* Round 894 (task #878): J/JAL/JR/JALR are the first opcodes whose
 * generated code touches ee_state_t fields OTHER than the flat
 * gpr[32]+hi+lo register array - they need to read `exc_this_pc` (to
 * compute J/JAL's absolute target at RUNTIME, since this dynarec's
 * cache is keyed by instruction encoding, not address - see
 * ppc_dynarec.c's EXC_THIS_PC_OFFSET comment) and write `next_pc`/
 * `branch_pending` (to hand control-flow back to ee_step() exactly the
 * way its own BRANCH_TO() macro does). This works because CTX_REG
 * (r3) is `&st->gpr[0]`, which - per the _Static_assert above - is
 * also byte offset 0 of the WHOLE ee_state_t struct, so any field is
 * reachable as a plain lwz/stw/stb at its real offset. These three
 * asserts pin those offsets against ee_core.h's actual layout at
 * COMPILE TIME (on whichever target actually builds this file, host or
 * GEKKO, so any host/PPC struct-padding difference would be caught
 * here too) - if ee_core.h ever moves pc/next_pc/branch_pending/
 * exc_this_pc, this fires a compile error instead of J/JAL/JR/JALR
 * silently corrupting control flow the next time one gets JIT-compiled. */
_Static_assert(offsetof(ee_state_t, next_pc) == 548,
               "ppc_dynarec.c's NEXT_PC_OFFSET assumes next_pc sits at this exact byte offset");
_Static_assert(offsetof(ee_state_t, branch_pending) == 684,
               "ppc_dynarec.c's BRANCH_PENDING_OFFSET assumes branch_pending sits at this exact byte offset");
_Static_assert(offsetof(ee_state_t, exc_this_pc) == 1456,
               "ppc_dynarec.c's EXC_THIS_PC_OFFSET assumes exc_this_pc sits at this exact byte offset");
_Static_assert(offsetof(ee_state_t, exc_raised_this_step) == 1461,
               "ppc_dynarec.c's EXC_RAISED_OFFSET must match the EE state");
_Static_assert(offsetof(ee_state_t, mem_tlb_miss) == 1462,
               "ppc_dynarec.c's MEM_TLB_MISS_OFFSET must match the EE state");
/* Round 896 (task #880): the "likely" branches (BLTZL/BGEZL/BEQL/BNEL/
 * BLEZL/BGTZL) are this dynarec's first opcodes to WRITE ee_state_t.pc
 * directly (every prior branch/jump opcode only ever wrote next_pc/
 * branch_pending) - see ppc_dynarec.c's PC_OFFSET comment for why the
 * not-taken/annulled case needs this. */
_Static_assert(offsetof(ee_state_t, pc) == 544,
               "ppc_dynarec.c's PC_OFFSET assumes pc sits at this exact byte offset");
/* R1249: pointer-dependent offsets describe the 32-bit PPC ABI only.
 * Host interpreter builds use 64-bit pointers and never execute PPC code. */
#ifdef GEKKO
/* R1173: direct generated-PPC KSEG0/KSEG1 RAM load fast path. */
_Static_assert(offsetof(ee_state_t, ram) == 10480, "R1173 RAM_PTR_OFFSET layout mismatch");
_Static_assert(offsetof(ee_state_t, ram_size) == 10484, "R1173 RAM_SIZE_OFFSET layout mismatch");
#endif
_Static_assert(offsetof(ee_state_t, mem_tlb_miss) == 1462, "R1173 MEM_TLB_MISS_OFFSET layout mismatch");

/* Round 902 (task #884): MFC1/CFC1/MTC1/CTC1/MOV.S/ABS.S/NEG.S are this
 * dynarec's first opcodes to touch ee_state_t's COP1 (FPU) fields. */
_Static_assert(offsetof(ee_state_t, fpr) == 1464,
               "ppc_dynarec.c's REG_FPR() assumes fpr[0] sits at this exact byte offset");
_Static_assert(offsetof(ee_state_t, fcr31) == 1592,
               "ppc_dynarec.c's FCR31_OFFSET assumes fcr31 sits at this exact byte offset");
_Static_assert(offsetof(ee_state_t, acc) == 1596,
               "ppc_dynarec.c's ACC_OFFSET assumes acc sits at this exact byte offset");

/* Round 907 (task #892): VADD/VSUB/VMUL (COP2/VU0 macro mode) are this
 * dynarec's first opcodes to touch ee_state_t's VU0 vector-register
 * file (vu0_vf[32][4], distinct from and much larger than the scalar
 * COP1 fpr[32] above). */
_Static_assert(offsetof(ee_state_t, vu0_vf) == 1728,
               "ppc_dynarec.c's VU0_VF_OFF() assumes vu0_vf[0][0] sits at this exact byte offset");
_Static_assert(offsetof(ee_state_t, vu0_mem) == 2240,
               "ppc_dynarec.c's VU0_MEM_OFFSET assumes vu0_mem[0] sits at this exact byte offset");

#define EE_JIT_CACHE_SLOTS 8192u /* power of two - see ee_jit_cache_lookup()/insert() */

typedef struct {
    uint32_t     instr; /* only meaningful when fn != NULL */
    ppc_block_fn fn;    /* NULL = empty slot */
} ee_jit_cache_slot_t;

static ee_jit_cache_slot_t g_cache[EE_JIT_CACHE_SLOTS];
static uint32_t g_cache_count = 0;
static uint64_t g_jit_executed = 0;

/* R1161: tiny direct-mapped L1 in front of the open-addressed cache.
 * R1160 measured ~28.26M cache hits for only ~2K misses, so the hot cost is
 * no longer compilation but doing the full hash/probe lookup on virtually
 * every EE instruction.  This L1 is only a lookup accelerator: it never owns
 * code buffers and a miss falls through to the exact old cache path. */
#define EE_JIT_L1_SLOTS 2048u
typedef struct { uint32_t instr; ppc_block_fn fn; } ee_jit_l1_slot_t;
static ee_jit_l1_slot_t g_l1[EE_JIT_L1_SLOTS];

/* R1168: enlarged hot caches after on-target profiling showed millions of
 * avoidable L0 conflict misses.  Keep exact R1162 semantics/SMC tagging; only
 * capacity changes (L0 1K -> 16K, L1 256 -> 2K).
 *
 * R1162: PC-tagged L0 trace cache.  R1160/R1161 showed >93% of EE
 * instructions already execute through the JIT and that the code cache is
 * overwhelmingly hot.  The remaining front-end work on every instruction
 * was still: decode the opcode enough for ee_jit_opcode_supported(), hash
 * the 32-bit instruction word, then probe the instruction-keyed L1.
 *
 * A real multi-instruction block JIT cannot simply skip ee_step()'s
 * per-instruction epilogue: this tree has prior regressions proving timer,
 * VBLANK, RPC and interrupt cadence matters at each genuine EE boundary.
 * This L0 is the safe first half of block formation: key by execution PC and
 * cache the already-resolved native function, while STILL executing exactly
 * one EE instruction and the exact old epilogue per call.  `instr` is part
 * of the tag and is re-fetched by ee_step() before this lookup, so SMC/overlay
 * replacement is detected immediately and falls back to the normal resolver. */
#define EE_JIT_PC_L0_SLOTS 16384u
typedef struct { uint32_t pc, instr; ppc_block_fn fn; uint8_t rejected; } ee_jit_pc_l0_slot_t;
static ee_jit_pc_l0_slot_t g_pc_l0[EE_JIT_PC_L0_SLOTS];
static uint64_t g_pc_l0_hits = 0, g_pc_l0_misses = 0;
static uint64_t g_pc_l0_rejected_hits = 0, g_compile_attempts = 0;
/* Deterministically unsupported encodings recur at many different PCs. */
typedef struct { uint32_t instr; uint8_t valid; } ee_rejected_slot;
static ee_rejected_slot g_ee_rejected[64];

static inline uint32_t ee_jit_pc_l0_index(uint32_t pc)
{
    return ((pc >> 2) ^ (pc >> 12)) & (EE_JIT_PC_L0_SLOTS - 1u);
}

static inline uint32_t ee_jit_l1_index(uint32_t instr)
{
    return ((instr >> 2) ^ (instr >> 11) ^ instr) & (EE_JIT_L1_SLOTS - 1u);
}

/* These three helpers are only reachable from the GEKKO branch of
 * ee_jit_try_execute_one() below (see that function's host-safety-gate
 * comment) - wrapped in #ifdef GEKKO here too so host-native builds
 * (which never call them) don't warn about unused static functions. */
#ifdef GEKKO

/* Whether `instr` is one of the MIPS opcodes ppc_dynarec_translate_one()
 * currently supports: ADDIU (op 0x09); SLTI/SLTIU (op 0x0A/0x0B); LUI
 * (op 0x0F, Round 887b); SPECIAL (op 0x00) ADDU/SUBU/AND/OR/XOR/NOR/
 * SLT/SLTU (funct 0x21/0x23-0x27/0x2A/0x2B); SLL/SRL/SRA/SLLV/SRLV/SRAV
 * (funct 0x00/0x02-0x04/0x06/0x07, Round 888); MOVZ/MOVN (funct
 * 0x0A/0x0B, Round 889); MFHI/MTHI/MFLO/MTLO (funct 0x10-0x13) and
 * MULT/MULTU/DIV/DIVU (funct 0x18/0x19/0x1A/0x1B), added in Round 890
 * now that HI/LO have somewhere real to live (see HI_IDX/LO_IDX in
 * ppc_dynarec.c); LW/SW (op 0x23/0x2B), new in Round 891 - this
 * dynarec's first opcodes that call a real C function
 * (ee_mem_read32/ee_mem_write32) rather than just moving bits between
 * the context array and PPC registers (see ppc_dynarec.c's
 * ADDR_EE_MEM_READ32/WRITE32 comment for the call-emission mechanism);
 * LB/LBU/LH/LHU/LWU/SB/SH (op 0x20/0x24/0x21/0x25/0x27/0x28/0x29),
 * new in Round 892 - the same call-emission mechanism extended to the
 * rest of the base-ISA byte/halfword/unsigned-word loads and stores;
 * LD/SD (op 0x37/0x3F), new in Round 893 - the same mechanism one
 * more time, now handling a genuine 64-bit callee value via a PowerPC
 * EABI register PAIR (r3:r4 for LD's return, r5:r6 for SD's argument)
 * instead of a single 32-bit register (see ppc_dynarec.c's
 * ADDR_EE_MEM_READ64/WRITE64 comment) - this completes the full
 * base-ISA integer load/store family; and J/JAL (op 0x02/0x03) and
 * JR/JALR (SPECIAL funct 0x08/0x09), new in Round 894 - the full set
 * of unconditional control-transfer opcodes, this dynarec's first
 * opcodes that touch ee_state_t fields other than the gpr/hi/lo
 * register array (exc_this_pc/next_pc/branch_pending - see
 * ppc_dynarec.c's EXC_THIS_PC_OFFSET/NEXT_PC_OFFSET/
 * BRANCH_PENDING_OFFSET comment for why that's safe under this
 * dynarec's instruction-encoding-keyed cache). BEQ/BNE/BLEZ/BGTZ (op
 * 0x04-0x07), new in Round 895 - four of the six non-REGIMM conditional
 * branches, done WITHOUT any real PPC branch instruction (an all-0s/
 * all-1s "taken" mask blended into next_pc/branch_pending, the same
 * technique MOVZ/MOVN already used for conditional register writes -
 * see ppc_dynarec.c's emit_branch_blend() comment). BLTZ/BGEZ (REGIMM,
 * op 0x01, gated on rt==0x00/0x01 - REGIMM's rt field selects which of
 * several unrelated sub-opcodes this really is, so unlike every opcode
 * above it can't be pre-filtered on op alone) and the "likely" variants
 * of every conditional branch (BLTZL/BGEZL via REGIMM rt==0x02/0x03,
 * BEQL/BNEL op 0x14/0x15, BLEZL/BGTZL op 0x16/0x17), new in Round 896 -
 * these reuse emit_branch_blend_likely(), a 22-instruction sibling of
 * emit_branch_blend() that additionally blends ee_state_t.pc itself on
 * the not-taken path, matching the real R5900's delay-slot-annulment
 * semantics for "likely" branches (see ppc_dynarec.c's PC_OFFSET and
 * emit_branch_blend_likely() comments). ADDI (op 0x08, joins ADDIU
 * unchanged - no overflow trap, matching ee_core.c's own documented
 * simplification) and ANDI/ORI/XORI (op 0x0C-0x0E, zero-extended-
 * immediate 64-bit bitwise ops), new in Round 897 - the remaining ALU
 * immediates, closing out the base-ISA immediate-arithmetic/logical
 * family (SLTI/SLTIU/LUI were already covered; DADDI/DADDIU's 64-bit
 * family is scoped for a future round alongside DADD/DSUB/DSLL/DSRL/
 * DSRA). DADD/DADDU/DSUB/DSUBU (funct 0x2C-0x2F) and DSLL/DSRL/DSRA
 * (funct 0x38/0x3A/0x3B), new in Round 898 - the first genuinely
 * 64-bit-native register-register opcodes this dynarec compiles (no
 * 32-bit-compute-then-sign-extend shortcut available, unlike ADDU/SUBU/
 * SLL/SRL/SRA above): synthesized from 32-bit PPC750 primitives via the
 * standard multi-word add-with-carry/subtract-with-borrow idiom (new
 * addc/adde encoders, paired with the existing subfc/subfe from Round
 * 886) for DADD/DSUB, and a "shift each half, OR in the bits that
 * crossed the hi/lo boundary from the other half" idiom (reusing Round
 * 888's existing slw/srw/sraw encoders, no new ones needed) for DSLL/
 * DSRL/DSRA - see ppc_dynarec.c's own comments on both dispatch blocks
 * for the full derivation. DSLL32/DSRL32/DSRA32 (the sa+32 range) are
 * NOT included this round, left for a future increment.
 *
 * LWL/LWR/SWL/SWR (op 0x22/0x26/0x2A/0x2E) and LQ/SQ (op 0x1E/0x1F),
 * new in Round 900 - the EE-specific unaligned-word and 128-bit load/
 * store family. LWL/LWR/SWL/SWR reproduce ee_core.c's per-shift lookup
 * tables as runtime register arithmetic instead of literal tables (see
 * ppc_dynarec.c's own dispatch-block comment for the exact formulas);
 * SWL/SWR are this dynarec's first opcodes that call a real C function
 * TWICE in one block (read-merge-write); LQ/SQ are its first that call
 * ee_mem_read64/write64 twice in one block, to cover the EE's real
 * 128-bit register width (a new REG_HI1/REG_LO1 addressing pair reaches
 * the upper 64 bits, `ud1`, that every earlier opcode left completely
 * alone).
 *
 * COP1/FPU data-movement and bit-level opcodes (op 0x11, `rs` selecting
 * MFC1/CFC1/MTC1/CTC1, or `rs`==0x10/COP1.S with `funct` selecting ABS.S/
 * MOV.S/NEG.S), new in Round 902 - deliberately scoped to exclude any
 * opcode needing real floating-point arithmetic (ADD.S/SUB.S/MUL.S/
 * DIV.S/SQRT.S/etc, plus CVT.W.S/CVT.S.W and the BC1 branch family),
 * which need genuine PPC750 FPU instructions and PCSX2's own overflow/
 * underflow clamping ported faithfully - saved for a later round in this
 * arc. Every opcode here operates on FPR/GPR/FCR31 raw 32-bit bit
 * patterns with plain integer loads/stores/logical ops, matching
 * ee_core.c's own case bodies exactly - no float hardware touched at
 * all. New REG_FPR()/FCR31_OFFSET/ACC_OFFSET addressing constants reach
 * ee_state_t's COP1 fields the same "any field is a plain lwz/stw at its
 * real offset from &gpr[0]" way as every other *_OFFSET constant.
 *
 * Kept in sync by hand with translate_one()'s own dispatch - see
 * that function's own comments for the authoritative list. This is a
 * cheap pre-filter so the (much more expensive) cache lookup/compile
 * path is never attempted for the vast majority of real instructions
 * ppc_dynarec.c can't handle yet (branches, MMI, COP0/2, FPU arithmetic,
 * ...). */
_Static_assert(offsetof(ee_state_t,sa_reg)==552,"EE SA prefix layout");
static int ee_jit_opcode_supported(uint32_t instr)
{
    uint32_t op = (instr >> 26) & 0x3Fu;
    if(op==0x10u){
        unsigned rs=(instr>>21)&31u,rd=(instr>>11)&31u;
        /* R1316: MTC0 EntryHi changes the active ASID/mapping. Keep this
         * one form scalar so the authoritative COP0 case bumps the epoch. */
        if(rs==4u&&rd==10u)return 0;
        return rs==0u||rs==4u;
    }
    if (op == 0x18u || op == 0x19u) return 1; /* R1268 DADDI/DADDIU */
    if (op == 0x08u || op == 0x09u) return 1; /* ADDI (Round 897) / ADDIU */
    if (op == 0x0Au || op == 0x0Bu) return 1; /* SLTI / SLTIU */
    if (op == 0x0Cu || op == 0x0Du || op == 0x0Eu) return 1; /* ANDI / ORI / XORI (Round 897) */
    if (op == 0x0Fu) return 1; /* LUI */
    if (op == 0x1Eu || op == 0x1Fu) return 1; /* LQ / SQ (Round 900) */
    if (op == 0x22u || op == 0x26u) return 1; /* LWL / LWR (Round 900) */
    if (op == 0x2Au || op == 0x2Eu) return 1; /* SWL / SWR (Round 900) */
    if (op == 0x20u || op == 0x24u) return 1; /* LB / LBU (Round 892) */
    if (op == 0x21u || op == 0x25u) return 1; /* LH / LHU (Round 892) */
    if (op == 0x23u) return 1; /* LW (Round 891) */
    if (op == 0x27u) return 1; /* LWU (Round 892) */
    if (op == 0x28u || op == 0x29u) return 1; /* SB / SH (Round 892) */
    if (op == 0x2Bu) return 1; /* SW (Round 891) */
    if (op == 0x37u) return 1; /* LD (Round 893) */
    if (op == 0x3Fu) return 1; /* SD (Round 893) */
    if (op == 0x02u) return 1; /* J (Round 894) */
    if (op == 0x03u) return 1; /* JAL (Round 894) */
    if (op == 0x04u || op == 0x05u) return 1; /* BEQ / BNE (Round 895) */
    if (op == 0x06u || op == 0x07u) return 1; /* BLEZ / BGTZ (Round 895) */
    if (op == 0x14u || op == 0x15u) return 1; /* BEQL / BNEL (Round 896) */
    if (op == 0x16u || op == 0x17u) return 1; /* BLEZL / BGTZL (Round 896) */
    if (op == 0x01u) {
        unsigned trap=(instr>>16)&31u;
        if(trap==8u||trap==9u||trap==10u||trap==11u||trap==12u||trap==14u)return 1;
        /* REGIMM: rt selects the real sub-opcode. R1313 admits the
         * four link variants already implemented by ppc_dynarec.c; keeping
         * them blocked here silently forced scalar fallback on Wii. */
        uint32_t rt = (instr >> 16) & 0x1Fu;
        switch (rt) {
        case 0x18: case 0x19: /* R1270 MTSAB/MTSAH */
        case 0x00: case 0x01: /* BLTZ / BGEZ */
        case 0x02: case 0x03: /* BLTZL / BGEZL */
        case 0x10: case 0x11: /* BLTZAL / BGEZAL */
        case 0x12: case 0x13: /* BLTZALL / BGEZALL */
            return 1;
        default:
            return 0;
        }
    }
    if (op == 0x11u) {
        /* COP1 (FPU), new in Round 902, extended Round 903/904/905/906/
         * 906b: like REGIMM above, `rs` selects the real sub-opcode, not
         * a flat op-only dispatch - only the subset ppc_dynarec.c's
         * op==0x11 block actually implements returns 1 here, matching
         * translate_one()'s own `return -1` paths inside this same
         * op==0x11 block exactly - kept in sync by hand, same
         * discipline as every entry above. As of Round 906b every COP1
         * opcode this project's ee_core.c implements at all is
         * JIT-covered - task #884 is closed. */
        uint32_t rs = (instr >> 21) & 0x1Fu;
        if (rs == 0x00u || rs == 0x02u || rs == 0x04u || rs == 0x06u)
            return 1; /* MFC1 / CFC1 / MTC1 / CTC1 */
        if (rs == 0x10u) {
            uint32_t funct = instr & 0x3Fu;
            if (funct == 0x05u || funct == 0x06u || funct == 0x07u)
                return 1; /* ABS.S / MOV.S / NEG.S */
            if (funct == 0x00u || funct == 0x01u || funct == 0x02u)
                return 1; /* ADD.S / SUB.S / MUL.S (Round 903) */
            if (funct == 0x03u)
                return 1; /* DIV.S (Round 904) */
            if (funct == 0x04u || funct == 0x16u)
                return 1; /* SQRT.S / RSQRT.S (Round 905) */
            if (funct == 0x28u || funct == 0x29u)
                return 1; /* MAX.S / MIN.S (Round 905) */
            if (funct == 0x18u || funct == 0x19u || funct == 0x1Au)
                return 1; /* ADDA.S / SUBA.S / MULA.S (Round 906) */
            if (funct == 0x1Cu || funct == 0x1Du)
                return 1; /* MADD.S / MSUB.S (Round 906) */
            if (funct == 0x1Eu || funct == 0x1Fu)
                return 1; /* MADDA.S / MSUBA.S (Round 906) */
            if (funct == 0x30u || funct == 0x32u || funct == 0x34u || funct == 0x36u)
                return 1; /* C.EQ.S / C.LT.S / C.LE.S (Round 906) */
            if (funct == 0x24u)
                return 1; /* CVT.W.S (Round 906b) */
        }
        if (rs == 0x14u) {
            uint32_t funct = instr & 0x3Fu;
            if (funct == 0x20u)
                return 1; /* CVT.S.W (Round 906b) */
        }
        if (rs == 0x08u) {
            uint32_t rt = (instr >> 16) & 0x1Fu;
            if (rt == 0x00u || rt == 0x01u || rt == 0x02u || rt == 0x03u)
                return 1; /* BC1F / BC1T / BC1FL / BC1TL (Round 906b) */
        }
        return 0;
    }
    if (op == 0x12u) {
        /* Round 922: broadened from a hand-enumerated funct list (which
         * only ever named VADD/VMUL/VSUB, Round 907) to a blanket
         * "op==0x12 is supported" match. This pre-filter had silently
         * fallen out of sync with translate_one()'s own op==0x12
         * dispatch, which by Round 913 covers nearly all of task #885's
         * COP2/VU0 macro-mode scope: the VADD/VSUB/VMUL family (907),
         * VMAX/VMINI/VOPMSUB/VABS/VCLIP (908), VDIV/VSQRT/VRSQRT (909),
         * VIADD/VISUB/VIAND/VIOR/VMOVE/VMR32 (910), VFTOI/VITOF/
         * VCALLMS/VCALLMSR (911), and the scalar transfer family
         * MFC2/QMFC2/CFC2/MTC2/QMTC2/CTC2 (912) - none of which this
         * pre-filter ever let through, so on real GEKKO hardware every
         * one of those Round-908-through-913 instructions was silently
         * falling back to the interpreter despite translate_one()
         * successfully compiling it. Widening this to a blanket op
         * match (rather than re-enumerating every rs/funct combination
         * here too, which is exactly the hand-sync burden that caused
         * this staleness) is safe: ee_jit_try_execute_one() below
         * already treats a nonzero ppc_dynarec_translate_one() return
         * as "not actually supported, fall back to the interpreter" for
         * every opcode, not just this one - so any op==0x12 sub-opcode
         * translate_one() doesn't yet implement costs one wasted (cheap)
         * ppc_dynarec_init()/translate_one() attempt, not a correctness
         * risk. */
        return 1;
    }
    if (op == 0x1Cu) {
        /* Round 922: same blanket-match rationale as op==0x12 just
         * above, for the MMI (EE multimedia/SIMD) family this pre-filter
         * had ZERO entries for at all - meaning every MMI opcode shipped
         * across the entire Round 914-921 arc (task #886, now closed:
         * PADDx/PSUBx, PMULTx/PDIVx, PAND/POR/PXOR/PNOR, the shift
         * family, the pack/unpack family, the merge family, PMFHI/PMFLO/
         * PMTHI/PMTLO/PMFHL/PMTHL, MFHI1/MTHI1/MFLO1/MTLO1, and PROT3W)
         * was being compiled correctly by translate_one() but was NEVER
         * actually reached on real GEKKO hardware, unconditionally
         * falling back to the interpreter for every single MMI
         * instruction a real game/BIOS executes. This historical gate
         * now reaches all 103 audited MMI forms, including the later
         * MADD, HI1/LO1 and QFSRV implementations. Reserved encodings
         * still decline in translate_one(); acceptance alone does not
         * establish architectural or hardware correctness. */
        return 1;
    }
    if (op == 0x00u) {
        uint32_t funct = instr & 0x3Fu;
        switch (funct) {
        case 0x30:case 0x31:case 0x32:case 0x33:case 0x34:case 0x36: /* traps */
        case 0x00: /* SLL (and the all-zero-word NOP encoding, harmlessly - see translate_one's rd==0 guard) */
        case 0x02: case 0x03: /* SRL / SRA */
        case 0x04: case 0x06: case 0x07: /* SLLV / SRLV / SRAV */
        case 0x08: case 0x09: /* JR / JALR (Round 894) */
        case 0x0A: case 0x0B: /* MOVZ / MOVN */
        case 0x10: case 0x11: case 0x12: case 0x13: /* MFHI / MTHI / MFLO / MTLO */
        case 0x18: case 0x19: /* MULT / MULTU */
        case 0x1A: case 0x1B: /* DIV / DIVU */
        case 0x20: case 0x21: case 0x22: case 0x23: /* ADD/ADDU/SUB/SUBU */
        case 0x24: case 0x25: case 0x26: case 0x27: /* AND / OR / XOR / NOR */
        case 0x28: case 0x29: /* R1270 MFSA/MTSA */
        case 0x2A: case 0x2B: /* SLT / SLTU */
        case 0x2C: case 0x2D: case 0x2E: case 0x2F: /* DADD / DADDU / DSUB / DSUBU (Round 898) */
        case 0x14: case 0x16: case 0x17: /* R1268 DSLLV/DSRLV/DSRAV */
        case 0x3C: case 0x3E: case 0x3F: /* R1268 DSLL32/DSRL32/DSRA32 */
        case 0x38: case 0x3A: case 0x3B: /* DSLL / DSRL / DSRA (Round 898) */
            return 1;
        default:
            return 0;
        }
    }
    return 0;
}

/* Instruction-keyed owning cache. Once full, existing entries remain usable;
 * uncached encodings fall back to the interpreter without allocating code.
 * L0 remembers deterministic rejection with both PC and instruction tags.
 * Allocation/finalization failures remain transient. Arena exhaustion defers
 * new compilation until the arena changes; it never marks an opcode unsupported. */
static ppc_block_fn ee_jit_cache_lookup(uint32_t instr)
{
    uint32_t h = (instr * 2654435761u) & (EE_JIT_CACHE_SLOTS - 1u);
    for (uint32_t probe = 0; probe < EE_JIT_CACHE_SLOTS; probe++) {
        uint32_t slot = (h + probe) & (EE_JIT_CACHE_SLOTS - 1u);
        if (g_cache[slot].fn == NULL)
            return NULL; /* empty slot reached along the probe chain: definitely not cached */
        if (g_cache[slot].instr == instr)
            return g_cache[slot].fn;
    }
    return NULL; /* cache full and not found */
}

static int ee_jit_cache_insert(uint32_t instr, ppc_block_fn fn)
{
    if (g_cache_count >= EE_JIT_CACHE_SLOTS)
        return 0; /* No ownership transfer when full. */
    uint32_t h = (instr * 2654435761u) & (EE_JIT_CACHE_SLOTS - 1u);
    for (uint32_t probe = 0; probe < EE_JIT_CACHE_SLOTS; probe++) {
        uint32_t slot = (h + probe) & (EE_JIT_CACHE_SLOTS - 1u);
        if (g_cache[slot].fn == NULL) {
            g_cache[slot].instr = instr;
            g_cache[slot].fn = fn;
            g_cache_count++;
            return 1;
        }
    }
    return 0;
}

#endif /* GEKKO */

static int ee_precise_compile_admitted(void);
static int ee_precise_make_room(size_t bytes,const void *keep);

static int ee_jit_resolve_and_execute(ee_state_t *st, uint32_t instr, ppc_block_fn *out_fn, int *out_rejected)
{
    if (out_rejected) *out_rejected = 0;
    if(!gekko2_opt_enabled(GEKKO2_OPT_EE_JIT))return 0;
#if !defined(GEKKO) || defined(PCSX2WII_JIT_DISABLE)
    /* Round 887 host-safety gate: ppc_dynarec.c generates raw PPC750
     * machine code, and the block below CALLS it as a function
     * pointer. This project's regression/test suite builds and runs
     * on an x86_64 host - invoking a buffer of PPC opcode bytes there
     * would execute garbage as x86_64 instructions (undefined
     * behavior / near-certain crash or memory corruption), not a
     * no-op. GEKKO is devkitPPC's own auto-defined macro (also passed
     * explicitly via -DGEKKO in this project's Wii Makefile), so it's
     * true exactly when compiling for the real PPC750/Broadway target
     * this generated code can actually run on. On every other build
     * (host-native tests, host tools) this function must decline
     * immediately so ee_step() falls back to the interpreter - exactly
     * the same behavior as every round before this one. Round 886's
     * r880_ppc_verify.c is the correct way to verify the generated PPC
     * ENCODINGS on host: it interprets the raw bytes in a synthetic
     * PPC model rather than executing them natively. See
     * include/core/recompiler/ee_jit.h's header comment.
     *
     * Round 924 (task #913): PCSX2WII_JIT_DISABLE is a new, additive,
     * off-by-default compile-time toggle (not passed by the normal
     * Makefile - only by a separate one-off `make` invocation with
     * `CFLAGS += -DPCSX2WII_JIT_DISABLE`) that forces this same no-op
     * path even on a real GEKKO build. It exists purely to produce a
     * "JIT off" .dol built from the exact same commit/tree as the
     * normal "JIT on" .dol, for a real, on-target Dolphin/Wii A/B
     * comparison - see docs/STATUS.md's Round 924 entry for how to
     * build and use it. Does not change default behavior at all: a
     * plain `make` is byte-for-byte the same JIT-on build as before
     * this round. */
    (void)st;
    (void)instr;
    return 0;
#else
    if (!ee_jit_opcode_supported(instr)) {
        if (out_rejected) *out_rejected = 1;
        return 0;
    }

    ee_rejected_slot *negative=&g_ee_rejected[(instr^(instr>>16))&63u];
    if(negative->valid && negative->instr==instr) {
        if(out_rejected)*out_rejected=1;
        return 0;
    }
    uint32_t l1i = ee_jit_l1_index(instr);
    ppc_block_fn fn = (g_l1[l1i].fn && g_l1[l1i].instr == instr)
                    ? g_l1[l1i].fn : NULL;
    if (!fn) {
        fn = ee_jit_cache_lookup(instr);
        if (fn) {
            g_l1[l1i].instr = instr;
            g_l1[l1i].fn = fn;
        }
    }
    if (!fn) {
        /* R1267: cached functions keep running when full; new encodings
         * interpret instead of allocating unowned executable buffers. */
        if (g_cache_count >= EE_JIT_CACHE_SLOTS) {
            if (out_rejected) *out_rejected = 1;
            return 0;
        }
        if(!ee_precise_compile_admitted())return 0;
        g_compile_attempts++;
        ppc_codegen_ctx_t ctx;
        if (ppc_dynarec_init(&ctx, 1) != 0)
            return 0; /* out of memory - fall back to the interpreter, not fatal */
        int translation=ppc_dynarec_translate_one(&ctx, instr);
        if (translation != 0) {
            /* Blanket COP2/MMI gates intentionally include unimplemented
             * encodings. Remember deterministic rejection at L0; never
             * execute a partially generated block. */
            ppc_dynarec_free(&ctx);
            if(translation==-2)return 0; /* Transient allocation failure retries. */
            negative->instr=instr;negative->valid=1;
            if (out_rejected) *out_rejected = 1;
            return 0;
        }
        if(!ee_precise_make_room((ctx.used_words+1u)*sizeof(uint32_t),NULL)){
            ppc_dynarec_free(&ctx);return 0;
        }
        fn = ppc_dynarec_finalize(&ctx);
        if (!fn) {
            ppc_dynarec_free(&ctx);
            return 0;
        }
        /* Deliberately NOT ppc_dynarec_free(&ctx) here: that would
         * free the very code buffer `fn` now points into (finalize()
         * returns ctx.code itself, memalign'd, cast to a function
         * pointer). `ctx` is a local struct of plain value/pointer
         * fields, so letting it go out of scope here is harmless -
         * ownership of the code buffer has effectively transferred to
         * the cache (ee_jit_reset_stats_for_test() is the only thing
         * that ever frees these, for host-native test hygiene). */
        if (!ee_jit_cache_insert(instr, fn)) {
            ppc_dynarec_free(&ctx);
            return 0;
        }
        g_l1[l1i].instr = instr;
        g_l1[l1i].fn = fn;
    }

    /* ppc_dynarec_gpr128_t and ee_reg128_t are separately-declared but
     * byte-layout-identical structs ({uint64_t ud0, ud1;} in both) -
     * see ppc_dynarec.h's own header comment, which explicitly names
     * this exact cast as the intended zero-copy integration path. */
    if (out_fn) *out_fn = fn;
    fn((ppc_dynarec_gpr128_t *)&st->gpr[0]);
    g_jit_executed++;
    return 1;
#endif /* GEKKO */
}

int ee_jit_try_execute_one(ee_state_t *st, uint32_t instr)
{
    return ee_jit_resolve_and_execute(st, instr, NULL, NULL);
}

int ee_jit_try_execute_one_at(ee_state_t *st, uint32_t pc, uint32_t instr)
{
#if !defined(GEKKO) || defined(PCSX2WII_JIT_DISABLE)
    (void)pc;
    return ee_jit_resolve_and_execute(st, instr, NULL, NULL);
#else
    if(!gekko2_opt_enabled(GEKKO2_OPT_EE_JIT))return 0;
    uint32_t i = ee_jit_pc_l0_index(pc);
    ee_jit_pc_l0_slot_t *e = &g_pc_l0[i];
    /* R1280: compare PC+encoding once for both positive and negative
     * cache entries. The warm positive path previously repeated both
     * comparisons after checking rejection. Preserve every counter and
     * exact-word validation, including self-modifying guest code. */
    if (e->pc == pc && e->instr == instr) {
        if (e->fn) {
            e->fn((ppc_dynarec_gpr128_t *)&st->gpr[0]);
            g_pc_l0_hits++;
            g_jit_executed++;
            return 1;
        }
        if (e->rejected) {
            g_pc_l0_rejected_hits++;
            return 0;
        }
    }

    g_pc_l0_misses++;
    ppc_block_fn fn = NULL;
    int rejected = 0;
    int ok = ee_jit_resolve_and_execute(st, instr, &fn, &rejected);
    if (ok && fn) {
        e->pc = pc;
        e->instr = instr;
        e->fn = fn;
        e->rejected = 0;
    } else if (rejected) {
        e->pc = pc; e->instr = instr; e->fn = NULL; e->rejected = 1;
    }
    return ok;
#endif
}

uint64_t ee_jit_get_rejected_hit_count(void) { return g_pc_l0_rejected_hits; }
uint64_t ee_jit_get_compile_attempt_count(void) { return g_compile_attempts; }

uint64_t ee_jit_get_executed_count(void) { return g_jit_executed; }
uint32_t ee_jit_get_cache_size(void) { return g_cache_count; }
uint64_t ee_jit_get_pc_l0_hit_count(void) { return g_pc_l0_hits; }
uint64_t ee_jit_get_pc_l0_miss_count(void) { return g_pc_l0_misses; }

static void ee_precise_reset_cache(void);
void ee_jit_reset_stats_for_test(void)
{
    ee_precise_reset_cache();
    for (uint32_t i = 0; i < EE_JIT_CACHE_SLOTS; i++) {
        if (g_cache[i].fn != NULL)
            ppc_code_cache_release((void*)g_cache[i].fn);
    }
    memset(g_cache, 0, sizeof(g_cache));
    memset(g_l1, 0, sizeof(g_l1));
    memset(g_pc_l0, 0, sizeof(g_pc_l0));
    memset(g_ee_rejected, 0, sizeof(g_ee_rejected));
    g_pc_l0_hits = g_pc_l0_misses = g_pc_l0_rejected_hits = g_compile_attempts = 0;
    g_cache_count = 0;
    g_jit_executed = 0;
}

/* Bounded PC/tag cache; first conservative precise EE block integration. */
typedef unsigned (*ee_precise_fn)(ee_state_t *,unsigned,uint32_t);
typedef unsigned (*ee_prefix_fn)(ee_state_t *,unsigned,uint32_t,unsigned);
#define EE_PRECISE_RAM_PAGES (32u*1024u*1024u/4096u)
#define EE_PRECISE_NON_RAM_PAGE UINT32_MAX
typedef struct {
 uint32_t pc,words[GEKKO2_EE_MAX_BLOCK_WORDS],count;
 unsigned formation_limit;
 uint32_t source_page,source_generation,mapping_generation;
 uint32_t serial; /* R1318: non-zero identity of this installed allocation. */
 /* R1326: lazily learned successor identity.  The serial and live target
  * generation are revalidated before every use, so collision eviction,
  * source writes, TLB/ASID changes and checkpoint/reset cannot jump into a
  * stale executable buffer.  This is a native function link, not a patched
  * code-buffer branch, keeping executable ownership simple and reversible. */
 uint32_t link_pc,link_serial;
 uint16_t link_index;
 ee_precise_fn link_fn;
 ee_precise_fn fn;
 unsigned (*event_fn)(ee_state_t *,unsigned);
 unsigned event_eligibility; /* 0 untested, 1 decline, length+2 eligible prefix */
 ee_prefix_fn prefix_fn; /* Same validated owner/source; independent bounded body. */
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
 ee_precise_fn resident_fn;
 unsigned resident_tested;
#endif
} ee_precise_slot;
/* Metadata capacity is independent of the 6 MiB executable-code arena.
 * Reuse keeps 16384 owners; Control retains 256 direct-mapped entries. */
#define EE_PRECISE_REUSE_SETS 4096u
#define EE_PRECISE_CACHE_SLOTS (4u*EE_PRECISE_REUSE_SETS)
static ee_precise_slot precise_cache[EE_PRECISE_CACHE_SLOTS];
static uint32_t precise_recency[EE_PRECISE_CACHE_SLOTS],precise_clock;
static uint32_t precise_live_owners,precise_pressure_cursor;
static uint32_t precise_blocked_epoch;
static int precise_pressure_blocked;
static uint64_t precise_pressure_stats[6];
uint64_t ee_jit_get_pressure_stat(unsigned n){return n<6u?precise_pressure_stats[n]:0;}
static jit_cache_profile precise_profile;
static uint64_t precise_budget_stats[8];
uint64_t ee_jit_get_budget_cache_stat(unsigned n){return n<8u?precise_budget_stats[n]:0;}
/* Admission hints never bypass scalar instruction/mapping validation.
 * Any changed owner invalidates the hint for both supported layouts. */
typedef struct { uint32_t pc,budget,stride,owner; } ee_precise_refusal;
static ee_precise_refusal precise_refusals[EE_PRECISE_REUSE_SETS];
/* Exact best-way hint for this PC and budget. Never a native-code proof.
 * Set mutations clear it; execution still validates mapping/source epochs. */
typedef struct {uint32_t pc,budget,stride,owner,fit,budget_limit;} ee_precise_lookup;
static ee_precise_lookup precise_lookups[EE_PRECISE_REUSE_SETS];
void ee_jit_get_cache_profile(jit_cache_profile *out){if(out)*out=precise_profile;}
/* One Broadway cache line per dispatch tag. Keep instruction arrays and
 * learned-edge bookkeeping off the common successor lookup. */
typedef struct {
 uint32_t pc,count,page,generation,mapping,serial,word;
 ee_precise_fn fn;
} ee_precise_dispatch;
#ifdef GEKKO
_Static_assert(sizeof(ee_precise_dispatch)==32u,"Broadway dispatch tag must fit one cache line");
#endif
static ee_precise_dispatch precise_dispatch[EE_PRECISE_CACHE_SLOTS] __attribute__((aligned(32)));
static uint64_t precise_dispatch_hits;
uint64_t ee_jit_get_dispatch_hits(void){return precise_dispatch_hits;}
static uint32_t precise_page_generation[EE_PRECISE_RAM_PAGES];
static uint32_t precise_mapping_generation;
static uint32_t precise_serial_source;
static uint64_t precise_runs,precise_retired,precise_evictions,precise_direct_link_hits;
static ee_precise_slot *precise_chain_source;
static uint32_t precise_chain_source_serial;
static int precise_active;
static unsigned precise_accounted_remaining;

static inline unsigned ee_precise_cache_stride(void)
{return gekko2_opt_enabled(GEKKO2_OPT_CACHE_REUSE)&&!gekko2_opt_enabled(GEKKO2_OPT_COMPACT_CACHE)?EE_PRECISE_REUSE_SETS:256u;}

static inline unsigned ee_precise_cache_index_stride(uint32_t pc,unsigned stride)
{
 unsigned mask=stride-1u;
 /* Compact retains the old control layout. Mix high address bits before
  * selecting the large reuse table to break repetitive BIOS page aliases. */
 if(mask==255u)return ((pc>>2)^(pc>>12))&mask;
 uint32_t key=(pc>>2)^(pc>>12)^(pc>>22);
 key*=0x9e3779b1u;
 return (key^(key>>16))&mask;
}

/* Compatibility entry for existing collision/eviction regression fixtures. */
static inline unsigned ee_precise_cache_index(uint32_t pc)
{return ee_precise_cache_index_stride(pc,ee_precise_cache_stride());}

unsigned ee_jit_get_cache_entries(void)
{return gekko2_opt_enabled(GEKKO2_OPT_CACHE_REUSE)?4u*ee_precise_cache_stride():256u;}

/* Lookup never allocates or evicts; native chains pin all cache owners. */
static void ee_precise_touch(unsigned index)
{
 if(++precise_clock==0u){memset(precise_recency,0,sizeof precise_recency);precise_clock=1u;}
 precise_recency[index]=precise_clock;
}
static ee_precise_slot *ee_precise_find(uint32_t pc,int install,unsigned budget)
{
 /* Keep one immutable cold-boot option snapshot within this lookup.
  * The index and way count must agree even under compiler reordering. */
 unsigned reuse=gekko2_opt_enabled(GEKKO2_OPT_CACHE_REUSE);
 unsigned stride=reuse&&!gekko2_opt_enabled(GEKKO2_OPT_COMPACT_CACHE)?EE_PRECISE_REUSE_SETS:256u;
 unsigned set=ee_precise_cache_index_stride(pc,stride),ways=reuse?4u:1u;
 ee_precise_lookup *lookup=&precise_lookups[set];
 if(ways==4u&&lookup->owner&&lookup->pc==pc&&budget>=lookup->budget&&budget<=lookup->budget_limit&&lookup->stride==stride){
  if(budget!=lookup->budget)precise_budget_stats[6]++;
  if(install&&lookup->fit)precise_budget_stats[0]++;
  precise_budget_stats[5]++;return &precise_cache[lookup->owner-1u];
 }
 ee_precise_refusal *refusal=&precise_refusals[set];
 if(install&&ways==4u&&refusal->budget&&refusal->pc==pc&&
    refusal->stride==stride&&budget<=refusal->budget) {
  precise_budget_stats[1]++;precise_budget_stats[3]++;
  precise_budget_stats[4]++;
  return gekko2_opt_enabled(GEKKO2_OPT_EE_PREFIX)&&refusal->owner?&precise_cache[refusal->owner-1u]:NULL;
 }
 ee_precise_slot *best=NULL,*prefix=NULL;unsigned largest=0,upper=UINT32_MAX;
 precise_budget_stats[7]++;
 for(unsigned w=0;w<ways;w++) {
  unsigned index=set+w*stride;
  const ee_precise_dispatch *tag=&precise_dispatch[index];
  if(!tag->fn||tag->pc!=pc)continue;
  if(ways==1u)return &precise_cache[index];
  if(tag->count>largest)largest=tag->count;
  if(tag->count>budget){
   if(tag->count-1u<upper)upper=tag->count-1u;
   if(!prefix||tag->count<prefix->count)prefix=&precise_cache[index];
  }
  if(tag->count<=budget&&(!best||tag->count>precise_dispatch[best-precise_cache].count))
   best=&precise_cache[index];
 }
 if(best){
  unsigned fit=best->count<largest;
  /* best is the largest count <= budget. Every larger owner is therefore
   * already among the >budget tags seen above; no second four-way pass. */
  *lookup=(ee_precise_lookup){pc,best->count,stride,(unsigned)(best-precise_cache)+1u,fit,upper};
  if(install&&fit)precise_budget_stats[0]++;return best;
 }
 if(install&&prefix&&gekko2_opt_enabled(GEKKO2_OPT_EE_PREFIX)) {
  *refusal=(ee_precise_refusal){pc,budget,stride,(unsigned)(prefix-precise_cache)+1u};
  precise_budget_stats[1]++;return prefix;
 }
 if(!install)return NULL;
 if(largest)precise_budget_stats[1]++;
 for(unsigned w=0;w<ways;w++)if(!precise_dispatch[set+w*stride].fn)return &precise_cache[set+w*stride];
 /* A short scheduler tail must not evict a reusable long block or another
  * PC just to admit another length variant. The scalar PPC JIT handles this
  * tail under the unchanged budget. Empty ways still admit warm variants. */
 if(ways>1u&&largest){
  *refusal=(ee_precise_refusal){pc,budget,stride,0u};
  precise_budget_stats[3]++;return NULL;
 }
 unsigned victim=set;
 for(unsigned w=1;w<ways;w++) {
  unsigned index=set+w*stride;
  if(precise_recency[index]<precise_recency[victim])victim=index;
 }
 return &precise_cache[victim];
}

static void ee_precise_bump(uint32_t *generation)
{
 if(++*generation==0u)*generation=1u;
}
static uint32_t ee_precise_next_serial(void)
{
 ee_precise_bump(&precise_serial_source);
 return precise_serial_source;
}
static void ee_precise_publish_dispatch(const ee_precise_slot *slot)
{
 unsigned i=(unsigned)(slot-precise_cache);
 precise_refusals[i%EE_PRECISE_REUSE_SETS].budget=0u;precise_refusals[i%256u].budget=0u;
 precise_lookups[i%EE_PRECISE_REUSE_SETS].owner=0u;precise_lookups[i%256u].owner=0u;
 precise_dispatch[i]=(ee_precise_dispatch){slot->pc,slot->count,slot->source_page,
  slot->source_generation,slot->mapping_generation,slot->serial,slot->words[0],slot->fn};
}
/* R1318: publish a replacement only after translation/finalization succeeded.
 * A live chain pins all installed allocations via precise_active, so failed or
 * nested installs leave the old slot byte-for-byte intact. */
static int ee_precise_install_slot(ee_precise_slot *slot,uint32_t pc,
 const uint32_t *words,unsigned count,uint32_t source_page,
 uint32_t source_generation,uint32_t mapping_generation,ee_precise_fn fn)
{
 if(!slot||!words||!fn||count<2u||count>GEKKO2_EE_MAX_BLOCK_WORDS||precise_active)return 0;
 ee_precise_slot next;memset(&next,0,sizeof(next));
 next.pc=pc;next.count=count;next.formation_limit=0;memcpy(next.words,words,count*4u);
 next.source_page=source_page;next.source_generation=source_generation;
 next.mapping_generation=mapping_generation;next.serial=ee_precise_next_serial();
 next.fn=fn;
 if(gekko2_opt_enabled(GEKKO2_OPT_CACHE_REUSE)) {
  unsigned stride=ee_precise_cache_stride(),set=ee_precise_cache_index_stride(pc,stride);
  for(unsigned w=0;w<4u;w++) {
   ee_precise_slot *other=&precise_cache[set+w*stride];
   if(other!=slot&&other->fn&&other->pc==pc&&other->count!=count){precise_budget_stats[2]++;break;}
  }
 }
 ee_precise_fn old=slot->fn;
 if(!old)precise_live_owners++;
 ee_prefix_fn old_prefix=slot->prefix_fn;
 void *old_event=(void*)slot->event_fn;
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
 void *old_resident=(void*)slot->resident_fn;
#endif
 int displaced=old&&(slot->pc!=pc||slot->count!=count||
                    memcmp(slot->words,words,count*4u)!=0);
 *slot=next;
 ee_precise_publish_dispatch(slot);
 if(old&&old!=fn){if(displaced)precise_evictions++;ppc_code_cache_release((void*)old);}
 if(old_prefix)ppc_code_cache_release((void*)old_prefix);
 if(old_event)ppc_code_cache_release(old_event);
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
 if(old_resident)ppc_code_cache_release(old_resident);
#endif
 return 1;
}
static void ee_precise_release_slot(ee_precise_slot *slot)
{
 if(!slot||precise_active)return;
 unsigned index=(unsigned)(slot-precise_cache);
 precise_refusals[index%EE_PRECISE_REUSE_SETS].budget=0u;precise_refusals[index%256u].budget=0u;
 precise_lookups[index%EE_PRECISE_REUSE_SETS].owner=0u;precise_lookups[index%256u].owner=0u;
 if(slot->fn){ppc_code_cache_release((void*)slot->fn);precise_live_owners--;}
 if(slot->prefix_fn)ppc_code_cache_release((void*)slot->prefix_fn);
 if(slot->event_fn)ppc_code_cache_release((void*)slot->event_fn);
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
 if(slot->resident_fn)ppc_code_cache_release((void*)slot->resident_fn);
#endif
 memset(&precise_dispatch[slot-precise_cache],0,sizeof(precise_dispatch[0]));
 memset(slot,0,sizeof(*slot));
}
/* Executing native chains pin every owner. Reclamation is only permitted
 * before publication/execution and keeps the current replacement/prefix owner.
 * A clock sweep favours owners not used in the last 256 precise executions.
 * Free in batches to avoid one allocation failure or full scan per new block. */
static int ee_precise_compile_admitted(void)
{
 if(!gekko2_opt_enabled(GEKKO2_OPT_CODE_ARENA))return 1;
 if(precise_pressure_blocked&&precise_blocked_epoch==ppc_code_cache_generation()){
  precise_pressure_stats[2]++;return 0;
 }
 precise_pressure_blocked=0;return 1;
}
static int ee_precise_make_room(size_t bytes,const void *keep)
{
 if(!gekko2_opt_enabled(GEKKO2_OPT_CODE_ARENA))return 1;
 if(precise_active)return 0;
 uint32_t cap=ppc_code_cache_capacity(),used=ppc_code_cache_used();
 if(!cap)return 1;
 int fits=ppc_code_cache_can_alloc(bytes);
 if(fits&&used<cap-256u*1024u)return 1;
 precise_pressure_stats[0]++;
 unsigned entries=ee_jit_get_cache_entries();
 /* Scan a bounded slice first; a second pass is only needed if this exact
  * allocation still cannot fit. No published owner moves in RAM. */
 for(unsigned pass=0;pass<2u&&precise_live_owners;pass++){
  unsigned limit=pass?entries:(entries<4096u?entries:4096u);
  for(unsigned n=0;n<limit&&precise_live_owners;n++){
   unsigned i=precise_pressure_cursor;
   precise_pressure_cursor=(i+1u)&(entries-1u);
   precise_pressure_stats[3]++;
   ee_precise_slot *victim=&precise_cache[i];
   if(!victim->fn||victim==keep)continue;
   if(!pass&&precise_clock-precise_recency[i]<=256u)continue;
   uint32_t before=ppc_code_cache_used();
   ee_precise_release_slot(victim);precise_evictions++;precise_pressure_stats[1]++;
   precise_pressure_stats[5]+=before-ppc_code_cache_used();
   fits=ppc_code_cache_can_alloc(bytes);
   if(fits&&ppc_code_cache_used()<cap-512u*1024u)return 1;
  }
  if(fits)return 1;
 }
 if(ppc_code_cache_can_alloc(bytes))return 1;
 precise_pressure_blocked=1;precise_blocked_epoch=ppc_code_cache_generation();
 precise_pressure_stats[4]++;return 0;
}

void ee_jit_notify_physical_write(uint32_t phys_addr,uint32_t len)
{
 if(!len||phys_addr>=32u*1024u*1024u)return;
 uint64_t last=(uint64_t)phys_addr+(uint64_t)len-1u;
 if(last>=32u*1024u*1024u)last=32u*1024u*1024u-1u;
 uint32_t first=phys_addr>>12,end=(uint32_t)last>>12;
 for(uint32_t page=first;page<=end;page++)ee_precise_bump(&precise_page_generation[page]);
}
extern void ee_fastmem_invalidate(void) __attribute__((weak));
void ee_jit_notify_mapping_change(void)
{
 if(ee_fastmem_invalidate)ee_fastmem_invalidate();
 ee_precise_bump(&precise_mapping_generation);
}
uint64_t ee_jit_get_block_count(void){return precise_runs;}
uint64_t ee_jit_get_block_retired(void){return precise_retired;}
uint64_t ee_jit_get_native_retired_count(void){return g_jit_executed+precise_retired;}
uint64_t ee_jit_get_block_evictions(void){return precise_evictions;}
uint64_t ee_jit_get_direct_link_hits(void){return precise_direct_link_hits;}
typedef unsigned (*ee_cached_chain_fn)(ee_state_t *,unsigned,uint32_t,unsigned,ee_precise_fn,unsigned);
static ee_cached_chain_fn precise_chain_fn;
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
static ee_cached_chain_fn precise_resident_chain_fn;
/* First eligible block chooses actual architectural groups. The map is
 * then frozen for all companions/wrappers until the entire cache resets. */
static ppc_ee_chain_map precise_resident_map;
static unsigned precise_resident_map_ready;
static uint64_t precise_resident_runs,precise_resident_retired,precise_resident_selected;
#endif
uint64_t ee_jit_get_chain_residency_stat(unsigned n)
{
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
 return n==0?(unsigned)(gekko2_experimental_enabled(GEKKO2_EXP_CHAIN)&&
  gekko2_opt_enabled(GEKKO2_OPT_EE_JIT)&&gekko2_opt_enabled(GEKKO2_OPT_EE_BLOCKS)&&
  gekko2_opt_enabled(GEKKO2_OPT_NATIVE_LINKS)&&gekko2_opt_enabled(GEKKO2_OPT_RESIDENCY)):
  n==1?precise_resident_runs:n==2?precise_resident_retired:n==3?precise_resident_selected:0;
#else
 (void)n;return 0;
#endif
}
typedef unsigned (*ee_event_chain_fn)(ee_state_t *,unsigned,void *,unsigned);
static ee_event_chain_fn precise_event_chain_fn;
static uint64_t precise_event_chain_runs,precise_event_chain_retired,precise_event_chain_selected;
uint64_t ee_jit_get_event_chain_stat(unsigned n)
{return n==0?precise_event_chain_runs:n==1?precise_event_chain_retired:n==2?precise_event_chain_selected:0;}
static uint64_t precise_native_successors;
uint64_t ee_jit_get_native_successors(void){return precise_native_successors;}
#if GEKKO2_EE_BLOCKS_ENABLED
static int ee_precise_source_snapshot(ee_state_t *st,uint32_t pc,uint32_t *page,uint32_t *generation)
{
 if(!ee_core_block_source_page(st,pc,page))return 0;
 if(*page==EE_PRECISE_NON_RAM_PAGE){*generation=0u;return 1;}
 if(*page>=EE_PRECISE_RAM_PAGES)return 0;
 *generation=precise_page_generation[*page];
 return 1;
}
static int ee_precise_slot_generation_current(const ee_precise_slot *slot)
{
 if(slot->mapping_generation!=precise_mapping_generation)return 0;
 return slot->source_page==EE_PRECISE_NON_RAM_PAGE ||
        (slot->source_page<EE_PRECISE_RAM_PAGES &&
         slot->source_generation==precise_page_generation[slot->source_page]);
}
/* No allocation, eviction or compilation here. precise_active pins all
 * precise-cache allocations until the complete native chain returns. */
static uint64_t ee_precise_cached_next(ee_state_t *st,unsigned remaining)
{
#ifdef GEKKO2_SPEED_STUB
 ee_quiet_left=0u;
#endif
 if(precise_active&&ee_core_interleave_quantum!=UINT32_MAX) {
  ee_core_interleave_account(precise_accounted_remaining-remaining);
  precise_accounted_remaining=remaining;
 }
 remaining=ee_core_interleave_limit(remaining);
 if(!precise_active||!st||remaining<2u||st->halted||st->idle||st->exc_raised_this_step||st->mem_tlb_miss||st->branch_pending||st->next_pc!=st->pc+4u)return 0;
 ee_precise_slot *source=precise_chain_source,*slot=0;
 ee_precise_slot *found=0;int learned=0;
 /* A learned edge is an indexed owner, not a new cache lookup. Validate
  * identity, budget and source generations before selecting it; otherwise
  * fall back to the regular variant-aware search. Active chains pin owners. */
 if(source&&source->serial==precise_chain_source_serial&&source->link_fn&&source->link_pc==st->pc&&
    source->link_index<EE_PRECISE_CACHE_SLOTS){
  ee_precise_slot *linked=&precise_cache[source->link_index];
  if(linked->serial==source->link_serial&&linked->fn==source->link_fn&&linked->pc==st->pc&&
     linked->count>=2u&&linked->count<=remaining&&ee_precise_slot_generation_current(linked)){found=linked;learned=1;}
 }
 if(!found)found=ee_precise_find(st->pc,0,remaining);
 if(!found)return 0;
 /* Selection above already checked a learned owner's generation. The
  * general variant lookup needs the same check once, not a second learned
  * edge search. Both routes retain the live first-word and per-slot guards. */
 slot=found;
 if(!learned&&(!slot->fn||!slot->serial||slot->pc!=st->pc||slot->count<2u||slot->count>remaining||
    !ee_precise_slot_generation_current(slot)))return 0;
 uint32_t serial=slot->serial;ee_precise_fn fn=slot->fn;
 uint32_t word;
 if(!ee_core_block_peek(st,st->pc,&word)||word!=slot->words[0])return 0;
 if(slot->serial!=serial||slot->fn!=fn||slot->pc!=st->pc)return 0;
 unsigned index=(unsigned)(slot-precise_cache);
 const ee_precise_dispatch *hot=&precise_dispatch[index];
 if(hot->fn==fn&&hot->serial==serial)
  precise_dispatch_hits++;
 if(source&&source->serial==precise_chain_source_serial) {
  if(source->link_fn==fn&&source->link_pc==slot->pc&&source->link_serial==serial&&source->link_index==index)
   precise_direct_link_hits++;
  else {
   source->link_pc=slot->pc;source->link_serial=serial;source->link_index=(uint16_t)index;source->link_fn=fn;
  }
 }
 precise_chain_source=slot;precise_chain_source_serial=serial;
 ee_precise_touch(index);precise_native_successors++;
 return ((uint64_t)(uint32_t)(uintptr_t)fn<<32)|slot->count;
}
static uint64_t ee_precise_event_next(ee_state_t *st,unsigned remaining)
{
 if(precise_active&&ee_core_interleave_quantum!=UINT32_MAX){
  ee_core_interleave_account(precise_accounted_remaining-remaining);precise_accounted_remaining=remaining;
 }
 remaining=ee_core_interleave_limit(remaining);
 if(!precise_active||!st||remaining<2u||st->halted||st->idle||st->exc_raised_this_step||st->mem_tlb_miss||st->branch_pending||st->next_pc!=st->pc+4u)return 0;
 ee_precise_slot *source=precise_chain_source,*slot=0;
 if(source&&source->serial==precise_chain_source_serial&&source->link_fn&&source->link_pc==st->pc&&source->link_index<EE_PRECISE_CACHE_SLOTS){
  ee_precise_slot *linked=&precise_cache[source->link_index];
  /* An indexed event edge is only reusable if it still owns the same
   * generation/mapping and the event-chain body remains valid.  A stale
   * edge must fall through to the normal variant search; returning zero
   * here can discard a valid replacement JIT block after DMA writes. */
  if(linked->serial==source->link_serial&&linked->fn==source->link_fn&&linked->pc==st->pc&&
     linked->count>=2u&&linked->count<=remaining&&linked->event_fn&&
     linked->event_eligibility==linked->count+2u&&
     ee_precise_slot_generation_current(linked))slot=linked;
 }
 if(!slot)slot=ee_precise_find(st->pc,0,remaining);
 if(!slot||!slot->fn||!slot->serial||!slot->event_fn||slot->pc!=st->pc||slot->count<2u||slot->count>remaining||
    slot->event_eligibility!=slot->count+2u||!ee_precise_slot_generation_current(slot))return 0;
 uint32_t live;
 if(!ee_core_block_peek(st,st->pc,&live)||live!=slot->words[0])return 0;
 unsigned index=(unsigned)(slot-precise_cache);
 if(source&&source->serial==precise_chain_source_serial){
  source->link_pc=slot->pc;source->link_serial=slot->serial;source->link_index=(uint16_t)index;source->link_fn=slot->fn;
 }
 precise_chain_source=slot;precise_chain_source_serial=slot->serial;
 ee_precise_touch(index);precise_event_chain_selected++;
 return ((uint64_t)(uint32_t)(uintptr_t)slot->event_fn<<32)|slot->count;
}
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
static uint64_t ee_precise_resident_next(ee_state_t *st,unsigned remaining)
{
 /* Reuse the authoritative resolver, including interleave accounting,
  * serial/source/page/mapping/PC/budget/fault checks and active-owner pinning.
  * It selects a normal identity; only its matching native-only companion
  * may cross this ABI edge. A missing companion returns to C, never calls
  * the normal C entry with live guest registers. */
 uint64_t next=ee_precise_cached_next(st,remaining);
 if(!next||!precise_chain_source||!precise_chain_source->resident_fn)return 0;
 precise_resident_selected++;
 return ((uint64_t)(uint32_t)(uintptr_t)precise_chain_source->resident_fn<<32)|(uint32_t)next;
}
static void ee_precise_make_resident_chain(void)
{
 if(precise_resident_chain_fn)return;
 ppc_codegen_ctx_t c;if(ppc_dynarec_init(&c,2u))return;
 if(ppc_dynarec_translate_ee_resident_chain(&c,(uint32_t)(uintptr_t)ee_precise_resident_next,
                                          &precise_resident_map)){ppc_dynarec_free(&c);return;}
 precise_resident_chain_fn=(ee_cached_chain_fn)ppc_dynarec_finalize(&c);
 if(!precise_resident_chain_fn)ppc_dynarec_free(&c);
}
#endif
static void ee_precise_make_event_chain(void)
{
 if(precise_event_chain_fn)return;
 ppc_codegen_ctx_t c;if(ppc_dynarec_init(&c,1u))return;
 if(ppc_dynarec_translate_ee_event_chain(&c,(uint32_t)(uintptr_t)ee_precise_event_next)){ppc_dynarec_free(&c);return;}
 precise_event_chain_fn=(ee_event_chain_fn)ppc_dynarec_finalize(&c);
 if(!precise_event_chain_fn)ppc_dynarec_free(&c);
}

static void ee_precise_make_chain(void)
{
 if(precise_chain_fn)return;
 ppc_codegen_ctx_t c;if(ppc_dynarec_init(&c,1u))return;
 if(ppc_dynarec_translate_ee_cached_chain(&c,(uint32_t)(uintptr_t)ee_precise_cached_next)) {
  ppc_dynarec_free(&c);return;
 }
 precise_chain_fn=(ee_cached_chain_fn)ppc_dynarec_finalize(&c);
 if(!precise_chain_fn)ppc_dynarec_free(&c);
}
#endif
#ifdef GEKKO2_SPEED_STUB
extern void ee_core_quiet_layout(uint32_t *out);
extern int ee_core_quiet_special_pc(uint32_t pc);
static void *precise_quiet_stub,*precise_quiet_mem_stub,*precise_quiet_batch_stub;
static void ee_precise_make_quiet_stub(void)
{
 if(precise_quiet_stub)return;
 uint32_t a[6];ee_core_quiet_layout(a);
 ppc_ee_quiet_layout L={a[0],a[1],a[2],a[3],a[4],a[5],
  (int16_t)offsetof(ee_state_t,instructions_executed),(int16_t)offsetof(ee_state_t,cop0)+9*4,
  (int16_t)offsetof(ee_state_t,pc),(int16_t)offsetof(ee_state_t,next_pc),
  (int16_t)offsetof(ee_state_t,exc_this_pc),(int16_t)offsetof(ee_state_t,exc_in_delay_slot),
  (int16_t)offsetof(ee_state_t,exc_raised_this_step),(int16_t)offsetof(ee_state_t,mem_tlb_miss),
  (int16_t)offsetof(ee_state_t,branch_pending),(int16_t)offsetof(ee_state_t,gpr)};
 if(offsetof(ee_state_t,instructions_executed)>32000u||offsetof(ee_state_t,cop0)>32000u)return;
 ppc_codegen_ctx_t c;if(ppc_dynarec_init(&c,1u))return;
 if(ppc_dynarec_translate_ee_quiet_stub(&c,&L)){ppc_dynarec_free(&c);return;}
 precise_quiet_stub=(void*)ppc_dynarec_finalize(&c);
 if(!precise_quiet_stub){ppc_dynarec_free(&c);return;}
 ppc_dynarec_set_ee_quiet_stub((uint32_t)(uintptr_t)precise_quiet_stub,ee_core_quiet_special_pc);
 {
  ppc_codegen_ctx_t b;
  if(!ppc_dynarec_init(&b,1u)) {
   if(!ppc_dynarec_translate_ee_quiet_batch_stub(&b,&L)) {
    precise_quiet_batch_stub=(void*)ppc_dynarec_finalize(&b);
    if(precise_quiet_batch_stub)ppc_dynarec_set_ee_quiet_batch_stub((uint32_t)(uintptr_t)precise_quiet_batch_stub);
    else ppc_dynarec_free(&b);
   } else ppc_dynarec_free(&b);
  }
 }
 {
  ppc_codegen_ctx_t m;
  if(!ppc_dynarec_init(&m,1u)) {
   if(!ppc_dynarec_translate_ee_quiet_mem_stub(&m,&L)) {
    precise_quiet_mem_stub=(void*)ppc_dynarec_finalize(&m);
    if(precise_quiet_mem_stub)ppc_dynarec_set_ee_quiet_mem_stub((uint32_t)(uintptr_t)precise_quiet_mem_stub);
    else ppc_dynarec_free(&m);
   } else ppc_dynarec_free(&m);
  }
 }
}
#endif
static ee_precise_fn ee_precise_build_impl(uint32_t pc,const uint32_t *words,unsigned count,const ee_precise_slot *keep)
{
#ifdef GEKKO2_SPEED_STUB
 ee_precise_make_quiet_stub();
#endif
 ppc_codegen_ctx_t c;if(ppc_dynarec_init(&c,count*2u))return 0;
#ifdef GEKKO2_LEGACY_BOUNDARIES
  int translation=ppc_dynarec_translate_ee_resident_delay_block(&c,pc,words,count,
    (uint32_t)(uintptr_t)ee_core_block_prepare,(uint32_t)(uintptr_t)ee_core_block_prepare_memory_resolved,(uint32_t)(uintptr_t)ee_core_block_prepare_delay,(uint32_t)(uintptr_t)ee_core_block_commit,(uint32_t)offsetof(ee_state_t,gpr_generation));
#else
  int translation=ppc_dynarec_translate_ee_fused_delay_block(&c,pc,words,count,
    (uint32_t)(uintptr_t)ee_core_block_prepare,(uint32_t)(uintptr_t)ee_core_block_prepare_memory_resolved,
    (uint32_t)(uintptr_t)ee_core_block_prepare_delay,(uint32_t)(uintptr_t)ee_core_block_commit,
    (uint32_t)(uintptr_t)ee_core_block_boundary,(uint32_t)(uintptr_t)ee_core_block_memory_boundary,
    (uint32_t)(uintptr_t)ee_core_block_delay_boundary,(uint32_t)offsetof(ee_state_t,gpr_generation));
#endif
  if(translation) {
   ppc_dynarec_free(&c);return 0;
  }
  if(!ee_precise_make_room((c.used_words+1u)*sizeof(uint32_t),keep)){
   ppc_dynarec_free(&c);return 0;
  }
  ee_precise_fn fn=(ee_precise_fn)ppc_dynarec_finalize(&c);
  if(!fn){ppc_dynarec_free(&c);return 0;}
 return fn;
}
static ee_precise_fn ee_precise_build(uint32_t pc,const uint32_t *words,unsigned count,const ee_precise_slot *keep)
{
 if(!ee_precise_compile_admitted())return 0;
 uint64_t begin=jit_compile_begin(&precise_profile);unsigned old=gp_enter(GP_COMPILE);
 ee_precise_fn fn=ee_precise_build_impl(pc,words,count,keep);
 gp_leave(old);jit_compile_end(&precise_profile,begin);
 if(!fn)precise_profile.failures++;else precise_profile.installed++;
 return fn;
}
#if defined(GEKKO2_EE_CHAIN_RESIDENCY) && GEKKO2_EE_BLOCKS_ENABLED
static void ee_precise_make_resident(ee_precise_slot *slot)
{
 if(precise_active||slot->resident_tested)return;
 slot->resident_tested=1;
 if(!precise_resident_map_ready){
  if(ppc_dynarec_plan_ee_chain_map(slot->words,slot->count,
     offsetof(ee_state_t,gpr_generation),&precise_resident_map))return;
  precise_resident_map_ready=1;
 }
 ppc_codegen_ctx_t c;if(ppc_dynarec_init(&c,slot->count*2u))return;
#ifdef GEKKO2_LEGACY_BOUNDARIES
 int translation=ppc_dynarec_translate_ee_chain_block(&c,slot->pc,slot->words,slot->count,
    (uint32_t)(uintptr_t)ee_core_block_prepare,
    (uint32_t)(uintptr_t)ee_core_block_prepare_memory_resolved,
    (uint32_t)(uintptr_t)ee_core_block_prepare_delay,
    (uint32_t)(uintptr_t)ee_core_block_commit,&precise_resident_map);
#else
 int translation=ppc_dynarec_translate_ee_fused_chain_block(&c,slot->pc,slot->words,slot->count,
    (uint32_t)(uintptr_t)ee_core_block_prepare,
    (uint32_t)(uintptr_t)ee_core_block_prepare_memory_resolved,
    (uint32_t)(uintptr_t)ee_core_block_prepare_delay,
    (uint32_t)(uintptr_t)ee_core_block_commit,
    (uint32_t)(uintptr_t)ee_core_block_boundary,
    (uint32_t)(uintptr_t)ee_core_block_memory_boundary,
    (uint32_t)(uintptr_t)ee_core_block_delay_boundary,&precise_resident_map);
#endif
 if(translation||!ee_precise_make_room((c.used_words+1u)*4u,slot)){
  ppc_dynarec_free(&c);return;
 }
 slot->resident_fn=(ee_precise_fn)ppc_dynarec_finalize(&c);
 if(!slot->resident_fn)ppc_dynarec_free(&c);
}
#endif
static ee_prefix_fn ee_precise_build_prefix(const ee_precise_slot *slot)
{
 if(!ee_precise_compile_admitted())return 0;
 uint64_t begin=jit_compile_begin(&precise_profile);unsigned old=gp_enter(GP_COMPILE);
 ppc_codegen_ctx_t c;ee_prefix_fn fn=0;
 if(!ppc_dynarec_init(&c,slot->count*3u)) {
#ifdef GEKKO2_LEGACY_BOUNDARIES
  uint32_t b=0,m=0,d=0;
#else
  uint32_t b=(uint32_t)(uintptr_t)ee_core_block_boundary;
  uint32_t m=(uint32_t)(uintptr_t)ee_core_block_memory_boundary;
  uint32_t d=(uint32_t)(uintptr_t)ee_core_block_delay_boundary;
#endif
  if(!ppc_dynarec_translate_ee_budget_delay_block(&c,slot->pc,slot->words,slot->count,
    (uint32_t)(uintptr_t)ee_core_block_prepare,(uint32_t)(uintptr_t)ee_core_block_prepare_memory_resolved,
    (uint32_t)(uintptr_t)ee_core_block_prepare_delay,(uint32_t)(uintptr_t)ee_core_block_commit,
    b,m,d,(uint32_t)offsetof(ee_state_t,gpr_generation))&&
    ee_precise_make_room((c.used_words+1u)*sizeof(uint32_t),slot))
   fn=(ee_prefix_fn)ppc_dynarec_finalize(&c);
  if(!fn)ppc_dynarec_free(&c);
 }
 gp_leave(old);jit_compile_end(&precise_profile,begin);
 if(!fn)precise_profile.failures++;else precise_profile.installed++;
 return fn;
}
int ee_jit_event_source_current(const ee_state_t *st,uint32_t pc,const uint32_t *words,unsigned count)
{
#if GEKKO2_EE_BLOCKS_ENABLED
 uintptr_t first=(uintptr_t)precise_cache[0].words,pointer=(uintptr_t)words;
 if(!precise_active||!st||st->pc!=pc||pointer<first)return 0;
 uintptr_t delta=pointer-first;
 if(delta%sizeof(ee_precise_slot)||delta/sizeof(ee_precise_slot)>=EE_PRECISE_CACHE_SLOTS)return 0;
 ee_precise_slot *slot=&precise_cache[delta/sizeof(ee_precise_slot)];
 return slot->fn&&slot->serial&&slot->pc==pc&&count>=2u&&count<=slot->count&&
  slot->event_eligibility>=count+2u&&ee_precise_slot_generation_current(slot);
#else
 (void)st;(void)pc;(void)words;(void)count;return 0;
#endif
}
static void ee_precise_make_event(ee_precise_slot *slot,unsigned budget)
{
 if(slot->event_fn||slot->event_eligibility==1u)return;
 if(!slot->event_eligibility){
  unsigned count=0;
  while(count<slot->count&&ee_jit_event_candidate(slot->words[count]))count++;
  /* A later store, branch or helper must not exclude the safe leading
   * instructions. Keep one owner; encode its immutable prefix length. */
  slot->event_eligibility=count>=2u?count+2u:1u;
  if(slot->event_eligibility==1u)return;
 }
 (void)budget; /* Safe prefixes are useful even before a later helper/store. */
 if(!ee_precise_compile_admitted())return;
 uint64_t begin=jit_compile_begin(&precise_profile);unsigned previous=gp_enter(GP_COMPILE);
 ppc_codegen_ctx_t c;
 unsigned event_count=slot->event_eligibility-2u;
 if(!ppc_dynarec_init(&c,event_count*2u)){
  if(!ppc_dynarec_translate_ee_event_window(&c,slot->pc,slot->words,event_count,
     (uint32_t)(uintptr_t)ee_core_native_window_begin_cached,offsetof(ee_state_t,gpr_generation),
     (uint32_t)(uintptr_t)ee_native_window_memory)&&ee_precise_make_room((c.used_words+1u)*4u,slot))
   slot->event_fn=(void*)ppc_dynarec_finalize(&c);
  if(!slot->event_fn)ppc_dynarec_free(&c);
 }
 gp_leave(previous);jit_compile_end(&precise_profile,begin);
 if(slot->event_fn)precise_profile.installed++;else precise_profile.failures++;

}

#ifdef GEKKO2_SPEED_STUB
/* SPEED3 profiler: block-entry PC histogram (direct-mapped, 4096 entries).
 * Entry-attributed: chained successors count toward the chain head. */
typedef struct {uint32_t pc;uint32_t runs;uint64_t retired;} ee_hotpc_t;
static ee_hotpc_t ee_hotpc[4096];
static inline void ee_hotpc_note(uint32_t pc,unsigned n)
{
 ee_hotpc_t *h=&ee_hotpc[((pc>>2)^(pc>>14))&4095u];
 if(h->pc!=pc){h->pc=pc;h->runs=0;h->retired=0;}
 h->runs++;h->retired+=n;
}
unsigned ee_jit_hotpc_top(uint32_t *pcs,uint32_t *runs,uint64_t *ret,unsigned max)
{
 unsigned c=0;
 for(unsigned i=0;i<4096u;i++){
  if(!ee_hotpc[i].runs)continue;
  unsigned k;
  if(c<max)k=c++;
  else if(ee_hotpc[i].retired>ret[max-1u])k=max-1u;
  else continue;
  pcs[k]=ee_hotpc[i].pc;runs[k]=ee_hotpc[i].runs;ret[k]=ee_hotpc[i].retired;
  while(k>0&&ret[k]>ret[k-1]){
   uint32_t tp=pcs[k],tr=runs[k];uint64_t tt=ret[k];
   pcs[k]=pcs[k-1];runs[k]=runs[k-1];ret[k]=ret[k-1];
   pcs[k-1]=tp;runs[k-1]=tr;ret[k-1]=tt;k--;
  }
 }
 return c;
}
#define EE_HOTPC_NOTE(pc,n) ee_hotpc_note((pc),(n))
#else
#define EE_HOTPC_NOTE(pc,n) ((void)0)
#endif
static unsigned ee_precise_execute(ee_state_t *st,unsigned budget,unsigned fetched,uint32_t first_word,int native_chain)
{
#ifdef GEKKO2_SPEED_STUB
 ee_quiet_left=0u;
#endif
#if GEKKO2_EE_BLOCKS_ENABLED
 if(!st||budget<2u||st->halted||st->idle||st->exc_raised_this_step||st->mem_tlb_miss||st->branch_pending||st->next_pc!=st->pc+4u||precise_active)return 0;
 if(!gekko2_opt_enabled(GEKKO2_OPT_EE_JIT)||!gekko2_opt_enabled(GEKKO2_OPT_EE_BLOCKS))return 0;
 native_chain &= gekko2_opt_enabled(GEKKO2_OPT_NATIVE_LINKS);
 unsigned quantum_budget=ee_core_interleave_limit(budget);
 if(quantum_budget<2u)return 0;
 uint32_t pc=st->pc,words[GEKKO2_EE_MAX_BLOCK_WORDS];
 unsigned maximum=gekko2_opt_enabled(GEKKO2_OPT_LONG_EE_BLOCKS)?GEKKO2_EE_MAX_BLOCK_WORDS:8u;
 unsigned count=0,limit=quantum_budget<maximum?quantum_budget:maximum;
 /* Admit the first instruction before allocating or compiling a body.
  * Resolution is pure: MMIO, missing TLB entries and alignment failures
  * return to scalar execution without changing the guest pipeline. */
 uint32_t admitted_physical=0;
 int admitted=gekko2_opt_enabled(GEKKO2_OPT_EE_SERVICES);
 if(admitted) {
  if(!fetched&&!ee_core_block_peek(st,pc,&first_word))return 0;
  if(!ee_jit_block_candidate(first_word)&&!ee_jit_block_terminal(first_word))return 0;
  if(ee_jit_block_memory_width(first_word)) {
   admitted_physical=ee_core_block_memory_resolve_precise(st,first_word);
   if(!admitted_physical)return 0;
  }
 }
 ee_precise_slot *slot=ee_precise_find(pc,1,quantum_budget);
 precise_profile.lookups++;
 if(!slot){precise_profile.misses++;return 0;}
 /* The emitted prepare callback validates live mapping/encoding before
  * EACH instruction. A warm entry needs no duplicate full-block scan. */
 int grow=slot->fn&&slot->pc==pc&&slot->formation_limit&&slot->count==slot->formation_limit&&
  slot->count<limit&&!ee_jit_block_terminal(slot->words[slot->count-1u]);
 if(!grow&&slot->fn&&slot->pc==pc&&(slot->count<=quantum_budget||gekko2_opt_enabled(GEKKO2_OPT_EE_PREFIX))&&
    ee_precise_slot_generation_current(slot)&&(!(fetched||admitted)||slot->words[0]==first_word)){precise_profile.hits++;goto execute_slot;}
 precise_profile.misses++;
 if(slot->fn){if(slot->pc!=pc)precise_profile.collisions++;else precise_profile.stale++;}
 limit=ee_core_block_words(st,pc,words,limit);
 unsigned formation_limit=limit;
 for(;count<limit;count++) {
  if(ee_jit_block_terminal(words[count])) {
   count++;
   if(count<limit&&ee_jit_block_candidate(words[count]))count++;
   break;
  }
  if(!ee_jit_block_candidate(words[count]))break;
 }
 if(count<2u)return 0;
 uint32_t source_page,source_generation;
 if(!ee_precise_source_snapshot(st,pc,&source_page,&source_generation))return 0;
 uint32_t mapping_generation=precise_mapping_generation;
 if(!slot->fn||slot->pc!=pc||slot->count!=count||memcmp(slot->words,words,count*4u)) {
  ee_precise_fn fn=ee_precise_build(pc,words,count,slot);if(!fn)return 0;
  if(!ee_precise_install_slot(slot,pc,words,count,source_page,source_generation,mapping_generation,fn)) {
   ppc_code_cache_release((void*)fn);return 0;
  }
  slot->formation_limit=formation_limit;
 } else {
  /* A stale epoch with byte-identical code reuses the compiled PPC safely;
   * only the validated source/mapping stamp changes; its allocation identity
   * remains stable because no executable buffer was replaced. */
  slot->source_page=source_page;slot->source_generation=source_generation;
  slot->mapping_generation=mapping_generation;
  ee_precise_publish_dispatch(slot);
 }
execute_slot:;
 int resident_chain=0;
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
 if(gekko2_experimental_enabled(GEKKO2_EXP_CHAIN)&&native_chain&&gekko2_opt_enabled(GEKKO2_OPT_RESIDENCY)&&slot->count<=quantum_budget&&slot->count+2u<=budget){
  ee_precise_make_resident(slot);
  if(slot->resident_fn){ee_precise_make_resident_chain();resident_chain=precise_resident_chain_fn!=0;}
 }
#endif
 if(!resident_chain&&gekko2_opt_enabled(GEKKO2_OPT_NATIVE_EVENTS)&&gekko2_opt_enabled(GEKKO2_OPT_EE_SERVICES)){
  ee_precise_make_event(slot,quantum_budget);
  /* The prepare callback caps retirement at the current event deadline.
   * Execute the safe prefix; leave the following helper/store precise. */
  if(slot->event_fn){
   unsigned event_count=slot->event_eligibility-2u;
   if(native_chain&&budget>=event_count+2u)ee_precise_make_event_chain();
   int event_chain=native_chain&&precise_event_chain_fn&&budget>=event_count+2u;
   precise_chain_source=event_chain?slot:0;precise_chain_source_serial=event_chain?slot->serial:0;
   precise_active=1;precise_accounted_remaining=budget;
   unsigned retired=event_chain?precise_event_chain_fn(st,budget,(void*)slot->event_fn,event_count):slot->event_fn(st,quantum_budget);
   if(event_chain){
    if(ee_core_interleave_quantum!=UINT32_MAX)ee_core_interleave_account(precise_accounted_remaining-(budget-retired));
    if(retired){precise_event_chain_runs++;precise_event_chain_retired+=retired;}
   }else if(retired)ee_core_interleave_account(retired);
   precise_active=0;precise_chain_source=0;precise_chain_source_serial=0;
   if(retired){ee_precise_touch((unsigned)(slot-precise_cache));precise_runs++;precise_retired+=retired;EE_HOTPC_NOTE(slot->pc,retired);return retired;}
  }
 }
 int prefix=slot->count>quantum_budget;
 if(prefix) {
  if(!gekko2_opt_enabled(GEKKO2_OPT_EE_PREFIX))return 0;
  if(!slot->prefix_fn)slot->prefix_fn=ee_precise_build_prefix(slot);
  if(!slot->prefix_fn)return 0;
 }
 ee_precise_touch((unsigned)(slot-precise_cache));
 uint32_t first_physical=admitted_physical;
 if(fetched||admitted) {
  if(slot->words[0]!=first_word)return 0;
  /* The scalar fetch already happened, but preparation must wait until
   * a first memory operation proves its current direct-RAM address. */
  if(!admitted&&ee_jit_block_memory_width(first_word)) {
   first_physical=ee_core_block_memory_resolve_precise(st,first_word);
   if(!first_physical)return 0;
  }
  if(!ee_core_block_prepare_fetched(st,pc))return 0;
  fetched=1u; /* Reuse the admitted fetch/address in the native entry. */
 }
 if(!resident_chain&&!prefix&&native_chain&&slot->count+2u<=budget)ee_precise_make_chain();
 int use_chain=resident_chain||(!prefix&&native_chain&&precise_chain_fn&&slot->count+2u<=budget);
 precise_chain_source=use_chain?slot:0;
 precise_chain_source_serial=use_chain?slot->serial:0;
 precise_active=1;
 precise_accounted_remaining=budget;
 unsigned n;
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
 if(resident_chain){
  n=precise_resident_chain_fn(st,fetched,first_physical,budget,slot->resident_fn,slot->count);
  precise_resident_runs++;precise_resident_retired+=n;
 } else
#endif
 n=prefix?slot->prefix_fn(st,fetched,first_physical,quantum_budget):use_chain?
  precise_chain_fn(st,fetched,first_physical,budget,slot->fn,slot->count):
  slot->fn(st,fetched,first_physical);
 if(ee_core_interleave_quantum!=UINT32_MAX)ee_core_interleave_account(precise_accounted_remaining-(budget-n));
 precise_active=0;
 precise_chain_source=0;precise_chain_source_serial=0;
 precise_runs++;precise_retired+=n;EE_HOTPC_NOTE(slot->pc,n);
 if(prefix){precise_budget_stats[6]++;precise_budget_stats[7]+=n;}
 /* Changed first word/mapping: release only after the native function
  * returns. The scalar path handles this instruction; later visits retry. */
 if(!n)ee_precise_release_slot(slot);
 return n;
#else
 (void)st;(void)budget;(void)fetched;(void)first_word;(void)native_chain;return 0;
#endif
}

unsigned ee_jit_try_execute_block(ee_state_t *st,unsigned budget)
{return ee_precise_execute(st,budget,0u,0u,0);}
unsigned ee_jit_try_execute_block_fetched(ee_state_t *st,unsigned budget,uint32_t first_word)
{return ee_precise_execute(st,budget,1u,first_word,0);}

/* Guarded continuation between returned native blocks within the SAME EE
 * budget. No native return address points into an evicted code buffer, and
 * required EE/IOP catch-up is accounted before continuation. Each successor keeps live source
 * and data checks; partial exits return to the full scalar frontend. */
unsigned ee_jit_try_execute_chain_fetched(ee_state_t *st,unsigned budget,uint32_t first_word)
{
#if GEKKO2_EE_BLOCKS_ENABLED
 if(!st||st->exc_raised_this_step||st->mem_tlb_miss)return 0;
 uint32_t start=st->pc;
 unsigned n=ee_precise_execute(st,budget,1u,first_word,1),total=n;
 while(n&&ee_core_interleave_limit(budget-total)>=2u) {
  ee_precise_slot *previous=ee_precise_find(start,0,n);
  if(!previous||previous->pc!=start||n!=previous->count||st->halted||st->idle||st->branch_pending||st->next_pc!=st->pc+4u)break;
  uint32_t instruction;
  if(!ee_core_block_peek(st,st->pc,&instruction)||
     (!ee_jit_block_candidate(instruction)&&!ee_jit_block_terminal(instruction)))break;
#ifdef GEKKO2_IDLE_SKIP
  if(ee_core_idle_pc(st->pc))break;
#endif
  start=st->pc;
  n=ee_precise_execute(st,budget-total,0u,0u,1);
  total+=n;
 }
 return total;
#else
 (void)st;(void)budget;(void)first_word;return 0;
#endif
}

static void ee_precise_reset_cache(void)
{
 if(precise_active)return; /* Never release the currently executing buffer. */
#ifdef GEKKO2_SPEED_STUB
 if(precise_quiet_stub){ppc_dynarec_set_ee_quiet_stub(0,0);ppc_dynarec_set_ee_quiet_mem_stub(0);ppc_dynarec_set_ee_quiet_batch_stub(0);if(precise_quiet_batch_stub){ppc_code_cache_release(precise_quiet_batch_stub);precise_quiet_batch_stub=0;}if(precise_quiet_mem_stub){ppc_code_cache_release(precise_quiet_mem_stub);precise_quiet_mem_stub=0;}ppc_code_cache_release(precise_quiet_stub);precise_quiet_stub=0;}
#endif
 if(precise_chain_fn)ppc_code_cache_release((void*)precise_chain_fn);
#ifdef GEKKO2_EE_CHAIN_RESIDENCY
 if(precise_resident_chain_fn)ppc_code_cache_release((void*)precise_resident_chain_fn);
 precise_resident_chain_fn=0;
 precise_resident_map_ready=0;memset(&precise_resident_map,0,sizeof precise_resident_map);
 precise_resident_runs=precise_resident_retired=precise_resident_selected=0;
#endif
 if(precise_event_chain_fn)ppc_code_cache_release((void*)precise_event_chain_fn);
 precise_event_chain_fn=0;precise_event_chain_runs=precise_event_chain_retired=precise_event_chain_selected=0;
 precise_chain_fn=0;precise_native_successors=0;precise_direct_link_hits=0;
 precise_chain_source=0;precise_chain_source_serial=0;
 /* Empty entries need no individual clears; both arrays are cleared below. */
 for(unsigned n=0;n<EE_PRECISE_CACHE_SLOTS;n++)
  if(precise_cache[n].fn)ee_precise_release_slot(&precise_cache[n]);
 memset(precise_cache,0,sizeof(precise_cache));
 memset(precise_dispatch,0,sizeof(precise_dispatch));precise_dispatch_hits=0;
 memset(precise_page_generation,0,sizeof(precise_page_generation));
 precise_mapping_generation=0;precise_serial_source=0;
 precise_runs=precise_retired=precise_evictions=0;
 memset(precise_recency,0,sizeof precise_recency);precise_clock=0;precise_live_owners=precise_pressure_cursor=precise_blocked_epoch=0;precise_pressure_blocked=0;
 memset(precise_pressure_stats,0,sizeof precise_pressure_stats);memset(&precise_profile,0,sizeof precise_profile);
 memset(precise_budget_stats,0,sizeof precise_budget_stats);
 memset(precise_refusals,0,sizeof precise_refusals);
 memset(precise_lookups,0,sizeof precise_lookups);
}
