#include "core/hw/iop_service_hle.h"
#include "core/recompiler/optimization.h"
#include "core/runtime_profile.h"
#include "core/recompiler/iop_jit.h"
/*
 * iop_core.c - R3000A (IOP) interpreter
 *
 * Semantics ported from PCSX2's pcsx2/R3000AOpcodeTables.cpp and
 * R3000A.cpp (GPL-3.0), same approach as ee_core.c: not reinvented
 * from the MIPS manual, so behavior matches real PCSX2 for opcodes
 * covered.
 *
 * Coverage: the MIPS I integer core - ALU imm+reg, shifts, MULT/DIV,
 * HI/LO moves, branches (incl. REGIMM w/ link variants), jumps incl.
 * link register, byte/half/word load+store, and unaligned
 * LWL/LWR/SWL/SWR. Basic COP0 (MFC0/MTC0), plus a real SYSCALL
 * exception (Cause/EPC/Status updated and PC vectored to
 * 0xBFC00180/0x80000080 depending on Status.BEV, ported from PCSX2's
 * psxException() in R3000A.cpp - see the SYSCALL case below for the
 * one documented simplification: branch-delay-slot detection isn't
 * modeled). BREAK is deliberately kept as this project's own
 * clean-halt-for-testing convention rather than also raising a real
 * exception, since every test in tests/ relies on it to signal clean
 * completion.
 *
 * Wired into a shared address space with: the SIF mailbox mirror
 * (core/hw/sif.h, 0x1D000000 window), the IOP's own interrupt
 * controller (core/hw/iop_intc.h), its own DMA controller register
 * stubs (core/hw/iop_dma.h), counter/timer register stubs
 * (core/hw/iop_timers.h), a BIOS syscall trap for the classic
 * A0/B0/C0 call convention (core/hw/iop_hle_bios.h), and a module
 * registry scaffold (core/hw/iop_hle_modules.h) - see each header for
 * exact scope/caveats. Runs interleaved with the EE core via
 * source/core/system.c, wired into main.c's actual boot path.
 *
 * NOT implemented: IOP HLE module loading beyond the registry
 * scaffold (no real IRX parsing, no real module ABI), no TLB (the
 * IOP doesn't have one on real hardware either). UPDATE (task #115):
 * real hardware-interrupt exceptions (I_STAT&I_MASK) ARE now
 * delivered - see iop_check_hw_interrupt() below. UPDATE (tasks
 * #215/#216): the IOP counter/timer block now really ticks and can
 * raise IRQs (iop_timers_tick()), and a real IOP VBLANK_IN/VBLANK_OUT
 * interrupt is now modeled (iop_check_vblank()) - see each function's
 * own doc comment for citations. See docs/ROADMAP.md for the full
 * picture and docs/STATUS.md's "First real BIOS boot attempt"
 * section for what a real BIOS dump's execution against this core
 * actually looks like today.
 */

#include "core/iop/iop_core.h"
#include "core/hw/sif.h"
#include "core/hw/iop_intc.h"
#include "core/hw/iop_dma.h"
#include "core/hw/iop_timers.h"
#include "core/hw/iop_spu2.h" /* SPU2 register scaffold - task #95 */
#include "core/hw/iop_cdvd.h" /* CDVD register scaffold, no-disc boot case - ROADMAP section 7 */
#include "core/hw/iop_cdrom_legacy.h" /* Round 133 (173rd finding): PS1-legacy CD-ROM Index/Status Register - see header for full trace/citation */
#include "core/hw/iop_asyncio.h" /* Round 153 (task #307): real async I/O queue - see header for full trace/citation */
#include "core/hw/iop_sio2.h" /* Round 135 (175th finding): SIO2 controller/memory-card serial interface - see header for full trace/citation */
#include "core/hw/iop_spu_legacy.h" /* Round 136 (177th finding): PS1-legacy SPU register block - see header for full trace/citation */
#include "core/hw/iop_hle_bios.h"
#include "core/hw/iop_hle_events.h"
#include "core/hw/iop_hle_modules.h"
#include "core/hw/iop_hle_intr.h"
#include "core/hw/iop_hle_thread.h" /* Round 389: real THREADMAN thread scheduler/semaphore HLE */
#include "core/hw/iop_hle_heap.h" /* Round 421: real SYSMEM heap-export sentinel gates */
#include "core/hw/iop_module_loader.h" /* real IOP module/IRX loader - task #92 */
#include "core/hw/iop_excb.h" /* real exception-handler priority chains at RAM[0x100] - Round 22 */
#include "core/hw/iop_icfg.h" /* real ICFG register / EE INTC_SBUS raise - task #214, 85th finding */
#include "core/hw/iop_heap.h" /* Round 401: real SYSMEM free-list heap allocator port */
#include "core/hw/iop_elf.h" /* real ELF32/MIPS IOP loader - reused for device-table embedded images, task #221/#245 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include "core/recompiler/iop_lightrec.h"

#define IOP_RAM_SIZE (2 * 1024 * 1024)
/* Round 417 (task #152): real LOADCORE init code (disassembly-
 * confirmed, docs/STATUS.md Round 417) computes its OWN kernel stack
 * pointer directly from boot_info's real RAM_MB field:
 * `sp = (RAM_MB) << 20` - a genuine, deliberate real MIPS-kernel
 * convention (megabytes-to-bytes shift), not a bug, and not
 * something this project's own dispatcher-assigned INITIAL_SP (see
 * iop_module_loader.c) has any influence over, since LOADCORE
 * unconditionally overwrites $sp with this computed value the moment
 * its own entry code runs. With this project's honestly-reported
 * `BOOT_INFO_RAM_MB=2`, that computation is exactly 0x00200000 -
 * this project's own modeled RAM's exact top boundary, leaving real,
 * disassembly-confirmed kernel code (this specific registration-list
 * function's own nested stack frame) zero headroom to work with.
 * Rather than under-report guest-visible RAM (which would be
 * observable/incorrect for any other real code path that legitimately
 * queries total memory), this project's own BACKING allocation is
 * widened by a small, guest-invisible guard region - the reported
 * "2MB total memory" boundary guest code sees via boot_info/SYSMEM's
 * $a0 is unchanged, but this project's own `st->ram`/`st->ram_size`
 * now provide real backing bytes slightly past that boundary, so a
 * real kernel stack computed to sit exactly at the reported top of
 * RAM (as real LOADCORE's own code legitimately does) doesn't
 * silently fail on every read/write the instant it needs any stack
 * space at all. */
#define IOP_RAM_GUARD_SIZE 0x00004000u
#define IOP_RAM_BACKING_SIZE (IOP_RAM_SIZE + IOP_RAM_GUARD_SIZE)
#define IOP_RESET_VECTOR 0xBFC00000u

static iop_state_t g_iop;
static uint64_t route_native,route_interpreter,route_recovery;
static uint64_t ram_fast_reads,ram_fast_writes;
/* Boot-local interrupt acknowledgement and low-memory diagnostic state. */
static uint32_t g_iop_spurious_istat_mask,g_iop_spurious_istat_hi_mask;
static uint64_t s_zero_run,iop_block_stale;
static void (*iop_before_tick)(void);
uint64_t iop_core_route_stat(unsigned n){return n==0?route_native:n==1?route_interpreter:n==2?route_recovery:n==3?ram_fast_reads:n==4?ram_fast_writes:0;}

iop_state_t *iop_core_get_state(void) { return &g_iop; }

static inline uint8_t *iop_mem_ptr(iop_state_t *st, uint32_t addr, uint32_t size)
{
    if (addr >= IOP_RESET_VECTOR) {
        uint32_t off = addr - IOP_RESET_VECTOR;
        if (st->bios && off + size <= st->bios->size)
            return st->bios->data + off;
        return NULL;
    }
    uint32_t phys = addr & 0x1FFFFFFFu;
    if (phys + size <= st->ram_size)
        return st->ram + phys;
    return NULL;
}

static inline uint8_t *iop_fast_ram(iop_state_t *st,uint32_t addr,unsigned width)
{
 if(!gekko2_opt_enabled(GEKKO2_OPT_FASTMEM)||addr>=IOP_RESET_VECTOR||!st->ram||st->ram_size<width)return NULL;
 uint32_t phys=addr&0x1fffffffu;
 return phys<=st->ram_size-width?st->ram+phys:NULL;
}
/* Same little-endian-explicit approach as ee_core.c - IOP memory is
 * little-endian, our Wii/PowerPC build target is big-endian. */
uint8_t iop_mem_read8(iop_state_t *st, uint32_t addr)
{
    uint8_t *fast=iop_fast_ram(st,addr,1);
    if(fast){uint8_t *p=fast;ram_fast_reads++;return ((uint8_t)p[0]);}
    uint8_t cdvd_val;
    if (iop_cdvd_mmio_read8(addr, &cdvd_val))
        return cdvd_val;

    /* Round 133 (task #172/#221/#288, 173rd finding): the separate
     * PS1-legacy CD-ROM controller block (0x1F801800-0x1F801803),
     * NOT to be confused with the PS2-native CDVD page above - see
     * iop_cdrom_legacy.h for the full instruction-level trace that
     * found this project's own IOP boot path polls this exact
     * register's PRMEMPT bit. */
    uint8_t cdrom_legacy_val;
    if (iop_cdrom_legacy_mmio_read8(addr, &cdrom_legacy_val))
        return cdrom_legacy_val;

    /* Round 135 (task #172/#292, 175th finding): SIO2 - see
     * iop_sio2.h for the full citation trail. */
    uint8_t sio2_val;
    if (iop_sio2_mmio_read8(addr, &sio2_val))
        return sio2_val;

    uint8_t *p = iop_mem_ptr(st, addr, 1);
    return p ? *p : 0;
}

uint16_t iop_mem_read16(iop_state_t *st, uint32_t addr)
{
    uint8_t *fast=iop_fast_ram(st,addr,2);
    if(fast){uint8_t *p=fast;ram_fast_reads++;return ((uint16_t)p[0]) | ((uint16_t)p[1] << 8);}
    uint16_t spu2_val;
    if (iop_spu2_mmio_read16(addr, &spu2_val))
        return spu2_val;
    /* Round 136 (177th finding): PS1-legacy SPU - see
     * iop_spu_legacy.h for the full citation trail. */
    uint16_t spu_legacy_val16;
    if (iop_spu_legacy_mmio_read16(addr, &spu_legacy_val16))
        return spu_legacy_val16;

    /* Round 74 (114th finding, task #172 continuation): the IOP
     * interrupt controller (I_STAT/I_MASK/I_CTRL, core/hw/iop_intc.h)
     * previously had ONLY a 32-bit read/write path wired up here -
     * iop_mem_read32()/iop_mem_write32() dispatch to it, but this
     * 16-bit path never did. Live host-native tracing (scratch copy,
     * never committed) proved real BIOS-resident code genuinely
     * issues 16-bit `sh`/`lh`-class accesses to 0x1F801074 (I_MASK) -
     * observed real writes of value 0x0001 and 0x0008 following a
     * live, correctly-resolved EnableIntr(16) call (see the 113th/
     * 114th findings) - which were previously silently falling
     * through to a plain-RAM 16-bit store/load instead of reaching
     * the interrupt-controller model at all, explaining why I_MASK
     * stayed 0x00000000 even after the P/I twin-export-shadowing fix
     * (task #239) made EnableIntr's argument correct. Widening to the
     * full 32-bit read and truncating to the low 16 bits matches this
     * project's own existing "plain assignment" semantics for this
     * register (see iop_intc.c's write32 case) - every real access to
     * this register observed in tracing was 16-bit, so there is no
     * evidence of a competing 32-bit access whose upper half would
     * need preserving separately. */
    if (addr >= 0x1F801070u && addr <= 0x1F80107Bu) {
        uint32_t intc_val;
        if (iop_intc_mmio_read32(addr, &intc_val))
            return (uint16_t)intc_val;
    }

    /* Round 75 (115th finding, task #243, task #172 continuation):
     * same class of bug as the 114th finding above, this time for the
     * IOP counter/timer block (core/hw/iop_timers.h). Live host-native
     * tracing (scratch copy, never committed) of a real BIOS boot to
     * the current idle=1 steady state captured a genuine real 16-bit
     * `sh`-class write of value 0x0070 (preceded by a 0x0000 write) to
     * address 0xBF8014A4 - T5's MODE register (T5 base 0x1F8014A0 +
     * 0x04, see iop_timers.c's s_ranges[5]) - which this project's own
     * ps2sdk timrman.c citation (see iop_timers.h) says SHOULD be
     * 32-bit-only on real hardware (only T0-T2 use 16-bit access per
     * that community-reimplementation source). Per this session's
     * established discipline (trust live tracing over the ps2sdk
     * reference, which is a reimplementation, not the retail ROM),
     * the live evidence wins: real BIOS-resident code genuinely
     * issues a 16-bit access to a timer register this project
     * classified as 32-bit-only, and it was previously silently
     * falling through to a plain-RAM 16-bit load/store instead of
     * reaching the timer model at all - meaning the real MODE=0x70
     * configuration write was being dropped. iop_timers_mmio_read32()
     * internally calls find_timer(), which already masks off the
     * KUSEG/KSEG0/KSEG1 segment-select bits (phys = addr &
     * 0x1FFFFFFFu) before matching - so passing the raw addr through
     * here (unlike the intc check above, which needed its own literal
     * range gate) correctly resolves the observed KSEG1-aliased
     * 0xBF8014A4 form. No narrower per-timer width restriction is
     * applied since the evidence directly contradicts the assumption
     * that would have motivated one. */
    {
        uint32_t timer_val;
        if (iop_timers_mmio_read32(addr, &timer_val))
            return (uint16_t)timer_val;
    }

    uint8_t *p = iop_mem_ptr(st, addr, 2);
    if (!p) return 0;
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

uint32_t iop_mem_read32(iop_state_t *st, uint32_t addr)
{
    uint8_t *fast=iop_fast_ram(st,addr,4);
    if(fast){uint8_t *p=fast;ram_fast_reads++;return ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);}
    /* IOP-side SIF mailbox mirror (0x1D000000-0x1D0000FF) - see
     * core/hw/sif.h. Checked before the RAM/BIOS path since it's
     * outside IOP RAM's range anyway, but explicit is better than
     * relying on that fact silently. */
    uint32_t sif_val;
    if (sif_iop_mmio_read32(addr, &sif_val))
        return sif_val;
    uint32_t intc_val;
    if (iop_intc_mmio_read32(addr, &intc_val))
        return intc_val;
    uint32_t dma_val;
    if (iop_dma_mmio_read32(addr, &dma_val))
        return dma_val;
    uint32_t timer_val;
    if (iop_timers_mmio_read32(addr, &timer_val))
        return timer_val;
    uint32_t spu2_val;
    if (iop_spu2_mmio_read32(addr, &spu2_val))
        return spu2_val;
    uint32_t spu_legacy_val32;
    if (iop_spu_legacy_mmio_read32(addr, &spu_legacy_val32))
        return spu_legacy_val32;
    uint32_t icfg_val;
    if (iop_icfg_mmio_read32(addr, &icfg_val))
        return icfg_val;
    /* Round 135 (175th finding): SIO2 - see iop_sio2.h. */
    uint32_t sio2_val32;
    if (iop_sio2_mmio_read32(addr, &sio2_val32))
        return sio2_val32;

    uint8_t *p = iop_mem_ptr(st, addr, 4);
    if (!p) return 0;
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

void iop_mem_write8(iop_state_t *st, uint32_t addr, uint8_t val)
{
    uint8_t *fast=iop_fast_ram(st,addr,1);
    if(fast){if(!(st->cop0[12]&0x10000u)){fast[0]=(uint8_t)(val>>0);ram_fast_writes++;}return;}
    if (iop_cdvd_mmio_write8(addr, val))
        return;

    /* Round 133 (173rd finding) - see iop_mem_read8()'s matching
     * comment above. */
    if (iop_cdrom_legacy_mmio_write8(addr, val))
        return;

    /* Round 135 (175th finding): SIO2 - see iop_sio2.h. */
    if (iop_sio2_mmio_write8(addr, val))
        return;

    /* Round 766 (task #761): Status.IsC (bit 16, real R3000A "Isolate
     * Cache" bit) - see iop_mem_write32()'s matching comment below for
     * the full citation/evidence trail. Gated here too since real
     * hardware isolates ALL store widths, not just word stores. */
    if (st->cop0[12] & 0x00010000u)
        return;

    uint8_t *p = iop_mem_ptr(st, addr, 1);
    if (p) *p = val;
}

void iop_mem_write16(iop_state_t *st, uint32_t addr, uint16_t val)
{
    uint8_t *fast=iop_fast_ram(st,addr,2);
    if(fast){if(!(st->cop0[12]&0x10000u)){fast[0]=(uint8_t)(val>>0);fast[1]=(uint8_t)(val>>8);ram_fast_writes++;}return;}
    if (iop_spu2_mmio_write16(addr, val))
        return;
    /* Round 136 (177th finding): PS1-legacy SPU - see
     * iop_spu_legacy.h for the full citation trail. */
    if (iop_spu_legacy_mmio_write16(addr, val))
        return;

    /* Round 74 (114th finding) - see iop_mem_read16()'s matching
     * comment above for the full citation/evidence trail. Zero-
     * extending the 16-bit value into iop_intc_mmio_write32() mirrors
     * every real access to this register this round's tracing
     * observed (all 16-bit, none 32-bit), and matches this project's
     * own existing "plain assignment" write semantics for I_MASK/
     * I_STAT/I_CTRL. */
    if (addr >= 0x1F801070u && addr <= 0x1F80107Bu) {
        if (iop_intc_mmio_write32(addr, (uint32_t)val))
            return;
    }

    /* Round 75 (115th finding, task #243) - see iop_mem_read16()'s
     * matching comment above for the full citation/evidence trail.
     * Zero-extending mirrors the intc fix's treatment and this
     * project's existing "plain assignment" write semantics for
     * COUNT/MODE/TARGET (iop_timers_mmio_write32's own cases). */
    {
        if (iop_timers_mmio_write32(addr, (uint32_t)val))
            return;
    }

    /* Round 766 (task #761): Status.IsC - see iop_mem_write32()'s
     * matching comment below for the full citation/evidence trail. */
    if (st->cop0[12] & 0x00010000u)
        return;

    uint8_t *p = iop_mem_ptr(st, addr, 2);
    if (!p) return;
    p[0] = (uint8_t)(val & 0xFF);
    p[1] = (uint8_t)((val >> 8) & 0xFF);
}

void iop_mem_write32(iop_state_t *st, uint32_t addr, uint32_t val)
{
    uint8_t *fast=iop_fast_ram(st,addr,4);
    if(fast){if(!(st->cop0[12]&0x10000u)){fast[0]=(uint8_t)(val>>0);fast[1]=(uint8_t)(val>>8);fast[2]=(uint8_t)(val>>16);fast[3]=(uint8_t)(val>>24);ram_fast_writes++;}return;}
    if (sif_iop_mmio_write32(addr, val))
        return;
    if (iop_intc_mmio_write32(addr, val))
        return;
    if (iop_dma_mmio_write32(addr, val))
        return;
    if (iop_timers_mmio_write32(addr, val))
        return;
    if (iop_spu2_mmio_write32(addr, val))
        return;
    if (iop_spu_legacy_mmio_write32(addr, val))
        return;
    if (iop_icfg_mmio_write32(addr, val))
        return;
    /* Round 135 (175th finding): SIO2 - see iop_sio2.h. */
    if (iop_sio2_mmio_write32(addr, val))
        return;

    /* Round 766 (task #761): real R3000A COP0 Status bit 16 - "Isolate
     * Cache" (IsC). Evidence trail: a GT3 checkpoint-chain investigation
     * (task #760, docs/STATUS.md Round 765) found SYSMEM's own already-
     * correctly-loaded code at IOP RAM 0x00000C40-0x00000C98 silently
     * differed from the real BIOS ROM's SYSMEM ELF at exactly 8 words -
     * not a load-time relocation bug (iop_elf.c's relocation math was
     * independently re-verified correct against this project's own
     * SHT_REL-entry list, which has no entries anywhere near this
     * range). A live write-watch on that address range (task #761)
     * caught the real culprit directly: real BIOS boot code at IOP RAM
     * ~0x00103BE0-0x00103C28 executes the textbook R3000A cache-
     * initialization idiom - `lui t4,1; mtc0 t4,$12` (sets Status.IsC),
     * then a tight loop storing zero across address range 0x000-0xF80
     * in 128-byte strides (8 words per iteration, 16 bytes apart) -
     * `mtc0 zero,$12` (clears Status.IsC) - `lui at,0xFFFE; sw
     * t1,0x130(at)` / cache-drain reads at 0xBF801578/0xBF801450. This
     * is real, correct, harmless PS1/PS2-kernel-heritage boot code:
     * with IsC set, real R3000A hardware routes these stores into the
     * CPU's own I-cache/D-cache line storage instead of real RAM, so on
     * real hardware none of these "clear 0x000-0xF80" stores ever touch
     * actual memory - they exist purely to reset cache-line state
     * before the cache is used, a well-documented PS1/PS2-family boot
     * technique. This project's IOP core previously had no concept of
     * IsC at all - `case 0x04: MTC0` (above) already just does a plain,
     * unconditional `st->cop0[rd] = rt32`, so Status.IsC being set was
     * tracked in cop0[12] but never actually gated memory stores -
     * meaning this same harmless real-hardware idiom was instead
     * writing zero directly over real RAM 0x000-0xF80, corrupting
     * SYSMEM's own resident code (loaded at the real fixed address
     * 0x830 per Round 760, squarely inside that clobbered range) after
     * SYSMEM had already been correctly loaded. This is almost
     * certainly the same root cause behind Round 754-759's earlier,
     * still-unresolved corruption of SYSMEM's ordinal-10 QueryBlockSize
     * body at 0x400-0x4C0 (also inside 0x000-0xF80), independently
     * investigated from a different angle in that Round-753-759 arc.
     * The minimal, evidence-backed fix matching real hardware's
     * observable effect (since this project doesn't model a real
     * I/D-cache as separate storage) is to make ordinary RAM stores a
     * no-op while Status.IsC is set - MMIO/hardware-register writes are
     * dispatched above this check and are correctly NOT affected, since
     * IsC only isolates the CACHED KUSEG/KSEG0 RAM path on real
     * hardware, not uncached hardware-register accesses. */
    if (st->cop0[12] & 0x00010000u)
        return;

    uint8_t *p = iop_mem_ptr(st, addr, 4);
    if (!p) return;
    p[0] = (uint8_t)(val & 0xFF);
    p[1] = (uint8_t)((val >> 8) & 0xFF);
    p[2] = (uint8_t)((val >> 16) & 0xFF);
    p[3] = (uint8_t)((val >> 24) & 0xFF);
}

static uint64_t iop_idle_batch_stats[2];

int iop_core_init(const bios_image_t *bios)
{
    iop_service_hle_reset();
    iop_idle_batch_stats[0]=iop_idle_batch_stats[1]=0;
    iop_jit_reset_for_test();route_native=route_interpreter=route_recovery=0;ram_fast_reads=ram_fast_writes=0;
    memset(&g_iop, 0, sizeof(g_iop));
    g_iop_spurious_istat_mask=g_iop_spurious_istat_hi_mask=0;
    s_zero_run=iop_block_stale=0;iop_before_tick=NULL;

    iop_intc_init(); /* IOP interrupt controller register block - see core/hw/iop_intc.h */
    iop_dma_init();  /* IOP DMA controller register block - see core/hw/iop_dma.h */
    iop_timers_init(); /* IOP counter/timer register stub - see core/hw/iop_timers.h */
    iop_spu2_init(); /* SPU2 register scaffold - task #95, see core/hw/iop_spu2.h */
    iop_cdvd_init(); /* CDVD register scaffold, no-disc boot case - see core/hw/iop_cdvd.h */
    iop_cdrom_legacy_init(); /* PS1-legacy CD-ROM Index/Status Register - Round 133, see core/hw/iop_cdrom_legacy.h */
    iop_asyncio_init(); /* Round 153: real async I/O queue/channel dispatch - see core/hw/iop_asyncio.h */
    iop_sio2_init(); /* SIO2 controller/memory-card interface - Round 135, see core/hw/iop_sio2.h */
    iop_spu_legacy_init(); /* PS1-legacy SPU register block - Round 136, see core/hw/iop_spu_legacy.h */
    iop_hle_bios_init(); /* IOP BIOS syscall trap (A0/B0/C0) - see core/hw/iop_hle_bios.h */
    iop_hle_events_init(); /* Round 142: real B0-table Event subsystem - see core/hw/iop_hle_events.h */
    iop_hle_modules_init(); /* IOP module registry scaffold - see core/hw/iop_hle_modules.h */
    iop_hle_intr_init(); /* Round 109: clean-room RegisterIntrHandler/RegisterExceptionHandler HLE table - see core/hw/iop_hle_intr.h */
    iop_hle_thread_init(); /* Round 389: real THREADMAN thread scheduler/semaphore HLE - see core/hw/iop_hle_thread.h */
    iop_module_loader_reset(); /* real module/IRX boot sequencer - see core/hw/iop_module_loader.h */
    iop_icfg_init(); /* real ICFG register - task #214, 85th finding */
    iop_heap_init(); /* Round 401: real SYSMEM free-list heap allocator port - see core/hw/iop_heap.h */

    g_iop.ram = memalign(32, IOP_RAM_BACKING_SIZE);
    if (!g_iop.ram)
        return -1;
    memset(g_iop.ram, 0, IOP_RAM_BACKING_SIZE);
    g_iop.ram_size = IOP_RAM_BACKING_SIZE; /* Round 417 - see IOP_RAM_BACKING_SIZE's comment above; guest-visible reported size (BOOT_INFO_RAM_MB, SYSMEM_ENTRY_TOP_OF_MEMORY) is unchanged */

    iop_dma_bind_iop_ram(g_iop.ram, g_iop.ram_size); /* Round 199: lets the SIF0 CHCR-kick path read real IOP RAM source bytes - see core/hw/iop_dma.h */

    g_iop.bios = bios;
    g_iop.pc = IOP_RESET_VECTOR;
    g_iop.next_pc = IOP_RESET_VECTOR + 4;

    /* Real hardware/PCSX2 (R3000A.cpp's psxReset()) initializes
     * Status.BEV (bit 22, "use bootstrap exception vectors") to 1 on
     * reset - real BIOS boot code relies on this to route early
     * exceptions to 0xBFC00180 before it has set up RAM-resident
     * handlers and cleared this bit itself. Without this, our SYSCALL
     * exception handling (above) would incorrectly default to the
     * "normal" vector (0x80000080) from the very start. */
    g_iop.cop0[12] = 0x00400000u;

    /* Round 59 (91st finding, task #219), REVERTED Round 60 (93rd
     * finding, task #222): real PCSX2's psxReset() (pcsx2/R3000A.cpp,
     * the EXACT SAME function already cited two lines above for
     * Status.BEV) sets `psxRegs.CP0.n.PRid = 0x0000001f;` right next
     * to that Status line - this project's Status.BEV init carried
     * that over correctly but never the PRid half, leaving IOP COP0
     * register 15 at its zero-initialized default from the memset()
     * above. Real ps2sdk boot code (intrman.c/timrman.c/sifman.c/
     * udnl.c/modload.c/igreeting.c's real `_start()` functions, all
     * independently reading `get_mips_cop_reg(0, COP0_REG_PRId)`)
     * uses this value to decide P/I module-twin residency
     * (INTRMANP/I, TIMEMANP/I, ...) - `prid >= 16` selects the "I"
     * twin, matching real retail PS2 hardware rather than PS1-BC
     * mode.
     *
     * Round 59 set this to the real 0x1f value - correct and cited,
     * but empirically (live-traced, 92nd finding) it also changes
     * the real BIOS ROM's OWN early boot control flow (BEFORE this
     * project's module loader ever gets a chance to run - see
     * iop_module_loader_boot()'s own header comment: it only
     * activates when real ROM code's PC tries to escape into memory
     * this project doesn't model as fetchable, which never happens
     * on the corrected-PRId path since it stays inside real, valid
     * ROM content the whole way). With the real PRId, the ROM walks
     * into a real device/driver descriptor validation routine at
     * 0xBFC4A340+ (disassembled via the live PCSX2 reference
     * debugger) that this project has no data for, hits a genuine
     * dead-end/panic loop (write status byte 2 to IOP RAM address 0,
     * spin forever, confirmed via live diagnostic: neither MIPS
     * exception vector is ever entered from there), and NEVER
     * reaches this project's own synthesized module-loading system
     * at all - meaning all of tasks #86-217's boot-progress work
     * (SYSMEM through THREADMAN and the whole SIF/RPC/OSDSYS chain)
     * becomes unreachable, a real net regression toward the
     * project's actual goal (a visible splash screen), confirmed via
     * a controlled isolation test (reverting only this one line
     * while keeping every other Round 59 change restores the
     * familiar pre-Round-59 idle=1/pc~0x8000CFCC boot state exactly).
     *
     * Deliberately reverted to 0 for now - the real value is still
     * correctly cited above for whenever a future round manages to
     * model that early ROM device-table validation well enough not
     * to dead-end on it (tracked as task #222); until then, 0 is the
     * practically useful value, and `iop_module_loader.c`'s P/I
     * export-visibility fix (Round 59/60) has been made conditional
     * on this exact value so it automatically does the right thing
     * either way, with no further change needed here when this does
     * get revisited. */
    g_iop.cop0[15] = 0x00000000u;

    /* Round 22: real RAM[0x100] exception-handler priority-chain
     * table + array, all-empty (no handler registered) - see
     * include/core/hw/iop_excb.h. Must run after g_iop.ram is
     * allocated (iop_excb_init() writes through iop_mem_write32()). */
    iop_excb_init(&g_iop);

    /* Round 172 (task #337, 212th finding): EAGERLY invoke the real
     * IOP module/IRX loader (core/hw/iop_module_loader.h, task #92)
     * here, unconditionally, instead of relying solely on
     * iop_step()'s lazy "PC escaped to unfetchable memory" fallback
     * trigger (still present below, unchanged, as a safety net for
     * synthetic/test BIOS images that don't have a valid ROMDIR).
     *
     * WHY: host-native diagnostic this round (scan_state.c/
     * eager_boot.c, not committed - see STATUS.md's 212th finding)
     * conclusively confirmed the Round 59/91st-finding comment two
     * screens above is exactly right and still true today - with a
     * real SCPH-10000 BIOS + real Tekken Tag Tournament (Europe)
     * (Demo) disc, running system_run_interleaved() from a freshly-
     * inited state for 45,000,000+ IOP instructions NEVER once
     * triggers the lazy fallback (modules_attempted stayed 0 the
     * entire time) - the interpreted real ROM bootstrap code always
     * settles into already-resident, real, fetchable RAM content
     * (the long-documented 0x00032C58-0x00032D50 poll region) without
     * its PC ever actually escaping to unmapped memory, because
     * whatever real mechanism the ROM uses to copy each module's
     * bytes into RAM in the first place isn't modeled by this
     * project's interpreted-ROM-bootstrap path. The SAME diagnostic
     * showed that calling iop_module_loader_boot() eagerly, before
     * any ROM bootstrap instruction ever executes, successfully
     * loads all 29 real ROMDIR/IOPBTCONF modules (355/355 imports
     * resolved, 0 unresolved - identical, already-tested machinery
     * to task #92, just invoked earlier), and that running forward
     * from there reaches Status.IEc=1 for the very first time ever
     * in this trajectory (CpuEnableIntr, task #217's 88th finding,
     * finally gets called for real by real, genuinely-loaded module
     * code) and a brand-new IOP halt wall (unimplemented primary
     * opcode 0x3F at pc=0x8000041C) further than the old lazy-only
     * path has ever reached.
     *
     * HONEST SCOPE NOTE (shortcut, not exact hardware emulation):
     * this skips interpreting whatever real ROM hardware-bring-up
     * instructions normally execute between the reset vector and the
     * ROM's own module-loading phase (this project doesn't currently
     * model the real bytes-into-RAM copy mechanism that phase relies
     * on anyway, so those instructions were never doing anything
     * beyond driving this project's own already-known-incomplete
     * memory/MMIO model). This mirrors the same, already-established
     * project convention as Round 171's EE game-ELF-entry shortcut
     * and iso_loader.c's mount_iso() - jump straight to a REAL,
     * genuinely-verified-correct state (real modules, real ELF
     * loading/relocation/import resolution, real entry-point
     * execution) rather than waiting on a not-yet-modeled exact
     * mechanism. iop_module_loader_boot() itself is unchanged,
     * already-tested code (task #92); only the call site/timing is
     * new. Safe for synthetic/test BIOS images: iop_module_loader_
     * boot() returns 0 immediately (leaving st->pc/next_pc untouched)
     * whenever ROMDIR/IOPBTCONF/the first listed module can't be
     * found, exactly as its existing header comment documents - the
     * four existing tests that manage this loader's one-shot state
     * explicitly (test_iop_module_loader_bootinfo.c,
     * test_iop_loadcore_panic_bypass.c,
     * test_iop_registration_walk_panic_bypass.c,
     * test_iop_trap_stub_bypass.c) already call iop_module_loader_
     * reset() themselves immediately after iop_core_init(), which
     * clears the one-shot "attempted" flag this eager call sets, so
     * their own explicit iop_module_loader_boot() calls are
     * unaffected. */
    iop_module_loader_boot(&g_iop);

    return 0;
}

static void halt(const char *reason)
{
    g_iop.halted = 1;
    /* Round 340 (incidental, found while rebuilding for the interrupt-
     * priority fix above): same real category of fix as Round 332's
     * iop_module_loader.c one - strncpy's own semantics can't
     * statically prove null-termination when the source string might
     * be exactly (or longer than) the destination size, which is
     * exactly what triggered a real -Wstringop-truncation warning
     * here. Unlike Round 332's case there was no separate explicit
     * terminating write already guaranteeing safety, so this is a
     * genuine (if low-probability in practice, since call sites pass
     * short fixed string literals) latent non-termination risk, not
     * just a cosmetic warning - fixed properly by explicitly writing
     * the terminator after a bounded copy, rather than just silencing
     * the warning. */
    strncpy(g_iop.halt_reason, reason, sizeof(g_iop.halt_reason) - 1);
    g_iop.halt_reason[sizeof(g_iop.halt_reason) - 1] = '\0';
}

/* Real IOP hardware-interrupt bit position, per the public psx-spx
 * reference (https://psx-spx.consoledev.net/interrupts/, "COP0
 * Interrupt Handling" / "PSX specific COP0 Notes" - explicitly noted
 * on that same page as applying to the PS2 IOP too: "The PS2's IOP
 * has the same interrupt controller as the PS1 but with more
 * channels"). Unlike the EE's 8 independent Cause.IP0-IP7 lines (see
 * ee_core.c's EE_CAUSE_IP7), the real IOP/PS1 architecture routes
 * EVERY peripheral IRQ (VBLANK, DMA, timers, etc - all of I_STAT/
 * I_MASK) through this ONE single CPU interrupt line, bit 10 of both
 * Cause (IP2) and Status (IM2): "If one or more interrupts are
 * requested and enabled, ie. if (I_STAT AND I_MASK)=nonzero, then
 * cop0r13.bit10 gets set, and when cop0r12.bit10 and cop0r12.bit0 are
 * set, too, then the interrupt gets executed." Also unlike the EE's
 * timer interrupt (Cause.IP7, a real sticky software-cleared latch),
 * this line is explicitly documented as NON-latching: "cop0r13.bit10
 * is NOT a latch, ie. it gets automatically cleared as soon as
 * (I_STAT AND I_MASK)=zero" - so this project recomputes it fresh
 * every step rather than latching it once and waiting for software to
 * clear it. */
#define IOP_CAUSE_IP2  0x400u
#define IOP_STATUS_IM2 0x400u
/* Round 945 (task #447/#536/#933, pc=0x178A8 IOP-halt root-cause fix):
 * standard MIPS-I Cause register bit 31, "Branch Delay" - set by real
 * hardware whenever an exception's EPC points at a branch/jump
 * instruction rather than the instruction that would have executed
 * next, so the exception handler's ERET/RFE re-fetches and
 * re-executes the whole branch+delay-slot pair atomically instead of
 * silently discarding the pending branch. Same bit position this
 * project's own EE core (source/core/ee/ee_core.c, ee_raise_exception())
 * already uses and has shipped correctly for the R5900 side - this is
 * the IOP/R3000A-side application of the identical, already-proven
 * convention, not a new invention. See iop_check_hw_interrupt()'s own
 * updated comment below for the full citation trail and the concrete
 * empirical trace that proved this gap was live (not just theoretical). */
#define IOP_CAUSE_BD   0x80000000u

/* Round 22 (see docs/STATUS.md): confirmed, while investigating why
 * Status.IEc never has any observable effect, that this check simply
 * didn't exist anywhere in this file - iop_intc.c's own scope comment
 * already flagged it ("NOT modeled: actually raising a CPU interrupt/
 * exception in iop_core.c when I_STAT & I_MASK becomes nonzero").
 * Implements exactly the two-step real hardware behavior quoted in
 * the comment above: first, Cause.IP2 mirrors (I_STAT & I_MASK) live,
 * non-latching; second, if Cause.IP2 AND Status.IM2 AND Status.IEc
 * (bit 0) are all set, a real Interrupt exception (Cause.ExcCode=0)
 * is raised, vectored exactly like the existing SYSCALL case (Status.
 * BEV-dependent vector, same KU/IE mode-stack push formula).
 *
 * Round 945 (task #447/#536/#933, pc=0x178A8 IOP-halt root-cause fix):
 * this function used to always be handed `next_pc` = "the next
 * not-yet-executed instruction's own address" with no delay-slot
 * tracking at all - the exact gap this comment used to flag as an
 * honest, documented simplification, mirroring SYSCALL's own
 * still-unaddressed instance of the same gap. That simplification
 * stopped being harmless the moment a concrete, reproducible failure
 * was traced to it: a real GT3 diskless-boot checkpoint-chain halt at
 * pc=0x000178A8 (Round 944's own disassembly of the SIFMAN module
 * descriptor/string data at that address) was root-caused, via a
 * two-stage branch-history + interrupt-restore instrumentation pass
 * (not present anywhere in the tracked tree before this round), to
 * exactly this gap: a real hardware interrupt (irq=0, VBLANK_START)
 * was recognized and dispatched at the EXACT instant the IOP had just
 * executed `j 0x001078E4` at pc=0x000177B8 (one of the three
 * legitimate jump-stub table entries Round 944 already decoded there)
 * but had NOT yet executed that jump's own delay-slot instruction at
 * 0x000177BC. The old code captured EPC=0x177BC (the delay slot)
 * instead of the architecturally-correct EPC=0x177B8 (the branch
 * itself, with Cause.BD=1) - so when the interrupt handler returned
 * (via the already-correct Round 423 IOP_HLE_INTR_HANDLER_RETURN_
 * TRAMPOLINE restore path in source/hw/iop_hle_intr.c, which does
 * `pc=saved_epc; next_pc=saved_epc+4`), execution silently resumed at
 * raw 0x177BC instead of re-fetching the branch+delay-slot pair, the
 * pending jump to 0x1078E4 was discarded, and PC fell through
 * sequentially into the SIFMAN descriptor/string data and then
 * genuinely-empty RAM, triggering the Round-173 tripwire halt.
 *
 * Fix: this function now takes the pre-computed EPC and Cause.BD bit
 * directly from its caller (iop_step() detects whether `this_pc` was
 * itself a taken branch/jump this exact step - see the call site's
 * own comment below for the detection logic - and passes EPC=this_pc/
 * BD=IOP_CAUSE_BD in that case instead of EPC=the delay-slot address/
 * BD=0). No change is needed to either restore path (this project's
 * own Round 131 default-vector fallback below, or iop_hle_intr.c's
 * Round 423 trampoline restore) - both already do `pc=EPC;
 * next_pc=EPC+4`, which correctly re-fetches and re-executes the
 * whole branch+delay-slot pair from scratch when EPC points at the
 * branch itself, naturally re-establishing the pending jump via a
 * fresh BRANCH_TO() call during that re-execution. This mirrors the
 * ALREADY-CORRECT, already-shipped Cause.BD handling this project's
 * own EE/R5900 core (source/core/ee/ee_core.c's ee_raise_exception(),
 * `st->cop0[14] = this_pc - 4u;` / `st->cop0[13] |= 0x80000000u;`)
 * has used all along - the identical bit position (0x80000000u,
 * IOP_CAUSE_BD above) and the identical "EPC=branch instruction, not
 * delay slot" convention, just applied to the sibling R3000A core for
 * the first time. The SYSCALL case (line ~1422 below) has the exact
 * same theoretical gap but no concrete failure has been traced to it
 * yet - left unchanged and still honestly flagged there, out of scope
 * for this fix. */
/* Task #216 (splash-screen blocker investigation, continued from
 * #214/#215): real IOP hardware exposes its own VBLANK interrupt,
 * distinct from the EE's already-modeled VBLANK (see ee_core.c's
 * ee_check_vblank() comment for the EE side). Real PCSX2's
 * IopCounters.cpp confirms this directly and was fetched/cited this
 * round: psxVBlankStart() calls iopIntcIrq(0), psxVBlankEnd() calls
 * iopIntcIrq(11) - independently corroborated by allkern/iris's
 * src/iop/intc.h, which names the exact same bit positions
 * IOP_INTC_VBLANK_IN (0x00000001, bit 0) and IOP_INTC_VBLANK_OUT
 * (0x00000800, bit 11), and calls them from its GS vsync-start/-end
 * handlers alongside the equivalent EE-side EE_INTC_VBLANK_IN/OUT
 * raises - two independent real sources agreeing on both bit
 * numbers. This is a real, continuously-firing, hardware-driven
 * interrupt line, independent of what the IOP CPU itself is doing -
 * the same property that made the timer-tick mechanism (#215) a
 * candidate for waking a genuinely `idle`-parked IOP (see
 * iop_core.h's `idle` field doc comment) - VBLANK is an even more
 * certain real-hardware source of periodic activity than a
 * boot-configured timer, since it requires no prior MODE-register
 * setup by any module at all.
 *
 * Timing: reuses this project's own already-established, already-
 * cited EE_CYCLES_PER_FRAME_NTSC (ee_core.c: 4921488, from the real
 * 294.912 MHz EE clock / 59.94 Hz NTSC refresh), divided by the real
 * ~8:1 EE:IOP clock ratio this project already documents and targets
 * (source/core/system.c's own header comment: ~294 MHz EE vs ~33-36
 * MHz IOP) rather than computing an independent IOP-clock figure, to
 * stay consistent with the one ratio this project has already
 * committed to elsewhere. VBLANK_END's offset reuses the same 1/12-
 * of-frame approximation ee_check_vblank() already uses and
 * documents at length (real NTSC vertical blanking is roughly 8.5%
 * of a frame).
 *
 * Round 943 (task #447/#536, IOP-freeze root-cause fix): previously
 * ticked here off `instructions_executed`, on the documented
 * assumption that this gave the same "1-instruction=1-cycle,
 * unconditional-even-while-idle" property iop_timers_tick()'s own
 * per-timer `count++` already has. That assumption was WRONG:
 * instructions_executed only increments inside iop_step()'s real
 * fetch/decode/execute body (see that function), which the `idle`
 * early-return in iop_core_step() skips entirely - so the instant
 * the IOP went idle, this phase computation silently froze solid at
 * whatever residual value it held, and could never again equal 0 or
 * IOP_CYCLES_VBLANK_DURATION. Confirmed empirically against a real
 * GT3/diskless-boot checkpoint parked at pc=0x00155910, idle=1: over
 * 1,845,558 further iop_core_step() calls (more than 3 nominal
 * VBLANK periods), istat/Cause never changed even once. Now reads
 * `sched_ticks` instead - a field incremented unconditionally at the
 * very top of every iop_core_step() call, See iop_core.h's own
 * updated doc comment for the full citation. */
#define IOP_CYCLES_PER_FRAME_NTSC  (4921488u / 8u)
#define IOP_CYCLES_VBLANK_DURATION (IOP_CYCLES_PER_FRAME_NTSC / 12u)
#define IOP_INTC_IRQ_VBLANK_START  0
#define IOP_INTC_IRQ_VBLANK_END    11

static uint64_t iop_vblank_last_tick=UINT64_MAX;
static uint32_t iop_vblank_phase;
static uint32_t iop_vblank_phase_now(const iop_state_t *st)
{
 if(st->sched_ticks==iop_vblank_last_tick)return iop_vblank_phase;
 if(iop_vblank_last_tick!=UINT64_MAX&&st->sched_ticks==iop_vblank_last_tick+1u) {
  if(++iop_vblank_phase==IOP_CYCLES_PER_FRAME_NTSC)iop_vblank_phase=0;
 } else iop_vblank_phase=(uint32_t)(st->sched_ticks%IOP_CYCLES_PER_FRAME_NTSC);
 iop_vblank_last_tick=st->sched_ticks;return iop_vblank_phase;
}
static void iop_check_vblank(iop_state_t *st)
{
    uint32_t phase = iop_vblank_phase_now(st);
    if (phase == 0)
        iop_intc_raise(IOP_INTC_IRQ_VBLANK_START);
    else if (phase == IOP_CYCLES_VBLANK_DURATION)
        iop_intc_raise(IOP_INTC_IRQ_VBLANK_END);
}

/* Round 935 (task #919, GT3 disc-boot SIF-RPC freeze root-cause fix):
 * when iop_check_hw_interrupt() falls all the way through to the fixed
 * default vector (0x80000080/0xBFC00180) because NO real handler -
 * neither the RegisterIntrHandler table nor the older ExCB mechanism -
 * is registered for ANY currently pending+unmasked IRQ (low range or
 * soft range), the interrupt source bit(s) that caused this exact
 * fallback are recorded here. iop_step()'s "Round 129/131 default/
 * spurious-interrupt-return stub" (the `pc == 0x80000080u &&
 * st->exception_pending` block below) consumes and clears these
 * recorded bits out of the real intc->istat/istat_hi hardware
 * registers when it resumes the interrupted instruction for the
 * Interrupt-exception-class case.
 *
 * This mirrors the ALREADY-CORRECT, already-shipped precedent in
 * source/hw/iop_hle_intr.c's IOP_HLE_INTR_HANDLER_RETURN_TRAMPOLINE
 * completion path, which does `intc->istat &= ~(1u <<
 * g.dispatched_irq)` (or the istat_hi equivalent) before resuming -
 * that path acknowledges the source bit whenever a REAL handler
 * finishes servicing it. The spurious-fallback stub was the one
 * sibling code path that modeled "no real handler exists for this
 * IRQ" without ever performing the equivalent acknowledgment,
 * because - unlike the trampoline case - it never had a specific
 * `dispatched_irq` value recorded to acknowledge.
 *
 * Root-caused via direct instrumentation against a real GT3 disc-boot
 * checkpoint (r931_gt3_progress.ckpt): with nothing in that boot
 * context ever registering a handler for the genuine SIF0 DMA-
 * completion interrupt (both the raw master line, bit 3, and the
 * correct per-channel soft line, bit 42 / IOP_IRQ_DMA_SIF0), the old
 * code resumed the interrupted instruction at EPC without ever
 * clearing intc->istat/istat_hi - so the identical interrupt refired
 * the instant Status.IEc was restored, re-vectoring back to the same
 * fixed default vector with the same EPC forever. A fine-grained
 * per-step trace (/tmp/r935_fine.c) and a 5,000,000-step exception-
 * counting trace (/tmp/r935_exc_trace.c) both confirmed a
 * deterministic, self-sustaining 3-step storm (idle -> exception-fire
 * -> resume-without-ack -> re-idle), with the IOP's pc permanently
 * stuck at 0x00155b40 and ZERO forward progress of any kind - which is
 * why no real IOP code ever ran far enough to set the EE-visible
 * SIF_SMFLAG bit 30 that GT3's real BIOS SIF-cmd dispatcher
 * (0x8000FBA0) waits on before performing the actual SIF-RPC DMA kick.
 *
 * Only the SPECIFIC bit(s) that were pending+unmasked AND failed both
 * real dispatch mechanisms this exact tick are recorded/cleared - not
 * a blind full-register clear - so IRQs that DO have a real handler
 * registered are entirely unaffected (they already return early via
 * iop_hle_intr_dispatch_interrupt()/iop_excb_dispatch_interrupt()
 * above and never reach this fallback path at all). */


static void iop_check_hw_interrupt(iop_state_t *st, uint32_t epc, uint32_t cause_bd)
{
    iop_intc_state_t *intc = iop_intc_get_state();

    /* Round 112 (task #172/#267/#268, 152nd finding's honestly-
     * documented gap): Cause.IP2 must also reflect the real 32-63
     * "soft" irq range (istat_hi/imask_hi - see iop_intc.h), not just
     * the 32-bit I_STAT/I_MASK MMIO registers. On real hardware both
     * ranges are still genuinely "an IOP interrupt is pending" from
     * the CPU's point of view - the split between memory-mapped and
     * INTRMAN-internal is purely about HOW the source is identified/
     * multiplexed, not whether it drives the same physical Cause.IP2
     * line. */
    if ((intc->istat & intc->imask) || (intc->istat_hi & intc->imask_hi))
        st->cop0[13] |= IOP_CAUSE_IP2;
    else
        st->cop0[13] &= ~IOP_CAUSE_IP2;

    if (!(st->cop0[13] & IOP_CAUSE_IP2))
        return;
    if (!(st->cop0[12] & IOP_STATUS_IM2))
        return;
    if (!(st->cop0[12] & 0x1u)) /* Status.IEc */
        return;

    /* Round 945: Cause.ExcCode=0 (Interrupt) and Cause.BD together -
     * see this function's own doc comment above for the full citation
     * trail on why BD/epc are now caller-supplied instead of always
     * being the plain "next not-yet-executed instruction" address. */
    st->gpr_generation++; /* IRQ dispatch may write argument/link GPRs. */
    st->cop0[13] = (st->cop0[13] & ~(0x7Fu | IOP_CAUSE_BD)) | cause_bd;
    if(cause_bd)st->cop0[6]=st->next_pc;
    iop_core_flush_pipeline(st);
    st->cop0[14] = epc; /* EPC */
    st->cop0[12] = (st->cop0[12] & ~0x3Fu) | ((st->cop0[12] & 0x0Fu) << 2); /* Status stack push */
    st->exception_pending = 1; /* task #156 - see iop_core.h's field comment */

    /* Round 109 (task #172/#247/#249 continuation, following the
     * user's "lets fix this now and maybe the sony docs have some
     * info" directive): before falling back to this project's
     * pre-existing fixed-vector behavior, give the clean-room
     * RegisterIntrHandler table (core/hw/iop_hle_intr.h) a chance to
     * redirect straight into a REAL, module-registered handler for
     * whichever specific IRQ is actually firing - real MIPS/R3000A
     * hardware convention: the lowest-numbered set bit among
     * currently pending+unmasked sources is serviced first (same
     * priority-by-bit-number convention this project's own IOP_INTC_
     * IRQ_VBLANK_START/END constants already rely on being bit 0/11
     * respectively). Falls through to the unmodified default
     * (fixed-vector) behavior below when nothing is registered for
     * that bit - per the 135th finding's own explicit design
     * requirement, point (b).
     *
     * Round 174 (task #339, 214th finding): live host-native tracing
     * against the real Round 172/173 boot trajectory found a genuine,
     * previously-hidden gap in this priority scheme, not a missing
     * handler. iop_dma_signal_channel_done() (iop_dma.c, Round 113/
     * 114) already raises BOTH the shared real hardware line
     * (iop_intc_raise(3) - the one real IOP_IRQ_DMA master line, bit
     * 3) AND the corresponding per-channel soft line (Round 112's
     * istat_hi/imask_hi range - here bit 42, IOP_IRQ_DMA_SIF0) for
     * the exact same real completion event - see iop_intc.h's own
     * citation that this split is "purely about HOW the source is
     * identified/multiplexed, not whether it drives the same
     * physical Cause.IP2 line". A live trace confirmed no module ever
     * calls RegisterIntrHandler(3, ...)/registers an ExCB chain for
     * the raw shared line (plausibly because real INTRMAN keeps that
     * master-line demux internal to its own un-executed real C code,
     * per this project's clean-room scope), so every dispatch for
     * irq=3 fell through to the fixed default vector - and, because
     * the old code only ever consulted the soft range in an `else`
     * branch (reached only when the LOW range had nothing pending at
     * all), the already-real, already-registered handler at
     * `intr_handler_addr[42]` (confirmed nonzero, =0x00117cb4, in the
     * same trace) was never given a chance, even though it was
     * simultaneously pending. Over thousands of these missed
     * dispatches the module loader's own "no more real code to
     * resume" bypass (is_unconditional_trap_stub(), iop_module_
     * loader.c) kept re-matching stale bytes sitting at the shared
     * default-vector address and re-entering its "module boot
     * sequence complete" path every cycle, which is what actually
     * produced the freeze/crawl pattern this round's own earlier
     * diagnostic mis-attributed to a THREADMAN thread-context/TCB
     * gap (213th finding) - a real, honest correction, not a
     * fabricated new mechanism: the underlying data (THREADMAN's
     * irq=16 Timer5 handler dispatching cleanly) was real, but the
     * NEW wall immediately afterward has a different, now-identified
     * cause. Fix: after a low-range irq's dispatch attempts both
     * fail, also try the soft range if it is independently pending,
     * before falling through to the default vector - same "give a
     * real registered handler a chance first" precedent already
     * applied to the low range above, just no longer gated on the
     * low range being completely empty. */
    {
        /* Round 340 (task #423 continuation, direct extension of the
         * already-shipped Round 174 precedent): host-native tracing
         * against the restored real BIOS/disc scratch driver (Round
         * 335-339's investigation chain) caught a genuine, previously
         * hidden priority-starvation gap, one level deeper than the
         * low-range-vs-soft-range boundary Round 174 already fixed.
         * The OLD code below only ever computed the SINGLE lowest
         * pending+unmasked low-range bit and, if BOTH real dispatch
         * mechanisms (RegisterIntrHandler table, then the older ExCB
         * chain) failed to find a real handler for that one bit, gave
         * up on the entire low range and fell straight through to the
         * soft range / fixed-vector default - even when a DIFFERENT,
         * higher-numbered low-range bit (lower real priority, but
         * still pending+unmasked) already had a real, ready,
         * previously-registered handler.
         *
         * Directly observed: CDVDMAN's own real IRQ2 handler
         * (registered via a real RegisterIntrHandler(2,...) call
         * during CDVDMAN's own one-time real init - see Round 338)
         * sat ready and non-zero for the entire remainder of a
         * 90-million-instruction fine-grained trace, while VBLANK_START
         * (bit 0, real, always the numerically-lowest pending bit
         * whenever a VBLANK is pending, which this project's own
         * already-correct iop_check_vblank() raises unconditionally
         * every real frame - see this file's own IOP_INTC_IRQ_VBLANK_
         * START citation above) had NO real handler registered yet at
         * this point in the trace and kept re-falling-through to the
         * generic fixed-vector default stub every single pass, which
         * (correctly, per its own Round 129/131 design) resumes
         * execution at EPC without ever touching intc->istat - so the
         * same VBLANK_START bit simply stays pending forever, and the
         * OLD code's "only try the single lowest bit" logic meant
         * IRQ2's already-ready handler was never even attempted,
         * confirmed via direct instrumentation (0 dispatches to
         * 0x00120d60 across the entire trace despite a real,
         * correctly-set-up handler sitting there).
         *
         * Fix: mirror Round 174's own already-shipped, already-proven
         * "give the next candidate its own independent chance rather
         * than blocking on an earlier one's failure" design, applied
         * one level deeper - try EVERY pending+unmasked low-range bit,
         * in ascending (real-hardware priority) order, until one
         * actually dispatches via either real mechanism, rather than
         * stopping after the first (numerically lowest) bit's
         * dispatch attempt fails. This changes nothing about real
         * priority ORDER (a lower-numbered bit with a real handler
         * still always wins over a higher-numbered one, exactly as
         * before) - it only stops a real, ready handler for a
         * higher-numbered bit from being starved forever by a lower-
         * numbered bit that has no real handler at all yet. */
        /* Round 935: snapshot the full low-range pending+unmasked
         * mask BEFORE the loop below starts clearing bits out of
         * the local `pending` copy, so that if the loop exhausts
         * every bit without a single real dispatch succeeding, the
         * exact set of bits responsible can be recorded for the
         * iop_step() spurious-interrupt stub to acknowledge. */
        uint32_t low_pending_snapshot = intc->istat & intc->imask;
        uint32_t pending = low_pending_snapshot;
        while (pending) {
            uint32_t lowest_bit = pending & (~pending + 1u); /* isolate lowest set bit */
            uint32_t irq = 0;
            uint32_t probe = lowest_bit;
            while (!(probe & 1u)) { probe >>= 1; irq++; }
            if (iop_hle_intr_dispatch_interrupt(st, irq))
                return;
            /* Round 168 (see core/hw/iop_excb.h's "ROUND 168 UPDATE"
             * comment for the full citation trail): real module code
             * can register a handler via the OLDER SysEnqIntRP/ExCB
             * mechanism instead of the newer RegisterIntrHandler API
             * just checked above - both are real, coexisting IOP
             * kernel APIs. A live, host-native trace (208th finding)
             * proved this project's own CD-ROM driver does exactly
             * that (3 real SysEnqIntRP calls, zero RegisterIntrHandler
             * calls, for the entire boot) - so this second fallback is
             * not speculative, it fixes an observed, real gap. */
            if (iop_excb_dispatch_interrupt(st, irq))
                return;
            pending &= ~lowest_bit; /* Round 340: this bit had no real handler either way - try the next-lowest pending bit instead of giving up on the whole low range */
        }
        /* Round 112 (soft-range consultation) + Round 174 (no longer
         * gated on `!pending` - see this block's own doc comment
         * above for the full citation trail): the real 0-31 hardware
         * range still takes numeric priority when it actually
         * resolves to a real handler (unchanged - the early `return`
         * above still wins whenever the low range dispatches
         * successfully), but a low-range irq that fails BOTH
         * dispatch mechanisms no longer blocks the soft range from
         * getting its own, independent chance at the same tick. */
        uint32_t failed_soft_bit_mask = 0;
        {
            uint32_t soft_pending = intc->istat_hi & intc->imask_hi;
            if (soft_pending) {
                uint32_t bit = 0;
                while (!(soft_pending & 1u)) { soft_pending >>= 1; bit++; }
                if (iop_hle_intr_dispatch_interrupt(st, 32u + bit))
                    return;
                if (iop_excb_dispatch_interrupt(st, 32u + bit)) /* Round 168 - see above */
                    return;
                /* Round 935: reaching here means the single soft-range
                 * bit consulted above (the real-hardware-priority lowest
                 * pending+unmasked one) failed BOTH dispatch mechanisms
                 * too - record it so it doesn't storm the same way the
                 * low range's exhausted bits would. */
                failed_soft_bit_mask = 1u << bit;
            }
        }

        /* Round 935 (task #919): every low-range bit that was
         * pending+unmasked at loop entry (low_pending_snapshot) has now
         * failed both real dispatch mechanisms - the `while (pending)`
         * loop above only returns early on success, so falling out of
         * it (and past the soft-range block, which likewise only
         * returns early on success) means NOTHING serviced any of
         * these bits this tick. Record them (plus any single failed
         * soft bit) for iop_step()'s spurious-interrupt-return stub to
         * acknowledge/clear out of the real intc->istat/istat_hi
         * registers before resuming - see this function's own leading
         * comment block for the full root-cause citation. */
        g_iop_spurious_istat_mask = low_pending_snapshot;
        g_iop_spurious_istat_hi_mask = failed_soft_bit_mask;
    }

    uint32_t vector = (st->cop0[12] & 0x400000u) ? 0xBFC00180u : 0x80000080u; /* Status.BEV */
    st->pc = vector;
    st->next_pc = vector + 4u;
}

/* A load writes after one intervening instruction. An explicit write or
 * another load to the same destination cancels the earlier pending write.
 * Merge loads forward the pending value without forwarding their EA base. */
void iop_core_flush_pipeline(iop_state_t *st)
{
    if(st->load_delay_reg){st->gpr_generation++;st->gpr[st->load_delay_reg]=st->load_delay_value;}
    st->load_delay_reg=0;
    st->branch_delay_pending=0;
    st->pipe_active=0;
    st->gpr[0]=0;
}
static unsigned iop_write_register(uint32_t w)
{
    unsigned op=w>>26,rt=(w>>16)&31u,fn=w&63u;
    if(op==0u) {
        if(fn==9u || fn==0u||fn==2u||fn==3u||fn==4u||fn==6u||fn==7u||
           fn==0x10u||fn==0x12u||(fn>=0x20u&&fn<=0x27u)||fn==0x2au||fn==0x2bu)
            return (w>>11)&31u;
        return 0;
    }
    if(op==3u || (op==1u&&(rt==0x10u||rt==0x11u)))return 31u;
    if((op>=8u&&op<=15u)||(op>=0x20u&&op<=0x26u)||
       (op==0x10u&&((w>>21)&31u)==0u))return rt;
    return 0;
}
static int iop_load_instruction(uint32_t w)
{
    unsigned op=w>>26;
    return op==0x20u||op==0x21u||op==0x22u||op==0x23u||op==0x24u||op==0x25u||op==0x26u||
           (op==0x10u&&((w>>21)&31u)==0u);
}
static int iop_branch_instruction(uint32_t w)
{
    unsigned op=w>>26,rt=(w>>16)&31u,fn=w&63u;
    return (op>=2u&&op<=7u)||(op==1u&&(rt<=1u||rt==0x10u||rt==0x11u))||
           (op==0u&&(fn==8u||fn==9u));
}
static void iop_pipeline_begin(iop_state_t *st,uint32_t pc,uint32_t word)
{
    st->pipe_pc=pc;st->pipe_word=word;st->pipe_fault=0;st->pipe_active=1;
    st->pipe_bd=st->branch_delay_pending;
    st->pipe_branch_pc=st->branch_pc;st->pipe_branch_target=st->next_pc;
    st->branch_delay_pending=0;
    st->pipe_write_reg=(uint8_t)iop_write_register(word);
    st->pipe_load_reg=iop_load_instruction(word)?(uint8_t)((word>>16)&31u):0;
    st->pipe_load_old=st->gpr[st->pipe_load_reg];
}
static void iop_raise_sync(iop_state_t *st,unsigned code,uint32_t badaddr,int address_error)
{
    st->cop0[13]=(st->cop0[13]&~(0x7fu|IOP_CAUSE_BD))|(code<<2)|
                   (st->pipe_bd?IOP_CAUSE_BD:0u);
    st->cop0[14]=st->pipe_bd?st->pipe_branch_pc:st->pipe_pc;
    if(st->pipe_bd)st->cop0[6]=st->pipe_branch_target;
    if(address_error)st->cop0[8]=badaddr;
    uint32_t vector=(st->cop0[12]&0x400000u)?0xbfc00180u:0x80000080u;
    st->pc=vector;st->next_pc=vector+4u;
    st->cop0[12]=(st->cop0[12]&~0x3fu)|((st->cop0[12]&0xfu)<<2);
    st->exception_pending=1;st->pipe_fault=1;st->branch_delay_pending=0;
}
static int iop_operand_fault(iop_state_t *st,uint32_t w)
{
    unsigned op=w>>26,rs=(w>>21)&31u,rt=(w>>16)&31u,fn=w&63u;
    uint32_t a=st->gpr[rs],b=st->gpr[rt],imm=(uint32_t)(int32_t)(int16_t)w;
    uint32_t ea=a+imm;
    if(((op==0x21u||op==0x25u||op==0x29u)&&(ea&1u))||
       ((op==0x23u||op==0x2bu)&&(ea&3u))) {
        iop_raise_sync(st,op>=0x28u?5u:4u,ea,1);return 1;
    }
    if(op==8u || (op==0u&&(fn==0x20u||fn==0x22u))) {
        if(op==8u)b=imm;
        uint32_t value=(op==0u&&fn==0x22u)?a-b:a+b;
        uint32_t overflow=(op==0u&&fn==0x22u)?((a^b)&(a^value)):(~(a^b)&(a^value));
        if(overflow&0x80000000u){iop_raise_sync(st,12u,0,0);return 1;}
    }
    return 0;
}

/* 0: HLE consumed tick; 1: halted; 2: fetched real instruction. */
static int iop_prepare(uint32_t *prepared_pc,uint32_t *prepared_word)
{
    iop_state_t *st = &g_iop;
    uint32_t pc = st->pc;
    if(pc&3u) {
        iop_pipeline_begin(st,pc,0);iop_raise_sync(st,4u,pc,1);
        iop_core_flush_pipeline(st);return 0;
    }

    if(iop_service_hle_try_handle(st,pc)){st->instructions_executed++;return 0;}

    /* All five HLE gate families below match exact PCs <= 0x44c.
     * Higher guest PCs have no side effects in those handlers. Keep the
     * module loader's live-code checks outside this guard. */
    if(!gekko2_opt_enabled(GEKKO2_OPT_EE_SERVICES)||pc<=IOP_HLE_HEAP_SYSMEM_ORDINAL10_QUERYBLOCKSIZE) {
    /* IOP BIOS syscall trap (0xA0/0xB0/0xC0) - see core/hw/iop_hle_bios.h.
     * If this is one of the three trap addresses, the "instruction"
     * there is not really interpreted at all - the call is handled
     * natively and control is redirected straight to the return
     * address, so this step is complete without any real MIPS
     * instruction being fetched/decoded. */
#ifdef R936_STEP_TRACE
    if (iop_hle_bios_try_handle(st, pc)) {
        fprintf(stderr, "[R936STEP] pc=0x%08x handled by iop_hle_bios_try_handle\n", pc);
        st->instructions_executed++;
        return 0;
    }
#else
    if (iop_hle_bios_try_handle(st, pc)) {
        st->instructions_executed++;
        return 0;
    }
#endif

    /* Round 109 (task #172/#247/#249 continuation): the clean-room
     * RegisterIntrHandler/RegisterExceptionHandler handler-
     * registration table's own 5 call gates and its "handler
     * finished" return trampoline - see core/hw/iop_hle_intr.h for
     * the full design. Checked in the same "intercept before fetch"
     * spot as the A0/B0/C0 table just above. */
#ifdef R936_STEP_TRACE
    if (iop_hle_intr_try_handle(st, pc)) {
        fprintf(stderr, "[R936STEP] pc=0x%08x handled by iop_hle_intr_try_handle\n", pc);
        st->instructions_executed++;
        return 0;
    }
#else
    if (iop_hle_intr_try_handle(st, pc)) {
        st->instructions_executed++;
        return 0;
    }
#endif

    /* Round 389: real THREADMAN thread scheduler/semaphore HLE - see
     * core/hw/iop_hle_thread.h. Same "intercept before fetch" spot as
     * every other HLE table above; this one can also perform a full
     * context switch (a plain register-file struct copy - see that
     * file's own header comment) before returning, so st->pc may end
     * up pointing at a completely different thread's own resumed
     * code, not just the syscall's own $ra. */
#ifdef R936_STEP_TRACE
    if (iop_hle_thread_try_handle(st, pc)) {
        fprintf(stderr, "[R936STEP] pc=0x%08x handled by iop_hle_thread_try_handle\n", pc);
        st->instructions_executed++;
        return 0;
    }
#else
    if (iop_hle_thread_try_handle(st, pc)) {
        st->instructions_executed++;
        return 0;
    }
#endif

    /* Round 421 (task #160, docs/STATUS.md Round 420 root cause):
     * real SYSMEM heap-management export gates (AllocSysMemory/
     * FreeSysMemory/QueryMemSize/QueryMaxFreeMemSize/
     * QueryTotalFreeMemSize) - see core/hw/iop_hle_heap.h. Same
     * "intercept before fetch" spot as every other HLE table above;
     * redirects real module heap calls to this project's own
     * already-tested synthetic heap model (iop_heap.c) instead of
     * real, un-coordinated SYSMEM ROM code whose heap arena collides
     * with this project's own separate module-loading bump_alloc()
     * arena. */
#ifdef R936_STEP_TRACE
    if (iop_hle_heap_try_handle(st, pc)) {
        fprintf(stderr, "[R936STEP] pc=0x%08x handled by iop_hle_heap_try_handle\n", pc);
        st->instructions_executed++;
        return 0;
    }
#else
    if (iop_hle_heap_try_handle(st, pc)) {
        st->instructions_executed++;
        return 0;
    }
#endif

    /* Round 168: real ExCB-chain dispatch return trampoline - see
     * core/hw/iop_excb.h's "ROUND 168 UPDATE" comment. Same
     * "intercept before fetch" spot as the RegisterIntrHandler
     * trampoline just above. */
#ifdef R936_STEP_TRACE
    if (iop_excb_try_handle(st, pc)) {
        fprintf(stderr, "[R936STEP] pc=0x%08x handled by iop_excb_try_handle\n", pc);
        st->instructions_executed++;
        return 0;
    }
#else
    if (iop_excb_try_handle(st, pc)) {
        st->instructions_executed++;
        return 0;
    }
#endif
    } /* Exact low-PC HLE gates. */

    /* Real IOP module/IRX boot sequencer trampoline (task #92) -
     * see core/hw/iop_module_loader.h. Checked right after the A0/
     * B0/C0 BIOS trap, same "intercept before fetch" convention. */
#ifdef R936_STEP_TRACE
    if (iop_module_loader_try_handle(st, pc)) {
        fprintf(stderr, "[R936STEP] pc=0x%08x handled by iop_module_loader_try_handle\n", pc);
        st->instructions_executed++;
        return st->halted ? 1 : 0;
    }
#else
    if (iop_module_loader_try_handle(st, pc)) {
        st->instructions_executed++;
        return st->halted ? 1 : 0;
    }
#endif

    /* Round 129 (task #172/#196, 169th finding, real fix): synthetic
     * default/spurious-interrupt-return stub. Real MIPS/R3000A
     * hardware fixed-vectors EVERY exception to 0x80000080 (or
     * 0xBFC00180 when Status.BEV=1) - real kernel software installs
     * a genuine dispatcher there very early in boot. This project
     * doesn't model that installation (and, per this project's
     * standing clean-room convention, never will by transcribing
     * real BIOS bytes to reconstruct one) - previously, whenever
     * iop_hle_intr_dispatch_interrupt() (just above, in the
     * interrupt-raise path) found no module-registered handler for
     * the firing IRQ and fell through to this fixed vector, the CPU
     * fetched whatever incidental RAM content happened to be sitting
     * at 0x80000080 - traced this round to stale bytes left over from
     * an earlier, unrelated real cache-flush instruction sequence
     * (see docs/STATUS.md's 169th finding for the full write-history
     * trace), eventually halting on a genuinely garbage word one
     * unrelated module's own store instruction had scribbled there.
     * Since the real, module-registered-handler path is ALREADY tried
     * first (immediately above, in the code that jumps here),
     * reaching this exact fixed address always means "no handler is
     * registered for this specific IRQ" - precisely the case a
     * minimal, clean-room default handler exists for. Modeled the
     * same way this project's other synthetic HLE stubs are (A0/B0/
     * C0 BIOS traps, etc.): acknowledge and RFE-equivalent return,
     * rather than attempting to reconstruct real kernel dispatcher
     * bytes. Deliberately NOT applied to the BEV=1 ROM vector
     * (0xBFC00180) - that address is genuine ROM content already
     * executed correctly by this project; the gap is specific to the
     * RAM-resident BEV=0 vector, which nothing ever populates. */
    if (pc == 0x80000080u && st->exception_pending) {
        iop_core_flush_pipeline(st);
        /* Round 131 (task #172/#196/#286, real fix): the guard above
         * only ever checked pc/exception_pending, never Cause.ExcCode
         * - so it also caught genuine SYSCALL/BREAK/Trap exceptions
         * that fall through to this exact same fixed vector (this
         * project's boot model has no real dispatcher installed here
         * for those either, same root gap as the interrupt case
         * Round 129 fixed). Those exception classes are NOT
         * restartable the way interrupts are: real MIPS semantics
         * (universal ISA behavior, not BIOS-specific - any R3000A/
         * MIPS I reference) require EPC+4 on return from a
         * synchronous, software-triggered exception, since EPC points
         * AT the triggering instruction itself and simply re-running
         * it would refire the identical exception forever. This
         * project's OWN code already established exactly this
         * EPC+4-plus-$v0=0 convention for the sibling "SYSCALL fell
         * through to an unclaimed BREAK trap-stub" case above (Round
         * 29/task #124) - this fix applies the identical, already-
         * proven convention here instead of inventing a new one.
         * Diagnosed via host-native instrumentation (scratch copy,
         * real repo untouched during diagnosis): a real SYSCALL
         * (raw instruction word 0x0000000C, funct=0x0C) landing at
         * this vector was being resumed at bare EPC by the Round 129
         * stub, infinite-looping on the same SYSCALL forever - the
         * exact cause of the IOP's Round 130 "resting point"
         * (pc=0x8003ECF4) never actually being a resolved wait, just
         * an unresolved exception refiring every 2 instructions. */
        uint32_t exc_code = (st->cop0[13] & 0x7Cu) >> 2u;
        st->cop0[12] = (st->cop0[12] & ~0x0Fu) | ((st->cop0[12] & 0x3Cu) >> 2); /* RFE-equivalent Status stack pop */
        st->exception_pending = 0;
        uint32_t epc = st->cop0[14];
        if (exc_code == 0x08u || exc_code == 0x09u || exc_code == 0x0Du || exc_code == 0x0Au) {
            /* Syscall / Breakpoint / Trap / Reserved Instruction
             * (Round 175, task #340) - all synchronous, non-
             * restartable: skip past the triggering instruction and
             * return the same generic "unimplemented, default value"
             * result this project already uses for every other
             * unclaimed BIOS/syscall call site. Reserved Instruction
             * joins this list for the identical reason Syscall/BP/
             * Trap already do - re-running the same instruction would
             * refire the identical exception forever. */
            st->gpr[2] = 0; /* $v0 = 0 */
            /* HLE skips the faulting slot after a completed branch. */
            st->pc = (st->cop0[13] & IOP_CAUSE_BD) ? st->cop0[6] : epc + 4u;
            st->next_pc = st->pc + 4u;
        } else {
            /* Interrupt (ExcCode==0) or any other restartable class -
             * unchanged Round 129 behavior: resume the interrupted
             * instruction itself.
             *
             * Round 935 (task #919) fix: before resuming, acknowledge/
             * clear the SPECIFIC intc->istat/istat_hi bit(s) that
             * iop_check_hw_interrupt() recorded as having caused this
             * exact fallback dispatch (see that function's own leading
             * comment block and g_iop_spurious_istat_mask/
             * g_iop_spurious_istat_hi_mask for the full citation and
             * root-cause trail). Without this, a real interrupt source
             * with no registered handler anywhere (the confirmed GT3
             * disc-boot case: a genuine SIF0 DMA-completion IRQ, raw
             * line bit 3 AND soft line bit 42, with zero handlers
             * registered) refires the instant Status.IEc is restored
             * below, re-vectoring to this identical fixed vector with
             * the identical EPC forever - a permanent, self-sustaining
             * storm with zero forward progress, exactly the mechanism
             * this project's own already-correct
             * IOP_HLE_INTR_HANDLER_RETURN_TRAMPOLINE path (source/hw/
             * iop_hle_intr.c) already avoids for the "real handler ran"
             * case by clearing intc->istat/istat_hi on completion. Only
             * the exact bit(s) recorded this tick are cleared - never a
             * blind full-register clear - so IRQs that DO have a real
             * handler registered are entirely unaffected (they dispatch
             * and `return` above, never setting these masks at all). */
            if (g_iop_spurious_istat_mask || g_iop_spurious_istat_hi_mask) {
                iop_intc_state_t *intc = iop_intc_get_state();
                intc->istat &= ~g_iop_spurious_istat_mask;
                intc->istat_hi &= ~g_iop_spurious_istat_hi_mask;
                g_iop_spurious_istat_mask = 0;
                g_iop_spurious_istat_hi_mask = 0;
            }
            st->pc = epc;
            st->next_pc = epc + 4u;
        }
        st->instructions_executed++;
        return 0;
    }

    /* Guard against PC escaping into memory this project doesn't
     * model as real, fetchable code (round 14 finding: a live-traced
     * real BIOS boot path executes a genuine JALR $s1 whose target
     * looks like a cross-address-space pointer - plausible as an
     * EE-RAM module image location a real IOP module/IRX loader
     * would DMA-copy locally before jumping to it - but this
     * project's iop_hle_modules.c deliberately doesn't implement
     * real module loading, so no such code is ever actually present).
     * Before this check, an out-of-range fetch silently read back 0
     * (a NOP) forever, letting execution "wander" through effectively
     * unmapped memory for tens of millions of steps until it
     * coincidentally hit a non-zero MMIO register value and halted on
     * a confusing, unrelated-looking illegal-opcode message. Detecting
     * the escape immediately and halting with a clear, honest
     * diagnostic is far more useful - see docs/STATUS.md's
     * "round 14" section for the full trace. */
    {
        int pc_is_fetchable;
        if (pc >= IOP_RESET_VECTOR) {
            uint32_t off = pc - IOP_RESET_VECTOR;
            pc_is_fetchable = (st->bios && off + 4 <= st->bios->size);
        } else {
            uint32_t phys = pc & 0x1FFFFFFFu;
            pc_is_fetchable = (phys + 4 <= st->ram_size);
        }
        if (!pc_is_fetchable) {
            /* Task #92: before halting, give the real IOP module/
             * IRX loader (core/hw/iop_module_loader.h) exactly one
             * chance to take over - this is precisely the round-14
             * wall it was built to resolve (a real BIOS module-
             * loading JALR whose target only a real loader would
             * ever populate). If it can't find what it needs (e.g.
             * no real BIOS is loaded, as in most synthetic-BIOS
             * tests), it returns 0 immediately and this falls
             * through to the original halt below, unchanged. */
            if (iop_module_loader_boot(st)) {
#ifdef IOP_MODLOADER_DEBUG
                fprintf(stderr, "[modloader] boot succeeded, redirected pc=0x%08x at instr=%llu\n", st->pc, (unsigned long long)st->instructions_executed);
#endif
                return 0;
            }

            /* Kept short and %lX-formatted (not %X) on purpose: this
             * message is copied into halt_reason[128] by halt()'s
             * strncpy, and uint32_t is a `long` on this project's
             * PowerPC/Wii build target - a plain %X here mismatches
             * the promoted argument type and warns under devkitPPC's
             * gcc (caught by this round's "0 warnings" Wii rebuild
             * check, not by the host-native test suite, which uses a
             * 32-bit-int-width host where the mismatch is silent). */
            static char msg[96];
            snprintf(msg, sizeof(msg),
                     "PC escaped to unfetchable addr 0x%08lX (unloaded IOP module - see STATUS.md round 14)",
                     (unsigned long)pc);
            halt(msg);
            return 1;
        }
    }

    /* Round 173 (task #338, 213th finding): a second, narrower class
     * of "PC wandered into memory this project never populates" -
     * distinct from Round 14's guard above (which only catches
     * addresses genuinely OUTSIDE modeled RAM/ROM). This one catches
     * addresses INSIDE modeled IOP RAM that are nonetheless never
     * populated by this project's current boot model: real IOP RAM
     * below 0x00100000 (iop_module_loader.c's own BUMP_BASE - every
     * real module this project ever loads is placed at or above this
     * address, by construction) is genuine, real "kernel reserved
     * workspace" on actual hardware (low kernel data, including the
     * real Thread Control Block table THREADMAN's own real scheduler
     * uses for context switches - see ps2sdk's iop/system/threadman
     * sources) - but since Round 172 made real module code (and,
     * transitively, real IOP interrupt delivery) reachable for the
     * first time, THREADMAN's real Timer5 scheduler-tick ISR
     * (RegisterIntrHandler+EnableIntr(16), confirmed via host-native
     * tracing this round - see docs/STATUS.md's 213th finding) now
     * genuinely runs, correctly, thousands of times in a row (a real,
     * positive validation of Round 172's fix) - until it eventually
     * performs what is very likely a genuine thread-context load,
     * reading this project's never-populated (all-zero) low-memory
     * TCB-equivalent area as if it were valid data. This project has
     * no real multi-threading/TCB model (out of scope for a single
     * round - a substantial undertaking), so PC free-running through
     * that all-zero region (executing each zero word as a literal
     * NOP, exactly as Round 14's own header comment already
     * describes for the analogous out-of-range case) is the honest,
     * unavoidable result. Detecting the escape immediately - instead
     * of letting it execute dozens of incidental NOPs before
     * coincidentally hitting non-zero bytes and halting on a
     * confusing, unrelated-looking "unimplemented opcode" message
     * (exactly Round 14's own precedent for why an immediate,
     * clearly-labeled halt beats silent wandering) - is a small,
     * strictly-diagnostic-only change: it does not alter behavior on
     * any currently-succeeding path (real module code always runs at
     * pc >= BUMP_BASE; the handful of already-modeled low sentinel/
     * trampoline addresses below BUMP_BASE are excluded below), only
     * the clarity of an already-terminal failure. */
    uint32_t fetched_word=0;int have_fetched_word=0;
    {

        /* Must compare the KSEG-masked PHYSICAL address, not the raw
         * pc - real IOP code (like this same low-memory crawl) is
         * routinely reached via KSEG0 (0x80000000-based) or KSEG1
         * addresses, never bare physical ones. Same masking
         * convention as this function's own pc_is_fetchable check
         * immediately above (`phys = pc & 0x1FFFFFFFu`). */
        uint32_t phys_pc = pc & 0x1FFFFFFFu;
        int in_modeled_low_region =
            (phys_pc < 0x00000100u) ||                    /* project HLE trap/trampoline sentinels (A0/B0/C0, 0xE4/0xE8/0xEC/0xF0 - see iop_hle_bios.h/iop_hle_intr.h/iop_excb.h) */
            (phys_pc >= 0x0000E000u && phys_pc < 0x00010000u);  /* IOP_EXCB_ARRAY_ADDR / real "Kernel Memory" region - see iop_excb.h */
        if (phys_pc < 0x00100000u && !in_modeled_low_region) {
            uint32_t word = fetched_word = iop_mem_read32(st, pc);
            have_fetched_word=1;
            if (word == 0u) {
                s_zero_run++;
                if (s_zero_run >= 8u) {
                    static char msg2[160];
                    snprintf(msg2, sizeof(msg2),
                             "PC wandered into unpopulated low IOP kernel memory 0x%08lX (real thread-context gap - STATUS.md round 173)",
                             (unsigned long)pc);
                    halt(msg2);
                    return 1;
                }
            } else {
                s_zero_run = 0;
            }
        } else {
            s_zero_run = 0;
        }
    }

    *prepared_pc = pc;
    *prepared_word = have_fetched_word?fetched_word:iop_mem_read32(st, pc);
    return 2;
}

static void iop_retire(iop_state_t *st,uint32_t this_pc,uint32_t fallthrough_pc)
{
    if(st->pipe_active) {
        unsigned load=st->pipe_fault?0u:st->pipe_load_reg;
        uint32_t value=st->gpr[load];
        if(load||st->load_delay_reg)st->gpr_generation++;
        if(load)st->gpr[load]=st->pipe_load_old;
        if(st->load_delay_reg && (st->pipe_fault||st->load_delay_reg!=st->pipe_write_reg))
            st->gpr[st->load_delay_reg]=st->load_delay_value;
        st->load_delay_reg=(uint8_t)load;st->load_delay_value=load?value:0u;
        if(!st->pipe_fault && iop_branch_instruction(st->pipe_word)) {
            st->branch_delay_pending=1;st->branch_pc=this_pc;
        }
        st->pipe_active=0;
    }
    st->gpr[0] = 0;

    /* Round 22: real hardware-interrupt delivery, checked at the end
     * of every real (non-HLE-trap) instruction step - see
     * iop_check_hw_interrupt()'s own comment above for the full
     * citation trail.
     *
     * Round 945: detect whether `this_pc` (the instruction just
     * executed above) was itself a taken branch/jump this exact step.
     * `fallthrough_pc` was captured at this function's own prologue as
     * st->next_pc's value BEFORE the switch ran (this_pc+4, i.e. what
     * st->next_pc would still be if nothing branched); every real
     * taken branch/jump site goes through the BRANCH_TO() macro, which
     * overwrites st->next_pc with the real target - so
     * st->next_pc != fallthrough_pc + 4 (this_pc+8) exactly
     * characterizes "this_pc was a taken branch/jump, and st->pc
     * (still just this_pc+4, the not-yet-executed delay slot) is a
     * pending delay slot with a real branch behind it". In that case,
     * the correct real-hardware EPC is the branch instruction itself
     * (this_pc) with Cause.BD set, not the delay-slot address -
     * otherwise (the overwhelmingly common case), behavior is
     * unchanged from before this round: EPC=st->pc, BD=0. */
    {
        int delay_slot_pending = st->branch_delay_pending || (st->next_pc != fallthrough_pc + 4u);
        if(st->pipe_fault) { /* synchronous fault already owns this boundary */ }
        else if (delay_slot_pending)
            iop_check_hw_interrupt(st, this_pc, IOP_CAUSE_BD);
        else
            iop_check_hw_interrupt(st, st->pc, 0u);
    }
#ifdef GEKKO2_PCPROF
    { extern uint32_t iop_pcprof[1u<<20]; iop_pcprof[(this_pc&0x1fffffu)>>2]++; }
#endif
    st->instructions_executed++;
}

static int iop_execute_prepared(uint32_t pc,uint32_t instr,int use_scalar_jit)
{
    iop_state_t *st=&g_iop;
    if(!st->pipe_active)iop_pipeline_begin(st,pc,instr);
    uint32_t op    = (instr >> 26) & 0x3F;
    uint32_t rs    = (instr >> 21) & 0x1F;
    uint32_t rt    = (instr >> 16) & 0x1F;
    uint32_t rd    = (instr >> 11) & 0x1F;
    uint32_t sa    = (instr >> 6)  & 0x1F;
    int32_t  imm   = (int16_t)(instr & 0xFFFF);
    uint32_t uimm  = instr & 0xFFFF;
    uint32_t funct = instr & 0x3F;

    uint32_t this_pc = pc;
    uint32_t fallthrough_pc = st->next_pc;
    st->pc = fallthrough_pc;
    st->next_pc = fallthrough_pc + 4;

    uint32_t rs32 = st->gpr[rs];
    uint32_t rt32 = st->gpr[rt];
    if((op==0x22u||op==0x26u) && rt && st->load_delay_reg==rt) {
        rt32=st->load_delay_value;
        /* One-op native bodies read the visible GPR, not the pending
         * merge value. Keep both data forwarding and the old EA base. */
        use_scalar_jit=0;
    }

#define GPR(x) st->gpr[x]
#define BRANCH_TO(target) do { st->next_pc = (target); } while (0)
#define LINK(reg) do { GPR(reg) = this_pc + 8; } while (0)

    if(iop_operand_fault(st,instr))goto iop_jit_done;
#ifdef GEKKO2_IOP_LIGHTREC_PILOT
    if(op==0u && funct>=0x18u && funct<=0x1bu &&
       iop_lightrec_try_execute(st,instr)){route_native++;goto iop_jit_done;}
#endif

#if defined(GEKKO) && !defined(PCSX2WII_JIT_DISABLE)
    /* R1281: full-retirement PPC measurements show these simple scalar
     * bodies are cheaper inline than a single native-cache dispatch.
     * Native translators remain available for direct calls/future blocks. */
    static const uint8_t cheap_special[64]={
        [0]=1,[2]=1,[3]=1,[4]=1,[6]=1,[7]=1,[8]=1,[9]=1,
        [0x21]=1,[0x23]=1,[0x24]=1,[0x25]=1,[0x26]=1,[0x27]=1,
        [0x2a]=1,[0x2b]=1
    };
    int cheap=op==9u || (op>=12u && op<=15u) ||
        (op==0u && (funct==0u || funct==0x21u || cheap_special[funct]));
    /* R1283: short branch/COP0 transfer effects stay inline, including
     * the existing IOP HLE JAL/JR checks. Native APIs remain available. */
    int cheap_control=(op>=2u&&op<=7u)||(op==0x10u&&(rs==0u||rs==4u));
    if(use_scalar_jit && !cheap && !cheap_control && iop_jit_try_execute_one(st,this_pc,instr)){route_native++;goto iop_jit_done;}
#else
    if(use_scalar_jit && iop_jit_try_execute_one(st,this_pc,instr)){route_native++;goto iop_jit_done;}
#endif

    route_interpreter++;
#include "iop_decoded_switch.inc"

#undef GPR
#undef BRANCH_TO
#undef LINK

iop_jit_done:
    iop_retire(st,this_pc,fallthrough_pc);
    return 0;
}

static int iop_step(void)
{
    uint32_t pc,word;
    int result=iop_prepare(&pc,&word);
    return result==2 ? iop_execute_prepared(pc,word,1) : result;
}

/* Public single-instruction step - see ee_core_step()'s comment in
 * ee_core.c for why this exists (source/core/system.c's interleaved
 * scheduler). */
static int iop_tick_profile_impl(void){
    if (g_iop.halted)
        return 1;

    /* Round 943 (task #447/#536, IOP-freeze root-cause fix): the one
     * genuinely unconditional per-tick counter - incremented here,
     * before anything else (including the `idle` early-return further
     * down), so it keeps advancing even while the IOP core itself is
     * parked. iop_check_vblank() below reads this instead of
     * `instructions_executed` (which freezes while idle - see its own
     * doc comment and iop_core.h's `sched_ticks` field comment for the
     * full root-cause writeup). */
    g_iop.sched_ticks++;
    if(g_spu2_irq_clock_required&&(int32_t)((uint32_t)g_iop.sched_ticks-g_spu2_next_sample)>=0)
        iop_spu2_sync(g_iop.sched_ticks);

#ifdef R814_CLOSECONFIG_TRACE
    /* Round 814: consume the post-SCMD_CLOSECONFIG-dispatch trace
     * armed by iop_cdvd.c's dispatch_scmd() (see that call site's own
     * R814_CLOSECONFIG_TRACE comment). Logs the real IOP CPU's own
     * PC/opcode/$ra for a bounded window right after the completion
     * boundary, so the actual caller's (CDVDMAN's real init code, per
     * Round 337) own next branch targets can be read directly off
     * stderr. Purely observational (read-only), no control-flow
     * effect. */
    if (g_r814_iop_post_trace_remaining > 0) {
        uint32_t opc = iop_mem_read32(&g_iop, g_iop.pc);
        fprintf(stderr, "[R814EVT] IOP-POST-TRACE step=%d pc=0x%08x opc=0x%08x ra=0x%08x\n",
                R814_IOP_POST_TRACE_STEPS - g_r814_iop_post_trace_remaining, g_iop.pc, opc, g_iop.gpr[31]);
        g_r814_iop_post_trace_remaining--;
    }
#endif

    /* Task #214/#215 continuation (85th/86th findings): real IOP
     * counters/timers run off the system clock, independent of
     * whatever the CPU itself is doing - this is called
     * unconditionally, even while `idle` below, precisely because
     * that's the real mechanism that lets a genuinely idle IOP
     * thread scheduler wake back up (a periodic timer-tick interrupt
     * fires regardless of CPU activity). See iop_timers.h's own
     * extensive citation trail for the full real-hardware grounding
     * and this project's honestly-scoped-down subset of it. */
    iop_timers_tick_fast();

    /* Round 389: real THREADMAN scheduler tick - wakes any thread
     * whose DelayThread() deadline has passed and, if a newly-woken
     * thread now outranks whatever is currently running, performs a
     * real pre-emptive context switch. Same unconditional-even-while-
     * idle rationale as iop_timers_tick() above (a real periodic
     * timer tick is exactly the mechanism real hardware's own
     * scheduler uses for this). No-op until the first real thread
     * primitive call has run (see iop_hle_thread.c's ensure_root_
     * thread()). */
    iop_hle_thread_tick(&g_iop);

    /* Round 153 (task #307): service the real async I/O queue once
     * per scheduler tick, same unconditional-even-while-idle
     * rationale as iop_timers_tick() above - a queued completion
     * (e.g. the CD-ROM boot-unblock request) must still fire even
     * while the CPU itself is parked in the real B0h/TestEvent poll
     * loop, exactly like a real timer-tick interrupt would. */
    iop_asyncio_service();

    /* Task #216 continuation: real IOP VBLANK, same unconditional-
     * even-while-idle rationale as iop_timers_tick() above - see
     * iop_check_vblank()'s own doc comment for the full citation
     * trail. */
    iop_check_vblank(&g_iop);

    /* Task #179 continued: real IOP hardware never halts after boot -
     * see the `idle` field's own doc comment in iop_core.h for the
     * full citation trail. While idle, skip real fetch/decode/execute
     * entirely (nothing genuine to run - the trampoline address isn't
     * real code) and only re-run the same hardware-interrupt check
     * every other instruction step already gets. If that check finds
     * a real pending interrupt, it vectors pc/next_pc into the normal
     * exception vector itself (see iop_check_hw_interrupt() above) -
     * clear `idle` so the very next call resumes genuine fetch/decode/
     * execute there, running whatever real handler code the modules
     * installed before returning. */
    if (g_iop.idle) {
        unsigned idle_profile=gp_enter(GP_IDLE);
        uint8_t pending_before = g_iop.exception_pending;
        /* Round 945: no delay-slot concept applies to the idle-check
         * path (the IOP isn't mid-fetch/decode here at all), so
         * Cause.BD is always 0 - unchanged behavior from before this
         * round. See iop_check_hw_interrupt()'s own doc comment above
         * for the full citation trail on why the signature changed. */
        iop_check_hw_interrupt(&g_iop, g_iop.pc, 0u);
        if (!pending_before && g_iop.exception_pending)
            g_iop.idle = 0; /* a real interrupt just vectored us - resume real execution next call */
        gp_leave(idle_profile);return 0;
    }

    return 2;
}
static int iop_tick(void)
{
 unsigned profile_previous=gp_enter(GP_SCHEDULER);
 int result=iop_tick_profile_impl();
 gp_leave(profile_previous);
 return result;
}


/* Native block callbacks retain the complete pre-fetch HLE path and tick
 * service. 0 consumes nothing, 1 admits native execution, 2 consumed a
 * tick through HLE/idle/scalar recovery. Source changes never execute stale
 * code and never charge the same timer tick twice. */
int iop_core_native_call_safe(iop_state_t *st,uint32_t pc,uint32_t word)
{
    if(st->cop0[15]!=0x1fu)return 1;
    if(word>>26==3u && ((pc&0xf0000000u)|((word&0x03ffffffu)<<2))==0xbfc4a600u)return 0;
    if(word>>26==0u && (word&63u)==9u && st->devtable_pending_image &&
       (pc==0xbfc4a39cu||pc==0xbfc4a44cu))return 0;
    return 1;
}
int iop_core_block_prepare(iop_state_t *st,uint32_t pc,uint32_t word,uint32_t previous_pc)
{
    /* Finish the previous native body BEFORE the next EE grant, just as
     * single stepping does. Last-slot retirement is emitted at block exit. */
    if(st==&g_iop && previous_pc!=UINT32_MAX)iop_retire(st,previous_pc,st->pc);
    if(st!=&g_iop || st->halted || st->pc!=pc)return 0;
    if(iop_before_tick)iop_before_tick();
    if(iop_tick()!=2){route_recovery++;return 2;}
    uint32_t live_pc,live_word;
    if(iop_prepare(&live_pc,&live_word)!=2){route_recovery++;return 2;}
    if(live_pc!=pc || live_word!=word) {
        iop_block_stale++;
        iop_execute_prepared(live_pc,live_word,0);
        return 2;
    }
    if(!iop_core_native_call_safe(st,pc,word)) {
        iop_execute_prepared(pc,word,0);
        return 2;
    }
    if(((word>>26)==0x22u||(word>>26)==0x26u) && st->load_delay_reg &&
       st->load_delay_reg==((word>>16)&31u)) {
        iop_execute_prepared(pc,word,0);return 2;
    }
    iop_pipeline_begin(st,pc,word);
    if(iop_operand_fault(st,word)){iop_retire(st,pc,st->next_pc);return 2;}
    st->gpr[0]=0;
    st->pc=st->next_pc;
    st->next_pc=st->pc+4;
#ifdef GEKKO2_IOP_LIGHTREC_PILOT
    /* Prepared native blocks previously bypassed the Lightrec pilot.
     * Operands are now visible with the original load-delay semantics;
     * retire here and return the consumed-tick status so the generated
     * block neither executes its old body nor retires this slot twice. */
    if((word>>26)==0u && (word&63u)>=0x18u && (word&63u)<=0x1bu &&
       iop_lightrec_try_execute(st,word)) {
        route_native++;iop_retire(st,pc,st->pc);return 2;
    }
#endif
    route_native++;return 1;
}
void iop_core_block_retire(iop_state_t *st,uint32_t pc)
{
    if(st==&g_iop)iop_retire(st,pc,st->pc);
}
void iop_core_block_scalar(iop_state_t *st,uint32_t pc,uint32_t word)
{
    if(st!=&g_iop)return;
    /* prepare has already advanced PC. Restore the pre-execute pipeline
     * before entering the original instruction/HLE-call switch. */
    st->next_pc=st->pc;
    st->pc=pc;
    route_native--;iop_execute_prepared(pc,word,0);
}
uint64_t iop_core_block_stale_count(void){return iop_block_stale;}
__attribute__((noinline)) int iop_core_step(void)
{
    if(iop_tick()!=2)return g_iop.halted ? 1 : 0;
    return iop_step();
}
#include "core/iop/iop_aot_generated.inc"

/* R1345: the EE-led scheduler always grants exactly one IOP tick.
 * Keep native admission, callback and recovery semantics of step_n(1),
 * without a general-budget loop around every tick. */
unsigned iop_core_step_one_native(void)
{
    if(g_iop.halted)return 0;
    if(iop_aot_try_execute(&g_iop,1u))return 1;
    if(iop_jit_try_execute_block(&g_iop,1u))return 1;
    if(iop_before_tick)iop_before_tick();
    iop_core_step();
    return 1;
}


uint64_t iop_core_idle_batch_stat(unsigned index){return index<2u?iop_idle_batch_stats[index]:0;}
unsigned iop_core_event_distance(unsigned maximum)
{
 if(!maximum)return 1u;
 iop_intc_state_t *intc=iop_intc_get_state();
 if((intc->istat&intc->imask)||(intc->istat_hi&intc->imask_hi)||iop_asyncio_busy_count())return 1u;
 unsigned phase=iop_vblank_phase_now(&g_iop);
 unsigned distance=IOP_CYCLES_PER_FRAME_NTSC-phase;
 if(phase<IOP_CYCLES_VBLANK_DURATION&&IOP_CYCLES_VBLANK_DURATION-phase<distance)
  distance=IOP_CYCLES_VBLANK_DURATION-phase;
 if(distance<maximum)maximum=distance;
 maximum=iop_spu2_event_distance(maximum);
 maximum=iop_timers_event_distance(maximum);
 return iop_hle_thread_event_distance(&g_iop,maximum);
}
#ifdef GEKKO2_IDLE_SKIP
/* IOP idle-skip (nicht auf Wii getestet): the SIF/thread poll loop at
 * 0x19230 (queue empty -> SleepThread of an unregistered thread returns
 * at once) has no side effect, so it is treated like a parked core. */
uint64_t iop_spin_skip_stats[4];
static int iop_spin_pc(void)
{
 iop_state_t *st=&g_iop;
 if(!iop_hle_thread_get_thread_count())return 0;
 /* THREADMAN deadlines still use retired instructions. Skipping that clock
  * while an alarm/delay is armed would postpone its event indefinitely. */
 if(iop_hle_thread_event_distance(st,UINT32_MAX)!=UINT32_MAX)return 0;
 if(st->pc!=0x00019230u||st->next_pc!=0x00019234u||st->branch_delay_pending||st->load_delay_reg||st->exception_pending)return 0;
 const uint8_t *r=st->ram; if(!r||st->ram_size<0x19234u)return 0;
 if(((uint32_t)r[0x19230]|((uint32_t)r[0x19231]<<8)|((uint32_t)r[0x19232]<<16)|((uint32_t)r[0x19233]<<24))!=0x0c00640fu)return 0;
 uint32_t q=(uint32_t)st->gpr[16]; if(q<0x1000u||q>st->ram_size-0x10u)return 0;
 return (r[q+0xc]|r[q+0xd]|r[q+0xe]|r[q+0xf])==0;
}
#else
static inline int iop_spin_pc(void){return 0;}
#endif
static unsigned iop_core_idle_batch(unsigned budget)
{
 /* Never remove EE callbacks from the old interleaved core. No instruction
  * is fabricated: only an already parked core may advance its clocks. */
 if(!gekko2_opt_enabled(GEKKO2_OPT_IOP_IDLE_BATCH)||iop_before_tick||!(g_iop.idle||iop_spin_pc())||
    g_iop.halted||g_iop.branch_delay_pending||g_iop.load_delay_reg||g_iop.exception_pending||budget<2u)return 0;
 unsigned distance=iop_core_event_distance(budget+1u);
 unsigned ticks=distance>1u?distance-1u:0u;
 if(ticks>budget)ticks=budget;
 if(ticks<2u||g_iop.sched_ticks>UINT64_MAX-ticks||!iop_timers_advance_before_event(ticks))return 0;
 g_iop.sched_ticks+=ticks;
 /* With no pending or intervening event this is the exact idle-path
  * Cause.IP2 update. Architectural instruction and Count totals stay put. */
 g_iop.cop0[13]&=~IOP_CAUSE_IP2;
 iop_idle_batch_stats[0]+=ticks;iop_idle_batch_stats[1]++;
#ifdef GEKKO2_IDLE_SKIP
 if(!g_iop.idle){iop_spin_skip_stats[0]++;iop_spin_skip_stats[1]+=ticks;}
#endif
 return ticks;
}
unsigned iop_core_spin_skip(unsigned budget)
{
#ifdef GEKKO2_IDLE_SKIP
 return iop_spin_pc()?iop_core_idle_batch(budget):0;
#else
 (void)budget;return 0;
#endif
}
__attribute__((noinline)) unsigned iop_core_step_n(unsigned budget)
{
    /* A one-tick grant cannot batch idle time and has exactly the same AOT,
     * JIT, callback and scalar recovery order as the native one-tick owner.
     * Avoid repeated budget/idle tests on dense scheduler deadlines. */
    if(budget==1u)return iop_core_step_one_native();
    unsigned ticks=0;
    while(ticks<budget && !g_iop.halted) {
        unsigned idle=iop_core_idle_batch(budget-ticks);
        if(idle){ticks+=idle;continue;}
        unsigned done=iop_aot_try_execute(&g_iop,budget-ticks);
        if(!done)done=iop_jit_try_execute_block(&g_iop,budget-ticks);
        if(done){ticks+=done;continue;}
        if(iop_before_tick)iop_before_tick();
        iop_core_step();ticks++;
    }
    return ticks;
}

unsigned iop_core_step_interleaved_n(unsigned budget,void (*before_tick)(void))
{
    /* No nested scheduler entry: callback lifetime is exactly this grant. */
    if(iop_before_tick)return 0;
    iop_before_tick=before_tick;
    unsigned done=iop_core_step_n(budget);
    iop_before_tick=NULL;
    return done;
}

void iop_core_run(void)
{
    while (!g_iop.halted) {
        if (iop_step())
            break;
    }

    printf("\n[!] IOP core halted after %llu instructions at pc=0x%08lX\n",
           (unsigned long long)g_iop.instructions_executed, (unsigned long)g_iop.pc);
    printf("    reason: %s\n", g_iop.halt_reason[0] ? g_iop.halt_reason : "(unknown)");
}

void iop_core_shutdown(void)
{
    iop_jit_reset_for_test();route_native=route_interpreter=route_recovery=0;ram_fast_reads=ram_fast_writes=0;
    if (g_iop.ram) {
        free(g_iop.ram);
        g_iop.ram = NULL;
    }
}
