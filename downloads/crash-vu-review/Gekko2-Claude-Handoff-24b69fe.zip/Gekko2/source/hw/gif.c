#include "core/hw/game_trace.h"
#include "core/hw/gs_triangle_coverage.h"
#include "core/runtime_profile.h"
#include "core/recompiler/optimization.h"
/*
 * gif.c - see include/core/hw/gif.h for scope notes and references.
 */

#include "core/hw/gif.h"
#include "core/hw/gs_mem.h"
#include "core/hw/gs_gx.h"
#include "core/hw/gs_gx_surface.h"
#include "core/hw/gs.h"
#include "core/hw/ee_intc.h"
#ifdef GEKKO
#include "core/ee/ee_core.h"
#endif
#include <string.h>
#include <math.h> /* Round 28: log2() for mipmap LOD selection - see rasterize_sprite()'s mip-level logic */

static gif_state_t g_gif;
const gif_state_t * const gif_scheduler_view = &g_gif;
static uint64_t g_date_stats[2];
static uint64_t g_signal_stalls;
static uint8_t signal_wait[3],path_wait[3];
uint64_t gif_signal_stall_count(void){return g_signal_stalls;}
uint64_t gif_date_stat(unsigned i){return i<2?g_date_stats[i]:0;}
static int g_gx_opaque; /* CT24 GPU import preserves destination alpha. */
static int g_texel_cache_enabled;
static uint32_t g_texel_tags[128],g_texel_values[128];
static double g_sprite_u[640];
static uint64_t g_sprite_cached_draws,g_sprite_fast_rows,g_triangle_cached_draws;
static uint64_t g_draw_routes[10]; /* overlapping state reasons, per primitive */
uint64_t gif_get_render_work(unsigned index)
{if(index<10u)return g_draw_routes[index];return index==10u?g_sprite_cached_draws:index==11u?g_sprite_fast_rows:0;}

/* R1330-K Gouraud accounting (see gif.h).  Pure diagnostics: nothing here feeds
 * back into drawing decisions. */
static uint64_t g_gst[GIF_GOURAUD_STAT_COUNT],g_gfb[GIF_GFB_COUNT];
static struct {uint32_t key;uint64_t n;} g_gstate[64];
static unsigned g_gstate_used;static uint64_t g_gstate_overflow;
static struct {int32_t xy[6];uint32_t prim;} g_gdeg[16];
uint64_t gif_get_triangle_texture_cache_draws(void){return g_triangle_cached_draws;}
uint64_t gif_get_gouraud_stat(unsigned index){return index<GIF_GOURAUD_STAT_COUNT?g_gst[index]:0;}
uint64_t gif_get_gouraud_fallback(unsigned index){return index<GIF_GFB_COUNT?g_gfb[index]:0;}
const char *gif_gouraud_fallback_name(unsigned index)
{
    static const char *const names[GIF_GFB_COUNT]={"none","gx_inactive","build_disabled","small","large",
        "texture","alpha_test","dither_fba","fbmask","depth","blend","fog","psm","scanmsk_field","gx_rejected","alpha_varies"};
    return index<GIF_GFB_COUNT?names[index]:"?";
}
unsigned gif_get_degenerate_sample(unsigned index,int32_t *xy6,uint32_t *prim)
{
    unsigned n=(unsigned)(g_gst[GIF_GOURAUD_DEGENERATE]<16u?g_gst[GIF_GOURAUD_DEGENERATE]:16u);
    if(index>=n)return 0;
    if(xy6)memcpy(xy6,g_gdeg[index].xy,sizeof(g_gdeg[index].xy));
    if(prim)*prim=g_gdeg[index].prim;return 1;
}
unsigned gif_get_gouraud_state(unsigned index,uint32_t *key,uint64_t *count)
{
    if(index>=g_gstate_used)return 0;
    if(key)*key=g_gstate[index].key;if(count)*count=g_gstate[index].n;return 1;
}
uint64_t gif_get_gouraud_state_overflow(void){return g_gstate_overflow;}
static void gouraud_state_record(uint32_t key)
{
    for(unsigned i=0;i<g_gstate_used;i++)if(g_gstate[i].key==key){g_gstate[i].n++;return;}
    if(g_gstate_used<64u){g_gstate[g_gstate_used].key=key;g_gstate[g_gstate_used].n=1;g_gstate_used++;}
    else g_gstate_overflow++;
}
static int g_opaque_pixel; /* Recomputed after context activation per draw. */

/* GIFtag.NLOOP is a 15-bit qword count: every legal IMAGE payload
 * must survive a split DMA transfer, including textures larger than 64 KiB. */
#define GIF_IMAGE_CARRY_MAX_QWORDS 32767u

/* Round 542: which real GIF_PATH_1/2/3 value is driving the packet
 * currently being parsed by process_one_packet() - set by
 * gif_process_quadwords() before its parse loop runs (a single call
 * always processes one caller-supplied buffer from exactly one path,
 * so a module-static "current path" is equivalent to threading an
 * extra parameter through process_one_packet() without touching its
 * existing signature/call sites elsewhere in this file). */
static uint32_t s_gif_active_path = GIF_PATH_3;

static uint32_t vertex_source[4][10],vertex_source_used,vertex_encoding;
unsigned gif_get_vertex_source(unsigned n,uint32_t out[10])
{if(!out||n>=vertex_source_used)return 0;memcpy(out,vertex_source[n],40);return 1;}

static uint64_t g_gif_local_copy_ok,g_gif_local_copy_declines,g_gif_local_copy_pixels;
static uint32_t g_gif_read_fifo_qword;
static uint64_t g_gif_read_ok,g_gif_read_bytes,g_gif_read_errors;
uint64_t gif_local_host_stat(unsigned which)
{ return which==0?g_gif_read_ok:which==1?g_gif_read_bytes:g_gif_read_errors; }
uint32_t gif_read_local_fifo(uint8_t *out,uint32_t qwc)
{
    if(!out||!qwc||g_gif.trx_xdir!=TRXDIR_LOCAL_TO_HOST)return 0;
    gs_local_copy_desc_t d={
      .sbp=g_gif.trx_sbp,.sbw=g_gif.trx_sbw,.spsm=g_gif.trx_spsm,
      .ssax=g_gif.trx_ssax,.ssay=g_gif.trx_ssay,
      .rrw=g_gif.trx_rrw,.rrh=g_gif.trx_rrh,
      .dirx=g_gif.trx_dirx,.diry=g_gif.trx_diry
    };
    uint32_t n=gs_mem_read_local_qwords(&d,g_gif_read_fifo_qword,out,qwc);
    if(!n){g_gif_read_errors++;return 0;}
    g_gif_read_fifo_qword+=n;
    g_gif_read_ok++;g_gif_read_bytes+=(uint64_t)n*16u;
    if(g_gif_read_fifo_qword>=gs_mem_local_fifo_total_qwords(&d))
        g_gif.trx_xdir=TRXDIR_OFF;
    return n;
}

uint64_t gif_local_copy_stat(unsigned which)
{
    return which==0 ? g_gif_local_copy_ok :
           which==1 ? g_gif_local_copy_declines : g_gif_local_copy_pixels;
}
void gif_init(void)
{
    s_gif_active_path=GIF_PATH_3;
    vertex_source_used=vertex_encoding=0;memset(vertex_source,0,sizeof vertex_source);
    g_texel_cache_enabled=0;
    g_sprite_cached_draws=g_sprite_fast_rows=g_triangle_cached_draws=0;
    memset(g_draw_routes,0,sizeof(g_draw_routes));
    memset(g_date_stats,0,sizeof(g_date_stats));
    g_signal_stalls=0;memset(signal_wait,0,sizeof signal_wait);memset(path_wait,0,sizeof path_wait);
    memset(g_gst,0,sizeof(g_gst));memset(g_gfb,0,sizeof(g_gfb));
    memset(g_gstate,0,sizeof(g_gstate));memset(g_gdeg,0,sizeof(g_gdeg));
    g_gstate_used=0;g_gstate_overflow=0;
    g_gif_local_copy_ok=g_gif_local_copy_declines=g_gif_local_copy_pixels=0;
    g_gif_read_fifo_qword=0;
    g_gif_read_ok=g_gif_read_bytes=g_gif_read_errors=0;
    memset(&g_gif, 0, sizeof(g_gif));
    g_gif.gif_q_bits=UINT32_C(0x3f800000);g_gif.cur_q=1.0f;
    g_gif.fbw = 640; /* sane default so an A+D FRAME write isn't strictly required for tests/demos */
    /* Round 27: both contexts' permanent storage gets the same guarded
     * default, so a PRIM.CTXT=1 draw before ANY FRAME_2 write behaves
     * exactly as sanely as context 1's pre-existing default (no
     * aliasing/zero-width surprise). */
    g_gif.ctx1_fbw = 640;
    g_gif.ctx2_fbw = 640;
    /* Round 97 (138th finding, task #254): cur_fog defaults to 0xFF
     * ("fog effect at minimum" per the GS Users Manual - i.e. the
     * vertex's own color passes through unmodified) rather than
     * memset's 0 ("fog effect at maximum" - full fog color) - this
     * project's usual safety-gate convention, see cur_fog's own field
     * comment in gif.h. */
    g_gif.cur_fog = 0xFFu;
    g_gif.prmodecont_ac = 1u; /* Round 99: default AC=1 ("use PRIM") - safety gate */
    g_gif.prmode = 0u;
    g_gif.colclamp = 1u; /* Round 101: default CLAMP=1 - safety gate, matches pre-existing hardcoded behavior */
    g_gif.colclamp_configured = 0;

    /* Round 542: real GIF register block. memset() above already
     * zeroed gif_ctrl/gif_mode/gif_tag0-3/gif_cnt/gif_p3cnt/gif_p3tag,
     * which is the real documented reset state for every one of them
     * (Gif.h's ResetRegs(): CTRL/MODE/STAT all reset to 0; TAG0-3/CNT/
     * P3CNT/P3TAG have no independent reset semantics - they simply
     * hold whatever the last-parsed tag was, and 0 is a perfectly
     * valid "no tag parsed yet" value). No explicit assignment needed;
     * this comment documents that the all-zero state is intentional,
     * not an oversight.
     */
    g_gif.dthe = 0u; /* Round 102: default "not performed" - safety gate */
    memset(g_gif.dimx, 0, sizeof(g_gif.dimx));
}

gif_state_t *gif_get_state(void) { return &g_gif; }

/* GIF_REG_* / GS_REG_* / PRIM_TYPE_* are now public - see gif.h. */

static inline uint32_t rd_le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

/* Resets the triangle AND line vertex-accumulation sequences - called
 * whenever PRIM is written (real hardware starts a fresh vertex queue
 * on a new PRIM, so a mid-strip primitive-type change can't
 * accidentally draw a triangle/line from mismatched vertices). Also
 * clears has_vertex0 (SPRITE's own 1-slot accumulator) for the same
 * reason - previously only reset implicitly by SPRITE completing a
 * draw; a PRIM change mid-SPRITE-vertex-pair could otherwise leak a
 * stale first vertex into whatever primitive comes next. */
static void reset_tri_vseq(void) { g_gif.tri_vseq = 0; g_gif.line_vseq = 0; g_gif.has_vertex0 = 0; }

/* Flat-shaded triangle fill via edge functions (standard scanline
 * rasterization - plain 2D geometry, not real-hardware-specific, so
 * it doesn't need external verification the way register layouts do).
 * Single color for the whole triangle (g_gif.rgba at the time the
 * triangle completes) - no per-vertex Gouraud shading, no Z test, no
 * texturing; see gif.h's scope comment. */
static int32_t edge(int32_t ax, int32_t ay, int32_t bx, int32_t by, int32_t px, int32_t py)
{
    return (bx - ax) * (py - ay) - (by - ay) * (px - ax);
}

/* PRIM_IIP_MASK is now public - see gif.h. */

static inline uint8_t rgba_channel(uint32_t rgba, int shift) { return (uint8_t)((rgba >> shift) & 0xFFu); }
static inline uint32_t rgba_pack(uint32_t r, uint32_t g, uint32_t b, uint32_t a)
{
    return (a << 24) | (b << 16) | (g << 8) | r;
}

/* Reinterprets a raw 32-bit GIF/A+D data word as the IEEE-754 float
 * it represents on real hardware (S/T/Q are all real floats - GS/
 * GSRegs.h's GIFRegRGBAQ/GIFRegST/GIFPackedSTQ all use `float`
 * members directly). memcpy avoids strict-aliasing UB from a
 * pointer-cast/union reinterpretation. */
static inline float u32_to_float(uint32_t v)
{
    float f;
    memcpy(&f, &v, sizeof(f));
    return f;
}

/* Round 24: real CLUT/paletted-texture sampling (PSMT8/PSMT4), gated
 * by TEX0's PSM field. See gif.h's TEX_PSM_xxx/CLUT_ROW_WIDTH/
 * CLUT_CSA_UNIT header comments for the full scope, addressing
 * scheme, and citation-honesty note (this round's live source-fetch
 * research pass hit a session limit before it could run, so the CLUT
 * addressing scheme below is sourced from established PS2 GS
 * knowledge rather than a fresh citation trail this round).
 *
 * For PSMT8/PSMT4, this project stores the texture's raw palette
 * INDEX (not a color) at each texel slot in gs_mem, via the exact
 * same `gs_mem_read_psmct32(tbp,tbw,x,y)` convention used for
 * PSMCT32 texture color - masked down to the relevant index range
 * (0-255 for PSMT8, 0-15 for PSMT4). This mirrors the project's
 * already-established, documented limitation that there is no real
 * texture-upload/bit-packing path yet (see test_gif_texture.c's own
 * scope note: textures are pre-existing gs_mem content, filled
 * directly via gs_mem_write_psmct32() before a test packet runs) -
 * real hardware's tightly-packed byte/nibble-per-texel storage is a
 * separate concern (the REGLIST/IMAGE transfer-mode work) from CLUT
 * lookup itself, and is not conflated here.
 *
 * The palette itself lives in gs_mem at tex_cbp (this project's own
 * bp convention, exactly like tex_tbp0), addressed as a small
 * CLUT_ROW_WIDTH-wide (16 entries/row) region: entry N is at pixel
 * (N % CLUT_ROW_WIDTH, N / CLUT_ROW_WIDTH) within that region. CSA
 * (tex_csa) selects a CLUT_CSA_UNIT (16-entry) offset within the
 * palette, matching real hardware's CSA addressing granularity - so
 * PSMT4's 16-entry palette at CSA=csa starts at flat index
 * `csa*CLUT_CSA_UNIT`, and PSMT8's 256-entry palette (spanning 16 CSA
 * units) conventionally starts at CSA=0.
 *
 * PSMT8's real hardware CSM1 storage additionally swizzles the raw
 * index before lookup - bits 3 and 4 of the index are swapped
 * (`(idx & 0xE7) | ((idx & 0x08) << 1) | ((idx & 0x10) >> 1)`), a
 * well-known PS2 GS quirk frequently documented in PS2 homebrew
 * texture-conversion tooling as the "CSM1 8-bit CLUT swizzle" -
 * flagged here as sourced from established community knowledge
 * rather than a primary-source citation this round, consistent with
 * this project's citation-honesty policy. PSMT4 does not need this
 * swizzle (its 16-entry palette has no sub-block structure to
 * rearrange).
 *
 * Temporary CLUT storage is shared by CT32/CT16/CT16S views. CT32 splits
 * low/high halfwords into separate 256-entry banks. A CPSM change with
 * CLD=0 reinterprets these words without touching source VRAM. */
static uint32_t gs_expand_16(uint32_t v);
/* Behavioral references: GS Users Manual 6.0 2.7.3/3.4.7; PCSX2 GSClut
 * 091ab687 WriteCLUT/ReadCLUT. Independent scalar implementation: no SIMD
 * or upstream cache implementation transplanted. */
static void gs_load_clut(uint32_t psm,uint32_t cbp,uint32_t cpsm,uint32_t csm,uint32_t csa,uint32_t cld)
{
    int is8=psm==0x13u || psm==0x1bu;
    int is4=psm==0x14u || psm==0x24u || psm==0x2cu;
    if(!(is8||is4) || !(cpsm==0u || cpsm==2u || cpsm==10u))return;
    int load=cld>=1u && cld<=3u;
    if(cld==4u)load=g_gif.clut_cbp0!=cbp;
    if(cld==5u)load=g_gif.clut_cbp1!=cbp;
    if(!load)return;
    if(!gs_mem_sync())return; /* failed readback must not erase a valid CLUT */
    if(cld==2u || cld==4u)g_gif.clut_cbp0=cbp;
    if(cld==3u || cld==5u)g_gif.clut_cbp1=cbp;
    unsigned mask=cpsm==0u?255u:511u;
    unsigned dst=(csa&(cpsm==0u?15u:31u))*16u;
    /* CSM1 I8/CT32 loads from the selected source bank to the same bank,
     * rather than rotating all 256 colors through the CSA offset. */
    unsigned first=(!csm&&is8&&!cpsm)?dst:0u;
    for(unsigned i=first;i<(is8?256u:16u);i++){
        unsigned x,y,bw;
        if(csm){x=g_gif.texclut_cou*16u+i;y=g_gif.texclut_cov;bw=g_gif.texclut_cbw*64u;if(!bw)bw=64;}
        else if(is8){x=(i&7u)|((i&16u)>>1);y=((i&8u)>>3)|((i&224u)>>4);bw=64;}
        else{x=i&7u;y=i>>3;bw=64;}
        uint32_t v=cpsm==0u?gs_mem_read_psmct32(cbp*64u,bw,x,y):
            (cpsm==10u?gs_mem_read_psmct16s:gs_mem_read_psmct16)(cbp*64u,bw,x,y);
        unsigned at=(!csm&&is8&&!cpsm)?i:dst+i;
        g_gif.clut_cache[at&mask]=v;
        g_gif.clut_words[at]=(uint16_t)v;
        if(!cpsm)g_gif.clut_words[at+256u]=(uint16_t)(v>>16);
    }
    g_gif.clut_write_csm=csm;g_gif.clut_words_valid=1;
}
static uint32_t gs_sample_clut(uint32_t index)
{
    unsigned mask=g_gif.tex_cpsm==0u?255u:511u;
    unsigned start=(g_gif.tex_csa&(g_gif.tex_cpsm==0u?15u:31u))*16u;
    if(g_gif.clut_words_valid){
        unsigned at=start+index;
        if(!g_gif.tex_cpsm){
            int is8=g_gif.tex_psm==0x13u||g_gif.tex_psm==0x1bu;
            if(is8){unsigned bank=start+(index&~15u);at=(bank>240u?240u:bank)+(index&15u);}
            else if(g_gif.tex_csm&&!g_gif.clut_write_csm)at=start+(index&7u)+((index&8u)?16u:0u);
            return g_gif.clut_words[at]|((uint32_t)g_gif.clut_words[at+256u]<<16);
        }
        return gs_expand_16(g_gif.clut_words[at]);
    }
    uint32_t v=g_gif.clut_cache[(start+index)&mask];
    return g_gif.tex_cpsm==0u?v:gs_expand_16(v);
}
static uint32_t gs_clut_hash_word(unsigned index)
{
 return g_gif.clut_words_valid?(uint32_t)g_gif.clut_words[index*2u]|
   ((uint32_t)g_gif.clut_words[index*2u+1u]<<16):g_gif.clut_cache[index];
}

static uint32_t gs_expand_16(uint32_t v)
{
    uint32_t rgb = ((v & 0x1fu) << 3) | ((v & 0x3e0u) << 6) | ((v & 0x7c00u) << 9);
    uint32_t alpha = (v & 0x8000u) ? g_gif.texa_ta1 :
                     (g_gif.texa_aem && (v & 0x7fffu) == 0 ? 0u : g_gif.texa_ta0);
    return rgb | (alpha << 24);
}

static int gs_is_depth_texture(uint32_t psm)
{return psm==0x30u||psm==0x31u||psm==0x32u||psm==0x3au;}
static uint32_t gs_sample_texel_uncached(int32_t tex_x, int32_t tex_y)
{
    /* Z textures share texel expansion rules, but use Z block swizzles.
     * TEXA applies to Z24/16/16S exactly as to the corresponding color view. */
    if(g_gif.tex_psm==0x32u||g_gif.tex_psm==0x3au)
        return gs_expand_16(gs_mem_read_z(g_gif.tex_tbp0*64u,g_gif.tex_tbw,
            (uint32_t)tex_x,(uint32_t)tex_y,g_gif.tex_psm&15u));
    /* Round 640: TBP0 is TEX0.TBP0 - real unit is 256 bytes (Address/64
     * words), not the plain functions' 4-byte-word assumption. */
    if (g_gif.tex_psm == 2u || g_gif.tex_psm == 10u)
        return gs_expand_16((g_gif.tex_psm == 10u ? gs_mem_read_psmct16s : gs_mem_read_psmct16)(g_gif.tex_tbp0 * 64u,
                              g_gif.tex_tbw, (uint32_t)tex_x, (uint32_t)tex_y));
    if (g_gif.tex_psm == TEX_PSM_PSMT8 || g_gif.tex_psm == TEX_PSM_PSMT4 ||
        g_gif.tex_psm == TEX_PSM_PSMT8H || g_gif.tex_psm == TEX_PSM_PSMT4HL || g_gif.tex_psm == TEX_PSM_PSMT4HH) {
        uint32_t idx=gs_mem_read_index(g_gif.tex_tbp0*64u,g_gif.tex_tbw,(uint32_t)tex_x,(uint32_t)tex_y,g_gif.tex_psm);
        return gs_sample_clut(idx);
    }
    uint32_t raw = gs_is_depth_texture(g_gif.tex_psm)?
        gs_mem_read_z(g_gif.tex_tbp0*64u,g_gif.tex_tbw,(uint32_t)tex_x,(uint32_t)tex_y,g_gif.tex_psm&15u):
        gs_mem_read_psmct32_blk(g_gif.tex_tbp0,g_gif.tex_tbw,(uint32_t)tex_x,(uint32_t)tex_y);
    if (g_gif.tex_psm == TEX_PSM_PSMCT24 || g_gif.tex_psm==0x31u) {
        uint32_t rgb = raw & 0x00ffffffu;
        uint32_t alpha = g_gif.texa_aem && rgb == 0 ? 0 : g_gif.texa_ta0;
        return rgb | (alpha << 24);
    }
    /* PSMCT32 (default) and any other unsupported PSM: sample
     * directly, no CLUT indirection. */
    return raw;
}

static uint32_t gs_sample_texel(int32_t x,int32_t y)
{
    if(!g_texel_cache_enabled)return gs_sample_texel_uncached(x,y);
    uint32_t key=((uint32_t)y<<16)|(uint32_t)x,index=((uint32_t)x^(uint32_t)y*131u)&127u;
    if(g_texel_tags[index]==key)return g_texel_values[index];
    uint32_t value=gs_sample_texel_uncached(x,y);
    g_texel_tags[index]=key;g_texel_values[index]=value;return value;
}

/* Round 23: real alpha test (TEST_1's ATE/ATST/AREF/AFAIL) and real
 * alpha blending (ALPHA_1, gated by PRIM's ABE bit) - see gif.h's
 * TEST_xxx, GS_ATST_xxx, GS_AFAIL_xxx, ALPHA_xxx, and GS_ALPHA_xxx field comments for
 * the full citation trail (PCSX2's GS/GSRegs.h + GSDrawScanline.cpp,
 * cross-checked via a dedicated research pass this round).
 *
 * Centralizes what was previously 4 near-identical inline "write
 * color, maybe write Z" tail blocks - one per rasterizer (triangle/
 * sprite/point/line) - into a single shared helper. This is a
 * deliberate, modest deviation from this file's established pattern
 * of duplicating the (much smaller) Z-test block identically in each
 * rasterizer: alpha test + blending is substantially more logic, and
 * the alpha unit's behavior is identical regardless of which
 * primitive produced the fragment (real hardware doesn't have 4
 * separate alpha units either) - keeping 4 independent copies in
 * sync here would be a real, avoidable maintenance risk.
 *
 * `frag_color` is the fragment's fully shaded/textured color (what
 * every rasterizer previously wrote directly via gs_mem_write_psmct32).
 * `z_write_allowed` is the caller's existing zbuf_configured/zmsk
 * gate (unchanged from before this round) - this function may
 * additionally suppress it (AFAIL) but never re-enables a Z write the
 * caller didn't already allow. */
/* Forward declaration: gs_effective_attr_prim() is defined further down
 * (right before gs_activate_context()) but gs_finish_pixel() below needs
 * it for the ABE check - Round 99, task #254. */
static uint32_t gs_effective_attr_prim(void);

/* COLCLAMP controls framebuffer color arithmetic. The texture function
 * has its own saturating stage (see gs_texture_function below). */
static uint32_t gs_colclamp_channel(int32_t v)
{
    if (!g_gif.colclamp_configured || g_gif.colclamp)
        return (uint32_t)(v < 0 ? 0 : (v > 255 ? 255 : v));
    return (uint32_t)v & 0xFFu;
}

/* R1253: TEX0.TCC and all four texture functions, matching the provided
 * PCSX2 GSDrawScanline.cpp AlphaTFX/ColorTFX paths. Texture arithmetic
 * saturates before framebuffer blending; RGB-only textures keep vertex alpha. */
static uint32_t gs_texture_function(uint32_t texel, uint32_t vertex)
{
    uint32_t c[4];
    uint32_t va = rgba_channel(vertex, 24), ta = rgba_channel(texel, 24);
    for (unsigned k = 0; k < 3; k++) {
        c[k] = rgba_channel(texel, k * 8);
        if (g_gif.tex_tfx != TEX_TFX_DECAL) {
            c[k] = c[k] * rgba_channel(vertex, k * 8) / 128u;
            if (g_gif.tex_tfx >= TEX_TFX_HIGHLIGHT) c[k] += va;
            if (c[k] > 255u) c[k] = 255u;
        }
    }
    c[3] = va;
    if (g_gif.tex_tcc) {
        switch (g_gif.tex_tfx) {
        case TEX_TFX_MODULATE: c[3] = ta * va / 128u; break;
        case TEX_TFX_DECAL: case TEX_TFX_HIGHLIGHT2: c[3] = ta; break;
        case TEX_TFX_HIGHLIGHT: c[3] = ta + va; break;
        }
        if (c[3] > 255u) c[3] = 255u;
    }
    return rgba_pack(c[0], c[1], c[2], c[3]);
}


/* Round 106 (147th finding, task #254 - GS gap follow-up 10/N):
 * SCANMSK - real GS Users Manual "SCANMSK : Raster Address Mask
 * Setting" ("This register sets whether drawing is performed only
 * to odd or even row by the row address of the frame buffer...The
 * mask is only effective for drawing primitives."). MSK=0 (default)
 * and MSK=1 (reserved, treated as normal per the manual giving it no
 * defined meaning) both draw normally; MSK=2 prohibits drawing
 * pixels whose Y coordinate is even; MSK=3 prohibits drawing pixels
 * whose Y is odd. Called from gs_finish_pixel() - the single funnel
 * point every rasterizer (triangle/sprite/point/line) already calls
 * per-pixel - so this applies uniformly without needing any
 * per-rasterizer bounding-box changes, unlike SCISSOR (Round 96). */
static int scanmsk_allows_y(int32_t yy)
{
    if (g_gif.scanmsk == 2u) return (yy & 1) != 0;   /* even Y prohibited */
    if (g_gif.scanmsk == 3u) return (yy & 1) == 0;   /* odd Y prohibited */
    return 1; /* MSK=0 (normal) or MSK=1 (reserved, treated as normal) */
}

/* CT16 and CT16S have independent GS swizzles.  Decode the actual
 * destination before alpha blend; AD is a single 0/0x80 alpha bit.
 * CT24 has a fixed alpha coefficient 0x80 even when its stored high byte
 * contains unrelated 32-bit-view data. */
static uint32_t gs_framebuffer_rgb_for_blend(uint32_t x,uint32_t y)
{
    if(g_gif.frame_psm==TEX_PSM_PSMCT16||g_gif.frame_psm==TEX_PSM_PSMCT16S){
        uint16_t packed=(g_gif.frame_psm==TEX_PSM_PSMCT16S?gs_mem_read_psmct16s:gs_mem_read_psmct16)
            (g_gif.fbp,g_gif.fbw,x,y);
        uint32_t r=packed&31u,g=(packed>>5)&31u,b=(packed>>10)&31u;
        /* The GS expands framebuffer channels with zero low bits, not
         * normalized 5-to-8-bit replication (GSDrawScanline AlphaBlend). */
        return ((packed&0x8000u)?0x80000000u:0u)|
            (b<<19)|(g<<11)|(r<<3);
    }
    uint32_t color=gs_mem_read_psmct32(g_gif.fbp,g_gif.fbw,x,y);
    if(g_gif.frame_psm==TEX_PSM_PSMCT24)color=(color&0x00ffffffu)|0x80000000u;
    return color;
}
/* Apply FRAME.FBMSK to the physical 16-bit destination halfword; the GS
 * swizzle means two adjacent X coordinates need not share a 32-bit word. */
static void gs_framebuffer_write16(uint32_t x,uint32_t y,uint32_t rgba,int preserve_alpha)
{
    uint32_t offset=gs_mem_framebuffer16_offset(g_gif.fbp,g_gif.fbw,x,y,g_gif.frame_psm);
    if(offset==UINT32_MAX)return;
    uint16_t packed=(uint16_t)(((rgba>>3)&31u)|(((rgba>>11)&31u)<<5)|
        (((rgba>>19)&31u)<<10)|((rgba&0x80000000u)?0x8000u:0u));
    uint16_t mask=(uint16_t)(g_gif.fbmask>>((offset&2u)?16u:0u));
    if(preserve_alpha)mask|=0x8000u;
    uint16_t old=(g_gif.frame_psm==TEX_PSM_PSMCT16S?gs_mem_read_psmct16s:gs_mem_read_psmct16)
        (g_gif.fbp,g_gif.fbw,x,y);
    packed=(uint16_t)((packed&~mask)|(old&mask));
    if(g_gif.frame_psm==TEX_PSM_PSMCT16S)
        gs_mem_write_psmct16s(g_gif.fbp,g_gif.fbw,x,y,packed);
    else gs_mem_write_psmct16(g_gif.fbp,g_gif.fbw,x,y,packed);
}
static int gs_dither_active(void)
{return g_gif.dthe&&(g_gif.frame_psm==TEX_PSM_PSMCT16||g_gif.frame_psm==TEX_PSM_PSMCT16S);}
static int gs_blend_shift7(int value)
{return value>=0?value/128:-((-value+127)/128);}
static void gs_finish_pixel(int32_t xx, int32_t yy, uint32_t frag_color, uint32_t frag_z, int z_write_allowed)
{
    if (!scanmsk_allows_y(yy)) return;
    /* DATE rejects both color and depth writes. CT24 rejects all DATE
     * draws (PCSX2 GSRendererHW hardware-test result), not alpha=0x80. */
    if (g_gif.date) {
        g_date_stats[0]++;
        if (g_gif.frame_psm == 1u) {g_date_stats[1]++;return;}
        uint32_t dst_alpha;
        if (g_gif.frame_psm == 2u || g_gif.frame_psm == 10u)
            dst_alpha = ((g_gif.frame_psm == 10u ? gs_mem_read_psmct16s : gs_mem_read_psmct16)
                (g_gif.fbp,g_gif.fbw,(uint32_t)xx,(uint32_t)yy) >> 15) & 1u;
        else dst_alpha = gs_mem_read_psmct32(g_gif.fbp,g_gif.fbw,(uint32_t)xx,(uint32_t)yy) >> 31;
        if (dst_alpha != (uint32_t)g_gif.datm) {g_date_stats[1]++;return;}
    }

    uint32_t frag_r = rgba_channel(frag_color, 0);
    uint32_t frag_g = rgba_channel(frag_color, 8);
    uint32_t frag_b = rgba_channel(frag_color, 16);
    uint32_t frag_a = rgba_channel(frag_color, 24);

    int color_write = 1;
    int z_write = z_write_allowed;
    int alpha_test_failed = 0;

    if (g_gif.ate) {
        int fail;
        switch (g_gif.atst) {
        case GS_ATST_NEVER:    fail = 1; break;
        case GS_ATST_ALWAYS:   fail = 0; break;
        case GS_ATST_LESS:     fail = (frag_a >= g_gif.aref); break;
        case GS_ATST_LEQUAL:   fail = (frag_a >  g_gif.aref); break;
        case GS_ATST_EQUAL:    fail = (frag_a != g_gif.aref); break;
        case GS_ATST_GEQUAL:   fail = (frag_a <  g_gif.aref); break;
        case GS_ATST_GREATER:  fail = (frag_a <= g_gif.aref); break;
        case GS_ATST_NOTEQUAL: fail = (frag_a == g_gif.aref); break;
        default: fail = 0; break;
        }
        if (fail) {
            alpha_test_failed = 1;
            g_gif.pixels_atest_failed++;
            switch (g_gif.afail) {
            case GS_AFAIL_KEEP:     color_write = 0; z_write = 0; break;
            case GS_AFAIL_FB_ONLY:  z_write = 0; break; /* color still writes, Z suppressed */
            case GS_AFAIL_ZB_ONLY:  color_write = 0; break; /* Z still writes (if allowed), color suppressed */
            case GS_AFAIL_RGB_ONLY: z_write = 0; break; /* RGB still writes, alpha preserved below, Z suppressed */
            default: break;
            }
        }
    }

    if (!color_write && !z_write)
        return;

    if (color_write) {
        int32_t out_r = (int32_t)frag_r, out_g = (int32_t)frag_g, out_b = (int32_t)frag_b;
        uint32_t out_a = frag_a;

        /* Round 104 (145th finding, task #254): PABE - real GS Users
         * Manual "Alpha Blending Control in Units of Pixels". When
         * PABE=1, alpha blending is additionally gated per-pixel by
         * the fragment's own alpha MSB (bit 7): blending only
         * actually happens if that bit is 1, even when ABE is set.
         * PABE=0 (default) leaves ABE as the sole condition, exactly
         * as every pre-existing round already implements - a genuine
         * no-op for every pre-existing test/demo. */
        int pabe_allows_blend = !g_gif.pabe || (frag_a & 0x80u) != 0;
        if ((gs_effective_attr_prim() & PRIM_ABE_MASK) && pabe_allows_blend) {
            /* Real alpha blending - RGB channels only; the written
             * alpha is always the fragment's own source alpha (As),
             * matching real GS hardware (see gif.h's ALPHA field
             * comment). */
            uint32_t dst=gs_framebuffer_rgb_for_blend((uint32_t)xx,(uint32_t)yy);
            uint32_t dst_r = rgba_channel(dst, 0),  dst_g = rgba_channel(dst, 8);
            uint32_t dst_b = rgba_channel(dst, 16), dst_a = rgba_channel(dst, 24);

            uint32_t coeff;
            switch (g_gif.alpha_c) {
            case GS_ALPHA_AS: coeff = frag_a; break;
            case GS_ALPHA_AD: coeff = dst_a;  break;
            default:          coeff = g_gif.alpha_fix; break; /* Af */
            }

            int32_t r_a = (g_gif.alpha_a == GS_ALPHA_CS) ? (int32_t)out_r : (g_gif.alpha_a == GS_ALPHA_CD) ? (int32_t)dst_r : 0;
            int32_t r_b = (g_gif.alpha_b == GS_ALPHA_CS) ? (int32_t)out_r : (g_gif.alpha_b == GS_ALPHA_CD) ? (int32_t)dst_r : 0;
            int32_t r_d = (g_gif.alpha_d == GS_ALPHA_CS) ? (int32_t)out_r : (g_gif.alpha_d == GS_ALPHA_CD) ? (int32_t)dst_r : 0;
            int32_t g_a = (g_gif.alpha_a == GS_ALPHA_CS) ? (int32_t)out_g : (g_gif.alpha_a == GS_ALPHA_CD) ? (int32_t)dst_g : 0;
            int32_t g_b = (g_gif.alpha_b == GS_ALPHA_CS) ? (int32_t)out_g : (g_gif.alpha_b == GS_ALPHA_CD) ? (int32_t)dst_g : 0;
            int32_t g_d = (g_gif.alpha_d == GS_ALPHA_CS) ? (int32_t)out_g : (g_gif.alpha_d == GS_ALPHA_CD) ? (int32_t)dst_g : 0;
            int32_t b_a = (g_gif.alpha_a == GS_ALPHA_CS) ? (int32_t)out_b : (g_gif.alpha_a == GS_ALPHA_CD) ? (int32_t)dst_b : 0;
            int32_t b_b = (g_gif.alpha_b == GS_ALPHA_CS) ? (int32_t)out_b : (g_gif.alpha_b == GS_ALPHA_CD) ? (int32_t)dst_b : 0;
            int32_t b_d = (g_gif.alpha_d == GS_ALPHA_CS) ? (int32_t)out_b : (g_gif.alpha_d == GS_ALPHA_CD) ? (int32_t)dst_b : 0;

            /* Real GS blend equation: Color = ((A-B)*C)>>7 + D - a
             * plain truncating shift, no rounding bias (cross-checked
             * against PCSX2's GSDrawScanline.cpp AlphaBlend path).
             * The coefficient is deliberately NOT clamped to [0,1] -
             * real hardware allows results >1.0x ("boosted" colors)
             * when coeff > 128, a genuine, documented hardware
             * behavior some games rely on. The FINAL result is passed
             * through gs_colclamp_channel() (Round 101, task #254),
             * which now genuinely honors COLCLAMP=0's real "wrap
             * instead of clamp" mode - previously a known, deliberately
             * un-modeled gap noted right here; closed this round. */
            int32_t r = gs_blend_shift7((r_a - r_b) * (int32_t)coeff) + r_d;
            int32_t g = gs_blend_shift7((g_a - g_b) * (int32_t)coeff) + g_d;
            int32_t b = gs_blend_shift7((b_a - b_b) * (int32_t)coeff) + b_d;
            out_r = r;
            out_g = g;
            out_b = b;
        }

        if (gs_dither_active()) {
            /* Round 102 (143rd finding, task #254): dithering - real
             * GS Users Manual "3.6.1 Dithering" formula, applied as
             * the final RGB transform before the pixel is written
             * (same offset added to R/G/B identically; alpha is
             * untouched, matching the manual's own R/G/B-only
             * formula). Passed back through gs_colclamp_channel()
             * (Round 101) since dithering can itself push a channel
             * out of [0,255] just like any other RGB-modifying stage
             * in this pipeline. */
            int32_t d = g_gif.dimx[(uint32_t)yy & 3u][(uint32_t)xx & 3u];
            out_r += d;
            out_g += d;
            out_b += d;
        }
        out_r = (int32_t)gs_colclamp_channel(out_r);
        out_g = (int32_t)gs_colclamp_channel(out_g);
        out_b = (int32_t)gs_colclamp_channel(out_b);

        if (g_gif.fba) {
            /* FBA corrects the source alpha before framebuffer write
             * masks. AFAIL=RGB_ONLY must still forbid an alpha write. */
            out_a = out_a | 0x80u;
        }

        /* Native 16-bit framebuffer writes use the CT16/CT16S swizzle,
         * two-byte physical pixels, single-bit alpha and per-halfword FBMSK. */
        if(g_gif.frame_psm==TEX_PSM_PSMCT16||g_gif.frame_psm==TEX_PSM_PSMCT16S) {
            gs_framebuffer_write16((uint32_t)xx,(uint32_t)yy,rgba_pack(out_r,out_g,out_b,out_a),
                alpha_test_failed&&g_gif.afail==GS_AFAIL_RGB_ONLY);
        } else {
        /* FRAME.FBMSK is a bit mask: protected bits retain their old value.
         * PSMCT24 additionally preserves the physical alpha byte. */
        uint32_t mask = g_gif.fbmask;
        if (g_gif.frame_psm == TEX_PSM_PSMCT24) mask |= 0xff000000u;
        if (alpha_test_failed && g_gif.afail == GS_AFAIL_RGB_ONLY &&
            g_gif.frame_psm == TEX_PSM_PSMCT32) mask |= 0xff000000u;
        uint32_t color = rgba_pack(out_r, out_g, out_b, out_a);
        if (mask) {
            uint32_t old = gs_mem_read_psmct32(g_gif.fbp, g_gif.fbw, (uint32_t)xx, (uint32_t)yy);
            color = (color & ~mask) | (old & mask);
        }
        gs_mem_write_psmct32(g_gif.fbp, g_gif.fbw, (uint32_t)xx, (uint32_t)yy, color);
        }
    }

    if (z_write) {
        gs_mem_write_z(g_gif.zbp, g_gif.fbw, (uint32_t)xx, (uint32_t)yy, g_gif.zpsm,
                       gs_mem_clamp_raster_z(frag_z,g_gif.zpsm));
    }
}

/* Derived draw state is valid only inside rasterization. Keep the general
 * pixel helper usable independently (including direct semantic tests). */
static inline __attribute__((always_inline)) void gs_finish_draw_pixel(
    int32_t xx,int32_t yy,uint32_t frag_color,uint32_t frag_z,int z_write_allowed)
{
    if(g_opaque_pixel) {
        if(!scanmsk_allows_y(yy))return;
        gs_mem_write_psmct32(g_gif.fbp,g_gif.fbw,(uint32_t)xx,(uint32_t)yy,frag_color);
        if(z_write_allowed)gs_mem_write_z(g_gif.zbp,g_gif.fbw,(uint32_t)xx,(uint32_t)yy,g_gif.zpsm,gs_mem_clamp_raster_z(frag_z,g_gif.zpsm));
    } else gs_finish_pixel(xx,yy,frag_color,frag_z,z_write_allowed);
}

/* Round 99 (140th finding, task #254 - GS gap follow-up 3/N): resolves
 * PRIM vs. PRMODE for the 8 mirrored drawing-attribute bits (IIP, TME,
 * FGE, ABE, AA1, FST, CTXT, FIX - bits 3-10), per PRMODECONT.AC (see
 * gif.h's GS_REG_PRMODECONT/GS_REG_PRMODE comment for the full manual
 * citation and bit layout). PRIM's own bits 0-2 (primitive TYPE) are
 * always taken from PRIM itself - PRMODE has no TYPE field at all, per
 * the manual - so this helper always returns PRIM's type bits
 * unchanged regardless of AC. Every attribute-bit read site in this
 * file (gs_activate_context's CTXT check, apply_fog's FGE check,
 * rasterize_*'s IIP/TME/FST/ABE checks) goes through this helper
 * instead of reading g_gif.prim directly, so PRMODECONT genuinely
 * takes effect everywhere real hardware says it should. Defaults to
 * AC=1 ("use PRIM", set in gif_init()) - the established safety-gate
 * convention, so this is a no-op for every pre-existing test/demo
 * unless it actually writes PRMODECONT. */
static uint32_t gs_effective_attr_prim(void)
{
    if (g_gif.prmodecont_ac) return g_gif.prim;
    return (g_gif.prim & 0x7u) | (g_gif.prmode & PRIM_ATTR_MASK);
}

/* Round 27: GS Context 2 (dual-context support) - see gif.h's
 * PRIM_CTXT_MASK/GS_REG_FRAME_2/etc and gif_state_t's ctx1_xxx/
 * ctx2_xxx field comments for the full design. Called once at the
 * very top of each of the 4 rasterizers, right before a primitive is
 * actually drawn - refreshes the flat "active" fields (which
 * gs_finish_pixel()/gs_sample_texel()/gs_sample_clut() and the
 * rasterizers themselves keep reading completely unchanged from
 * before this round) from whichever of ctx1_xxx/ctx2_xxx PRIM's CTXT
 * bit (bit 9) currently selects (Round 99: routed through
 * gs_effective_attr_prim() so PRMODECONT.AC=0 correctly sources CTXT
 * from PRMODE instead, per the manual's own mirrored-bit list). For
 * CTXT=0 this simply re-copies context 1's own already-correct values
 * back (idempotent, matching exactly what apply_ad_write's _1 cases
 * already wrote directly) - so existing single-context callers/tests
 * see zero behavioral change. For CTXT=1, context 2's permanent
 * storage becomes "live" in the active fields for the duration of
 * this primitive's rasterization. */
static void gs_activate_context(void)
{
    if (gs_effective_attr_prim() & PRIM_CTXT_MASK) {
        g_gif.fbp = g_gif.ctx2_fbp;
        g_gif.fbw = g_gif.ctx2_fbw;
        g_gif.fbmask = g_gif.ctx2_fbmask;
        g_gif.frame_psm = g_gif.ctx2_frame_psm;
        g_gif.xyoffset_x = g_gif.ctx2_xyoffset_x;
        g_gif.xyoffset_y = g_gif.ctx2_xyoffset_y;
        g_gif.tex_tbp0 = g_gif.ctx2_tex_tbp0;
        g_gif.tex_tbw = g_gif.ctx2_tex_tbw;
        g_gif.tex_tfx = g_gif.ctx2_tex_tfx;
        g_gif.tex_tcc = g_gif.ctx2_tex_tcc;
        g_gif.tex_tw = g_gif.ctx2_tex_tw;
        g_gif.tex_th = g_gif.ctx2_tex_th;
        g_gif.tex_psm = g_gif.ctx2_tex_psm;
        g_gif.tex_cbp = g_gif.ctx2_tex_cbp;
        g_gif.tex_cpsm = g_gif.ctx2_tex_cpsm;
        g_gif.tex_csa = g_gif.ctx2_tex_csa;
        g_gif.tex_cld = g_gif.ctx2_tex_cld;
        g_gif.tex_csm = g_gif.ctx2_tex_csm;
        g_gif.zbp = g_gif.ctx2_zbp;
        g_gif.zpsm = g_gif.ctx2_zpsm;
        g_gif.zmsk = g_gif.ctx2_zmsk;
        g_gif.zbuf_configured = g_gif.ctx2_zbuf_configured;
        g_gif.zte = g_gif.ctx2_zte;
        g_gif.ztst = g_gif.ctx2_ztst;
        g_gif.ate = g_gif.ctx2_ate;
        g_gif.date=g_gif.ctx2_date; g_gif.datm=g_gif.ctx2_datm;
        g_gif.atst = g_gif.ctx2_atst;
        g_gif.aref = g_gif.ctx2_aref;
        g_gif.afail = g_gif.ctx2_afail;
        g_gif.alpha_a = g_gif.ctx2_alpha_a;
        g_gif.alpha_b = g_gif.ctx2_alpha_b;
        g_gif.alpha_c = g_gif.ctx2_alpha_c;
        g_gif.alpha_d = g_gif.ctx2_alpha_d;
        g_gif.alpha_fix = g_gif.ctx2_alpha_fix;
        g_gif.scissor_x0 = g_gif.ctx2_scissor_x0;
        g_gif.scissor_x1 = g_gif.ctx2_scissor_x1;
        g_gif.scissor_y0 = g_gif.ctx2_scissor_y0;
        g_gif.scissor_y1 = g_gif.ctx2_scissor_y1;
        g_gif.scissor_configured = g_gif.ctx2_scissor_configured;
        g_gif.tex1_lcm = g_gif.ctx2_tex1_lcm;
        g_gif.tex1_mxl = g_gif.ctx2_tex1_mxl;
        g_gif.tex1_mmag = g_gif.ctx2_tex1_mmag;
        g_gif.tex1_mmin = g_gif.ctx2_tex1_mmin;
        g_gif.tex1_mtba = g_gif.ctx2_tex1_mtba;
        g_gif.tex1_l = g_gif.ctx2_tex1_l;
        g_gif.tex1_k = g_gif.ctx2_tex1_k;
        for (int lvl = 0; lvl < 6; lvl++) {
            g_gif.tex_mip_tbp[lvl] = g_gif.ctx2_tex_mip_tbp[lvl];
            g_gif.tex_mip_tbw[lvl] = g_gif.ctx2_tex_mip_tbw[lvl];
        }
        g_gif.clamp_wms = g_gif.ctx2_clamp_wms;
        g_gif.clamp_wmt = g_gif.ctx2_clamp_wmt;
        g_gif.clamp_minu = g_gif.ctx2_clamp_minu;
        g_gif.clamp_maxu = g_gif.ctx2_clamp_maxu;
        g_gif.clamp_minv = g_gif.ctx2_clamp_minv;
        g_gif.clamp_maxv = g_gif.ctx2_clamp_maxv;
        g_gif.clamp_configured = g_gif.ctx2_clamp_configured;
        g_gif.fba = g_gif.ctx2_fba;
        g_gif.fba_configured = g_gif.ctx2_fba_configured;
    } else {
        g_gif.fbp = g_gif.ctx1_fbp;
        g_gif.fbw = g_gif.ctx1_fbw;
        g_gif.fbmask = g_gif.ctx1_fbmask;
        g_gif.frame_psm = g_gif.ctx1_frame_psm;
        g_gif.xyoffset_x = g_gif.ctx1_xyoffset_x;
        g_gif.xyoffset_y = g_gif.ctx1_xyoffset_y;
        g_gif.tex_tbp0 = g_gif.ctx1_tex_tbp0;
        g_gif.tex_tbw = g_gif.ctx1_tex_tbw;
        g_gif.tex_tfx = g_gif.ctx1_tex_tfx;
        g_gif.tex_tcc = g_gif.ctx1_tex_tcc;
        g_gif.tex_tw = g_gif.ctx1_tex_tw;
        g_gif.tex_th = g_gif.ctx1_tex_th;
        g_gif.tex_psm = g_gif.ctx1_tex_psm;
        g_gif.tex_cbp = g_gif.ctx1_tex_cbp;
        g_gif.tex_cpsm = g_gif.ctx1_tex_cpsm;
        g_gif.tex_csa = g_gif.ctx1_tex_csa;
        g_gif.tex_cld = g_gif.ctx1_tex_cld;
        g_gif.tex_csm = g_gif.ctx1_tex_csm;
        g_gif.zbp = g_gif.ctx1_zbp;
        g_gif.zpsm = g_gif.ctx1_zpsm;
        g_gif.zmsk = g_gif.ctx1_zmsk;
        g_gif.zbuf_configured = g_gif.ctx1_zbuf_configured;
        g_gif.zte = g_gif.ctx1_zte;
        g_gif.ztst = g_gif.ctx1_ztst;
        g_gif.ate = g_gif.ctx1_ate;
        g_gif.date=g_gif.ctx1_date; g_gif.datm=g_gif.ctx1_datm;
        g_gif.atst = g_gif.ctx1_atst;
        g_gif.aref = g_gif.ctx1_aref;
        g_gif.afail = g_gif.ctx1_afail;
        g_gif.alpha_a = g_gif.ctx1_alpha_a;
        g_gif.alpha_b = g_gif.ctx1_alpha_b;
        g_gif.alpha_c = g_gif.ctx1_alpha_c;
        g_gif.alpha_d = g_gif.ctx1_alpha_d;
        g_gif.alpha_fix = g_gif.ctx1_alpha_fix;
        g_gif.scissor_x0 = g_gif.ctx1_scissor_x0;
        g_gif.scissor_x1 = g_gif.ctx1_scissor_x1;
        g_gif.scissor_y0 = g_gif.ctx1_scissor_y0;
        g_gif.scissor_y1 = g_gif.ctx1_scissor_y1;
        g_gif.scissor_configured = g_gif.ctx1_scissor_configured;
        g_gif.tex1_lcm = g_gif.ctx1_tex1_lcm;
        g_gif.tex1_mxl = g_gif.ctx1_tex1_mxl;
        g_gif.tex1_mmag = g_gif.ctx1_tex1_mmag;
        g_gif.tex1_mmin = g_gif.ctx1_tex1_mmin;
        g_gif.tex1_mtba = g_gif.ctx1_tex1_mtba;
        g_gif.tex1_l = g_gif.ctx1_tex1_l;
        g_gif.tex1_k = g_gif.ctx1_tex1_k;
        for (int lvl = 0; lvl < 6; lvl++) {
            g_gif.tex_mip_tbp[lvl] = g_gif.ctx1_tex_mip_tbp[lvl];
            g_gif.tex_mip_tbw[lvl] = g_gif.ctx1_tex_mip_tbw[lvl];
        }
        g_gif.clamp_wms = g_gif.ctx1_clamp_wms;
        g_gif.clamp_wmt = g_gif.ctx1_clamp_wmt;
        g_gif.clamp_minu = g_gif.ctx1_clamp_minu;
        g_gif.clamp_maxu = g_gif.ctx1_clamp_maxu;
        g_gif.clamp_minv = g_gif.ctx1_clamp_minv;
        g_gif.clamp_maxv = g_gif.ctx1_clamp_maxv;
        g_gif.clamp_configured = g_gif.ctx1_clamp_configured;
        g_gif.fba = g_gif.ctx1_fba;
        g_gif.fba_configured = g_gif.ctx1_fba_configured;
    }
    g_texel_cache_enabled=0;
    uint32_t attr=gs_effective_attr_prim();
    g_draw_routes[0]++;
    if(attr&PRIM_TME_MASK)g_draw_routes[1]++;
    if(attr&PRIM_ABE_MASK)g_draw_routes[2]++;
    if(g_gif.zbuf_configured&&!g_gif.zmsk)g_draw_routes[3]++;
    if(g_gif.zbuf_configured&&g_gif.zte&&g_gif.ztst!=GS_ZTST_ALWAYS)g_draw_routes[4]++;
    if(g_gif.ate)g_draw_routes[5]++;
    if(g_gif.fbmask)g_draw_routes[6]++;
    if(gs_dither_active()||g_gif.fba)g_draw_routes[7]++;
    if(attr&PRIM_FGE_MASK)g_draw_routes[8]++;
    if((attr&PRIM_IIP_MASK)&&(g_gif.prim&7u)>=3u&&(g_gif.prim&7u)<=5u)g_draw_routes[9]++;
    /* Drawing attributes remain fixed during this synchronous primitive. */
    g_gx_opaque=!g_gif.date && !g_gif.ate && !gs_dither_active() && !g_gif.fba && !g_gif.fbmask &&
        (g_gif.frame_psm==TEX_PSM_PSMCT32 || g_gif.frame_psm==TEX_PSM_PSMCT24) &&
        !(gs_effective_attr_prim()&PRIM_ABE_MASK);
    g_opaque_pixel=g_gx_opaque && g_gif.frame_psm==TEX_PSM_PSMCT32;

}

static int gs_depth_is_inactive(void)
{return !g_gif.zbuf_configured || (g_gif.zmsk && (!g_gif.zte || g_gif.ztst==GS_ZTST_ALWAYS));}

/* Conservative physical page envelopes cover all supported texture layouts.
 * A draw-local cache is safe only when framebuffer AND writable depth are
 * disjoint from the source. No persistent VRAM generation assumptions. */
/* Conservative *physical eDRAM* extent, not a nominal PSMCT32-sized
 * allocation.  Color, Z, 16S and indexed texture views can address the same
 * pages even though their logical pixel rectangles have different sizes.
 * The bound is intentionally an envelope, never a false-disjoint guess. */
static uint64_t gs_page_end(uint64_t base,uint32_t bw,uint32_t width,uint32_t height,uint32_t psm)
{
    uint32_t pw=64u,ph=32u;
    switch(psm) {
    case 2u:case 10u:case 0x32u:case 0x3au:ph=64u;break;
    case 0x13u:pw=128u;ph=64u;break;
    case 0x14u:pw=128u;ph=128u;break;
    default:break; /* 32/24/8H/4HL/4HH all use 64x32 pages */
    }
    uint64_t pages=bw/pw;if(!pages)pages=1u;
    if(!width||!height)return base;
    return base+((((uint64_t)(height-1u)/ph)*pages)+
                 ((uint64_t)(width-1u)/pw)+1u)*8192u;
}
static int gs_draw_texture_cache_begin_impl(int32_t sx0,int32_t sy0,int32_t sx1,int32_t sy1,uint32_t minimum_pixels)
{
    if(g_gif.tex1_mxl&&g_gif.tex1_mmin>=2u&&g_gif.tex1_mmin<=5u)return 0;
    if(sx0<0||sy0<0||sx1<=sx0||sy1<=sy0||
       (uint64_t)(sx1-sx0)*(uint32_t)(sy1-sy0)<minimum_pixels||
       !g_gif.clamp_configured||g_gif.clamp_wms>1u||g_gif.clamp_wmt>1u||g_gif.tex_tw>10u||g_gif.tex_th>10u)return 0;
    uint64_t source=(uint64_t)g_gif.tex_tbp0*256u;
    uint64_t source_end=gs_page_end(source,g_gif.tex_tbw,1u<<g_gif.tex_tw,1u<<g_gif.tex_th,g_gif.tex_psm);
    uint64_t frame=(uint64_t)g_gif.fbp*4u,frame_end=gs_page_end(frame,g_gif.fbw,sx1,sy1,g_gif.frame_psm);
    if(source_end>GS_MEM_SIZE||frame_end>GS_MEM_SIZE||!(source_end<=frame||frame_end<=source))return 0;
    if(g_gif.zbuf_configured&&!g_gif.zmsk) {
        uint64_t z=(uint64_t)g_gif.zbp*4u,z_end=gs_page_end(z,g_gif.fbw,sx1,sy1,g_gif.zpsm);
        if(z_end>GS_MEM_SIZE||!(source_end<=z||z_end<=source))return 0;
    }
    memset(g_texel_tags,0xff,sizeof(g_texel_tags));g_texel_cache_enabled=1;return 1;
}

static int gs_draw_texture_cache_begin(int32_t x0,int32_t y0,int32_t x1,int32_t y1)
{return gs_draw_texture_cache_begin_impl(x0,y0,x1,y1,512u);}

/* Round 96: real SCISSOR clipping (GS Users Manual "SCISSOR_1/2:
 * Setting for Scissoring Area") - previously entirely unmodeled (see
 * the Round 28 comment on GS_REG_TEX1_1 above). Applied uniformly
 * across all 4 rasterizers below: triangle/sprite clamp their
 * bounding box directly (cheaper, and those two already computed a
 * bounding box); point/line test each individual pixel, since they
 * don't have a bounding box to clamp. scissor_configured follows the
 * same "safety gate" pattern as zbuf_configured - if no real SCISSOR
 * write has ever happened, this is a no-op and every pre-existing
 * test/demo keeps drawing exactly as before this round. */
static int scissor_test(int32_t x, int32_t y)
{
    if (!g_gif.scissor_configured) return 1;
    if (x < (int32_t)g_gif.scissor_x0 || x > (int32_t)g_gif.scissor_x1) return 0;
    if (y < (int32_t)g_gif.scissor_y0 || y > (int32_t)g_gif.scissor_y1) return 0;
    return 1;
}

static void clamp_bbox_to_scissor(int32_t *minx, int32_t *maxx, int32_t *miny, int32_t *maxy, int exclusive_max)
{
    if (!g_gif.scissor_configured) return;
    /* SCISSOR's SCAX1/SCAY1 are real, documented INCLUSIVE bounds
     * (GS Users Manual). rasterize_triangle()'s own bbox loop is
     * already inclusive on both ends (`xx <= maxx`), so its maxx/maxy
     * compare directly against SCAX1/SCAY1. rasterize_sprite()'s own
     * loop is EXCLUSIVE on the high edge (`xx < sx1`, matching this
     * project's established SPRITE X1/Y1 convention - see
     * rasterize_sprite()'s own header comment) - exclusive_max=1
     * shifts the comparison by one so an inclusive real SCISSOR bound
     * still allows exactly that last real pixel to be drawn under an
     * exclusive loop. */
    int32_t sx0 = (int32_t)g_gif.scissor_x0, sx1 = (int32_t)g_gif.scissor_x1;
    int32_t sy0 = (int32_t)g_gif.scissor_y0, sy1 = (int32_t)g_gif.scissor_y1;
    if (exclusive_max) { sx1 += 1; sy1 += 1; }
    if (*minx < sx0) *minx = sx0;
    if (*maxx > sx1) *maxx = sx1;
    if (*miny < sy0) *miny = sy0;
    if (*maxy > sy1) *maxy = sy1;
}

/* Round 97 (138th finding, task #254): the Fog effect - blends a
 * fragment's shaded/textured color toward FOGCOL using a per-pixel
 * Fog coefficient F (0-255), per the official GS Users Manual's
 * "3.5. Fog Effect":
 *   R = F*Rv + (0xff-F)*Rfc   (and likewise G, B; alpha is untouched)
 * The manual's own footnote on this formula ("A*B = (AxB)>>8")
 * establishes the real fixed-point convention: divide by 256, not
 * 255 - confirmed self-consistent with the F=255/F=0 boundary
 * descriptions ("255 = fog effect at minimum" implies output should
 * equal the vertex color almost exactly, which >>8 gives - 255/256
 * of the original value - while a plain /255 division would not
 * introduce this same, deliberately-matching, real-hardware
 * rounding). Gated by PRIM's real FGE bit (Round 97's PRIM_FGE_MASK) -
 * "Whether or not Fogging is performed is specified with the FGE flag
 * of the PRIM register", per the manual - so this is a genuine no-op
 * for every pre-existing test/demo, none of which ever set FGE. */
static uint32_t apply_fog(uint32_t color, uint32_t fog)
{
    if (!(gs_effective_attr_prim() & PRIM_FGE_MASK)) return color;
    uint32_t r = rgba_channel(color, 0), g = rgba_channel(color, 8), b = rgba_channel(color, 16), a = rgba_channel(color, 24);
    uint32_t fcr = rgba_channel(g_gif.fogcol, 0), fcg = rgba_channel(g_gif.fogcol, 8), fcb = rgba_channel(g_gif.fogcol, 16);
    uint32_t inv = 255u - fog;
    uint32_t nr = ((fog * r) + (inv * fcr)) >> 8;
    uint32_t ng = ((fog * g) + (inv * fcg)) >> 8;
    uint32_t nb = ((fog * b) + (inv * fcb)) >> 8;
    nr = gs_colclamp_channel((int32_t)nr);
    ng = gs_colclamp_channel((int32_t)ng);
    nb = gs_colclamp_channel((int32_t)nb);
    return rgba_pack(nr, ng, nb, a);
}

/* Round 98 (139th finding, task #254): CLAMP_1/2 real texture wrap
 * mode - per the official GS Users Manual's own FIELD table:
 *   REPEAT (00): coord & (size-1) - real hardware requires power-of-2
 *     texture sizes (matches this project's existing log2 tex_tw/th
 *     fields), so a bitmask is the exact real wrap operation.
 *   CLAMP (01): coord clamped to [0, size-1].
 *   REGION_CLAMP (10): coord clamped to the explicit [minv,maxv]
 *     sub-rectangle (minv/maxv here already resolved to whichever of
 *     MINU/MAXU or MINV/MAXV the caller passed - see call sites).
 *   REGION_REPEAT (11): coord = (coord & minv) | maxv - a masked-
 *     repeat (minv/maxv here are really UMSK/UFIX or VMSK/VFIX in
 *     this mode, per the manual's own field-reuse note).
 * Gated by clamp_configured (this project's established safety-gate
 * convention) - when CLAMP_1/2 was never written, this is a pure
 * pass-through, so every pre-existing texture test/demo keeps
 * sampling exactly as before this round. */
static int32_t gs_apply_clamp_wrap(int32_t coord, uint32_t size_log2, uint32_t wm, uint32_t minv, uint32_t maxv)
{
    if (!g_gif.clamp_configured) return coord;
    int32_t size = (int32_t)(1u << size_log2);
    switch (wm) {
    case GS_CLAMP_REPEAT:
        return coord & (size - 1);
    case GS_CLAMP_CLAMP:
        if (coord < 0) return 0;
        if (coord > size - 1) return size - 1;
        return coord;
    case GS_CLAMP_REGION_CLAMP:
        if (coord < (int32_t)minv) return (int32_t)minv;
        if (coord > (int32_t)maxv) return (int32_t)maxv;
        return coord;
    case GS_CLAMP_REGION_REPEAT:
        return (coord & (int32_t)minv) | (int32_t)maxv;
    default:
        return coord;
    }
}

/* One-level UV/STQ filtering, selected by the Q/K/L caller.
 * GS texel centers are at n+0.5; the bundled PCSX2 scanline reference
 * subtracts 0x8000 in 16.16 coordinates before its four-tap lookup. */
static uint32_t gs_sample_texture_base(double u, double v,int linear)
{
    /* TEX1 filtering applies to both UV and STQ coordinates. */
    if (linear) {
        u -= 0.5; v -= 0.5;
        if (!(u > -2147483647.0 && u < 2147483646.0 &&
              v > -2147483647.0 && v < 2147483646.0)) return 0u;
        int32_t x0 = (int32_t)u, y0 = (int32_t)v;
        if (u < (double)x0) --x0;
        if (v < (double)y0) --y0;
        uint32_t fx = (uint32_t)((u - (double)x0) * 16.0);
        uint32_t fy = (uint32_t)((v - (double)y0) * 16.0);
        int32_t xs[2], ys[2];
        for (unsigned i = 0; i < 2; ++i) {
            xs[i] = gs_apply_clamp_wrap(x0+(int32_t)i,g_gif.tex_tw,g_gif.clamp_wms,g_gif.clamp_minu,g_gif.clamp_maxu);
            ys[i] = gs_apply_clamp_wrap(y0+(int32_t)i,g_gif.tex_th,g_gif.clamp_wmt,g_gif.clamp_minv,g_gif.clamp_maxv);
        }
        uint32_t c00=gs_sample_texel(xs[0],ys[0]), c01=gs_sample_texel(xs[1],ys[0]);
        uint32_t c10=gs_sample_texel(xs[0],ys[1]), c11=gs_sample_texel(xs[1],ys[1]);
        uint32_t result=0;
        for (unsigned shift=0; shift<32; shift+=8) {
            uint32_t a=(rgba_channel(c00,shift)*(16u-fx)+rgba_channel(c01,shift)*fx)>>4;
            uint32_t b=(rgba_channel(c10,shift)*(16u-fx)+rgba_channel(c11,shift)*fx)>>4;
            result |= ((a*(16u-fy)+b*fy)>>4)<<shift;
        }
        return result;
    }
    /* Nearest selects the containing texel (16.16 >> 16), not
     * round-to-nearest. Preserve negative coordinates for REPEAT. */
    if (!(u > -2147483647.0 && u < 2147483646.0 &&
          v > -2147483647.0 && v < 2147483646.0)) return 0u;
    int32_t x=(int32_t)u, y=(int32_t)v;
    if (u < (double)x) --x;
    if (v < (double)y) --y;
    x=gs_apply_clamp_wrap(x,g_gif.tex_tw,g_gif.clamp_wms,g_gif.clamp_minu,g_gif.clamp_maxu);
    y=gs_apply_clamp_wrap(y,g_gif.tex_th,g_gif.clamp_wmt,g_gif.clamp_minv,g_gif.clamp_maxv);
    return gs_sample_texel(x,y);
}

/* Mipmap coordinates and clamp bounds are expressed at the selected level.
 * Preserve canonical registers; never share a texel cache across levels. */
static uint32_t gs_sample_level(double u,double v,unsigned level,int linear)
{
 if(!level)return gs_sample_texture_base(u,v,linear);
 uint32_t bp=g_gif.tex_tbp0,bw=g_gif.tex_tbw,tw=g_gif.tex_tw,th=g_gif.tex_th;
 uint32_t minu=g_gif.clamp_minu,maxu=g_gif.clamp_maxu,minv=g_gif.clamp_minv,maxv=g_gif.clamp_maxv;
 int cache=g_texel_cache_enabled;g_texel_cache_enabled=0;
 g_gif.tex_tbp0=g_gif.tex_mip_tbp[level-1];g_gif.tex_tbw=g_gif.tex_mip_tbw[level-1];
 g_gif.tex_tw=tw>level?tw-level:0;g_gif.tex_th=th>level?th-level:0;
 g_gif.clamp_minu=minu>>level;g_gif.clamp_maxu=maxu>>level;
 g_gif.clamp_minv=minv>>level;g_gif.clamp_maxv=maxv>>level;
 double scale=1.0/(1u<<level);
 uint32_t color=gs_sample_texture_base(u*scale,v*scale,linear);
 g_gif.tex_tbp0=bp;g_gif.tex_tbw=bw;g_gif.tex_tw=tw;g_gif.tex_th=th;
 g_gif.clamp_minu=minu;g_gif.clamp_maxu=maxu;g_gif.clamp_minv=minv;g_gif.clamp_maxv=maxv;
 g_texel_cache_enabled=cache;return color;
}
static uint32_t gs_sample_texture_q(double u,double v,double q)
{
 unsigned mode=g_gif.tex1_mmin,mxl=g_gif.tex1_mxl>6u?6u:g_gif.tex1_mxl;
 /* Preserve the common min==mag fast path: no logarithm for nonmipped draws. */
 if(mode<=1u&&g_gif.tex1_mmag==(mode==1u))return gs_sample_texture_base(u,v,mode==1u);
 double lod=(double)g_gif.tex1_k/16.0;
 if(!g_gif.tex1_lcm&&!(gs_effective_attr_prim()&PRIM_FST_MASK)){
  double magnitude=fabs(q);
  if(magnitude>0.0&&isfinite(magnitude))lod-=log2(magnitude)*(1u<<g_gif.tex1_l);
  else lod=magnitude==0.0?(double)mxl:0.0;
 }
 int linear=lod<=0.0?g_gif.tex1_mmag:(mode==1u||mode==4u||mode==5u);
 if(!mxl||mode<2u||mode>5u||lod<=0.0)return gs_sample_texture_base(u,v,linear);
 if(lod>mxl)lod=mxl;
 unsigned level=(unsigned)((mode&1u)?lod:lod+0.5);
 if(level>mxl)level=mxl;
 uint32_t first=gs_sample_level(u,v,level,linear);
 if(!(mode&1u)||level>=mxl)return first;
 unsigned blend=(unsigned)((lod-level)*32768.0);
 if(!blend)return first;
 uint32_t second=gs_sample_level(u,v,level+1u,linear),out=0;
 for(unsigned shift=0;shift<32;shift+=8){
  unsigned a=(first>>shift)&255u,b=(second>>shift)&255u;
  out|=((a*(32768u-blend)+b*blend)>>15)<<shift;
 }
 return out;
}
static uint32_t gs_sample_texture(double u,double v)
{return gs_sample_texture_q(u,v,g_gif.cur_q);}

static uint32_t gs_gx_raw_texture_sample(int32_t x,int32_t y);

/* R1330-K: first reason (priority order) why a visible IIP triangle cannot use
 * the GX path in this build.  Size heuristics come last so that the counters
 * show structural state blockers first.  GIF_GFB_NONE means eligible. */
#ifndef GEKKO2_GOURAUD_GX_MIN_PIXELS
#define GEKKO2_GOURAUD_GX_MIN_PIXELS 0u
#endif
static unsigned gouraud_gx_block_reason(int textured,int32_t minx,int32_t miny,int32_t maxx,int32_t maxy,uint32_t a0,uint32_t a1,uint32_t a2)
{
    if(!gekko2_opt_enabled(GEKKO2_OPT_GX_GOURAUD))return GIF_GFB_BUILD_DISABLED;
    if(!(!g_gif.date && gs_gx_render_active()))return GIF_GFB_GX_INACTIVE;
#ifdef GEKKO2_GOURAUD_GX_DISABLE
    return GIF_GFB_BUILD_DISABLED;
#endif
    uint32_t attr=gs_effective_attr_prim();
    if(textured)return GIF_GFB_TEXTURE;
    if(g_gif.ate)return GIF_GFB_ALPHA_TEST;
    if(gs_dither_active()||g_gif.fba)return GIF_GFB_DITHER_FBA;
    if(g_gif.fbmask)return GIF_GFB_FBMASK;
    if(g_gif.zbuf_configured)return GIF_GFB_DEPTH;
    if(attr&PRIM_ABE_MASK)return GIF_GFB_BLEND;
    if(attr&PRIM_FGE_MASK)return GIF_GFB_FOG;
    if(g_gif.frame_psm!=TEX_PSM_PSMCT32)return GIF_GFB_PSM;
    /* K: EFB is RGB8 (no alpha); alpha is a per-triangle constant at import.
     * Varying alpha stays in software (traceable fallback). */
    if(a0!=a1||a1!=a2)return GIF_GFB_ALPHA_VARIES;
    if(maxx-minx>=640||maxy-miny>=512)return GIF_GFB_LARGE;
    if((uint64_t)(maxx-minx+1)*(uint64_t)(maxy-miny+1)<GEKKO2_GOURAUD_GX_MIN_PIXELS)return GIF_GFB_SMALL;
    return GIF_GFB_NONE;
}

static int triangle_classify(int32_t x0,int32_t y0,int32_t x1,int32_t y1,int32_t x2,int32_t y2)
{
    const int gouraud_prim=(gs_effective_attr_prim()&PRIM_IIP_MASK)!=0;
    const int32_t area=edge(x0,y0,x1,y1,x2,y2);
    if (gouraud_prim) g_gst[GIF_GOURAUD_SUBMITTED]++; else g_gst[GIF_GOURAUD_FLAT_SUBMITTED]++;
    if (area == 0) {
        if (gouraud_prim) {
            uint64_t n = g_gst[GIF_GOURAUD_DEGENERATE]++;
            unsigned same = (x0 == x1 && y0 == y1) + (x1 == x2 && y1 == y2) + (x0 == x2 && y0 == y2);
            g_gst[same >= 3u ? GIF_GOURAUD_DEG_IDENTICAL3 : same ? GIF_GOURAUD_DEG_TWO_SAME : GIF_GOURAUD_DEG_COLLINEAR]++;
            if (!x0 && !y0 && !x1 && !y1 && !x2 && !y2) g_gst[GIF_GOURAUD_DEG_ORIGIN]++;
            if (n < 16u) {
                g_gdeg[n].xy[0] = x0; g_gdeg[n].xy[1] = y0; g_gdeg[n].xy[2] = x1;
                g_gdeg[n].xy[3] = y1; g_gdeg[n].xy[4] = x2; g_gdeg[n].xy[5] = y2;
                g_gdeg[n].prim = g_gif.prim;
            }
        } else g_gst[GIF_GOURAUD_FLAT_DEGENERATE]++;
        return 0;
    }
    return 1;
}
static int triangle_assembly_visible(void)
{
#ifdef GEKKO2_GOURAUD_EARLY_DEGENERATE
    return triangle_classify(g_gif.tri_x[0],g_gif.tri_y[0],g_gif.tri_x[1],g_gif.tri_y[1],g_gif.tri_x[2],g_gif.tri_y[2]);
#else
    return 1;
#endif
}

#ifdef GEKKO2_GX_GENERIC_SHADER
static uint32_t gs_gx_white_texel(int32_t x,int32_t y)
{(void)x;(void)y;return 0x80808080u;}
static int gs_gx_source_axes(gs_gx_axis_plan *x,gs_gx_axis_plan *y)
{return g_gif.clamp_configured&&gs_gx_plan_axis(g_gif.tex_tw,g_gif.clamp_wms,g_gif.clamp_minu,g_gif.clamp_maxu,x)&&
 gs_gx_plan_axis(g_gif.tex_th,g_gif.clamp_wmt,g_gif.clamp_minv,g_gif.clamp_maxv,y)&&gs_gx_native_texture_valid(x->size,y->size);}
static uint32_t gs_gx_atlas_texel(int32_t x,int32_t y)
{return gs_sample_texel_uncached(
 gs_apply_clamp_wrap(x,g_gif.tex_tw,g_gif.clamp_wms,g_gif.clamp_minu,g_gif.clamp_maxu),
 gs_apply_clamp_wrap(y,g_gif.tex_th,g_gif.clamp_wmt,g_gif.clamp_minv,g_gif.clamp_maxv));}
static int gs_gx_atlas_disjoint(int32_t sx,int32_t sy,const gs_gx_axis_plan *x,const gs_gx_axis_plan *y)
{
 uint64_t base=(uint64_t)g_gif.tex_tbp0*256u;
 uint64_t end=gs_page_end(base,g_gif.tex_tbw,x->max_index+1u,y->max_index+1u,g_gif.tex_psm);
 uint64_t frame=(uint64_t)g_gif.fbp*4u,fe=gs_page_end(frame,g_gif.fbw,sx,sy,g_gif.frame_psm);
 if(end>GS_MEM_SIZE||fe>GS_MEM_SIZE||!(end<=frame||fe<=base))return 0;
 if(g_gif.zbuf_configured&&(g_gif.zte||!g_gif.zmsk)){
  uint64_t z=(uint64_t)g_gif.zbp*4u,ze=gs_page_end(z,g_gif.fbw,sx,sy,g_gif.zpsm);
  if(ze>GS_MEM_SIZE||!(end<=z||ze<=base))return 0;
 }
 return 1;
}
#endif
static void gs_gx_native_source_key(void)
{
 uint64_t hash=0,base=(uint64_t)g_gif.tex_tbp0*256u;
 uint64_t end=gs_page_end(base,g_gif.tex_tbw,1u<<g_gif.tex_tw,1u<<g_gif.tex_th,g_gif.tex_psm);
#ifdef GEKKO2_GX_GENERIC_SHADER
 gs_gx_axis_plan ax,ay;
 if(gs_gx_source_axes(&ax,&ay))end=gs_page_end(base,g_gif.tex_tbw,ax.max_index+1u,ay.max_index+1u,g_gif.tex_psm);
 else end=0;
#endif
 int valid=end<=GS_MEM_SIZE&&end>base&&end-base<=2097152u;
 if(valid)valid=gs_mem_gpu_sync_alias_range((uint32_t)base,(uint32_t)end);
 if(valid)valid=gs_mem_hash_range((uint32_t)base,(uint32_t)(end-base),&hash);
 uint32_t state[]={g_gif.tex_tbp0,g_gif.tex_tbw,g_gif.tex_tw,g_gif.tex_th,g_gif.tex_psm,
  g_gif.tex_cbp,g_gif.tex_cpsm,g_gif.tex_csa,g_gif.tex_csm,g_gif.texa_ta0,g_gif.texa_ta1,g_gif.texa_aem,g_gif.clut_words_valid?g_gif.clut_write_csm:2u,
  g_gif.clamp_wms,g_gif.clamp_wmt,g_gif.clamp_minu,g_gif.clamp_maxu,g_gif.clamp_minv,g_gif.clamp_maxv};
 uint32_t lo=(uint32_t)hash,hi=(uint32_t)(hash>>32);
 for(unsigned n=0;n<sizeof(state)/sizeof(*state);n++){lo=(lo^state[n])*16777619u;hi=((hi<<5)|(hi>>27))^state[n];}
 if(g_gif.tex_psm==0x13u||g_gif.tex_psm==0x14u||g_gif.tex_psm==0x1bu||g_gif.tex_psm==0x24u||g_gif.tex_psm==0x2cu)
  for(unsigned n=0;n<512;n++){lo=(lo^gs_clut_hash_word(n))*16777619u;hi=((hi<<5)|(hi>>27))^gs_clut_hash_word(n);}
 gs_gx_source_key(lo,hi,valid);
}
static struct {int32_t xy[6],maxx,maxy;double uv[6];float stq[9];uint32_t colors[3];double inv;} gx_triangle;
static uint32_t gs_gx_triangle_sample(int32_t xx,int32_t yy)
{
 const int32_t *xy=gx_triangle.xy;const double *uv=gx_triangle.uv;const float *stq=gx_triangle.stq;
 if(xx>gx_triangle.maxx||yy>gx_triangle.maxy)return 0;
 double b0=(double)edge(xy[2],xy[3],xy[4],xy[5],xx,yy)*gx_triangle.inv;
 double b1=(double)edge(xy[4],xy[5],xy[0],xy[1],xx,yy)*gx_triangle.inv;
 double b2=(double)edge(xy[0],xy[1],xy[2],xy[3],xx,yy)*gx_triangle.inv;
 int sign=gx_triangle.inv>0?1:-1;
 if(!gs_triangle_edge_inside(edge(xy[2],xy[3],xy[4],xy[5],xx,yy),sign,gs_triangle_edge_inclusive(xy[2],xy[3],xy[4],xy[5],sign))||
    !gs_triangle_edge_inside(edge(xy[4],xy[5],xy[0],xy[1],xx,yy),sign,gs_triangle_edge_inclusive(xy[4],xy[5],xy[0],xy[1],sign))||
    !gs_triangle_edge_inside(edge(xy[0],xy[1],xy[2],xy[3],xx,yy),sign,gs_triangle_edge_inclusive(xy[0],xy[1],xy[2],xy[3],sign)))return 0;
 uint32_t c0=gx_triangle.colors[0],c1=gx_triangle.colors[1],c2=gx_triangle.colors[2];
 double u0=uv[0],v0=uv[1],u1=uv[2],v1=uv[3],u2=uv[4],v2=uv[5];
 float s0=stq[0],t0=stq[1],q0=stq[2],s1=stq[3],t1=stq[4],q1=stq[5],s2=stq[6],t2=stq[7],q2=stq[8];
 int gouraud=!!(gs_effective_attr_prim()&PRIM_IIP_MASK),textured=1;
 uint32_t flat_r=rgba_channel(c2,0),flat_g=rgba_channel(c2,8),flat_b=rgba_channel(c2,16),flat_a=rgba_channel(c2,24);
                uint32_t shaded_r, shaded_g, shaded_b, shaded_a;
                if (!gouraud) {
                    shaded_r = flat_r; shaded_g = flat_g; shaded_b = flat_b; shaded_a = flat_a;
                } else {
                    uint32_t r = (uint32_t)(b0 * rgba_channel(c0, 0)  + b1 * rgba_channel(c1, 0)  + b2 * rgba_channel(c2, 0)  + 0.5);
                    uint32_t g = (uint32_t)(b0 * rgba_channel(c0, 8)  + b1 * rgba_channel(c1, 8)  + b2 * rgba_channel(c2, 8)  + 0.5);
                    uint32_t b = (uint32_t)(b0 * rgba_channel(c0, 16) + b1 * rgba_channel(c1, 16) + b2 * rgba_channel(c2, 16) + 0.5);
                    uint32_t a = (uint32_t)(b0 * rgba_channel(c0, 24) + b1 * rgba_channel(c1, 24) + b2 * rgba_channel(c2, 24) + 0.5);
                    r = gs_colclamp_channel((int32_t)r);
                    g = gs_colclamp_channel((int32_t)g);
                    b = gs_colclamp_channel((int32_t)b);
                    a = gs_colclamp_channel((int32_t)a);
                    shaded_r = r; shaded_g = g; shaded_b = b; shaded_a = a;
                }

                uint32_t out;
                if (!textured) {
                    out = rgba_pack(shaded_r, shaded_g, shaded_b, shaded_a);
                } else {
                    double tu, tv;
                    if (gs_effective_attr_prim() & PRIM_FST_MASK) {
                        /* FST=1 (UV mode): plain affine interpolation,
                         * exactly as before task #88 - UV is already
                         * in integer texel units. */
                        tu = b0 * (double)u0 + b1 * (double)u1 + b2 * (double)u2;
                        tv = b0 * (double)v0 + b1 * (double)v1 + b2 * (double)v2;
                    } else {
                        /* GS STQ are homogeneous texture coordinates: interpolate
                         * S, T and Q in screen space, then divide S/T by Q.
                         * Reference: bundled PCSX2 GSDrawScanline.cpp,
                         * DrawScanline: s/t/q setup, SampleTexture and Step.
                         * Interpolating S/Q and 1/Q instead incorrectly cancels
                         * a constant Q and changes varying-Q texture mapping. */
                        double q_interp = b0 * (double)q0 + b1 * (double)q1 + b2 * (double)q2;
                        double inv_q = (q_interp != 0.0) ? 1.0 / q_interp : 0.0;
                        double s_norm = (b0 * (double)s0 + b1 * (double)s1 + b2 * (double)s2) * inv_q;
                        double t_norm = (b0 * (double)t0 + b1 * (double)t1 + b2 * (double)t2) * inv_q;

                        /* Scale normalized ST into texel space using
                         * TEX0's real TW/TH (log2 texture width/
                         * height) fields. */
                        tu = s_norm * (double)(1u << g_gif.tex_tw);
                        tv = t_norm * (double)(1u << g_gif.tex_th);
                    }
                    uint32_t texel = gs_sample_texture_q(tu,tv,b0*(double)q0+b1*(double)q1+b2*(double)q2);
                    out = gs_texture_function(texel, rgba_pack(shaded_r, shaded_g, shaded_b, shaded_a));
                }
 return out;
}

static void rasterize_triangle_profile_impl(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2,
                                uint32_t c0, uint32_t c1, uint32_t c2,
                                double u0, double v0, double u1, double v1, double u2, double v2,
                                float s0, float t0, float q0, float s1, float t1, float q1, float s2, float t2, float q2,
                                uint32_t z0, uint32_t z1, uint32_t z2,
                                uint32_t f0, uint32_t f1, uint32_t f2){
    /* R1330-K: classify before any context work.  edge() is pure integer
     * geometry, so the zero-area decision does not depend on the context. */
    const int gouraud_prim = (gs_effective_attr_prim() & PRIM_IIP_MASK) != 0;
    const int32_t area = edge(x0, y0, x1, y1, x2, y2);
#ifndef GEKKO2_GOURAUD_EARLY_DEGENERATE
    triangle_classify(x0,y0,x1,y1,x2,y2);
#endif
    if(area==0)return;
    gs_activate_context(); /* Round 27: dual-context - see its own comment */
    int32_t minx = x0, maxx = x0, miny = y0, maxy = y0;
    if (x1 < minx) minx = x1;
    if (x1 > maxx) maxx = x1;
    if (x2 < minx) minx = x2;
    if (x2 > maxx) maxx = x2;
    if (y1 < miny) miny = y1;
    if (y1 > maxy) maxy = y1;
    if (y2 < miny) miny = y2;
    if (y2 > maxy) maxy = y2;
    if (minx < 0) minx = 0;
    if (miny < 0) miny = 0;
    clamp_bbox_to_scissor(&minx, &maxx, &miny, &maxy, 0); /* triangle: inclusive loop */

    /* Degenerate (zero-area) triangle - nothing to draw. Also guards
     * against divide-by-zero-shaped edge cases below. */
    if (area == 0) return;
    unsigned gouraud_reason = GIF_GFB_NONE;
    if (gouraud_prim) {
        if (maxx < minx || maxy < miny) g_gst[GIF_GOURAUD_OFFSCREEN]++;
        else {
            g_gst[GIF_GOURAUD_VISIBLE]++;
            uint32_t a = gs_effective_attr_prim(), key = 0;
            const uint32_t psm = g_gif.frame_psm;
            if (a & PRIM_TME_MASK) key |= 1u << 0;
            if (a & PRIM_ABE_MASK) key |= 1u << 1;
            if (g_gif.zbuf_configured && !g_gif.zmsk) key |= 1u << 2;
            if (g_gif.zbuf_configured && g_gif.zte && g_gif.ztst != GS_ZTST_ALWAYS) key |= 1u << 3;
            if (a & PRIM_FGE_MASK) key |= 1u << 4;
            if (g_gif.ate) key |= 1u << 5;
            if (gs_dither_active() || g_gif.fba) key |= 1u << 6;
            if (g_gif.fbmask) key |= 1u << 7;
            key |= (psm == TEX_PSM_PSMCT32 ? 0u : psm == TEX_PSM_PSMCT24 ? 1u :
                    (psm == TEX_PSM_PSMCT16 || psm == TEX_PSM_PSMCT16S) ? 2u : 3u) << 8;
            if (z0 != z1 || z1 != z2) key |= 1u << 10;
            if (a & PRIM_TME_MASK) {
                key |= (g_gif.tex_tfx & 3u) << 11;
                if (g_gif.tex1_mmag == 1u && g_gif.tex1_mmin == 1u) key |= 1u << 13;
                if (a & PRIM_FST_MASK) key |= 1u << 14;
            }
            gouraud_state_record(key);
        }
    }

    int gouraud = (gs_effective_attr_prim() & PRIM_IIP_MASK) != 0;
    int textured = (gs_effective_attr_prim() & PRIM_TME_MASK) != 0;
    const int interpolate_color=gouraud && (c0!=c1 || c1!=c2);
    /* Flat shading uses the LAST vertex's color on real hardware
     * (matches this rasterizer's pre-Gouraud behavior, which always
     * used whichever RGBAQ was active when the triangle completed -
     * i.e. exactly c2's value, since c2 is always the most-recently-
     * kicked vertex's color). */
    uint32_t flat_r = rgba_channel(c2, 0), flat_g = rgba_channel(c2, 8);
    uint32_t flat_b = rgba_channel(c2, 16), flat_a = rgba_channel(c2, 24);

#ifdef GEKKO2_GX_EXTENDED_TRIANGLES
    /* GPU evaluates texture/color interpolation. GS destination permissions,
     * arbitrary alpha/depth islands and full-precision Z remain canonical. */
    int native_generic=0,native_axis_ok=0;
    gs_gx_axis_plan ax={0},ay={0};
#ifdef GEKKO2_GX_GENERIC_SHADER
    native_generic=1;native_axis_ok=!textured||gs_gx_source_axes(&ax,&ay);
#endif
    if((textured||native_generic)&&(native_generic||!interpolate_color||(g_gif.tex_tfx<=1u&&
       (c0>>24)==(c1>>24)&&(c1>>24)==(c2>>24)))&&
       !gs_dither_active()&&!g_gif.fbmask&&(native_generic||!(gs_effective_attr_prim()&PRIM_FGE_MASK))&&
       (!textured||(
       !g_gif.tex1_mxl&&g_gif.tex1_mmin<=1u&&g_gif.tex1_mmag==g_gif.tex1_mmin&&g_gif.tex_tw<=10u&&g_gif.tex_th<=10u&&
       (native_generic?native_axis_ok:(gs_gx_native_texture_valid(1u<<g_gif.tex_tw,1u<<g_gif.tex_th)&&
       g_gif.clamp_configured&&g_gif.clamp_wms<=1u&&g_gif.clamp_wmt<=1u))&&
       (gs_effective_attr_prim()&PRIM_FST_MASK||(q0>0&&q1>0&&q2>0&&isfinite(q0)&&isfinite(q1)&&isfinite(q2)))))&&
       gekko2_opt_enabled(GEKKO2_OPT_GX_GOURAUD)&&gekko2_opt_enabled(GEKKO2_OPT_GX_RESIDENT)&&
       gs_gx_render_active()&&maxx>=minx&&maxy>=miny&&
       (g_gif.frame_psm==0u||g_gif.frame_psm==1u)&&(!textured||
#ifdef GEKKO2_GX_GENERIC_SHADER
       gs_gx_atlas_disjoint(maxx+1,maxy+1,&ax,&ay)
#else
       gs_draw_texture_cache_begin_impl(minx,miny,maxx+1,maxy+1,0u)
#endif
       )){
        int32_t xy[6]={x0,y0,x1,y1,x2,y2};float uv[6],qs[3]={q0,q1,q2};
        uint32_t colors[3]={c0,c1,c2},zs[3]={z0,z1,z2};
        uint32_t tw=textured?(native_generic?ax.size:1u<<g_gif.tex_tw):4u,th=textured?(native_generic?ay.size:1u<<g_gif.tex_th):4u;
        if(!textured){memset(uv,0,sizeof uv);qs[0]=qs[1]=qs[2]=1;}
        else if(gs_effective_attr_prim()&PRIM_FST_MASK){
            uv[0]=(float)u0/tw;uv[1]=(float)v0/th;
            uv[2]=(float)u1/tw;uv[3]=(float)v1/th;
            uv[4]=(float)u2/tw;uv[5]=(float)v2/th;
            qs[0]=qs[1]=qs[2]=1;
        }else{float sx=(float)(1u<<g_gif.tex_tw)/tw,sy=(float)(1u<<g_gif.tex_th)/th;
            uv[0]=s0*sx;uv[1]=t0*sy;uv[2]=s1*sx;uv[3]=t1*sy;uv[4]=s2*sx;uv[5]=t2*sy;}
        gs_gx_native_color color={c2,textured?g_gif.tex_tcc:0u,textured?g_gif.tex_tfx:0u,g_gif.scissor_configured?g_gif.scissor_y1+1u:0u};
#ifdef GEKKO2_GX_GENERIC_SHADER
        color.fog_enabled=!!(gs_effective_attr_prim()&PRIM_FGE_MASK);color.fog_color=g_gif.fogcol;
        color.fog[0]=f0;color.fog[1]=f1;color.fog[2]=f2;color.untextured=!textured;
#endif
        gs_gx_pipeline pipe={g_gif.zbp,g_gif.zpsm,g_gif.zbuf_configured&&g_gif.zte,
            g_gif.zbuf_configured&&!g_gif.zmsk,g_gif.ztst,z2,
            !!(gs_effective_attr_prim()&PRIM_ABE_MASK),g_gif.alpha_a,g_gif.alpha_b,g_gif.alpha_c,g_gif.alpha_d,
            g_gif.alpha_fix,g_gif.pabe,!g_gif.colclamp_configured||g_gif.colclamp,g_gif.fbmask,g_gif.fba,
            g_gif.date,g_gif.datm,g_gif.ate,g_gif.atst,g_gif.aref,g_gif.afail};
        gs_gx_texel_fn sampler=gs_sample_texel_uncached;
        if(textured)gs_gx_native_source_key();
#ifdef GEKKO2_GX_GENERIC_SHADER
        else {gs_gx_source_key(0x554e5445u,0x58545552u,1);sampler=gs_gx_white_texel;}
        if(textured)sampler=gs_gx_atlas_texel;
#endif
        int accepted=gs_gx_draw_native_triangle_ex(g_gif.frame_psm,g_gif.fbp,g_gif.fbw,
            minx,miny,maxx,maxy,xy,uv,textured?qs:NULL,interpolate_color&&(native_generic||g_gif.tex_tfx==TEX_TFX_MODULATE)?colors:NULL,
            tw,th,textured?(native_generic?ax.clamp:g_gif.clamp_wms):1u,textured?(native_generic?ay.clamp:g_gif.clamp_wmt):1u,
            textured&&g_gif.tex1_mmag==1u&&g_gif.tex1_mmin==1u,g_gif.scanmsk,sampler,&pipe,zs,&color);
        g_texel_cache_enabled=0;
        if(accepted){if(gouraud){g_gst[GIF_GOURAUD_GX]++;g_gst[GIF_GOURAUD_GX_HYBRID]++;}
            g_gif.triangles_drawn++;return;}
    }
#endif
#ifdef GEKKO2_GX_NATIVE_BIOS_TRI
    uint32_t native_z_min=z0<z1?z0:z1;if(z2<native_z_min)native_z_min=z2;
    int native_z_var=z0!=z1||z1!=z2;
    int native_z_bound=!native_z_var||
      ((!g_gif.zbuf_configured||g_gif.zmsk)&&
       (g_gif.zpsm==0u||(g_gif.zpsm==1u&&z0<=0xffffffu&&z1<=0xffffffu&&z2<=0xffffffu)||
        ((g_gif.zpsm==2u||g_gif.zpsm==10u)&&z0<=0xffffu&&z1<=0xffffu&&z2<=0xffffu)));
    if(textured&&(!interpolate_color||(g_gif.tex_tfx==TEX_TFX_MODULATE&&g_gif.tex_tcc&&(c0>>24)==(c1>>24)&&(c1>>24)==(c2>>24)))&&native_z_bound&&
       !g_gif.ate&&!g_gif.date&&!gs_dither_active()&&!g_gif.fba&&!g_gif.fbmask&&
       !(gs_effective_attr_prim()&PRIM_FGE_MASK)&&!g_gif.tex1_mxl&&
       g_gif.tex1_mmin<=1u&&g_gif.tex1_mmag==g_gif.tex1_mmin&&g_gif.tex_tw>=2u&&g_gif.tex_th>=2u&&g_gif.tex_tw<=7u&&g_gif.tex_th<=7u&&
       g_gif.clamp_configured&&g_gif.clamp_wms<=1u&&g_gif.clamp_wmt<=1u&&
       (gs_effective_attr_prim()&PRIM_FST_MASK || (q0>0.0f&&q1>0.0f&&q2>0.0f&&isfinite(q0)&&isfinite(q1)&&isfinite(q2)))&&
       gekko2_opt_enabled(GEKKO2_OPT_GX_GOURAUD)&&gekko2_opt_enabled(GEKKO2_OPT_GX_RESIDENT)&&gs_gx_render_active()&&
       maxx>=minx&&maxy>=miny&&gs_draw_texture_cache_begin(minx,miny,maxx+1,maxy+1)) {
        int32_t xy[6]={x0,y0,x1,y1,x2,y2};float uv[6],qs[3]={q0,q1,q2};uint32_t colors[3]={c0,c1,c2};
        if(gs_effective_attr_prim()&PRIM_FST_MASK){
          uv[0]=(float)u0/(1u<<g_gif.tex_tw);uv[1]=(float)v0/(1u<<g_gif.tex_th);
          uv[2]=(float)u1/(1u<<g_gif.tex_tw);uv[3]=(float)v1/(1u<<g_gif.tex_th);
          uv[4]=(float)u2/(1u<<g_gif.tex_tw);uv[5]=(float)v2/(1u<<g_gif.tex_th);
        qs[0]=qs[1]=qs[2]=1.0f;
        }else{uv[0]=s0;uv[1]=t0;uv[2]=s1;uv[3]=t1;uv[4]=s2;uv[5]=t2;}
        gs_gx_native_color native_color={c2,g_gif.tex_tcc,g_gif.tex_tfx,g_gif.scissor_configured?g_gif.scissor_y1+1u:0u};gs_gx_pipeline pipe={g_gif.zbp,g_gif.zpsm,g_gif.zbuf_configured&&g_gif.zte,
          g_gif.zbuf_configured&&!g_gif.zmsk,g_gif.ztst,native_z_var?(native_z_min?native_z_min-1u:0u):z2,
          !!(gs_effective_attr_prim()&PRIM_ABE_MASK),g_gif.alpha_a,g_gif.alpha_b,g_gif.alpha_c,g_gif.alpha_d,
          g_gif.alpha_fix,g_gif.pabe,!g_gif.colclamp_configured||g_gif.colclamp,
          g_gif.fbmask,g_gif.fba};
        int accepted=gs_gx_draw_native_stq_triangle(g_gif.frame_psm,g_gif.fbp,g_gif.fbw,
          minx,miny,maxx,maxy,xy,uv,qs,interpolate_color?colors:NULL,1u<<g_gif.tex_tw,1u<<g_gif.tex_th,g_gif.clamp_wms,g_gif.clamp_wmt,
          g_gif.tex1_mmag==1u&&g_gif.tex1_mmin==1u,g_gif.scanmsk,gs_sample_texel_uncached,&pipe,native_z_var,&native_color);
        g_texel_cache_enabled=0;
        if(accepted){if(gouraud_prim){g_gst[GIF_GOURAUD_GX]++;g_gst[GIF_GOURAUD_GX_DEFERRED]++;}
          g_gif.triangles_drawn++;return;}
    }
#endif

    /* R1370: exact shaded screen snapshot -> resident GX blend/target.
     * Constant Z and supported GS state only; no texture updates are dropped. */
    if(textured&&gekko2_opt_enabled(GEKKO2_OPT_GX_GOURAUD)&&
       gekko2_opt_enabled(GEKKO2_OPT_GX_RESIDENT)&&(!g_gif.date && gs_gx_render_active())&&
       (!(gs_effective_attr_prim()&PRIM_ABE_MASK)||g_gif.alpha_c!=0u||
        (!g_gif.tex_tcc&&(c0>>24)==(c1>>24)&&(c1>>24)==(c2>>24)))&&
       z0==z1&&z1==z2&&!g_gif.ate&&!gs_dither_active()&&!g_gif.fba&&!g_gif.fbmask&&
       !(gs_effective_attr_prim()&PRIM_FGE_MASK)&&!g_gif.tex1_mxl&&
       maxx>=minx&&maxy>=miny&&(g_gif.frame_psm==0u||g_gif.frame_psm==1u||g_gif.frame_psm==2u||g_gif.frame_psm==10u)) {
        int32_t xy[6]={x0,y0,x1,y1,x2,y2};double uv[6]={u0,v0,u1,v1,u2,v2};
        float stq[9]={s0,t0,q0,s1,t1,q1,s2,t2,q2};uint32_t colors[3]={c0,c1,c2};
        memcpy(gx_triangle.xy,xy,sizeof xy);memcpy(gx_triangle.uv,uv,sizeof uv);
        memcpy(gx_triangle.stq,stq,sizeof stq);memcpy(gx_triangle.colors,colors,sizeof colors);
        gx_triangle.inv=1.0/(double)area;gx_triangle.maxx=maxx;gx_triangle.maxy=maxy;
        gs_gx_pipeline pipe={g_gif.zbp,g_gif.zpsm,g_gif.zbuf_configured&&g_gif.zte,
            g_gif.zbuf_configured&&!g_gif.zmsk,g_gif.ztst,z2,
            !!(gs_effective_attr_prim()&PRIM_ABE_MASK),g_gif.alpha_a,g_gif.alpha_b,g_gif.alpha_c,g_gif.alpha_d,
            g_gif.alpha_fix,g_gif.pabe,!g_gif.colclamp_configured||g_gif.colclamp,
          g_gif.fbmask,g_gif.fba};
        if(gs_gx_draw_shaded_triangle(g_gif.frame_psm,g_gif.fbp,g_gif.fbw,minx,miny,maxx,maxy,xy,g_gif.scanmsk,gs_gx_triangle_sample,&pipe)){
            if(gouraud){g_gst[GIF_GOURAUD_GX]++;g_gst[GIF_GOURAUD_GX_HYBRID]++;g_gst[GIF_GOURAUD_GX_DEFERRED]++;}
            g_gif.triangles_drawn++;return;
        }
    }
    if(textured&&!g_gif.tex1_mxl&&(gs_effective_attr_prim()&PRIM_FST_MASK)&&g_gif.tex_tfx==TEX_TFX_DECAL&&
       !g_gif.tex_tcc&&g_gif.tex1_mmag==0u&&g_gif.tex1_mmin==0u&&!gouraud&&
       gs_depth_is_inactive()&&!g_gif.ate&&!gs_dither_active()&&!g_gif.fba&&!g_gif.fbmask&&
       !(gs_effective_attr_prim()&(PRIM_FGE_MASK|PRIM_ABE_MASK))&&g_gif.frame_psm==0u&&(!g_gif.date && gs_gx_render_active())) {
        int32_t xy[6]={x0,y0,x1,y1,x2,y2};float uv[6]={(float)u0,(float)v0,(float)u1,(float)v1,(float)u2,(float)v2};
        if(gs_gx_draw_uv_decal_triangle(g_gif.frame_psm,g_gif.fbp,g_gif.fbw,minx,miny,maxx,maxy,xy,uv,
            1u<<g_gif.tex_tw,1u<<g_gif.tex_th,c2>>24,g_gif.scanmsk,gs_gx_raw_texture_sample)) {
            g_gif.triangles_drawn++;return;
        }
    }
    if(g_gx_opaque && !textured && !gouraud && gs_depth_is_inactive() &&
       !(gs_effective_attr_prim()&PRIM_FGE_MASK)) {
        int32_t xy[6]={x0,y0,x1,y1,x2,y2};
        if(gs_gx_draw_flat_psm(g_gif.frame_psm,3,g_gif.fbp,g_gif.fbw,minx,miny,maxx,maxy,xy,c2,g_gif.scanmsk)) {
            g_gif.triangles_drawn++;return;
        }
    }
    if(gouraud&&maxx>=minx&&maxy>=miny) {
        gouraud_reason=gouraud_gx_block_reason(textured,minx,miny,maxx,maxy,c0>>24,c1>>24,c2>>24);
        if(gouraud_reason==GIF_GFB_NONE) {
            int32_t xy[6]={x0,y0,x1,y1,x2,y2};uint32_t colors[3]={c0,c1,c2};
            gs_gx_pipeline pipe={0};
            if(gs_gx_draw_gouraud_triangle(g_gif.frame_psm,g_gif.fbp,g_gif.fbw,
                minx,miny,maxx,maxy,xy,colors,g_gif.scanmsk,&pipe)) {
                g_gst[GIF_GOURAUD_GX]++;g_gst[GIF_GOURAUD_GX_DEFERRED]++;
                g_gst[GIF_GOURAUD_GX_BBOX_PIXELS]+=(uint64_t)(maxx-minx+1)*(uint64_t)(maxy-miny+1);
                g_gif.triangles_drawn++;return;
            }
            gouraud_reason=GIF_GFB_GX_REJECTED;
        }
    }
    if(!textured&&!gouraud&&z0==z1&&z1==z2&&!g_gif.ate&&!gs_dither_active()&&!g_gif.fba&&!g_gif.fbmask&&
       !(gs_effective_attr_prim()&PRIM_FGE_MASK)&&(g_gif.frame_psm==0u||g_gif.frame_psm==1u||g_gif.frame_psm==2u||g_gif.frame_psm==10u)&&(!g_gif.date && gs_gx_render_active())) {
        int32_t xy[6]={x0,y0,x1,y1,x2,y2};
        gs_gx_pipeline pipe={g_gif.zbp,g_gif.zpsm,g_gif.zbuf_configured&&g_gif.zte,
            g_gif.zbuf_configured&&!g_gif.zmsk,g_gif.ztst,z2,
            !!(gs_effective_attr_prim()&PRIM_ABE_MASK),g_gif.alpha_a,g_gif.alpha_b,g_gif.alpha_c,g_gif.alpha_d,
            g_gif.alpha_fix,g_gif.pabe,!g_gif.colclamp_configured||g_gif.colclamp,
          g_gif.fbmask,g_gif.fba};
        if(gs_gx_draw_flat_pipeline(g_gif.frame_psm,3,g_gif.fbp,g_gif.fbw,minx,miny,maxx,maxy,xy,c2,g_gif.scanmsk,&pipe)) {
            g_gif.triangles_drawn++;return;
        }
    }
    if(gouraud&&maxx>=minx&&maxy>=miny) {
        g_gst[GIF_GOURAUD_SOFTWARE]++;g_gfb[gouraud_reason]++;
        g_gst[GIF_GOURAUD_SW_BBOX_PIXELS]+=(uint64_t)(maxx-minx+1)*(uint64_t)(maxy-miny+1);
    }
    double inv_area = 1.0 / (double)area;

    /* Memoization requires disjoint base-level source/targets. Mipped draws
     * are excluded because the envelope does not cover all levels. */
    if(textured && maxx>=minx && maxy>=miny)
        g_triangle_cached_draws+=gs_draw_texture_cache_begin(minx,miny,maxx+1,maxy+1);
    const uint32_t draw_attributes=gs_effective_attr_prim();
    const int texture_fst=!!(draw_attributes&PRIM_FST_MASK);
    const double texture_width=(double)(1u<<g_gif.tex_tw);
    const double texture_height=(double)(1u<<g_gif.tex_th);
    const int fog_enabled=(draw_attributes&PRIM_FGE_MASK)!=0;
    const int need_z=g_gif.zbuf_configured && (!g_gif.zmsk ||
        (g_gif.zte && g_gif.ztst>=GS_ZTST_GEQUAL));
    const int need_weights=interpolate_color||textured||fog_enabled||need_z;
    const int coverage_sign=area>0?1:-1;
    const int inc0=gs_triangle_edge_inclusive(x1,y1,x2,y2,coverage_sign);
    const int inc1=gs_triangle_edge_inclusive(x2,y2,x0,y0,coverage_sign);
    const int inc2=gs_triangle_edge_inclusive(x0,y0,x1,y1,coverage_sign);
    for (int32_t yy = miny; yy <= maxy; yy++) {
        int32_t ew0=edge(x1,y1,x2,y2,minx,yy),ew1=edge(x2,y2,x0,y0,minx,yy),ew2=edge(x0,y0,x1,y1,minx,yy);
        for (int32_t xx = minx; xx <= maxx; xx++) {
            /* Exact integer recurrence; advance before every possible continue. */
            int32_t w0=ew0,w1=ew1,w2=ew2;
            ew0-=y2-y1;ew1-=y0-y2;ew2-=y1-y0;
            /* Inside the triangle if all 3 edge signs match the
             * overall winding (area's sign) - works for either
             * winding direction, since GIF vertex order isn't
             * guaranteed consistent. */
            if (gs_triangle_edge_inside(w0,coverage_sign,inc0)&&gs_triangle_edge_inside(w1,coverage_sign,inc1)&&gs_triangle_edge_inside(w2,coverage_sign,inc2)) {
                /* Barycentric weights (w0 corresponds to the vertex
                 * OPPOSITE it, i.e. weights c0 by w0 etc - standard
                 * edge-function barycentric convention). Used for
                 * BOTH Gouraud color interpolation and (when TME is
                 * set) texture-coordinate interpolation - on real
                 * hardware texture coordinates always interpolate per
                 * pixel when texturing is on, independent of the IIP
                 * (color-shading) bit. Plain affine (screen-space)
                 * interpolation, NOT the real GS's perspective-
                 * corrected (1/Q) one - see gif.h's scope comment. */
                double b0 = need_weights?(double)w0 * inv_area:0.0;
                double b1 = need_weights?(double)w1 * inv_area:0.0;
                double b2 = need_weights?(double)w2 * inv_area:0.0;

                /* Z-buffer / depth test (task #89). Z is genuinely
                 * screen-space-linear on real GS hardware (unlike
                 * S/T - Z has already gone through the perspective
                 * projection by the time it reaches the rasterizer,
                 * so it interpolates the same plain barycentric way
                 * as Gouraud color, no 1/Q correction needed - well-
                 * known real-hardware behavior, not specific to this
                 * project). Gated behind zbuf_configured (this
                 * project's own safety gate - see gif.h) so draws
                 * that never configured a Z buffer behave exactly as
                 * before this round. */
                double zf = need_z?(b0 * (double)z0 + b1 * (double)z1 + b2 * (double)z2):0.0;
                uint32_t frag_z = gs_mem_clamp_raster_z((zf < 0.0) ? 0u : (uint32_t)(zf + 0.5),g_gif.zpsm);
                int z_pass = 1;
                if (g_gif.zbuf_configured && g_gif.zte) {
                    uint32_t stored_z = g_gif.ztst>=GS_ZTST_GEQUAL?gs_mem_read_z(g_gif.zbp, g_gif.fbw, (uint32_t)xx, (uint32_t)yy, g_gif.zpsm):0u;
                    switch (g_gif.ztst) {
                    case GS_ZTST_NEVER:   z_pass = 0; break;
                    case GS_ZTST_ALWAYS:  z_pass = 1; break;
                    case GS_ZTST_GEQUAL:  z_pass = (frag_z >= stored_z); break;
                    case GS_ZTST_GREATER: z_pass = (frag_z >  stored_z); break;
                    default: z_pass = 1; break;
                    }
                }
                if (!z_pass) {
                    g_gif.pixels_ztest_failed++;
                    continue;
                }

                uint32_t shaded_r, shaded_g, shaded_b, shaded_a;
                if (!interpolate_color) {
                    shaded_r = flat_r; shaded_g = flat_g; shaded_b = flat_b; shaded_a = flat_a;
                } else {
                    uint32_t r = (uint32_t)(b0 * rgba_channel(c0, 0)  + b1 * rgba_channel(c1, 0)  + b2 * rgba_channel(c2, 0)  + 0.5);
                    uint32_t g = (uint32_t)(b0 * rgba_channel(c0, 8)  + b1 * rgba_channel(c1, 8)  + b2 * rgba_channel(c2, 8)  + 0.5);
                    uint32_t b = (uint32_t)(b0 * rgba_channel(c0, 16) + b1 * rgba_channel(c1, 16) + b2 * rgba_channel(c2, 16) + 0.5);
                    uint32_t a = (uint32_t)(b0 * rgba_channel(c0, 24) + b1 * rgba_channel(c1, 24) + b2 * rgba_channel(c2, 24) + 0.5);
                    r = gs_colclamp_channel((int32_t)r);
                    g = gs_colclamp_channel((int32_t)g);
                    b = gs_colclamp_channel((int32_t)b);
                    a = gs_colclamp_channel((int32_t)a);
                    shaded_r = r; shaded_g = g; shaded_b = b; shaded_a = a;
                }

                uint32_t out;
                if (!textured) {
                    out = rgba_pack(shaded_r, shaded_g, shaded_b, shaded_a);
                } else {
                    double tu, tv;
                    if (texture_fst) {
                        /* FST=1 (UV mode): plain affine interpolation,
                         * exactly as before task #88 - UV is already
                         * in integer texel units. */
                        tu = b0 * (double)u0 + b1 * (double)u1 + b2 * (double)u2;
                        tv = b0 * (double)v0 + b1 * (double)v1 + b2 * (double)v2;
                    } else {
                        /* GS STQ are homogeneous texture coordinates: interpolate
                         * S, T and Q in screen space, then divide S/T by Q.
                         * Reference: bundled PCSX2 GSDrawScanline.cpp,
                         * DrawScanline: s/t/q setup, SampleTexture and Step.
                         * Interpolating S/Q and 1/Q instead incorrectly cancels
                         * a constant Q and changes varying-Q texture mapping. */
                        double q_interp = b0 * (double)q0 + b1 * (double)q1 + b2 * (double)q2;
                        double inv_q = (q_interp != 0.0) ? 1.0 / q_interp : 0.0;
                        double s_norm = (b0 * (double)s0 + b1 * (double)s1 + b2 * (double)s2) * inv_q;
                        double t_norm = (b0 * (double)t0 + b1 * (double)t1 + b2 * (double)t2) * inv_q;

                        /* Scale normalized ST into texel space using
                         * TEX0's real TW/TH (log2 texture width/
                         * height) fields. */
                        tu = s_norm * texture_width;
                        tv = t_norm * texture_height;
                    }
                    uint32_t texel = gs_sample_texture_q(tu,tv,b0*(double)q0+b1*(double)q1+b2*(double)q2);
                    out = gs_texture_function(texel, rgba_pack(shaded_r, shaded_g, shaded_b, shaded_a));
                }
                /* Round 97 (138th finding, task #254): Fog effect -
                 * F interpolates the exact same plain-affine
                 * barycentric way as Z above (see tri_f's field
                 * comment in gif.h), applied here right before the
                 * final composite, same insertion point Round 96's
                 * SCISSOR clamp used for its own gate. */
                if(fog_enabled) {
                double ff = b0 * (double)f0 + b1 * (double)f1 + b2 * (double)f2;
                uint32_t frag_fog = (ff < 0.0) ? 0u : (ff > 255.0 ? 255u : (uint32_t)(ff + 0.5));
                out = apply_fog(out, frag_fog);
                }
                /* ZMSK (real ZBUF register bit): 1 = Z writes
                 * disabled for this draw, matching real hardware
                 * exactly (color can still be written while Z stays
                 * untouched). Round 23: alpha test + blending now
                 * happen inside gs_finish_draw_pixel() - see its comment
                 * above. */
                gs_finish_draw_pixel(xx, yy, out, frag_z, g_gif.zbuf_configured && !g_gif.zmsk);
            }
        }
    }
    g_texel_cache_enabled=0;
    g_gif.triangles_drawn++;


}
static void rasterize_triangle(int32_t x0, int32_t y0, int32_t x1, int32_t y1, int32_t x2, int32_t y2,
                                uint32_t c0, uint32_t c1, uint32_t c2,
                                double u0, double v0, double u1, double v1, double u2, double v2,
                                float s0, float t0, float q0, float s1, float t1, float q1, float s2, float t2, float q2,
                                uint32_t z0, uint32_t z1, uint32_t z2,
                                uint32_t f0, uint32_t f1, uint32_t f2)
{
 unsigned profile_previous=gp_enter(GP_GS_RASTER);
 rasterize_triangle_profile_impl(x0,y0,x1,y1,x2,y2,c0,c1,c2,u0,v0,u1,v1,u2,v2,s0,t0,q0,s1,t1,q1,s2,t2,q2,z0,z1,z2,f0,f1,f2);
 gp_leave(profile_previous);
}


/* SPRITE rasterizer (task #88 adds texturing here - previously
 * SPRITE was always flat-color only). Real hardware: SPRITE is a
 * filled, axis-aligned rectangle between 2 vertices, always flat-
 * shaded (no Gouraud) - but CAN be textured (PRIM's TME bit) just
 * like triangles.
 *
 * Texture-coordinate interpolation here is a deliberate, simpler
 * approximation than rasterize_triangle()'s full per-pixel
 * perspective correction: since SPRITE is screen-axis-aligned (U
 * varies only with X, V varies only with Y), each corner's texture
 * coordinate is resolved to final texel space FIRST (applying the
 * perspective divide at the corner, for FST=0/ST+Q mode), and then
 * plain linear interpolation is used between the two corners' already-
 * resolved texel coordinates. This is exact when Q is equal at both
 * corners (the overwhelmingly common real case for an axis-aligned
 * 2D sprite) but is a noted simplification - not silently assumed
 * correct - for the rarer case of a genuinely different Q per corner
 * (e.g. a "billboarded" sprite in true 3D perspective), where real
 * hardware would still interpolate more precisely. */
/* R1298: snapshot GS-decoded texture colors once, then use GX nearest
 * sampling of that snapshot. Constant bilinear phase is baked exactly with
 * the existing two-stage 4-bit GS filter, not approximated by GX bilinear. */
static int32_t g_gx_sprite_columns[640],g_gx_sprite_rows[512];
static double g_gx_sprite_v[512];
static unsigned g_gx_sprite_linear,g_gx_sprite_fx,g_gx_sprite_fy,g_gx_sprite_textured;
static uint32_t gs_gx_raw_texture_sample(int32_t x,int32_t y)
{return gs_sample_texture((double)x,(double)y);}
static uint32_t gs_gx_sprite_sample(int32_t x,int32_t y)
{
    if(!g_gx_sprite_textured)return g_gif.rgba;
    double u=x,v=y;
    if(g_gx_sprite_linear){u+=0.5+(double)g_gx_sprite_fx/16.0;v+=0.5+(double)g_gx_sprite_fy/16.0;}
    return gs_texture_function(gs_sample_texture(u,v),g_gif.rgba);
}
static int gs_gx_sprite_axis(int32_t *map,uint32_t n,double first,double step,unsigned linear,unsigned *phase,const double *samples)
{
    unsigned selected=0;
    for(uint32_t k=0;k<n;k++) {
        double value=samples?samples[k]:first+step*k;
        if(!(value>-2047.0&&value<2047.0))return 0;
        if(linear) {
            value-=0.5;int32_t i=(int32_t)value;if(value<(double)i)--i;
            unsigned fraction=(unsigned)((value-i)*16.0);
            if(k&&fraction!=selected)return 0;selected=fraction;map[k]=i;
        }else {int32_t i=(int32_t)value;if(value<(double)i)--i;map[k]=i;}
    }
    *phase=selected;return 1;
}
static void gs_gx_sprite_key(void)
{
 uint64_t data=0;uint32_t valid=1;
 if(g_gx_sprite_textured) {
  uint64_t base=(uint64_t)g_gif.tex_tbp0*256u;
  uint64_t end=gs_page_end(base,g_gif.tex_tbw,1u<<g_gif.tex_tw,1u<<g_gif.tex_th,g_gif.tex_psm);
  valid=end<=GS_MEM_SIZE&&end>=base&&end-base<=262144u;
  if(valid)valid=gs_mem_gpu_sync_alias_range((uint32_t)base,(uint32_t)end);
  if(valid)valid=gs_mem_hash_range((uint32_t)base,(uint32_t)(end-base),&data);
 }
 uint32_t state[]={g_gx_sprite_textured,g_gx_sprite_linear,g_gx_sprite_fx,g_gx_sprite_fy,g_gif.rgba,
  g_gif.tex_tbp0,g_gif.tex_tbw,g_gif.tex_tw,g_gif.tex_th,g_gif.tex_psm,g_gif.tex_cbp,g_gif.tex_cpsm,
  g_gif.tex_csa,g_gif.tex_csm,g_gif.tex_tcc,g_gif.tex_tfx,g_gif.texa_ta0,g_gif.texa_ta1,g_gif.texa_aem,
  g_gif.clamp_configured,g_gif.clamp_wms,g_gif.clamp_wmt,g_gif.clamp_minu,g_gif.clamp_maxu,g_gif.clamp_minv,g_gif.clamp_maxv,g_gif.clut_words_valid?g_gif.clut_write_csm:2u};
 uint32_t a=(uint32_t)data,b=data>>32;
 for(unsigned k=0;k<sizeof(state)/sizeof(state[0]);k++){a=(a^state[k])*16777619u;b=((b<<5)|(b>>27))^state[k];}
 for(unsigned k=0;k<512;k++){a=(a^gs_clut_hash_word(k))*16777619u;b=((b<<5)|(b>>27))^gs_clut_hash_word(k);}
 gs_gx_source_key(a,b,valid);
}
static void rasterize_sprite_12_4_profile_impl(int32_t raw_x0, int32_t raw_y0, int32_t raw_x1, int32_t raw_y1,
                              double u0, double v0, double u1, double v1,
                              float s0, float t0, float q0, float s1, float t1, float q1,
                              uint32_t z0, uint32_t z1, uint32_t f0, uint32_t f1){
    /* GS/reference DrawSprite covers [ceil(min),ceil(max)). Keep the
     * original 12.4 positions for the texture gradient and pre-step. */
    int32_t x0=(raw_x0+15)>>4,y0=(raw_y0+15)>>4;
    int32_t x1=(raw_x1+15)>>4,y1=(raw_y1+15)>>4;
    double pos_x0=(double)raw_x0/16.0,pos_y0=(double)raw_y0/16.0;
    gs_activate_context(); /* Round 27: dual-context - see its own comment */
    int textured = (gs_effective_attr_prim() & PRIM_TME_MASK) != 0;
    /* Z (task #89): real hardware treats SPRITE Z the same way it
     * treats SPRITE color - a single flat value for the whole
     * primitive, taken from the second (completing) vertex,
     * mirroring this file's already-established "flat shading
     * uses the LAST vertex" convention (see rasterize_triangle()'s
     * flat_r/g/b/a). Unlike that color convention, this specific
     * SPRITE-Z-uses-second-vertex detail was not independently
     * re-verified against its own separate citation this round -
     * it is an extension of the same real, already-cited flat-
     * primitive convention, not a fresh guess. z0 is accepted for
     * signature symmetry with the other per-corner parameters but
     * is intentionally unused. */
    (void)z0;
    uint32_t frag_z = gs_mem_clamp_raster_z(z1,g_gif.zpsm);
    /* Round 97 (138th finding, task #254): SPRITE Fog, same "flat,
     * second-vertex" convention this file already established for
     * SPRITE Z just above (real hardware does not interpolate either
     * attribute across a SPRITE the way it does for TRIANGLE - both
     * are simple flat per-primitive values here, f0 kept for
     * signature symmetry only, same as z0). */
    (void)f0;
    uint32_t frag_fog = f1;

    /* Resolve each corner's texture coordinate into texel space
     * BEFORE the min/max reordering below, so the X/Y->U/V
     * correspondence direction is preserved regardless of which
     * corner the caller gave first (real hardware allows either
     * vertex order). */
    double tex_u0 = 0.0, tex_v0 = 0.0, tex_u1 = 0.0, tex_v1 = 0.0;
    if (textured) {
        if (gs_effective_attr_prim() & PRIM_FST_MASK) {
            tex_u0 = (double)u0; tex_v0 = (double)v0;
            tex_u1 = (double)u1; tex_v1 = (double)v1;
        } else {
            double inv_q0 = (q0 != 0.0f) ? 1.0 / (double)q0 : 0.0;
            double inv_q1 = (q1 != 0.0f) ? 1.0 / (double)q1 : 0.0;
            tex_u0 = (double)s0 * inv_q0 * (double)(1u << g_gif.tex_tw);
            tex_v0 = (double)t0 * inv_q0 * (double)(1u << g_gif.tex_th);
            tex_u1 = (double)s1 * inv_q1 * (double)(1u << g_gif.tex_tw);
            tex_v1 = (double)t1 * inv_q1 * (double)(1u << g_gif.tex_th);
        }
    }

    int32_t sx0 = x0, sx1 = x1, sy0 = y0, sy1 = y1;
    if (sx1 < sx0) { int32_t t = sx0; sx0 = sx1; sx1 = t; }
    if (sy1 < sy0) { int32_t t = sy0; sy0 = sy1; sy1 = t; }
    if (sx0 < 0) sx0 = 0;
    if (sy0 < 0) sy0 = 0;
    clamp_bbox_to_scissor(&sx0, &sx1, &sy0, &sy1, 1); /* sprite: exclusive loop */

    /* No texture/mip changes, pixel tests, fog or Z work in this subset.
     * Scissor was already applied; SCANMSK still applies per row. */
    if(g_gx_opaque && !textured && gs_depth_is_inactive() &&
       !(gs_effective_attr_prim()&PRIM_FGE_MASK) && sx1>sx0) {
        int32_t xy[4]={x0,y0,x1,y1};
        if(gs_gx_draw_flat_psm(g_gif.frame_psm,6,g_gif.fbp,g_gif.fbw,sx0,sy0,sx1,sy1,xy,g_gif.rgba,g_gif.scanmsk)) {
            g_gif.sprites_drawn++;return;
        }
    }
    if(g_opaque_pixel && !textured && gs_depth_is_inactive() &&
       !(gs_effective_attr_prim()&PRIM_FGE_MASK) && sx1>sx0) {
        g_sprite_fast_rows++;
        for(int32_t y=sy0;y<sy1;y++)if(scanmsk_allows_y(y))
            gs_mem_fill_psmct32_span(g_gif.fbp,g_gif.fbw,(uint32_t)sx0,
                (uint32_t)y,(uint32_t)(sx1-sx0),g_gif.rgba);
        g_gif.sprites_drawn++;
        return;
    }

    double x_span = (double)(raw_x1 - raw_x0)/16.0;
    double y_span = (double)(raw_y1 - raw_y0)/16.0;
    int cached_u=textured && sx1>sx0 && sx1-sx0<=640;
    if(cached_u)for(int32_t x=sx0;x<sx1;x++) {
        double fraction=x_span!=0.0?((double)x-pos_x0)/x_span:0.0;
        g_sprite_u[x-sx0]=tex_u0+fraction*(tex_u1-tex_u0);
    }
    int safe_texture=textured?gs_draw_texture_cache_begin(sx0,sy0,sx1,sy1):0;
    g_sprite_cached_draws+=safe_texture;
    /* BETA12.20: Sprite snapshot can evaluate ATE/DATE late in the CPU
     * importer. Resident GX depth/blend paths are independently excluded. */
    if((!textured||(safe_texture&&!g_gif.tex1_mxl&&g_gif.tex1_mmin<=1u&&g_gif.tex1_mmag==g_gif.tex1_mmin))&&!gs_dither_active()&&
       ((g_gif.frame_psm==2u||g_gif.frame_psm==10u)||(!g_gif.fba&&!g_gif.fbmask))&&
       (g_gif.frame_psm==0u||g_gif.frame_psm==1u||g_gif.frame_psm==2u||g_gif.frame_psm==10u)&&
       !(gs_effective_attr_prim()&PRIM_FGE_MASK)&&gs_gx_render_active()&&
       sx1>sx0&&sy1>sy0&&sx1-sx0<=640&&sy1-sy0<=512&&
       (!textured||g_gif.tex_psm==0u||g_gif.tex_psm==1u||g_gif.tex_psm==2u||g_gif.tex_psm==10u||
        g_gif.tex_psm==0x13u||g_gif.tex_psm==0x14u||g_gif.tex_psm==0x1bu||g_gif.tex_psm==0x24u||g_gif.tex_psm==0x2cu||gs_is_depth_texture(g_gif.tex_psm))) {
        double du=textured&&x_span!=0.0?(tex_u1-tex_u0)/x_span:0.0;
        double dv=textured&&y_span!=0.0?(tex_v1-tex_v0)/y_span:0.0;
        double first_u=!textured?0.0:cached_u?g_sprite_u[0]:tex_u0;
        double first_v=!textured?0.0:tex_v0+(y_span!=0.0?((double)sy0-pos_y0)/y_span:0.0)*(tex_v1-tex_v0);
        g_gx_sprite_textured=textured;
        g_gx_sprite_linear=textured&&g_gif.tex1_mmag==1u&&g_gif.tex1_mmin==1u;
        if(textured)for(int32_t y=sy0;y<sy1;y++)g_gx_sprite_v[y-sy0]=tex_v0+
            (y_span!=0.0?((double)y-pos_y0)/y_span:0.0)*(tex_v1-tex_v0);
        gs_gx_pipeline pipeline={g_gif.zbp,g_gif.zpsm,g_gif.zbuf_configured&&g_gif.zte,
            g_gif.zbuf_configured&&!g_gif.zmsk,g_gif.ztst,frag_z,
            !!(gs_effective_attr_prim()&PRIM_ABE_MASK),g_gif.alpha_a,g_gif.alpha_b,g_gif.alpha_c,g_gif.alpha_d,
            g_gif.alpha_fix,g_gif.pabe,!g_gif.colclamp_configured||g_gif.colclamp,
          g_gif.fbmask,g_gif.fba,
          g_gif.date,g_gif.datm,g_gif.ate,g_gif.atst,g_gif.aref,g_gif.afail};
        if(gs_gx_sprite_axis(g_gx_sprite_columns,sx1-sx0,first_u,du,g_gx_sprite_linear,&g_gx_sprite_fx,textured?g_sprite_u:NULL)&&
           gs_gx_sprite_axis(g_gx_sprite_rows,sy1-sy0,first_v,dv,g_gx_sprite_linear,&g_gx_sprite_fy,textured?g_gx_sprite_v:NULL)&&
           (gs_gx_sprite_key(),gs_gx_draw_texture_sprite(g_gif.frame_psm,g_gif.fbp,g_gif.fbw,sx0,sy0,sx1-sx0,sy1-sy0,
                g_gx_sprite_columns,g_gx_sprite_rows,du,dv,g_gif.scanmsk,gs_gx_sprite_sample,&pipeline))) {
            g_texel_cache_enabled=0;
            g_gif.sprites_drawn++;return;
        }
    }


    for (int32_t yy = sy0; yy < sy1; yy++) {
        if (yy < 0) continue;
        double frac_y = (y_span != 0.0) ? ((double)yy - pos_y0) / y_span : 0.0;
        for (int32_t xx = sx0; xx < sx1; xx++) {
            if (xx < 0) continue;

            /* Z-buffer / depth test (task #89) - see
             * rasterize_triangle()'s identical logic for the full
             * comment; SPRITE just uses the flat frag_z computed
             * above instead of a per-pixel barycentric one. */
            int z_pass = 1;
            if (g_gif.zbuf_configured && g_gif.zte) {
                uint32_t stored_z = g_gif.ztst>=GS_ZTST_GEQUAL?gs_mem_read_z(g_gif.zbp, g_gif.fbw, (uint32_t)xx, (uint32_t)yy, g_gif.zpsm):0u;
                switch (g_gif.ztst) {
                case GS_ZTST_NEVER:   z_pass = 0; break;
                case GS_ZTST_ALWAYS:  z_pass = 1; break;
                case GS_ZTST_GEQUAL:  z_pass = (frag_z >= stored_z); break;
                case GS_ZTST_GREATER: z_pass = (frag_z >  stored_z); break;
                default: z_pass = 1; break;
                }
            }
            if (!z_pass) {
                g_gif.pixels_ztest_failed++;
                continue;
            }

            uint32_t out;
            if (!textured) {
                out = g_gif.rgba;
            } else {
                double frac_x = (x_span != 0.0) ? ((double)xx - pos_x0) / x_span : 0.0;
                double tu = cached_u?g_sprite_u[xx-sx0]:tex_u0 + frac_x * (tex_u1 - tex_u0);
                double tv = tex_v0 + frac_y * (tex_v1 - tex_v0);
                uint32_t texel = gs_sample_texture_q(tu,tv,q1);
                out = gs_texture_function(texel, g_gif.rgba);
            }
            out = apply_fog(out, frag_fog);
            gs_finish_draw_pixel(xx, yy, out, frag_z, g_gif.zbuf_configured && !g_gif.zmsk);
        }
    }
    g_texel_cache_enabled=0;
    g_gif.sprites_drawn++;


}
static void rasterize_sprite_12_4(int32_t raw_x0, int32_t raw_y0, int32_t raw_x1, int32_t raw_y1,
                              double u0, double v0, double u1, double v1,
                              float s0, float t0, float q0, float s1, float t1, float q1,
                              uint32_t z0, uint32_t z1, uint32_t f0, uint32_t f1)
{
 unsigned profile_previous=gp_enter(GP_GS_RASTER);
 rasterize_sprite_12_4_profile_impl(raw_x0,raw_y0,raw_x1,raw_y1,u0,v0,u1,v1,s0,t0,q0,s1,t1,q1,z0,z1,f0,f1);
 gp_leave(profile_previous);
}


/* Integer-coordinate entry used by native rasterizer tests. */
static void rasterize_sprite(int32_t x0,int32_t y0,int32_t x1,int32_t y1,
    double u0,double v0,double u1,double v1,
    float s0,float t0,float q0,float s1,float t1,float q1,
    uint32_t z0,uint32_t z1,uint32_t f0,uint32_t f1)
{
    rasterize_sprite_12_4(x0*16,y0*16,x1*16,y1*16,u0,v0,u1,v1,
        s0,t0,q0,s1,t1,q1,z0,z1,f0,f1);
}

/* POINT rasterizer (task: "GS coverage breadth"). Real hardware
 * (PCSX2's `GSRasterizer::DrawPoint`): a single pixel, vertex color
 * and optional texture (the point's own vertex selects `last=0` for
 * `GS_POINT_CLASS`, i.e. there's only ever one vertex to begin with,
 * no interpolation of any kind), gated behind the same Z test every
 * other primitive uses. */
static void rasterize_point_profile_impl(int32_t x, int32_t y, uint32_t rgba, uint32_t z, uint32_t fog){
    gs_activate_context(); /* Round 27: dual-context - see its own comment */
    if (x < 0 || y < 0) return;
    if (!scissor_test(x, y)) return;

    z=gs_mem_clamp_raster_z(z,g_gif.zpsm);
    int z_pass = 1;
    if (g_gif.zbuf_configured && g_gif.zte) {
        uint32_t stored_z = gs_mem_read_z(g_gif.zbp, g_gif.fbw, (uint32_t)x, (uint32_t)y, g_gif.zpsm);
        switch (g_gif.ztst) {
        case GS_ZTST_NEVER:   z_pass = 0; break;
        case GS_ZTST_ALWAYS:  z_pass = 1; break;
        case GS_ZTST_GEQUAL:  z_pass = (z >= stored_z); break;
        case GS_ZTST_GREATER: z_pass = (z >  stored_z); break;
        default: z_pass = 1; break;
        }
    }
    if (!z_pass) {
        g_gif.pixels_ztest_failed++;
        return;
    }

    /* Round 97 (138th finding, task #254): POINT Fog - a single
     * vertex, so no interpolation is possible or needed (same "no
     * interpolation of any kind" real-hardware rule this file already
     * documents for POINT's color). */
    if (gs_effective_attr_prim() & PRIM_TME_MASK) {
        double u=g_gif.cur_u,v=g_gif.cur_v;
        if (!(gs_effective_attr_prim() & PRIM_FST_MASK)) {
            double inv_q=g_gif.cur_q!=0.0f?1.0/(double)g_gif.cur_q:0.0;
            u=(double)g_gif.cur_s*inv_q*(double)(1u<<g_gif.tex_tw);
            v=(double)g_gif.cur_t*inv_q*(double)(1u<<g_gif.tex_th);
        }
        rgba=gs_texture_function(gs_sample_texture_q(u,v,g_gif.cur_q),rgba);
    }
    gs_finish_draw_pixel(x, y, apply_fog(rgba, fog), z, g_gif.zbuf_configured && !g_gif.zmsk);
    g_gif.points_drawn++;
}
static void rasterize_point(int32_t x, int32_t y, uint32_t rgba, uint32_t z, uint32_t fog)
{
 unsigned profile_previous=gp_enter(GP_GS_RASTER);
 rasterize_point_profile_impl(x,y,rgba,z,fog);
 gp_leave(profile_previous);
}


/* LINE/LINE_STRIP rasterizer (task: "GS coverage breadth"). Ported
 * from PCSX2's real `GSRasterizer::DrawEdgeLine` DDA algorithm: walk
 * whichever axis has the larger absolute delta (the "major" axis) one
 * pixel at a time, and linearly step every interpolated attribute
 * (color, Z) by its total delta divided by the major-axis step count -
 * true per-pixel-step DDA, not a Bresenham integer-error accumulator
 * (real hardware's line rule is the same "step the dependent
 * coordinate/attributes linearly per major-axis pixel" shape; this
 * project's own simplification is using a plain float step instead of
 * PCSX2's fixed-point 16.16 subpixel accumulator - a well-known,
 * equivalent-result technique for a software rasterizer, not a
 * real-hardware-specific detail the way the flat/Gouraud-vertex-
 * selection and linear-Z rules are). Flat shading uses the LAST
 * vertex's color (c1) - cross-checked against PCSX2's
 * `GSDrawScanline::CSetupPrim`, which selects `last=1` for
 * `GS_LINE_CLASS` (the same "flat uses the last vertex" convention
 * already established for triangles/sprites in this file). */
static void rasterize_line_profile_impl(int32_t x0, int32_t y0, int32_t x1, int32_t y1,
                            uint32_t c0, uint32_t c1, uint32_t z0, uint32_t z1,
                            uint32_t f0, uint32_t f1){
    gs_activate_context(); /* Round 27: dual-context - see its own comment */
    uint32_t attributes=gs_effective_attr_prim();
    int gouraud=(attributes&PRIM_IIP_MASK)!=0;
    int textured=(attributes&PRIM_TME_MASK)!=0;
    uint32_t flat_r = rgba_channel(c1, 0), flat_g = rgba_channel(c1, 8);
    uint32_t flat_b = rgba_channel(c1, 16), flat_a = rgba_channel(c1, 24);

    int32_t dx = x1 - x0, dy = y1 - y0;
    int32_t adx = (dx < 0) ? -dx : dx;
    int32_t ady = (dy < 0) ? -dy : dy;

    if (adx == 0 && ady == 0) {
        /* Degenerate (both vertices coincide) - real hardware still
         * draws the single point (a 0-length line still emits its
         * one pixel); handled the same way DrawPoint would. */
        uint32_t z_avg = z1;
        rasterize_point(x0, y0, gouraud ? c1 : rgba_pack(flat_r, flat_g, flat_b, flat_a), z_avg, f1);
        g_gif.lines_drawn++;
        return;
    }

    int32_t steps = (adx >= ady) ? adx : ady;
    double step_x = (double)dx / (double)steps;
    double step_y = (double)dy / (double)steps;
    double step_z = ((double)z1 - (double)z0) / (double)steps;
    /* Round 97 (138th finding, task #254): Fog steps linearly along
     * the line exactly like Z above (same "already screen-space-
     * linear, no perspective correction needed" real-hardware rule -
     * see gif.h's tri_f field comment). */
    double step_fog = ((double)f1 - (double)f0) / (double)steps;
    double px = (double)x0, py = (double)y0, pz = (double)z0, pf = (double)f0;

    for (int32_t i = 0; i <= steps; i++) {
        int32_t xx = (int32_t)(px + 0.5);
        int32_t yy = (int32_t)(py + 0.5);
        uint32_t frag_z = gs_mem_clamp_raster_z((pz < 0.0) ? 0u : (uint32_t)(pz + 0.5),g_gif.zpsm);

        if (xx >= 0 && yy >= 0 && scissor_test(xx, yy)) {
            int z_pass = 1;
            if (g_gif.zbuf_configured && g_gif.zte) {
                uint32_t stored_z = g_gif.ztst>=GS_ZTST_GEQUAL?gs_mem_read_z(g_gif.zbp, g_gif.fbw, (uint32_t)xx, (uint32_t)yy, g_gif.zpsm):0u;
                switch (g_gif.ztst) {
                case GS_ZTST_NEVER:   z_pass = 0; break;
                case GS_ZTST_ALWAYS:  z_pass = 1; break;
                case GS_ZTST_GEQUAL:  z_pass = (frag_z >= stored_z); break;
                case GS_ZTST_GREATER: z_pass = (frag_z >  stored_z); break;
                default: z_pass = 1; break;
                }
            }
            if (!z_pass) {
                g_gif.pixels_ztest_failed++;
            } else {
                uint32_t out;
                double t=(gouraud||textured)?(double)i/(double)steps:0.0;
                if (!gouraud) {
                    out = rgba_pack(flat_r, flat_g, flat_b, flat_a);
                } else {
                    uint32_t r = (uint32_t)((1.0 - t) * rgba_channel(c0, 0)  + t * rgba_channel(c1, 0)  + 0.5);
                    uint32_t g = (uint32_t)((1.0 - t) * rgba_channel(c0, 8)  + t * rgba_channel(c1, 8)  + 0.5);
                    uint32_t b = (uint32_t)((1.0 - t) * rgba_channel(c0, 16) + t * rgba_channel(c1, 16) + 0.5);
                    uint32_t a = (uint32_t)((1.0 - t) * rgba_channel(c0, 24) + t * rgba_channel(c1, 24) + 0.5);
                    r = gs_colclamp_channel((int32_t)r);
                    g = gs_colclamp_channel((int32_t)g);
                    b = gs_colclamp_channel((int32_t)b);
                    a = gs_colclamp_channel((int32_t)a);
                    out = rgba_pack(r, g, b, a);
                }
                if(textured){
                    double q=(1.0-t)*g_gif.tri_q[0]+t*g_gif.tri_q[1];
                    double u,v;
                    if(attributes&PRIM_FST_MASK){
                        u=(1.0-t)*g_gif.tri_u[0]+t*g_gif.tri_u[1];
                        v=(1.0-t)*g_gif.tri_v[0]+t*g_gif.tri_v[1];
                    }else{
                        double inv=q!=0.0?1.0/q:0.0;
                        u=((1.0-t)*g_gif.tri_s[0]+t*g_gif.tri_s[1])*inv*(1u<<g_gif.tex_tw);
                        v=((1.0-t)*g_gif.tri_t[0]+t*g_gif.tri_t[1])*inv*(1u<<g_gif.tex_th);
                    }
                    out=gs_texture_function(gs_sample_texture_q(u,v,q),out);
                }
                uint32_t frag_fog = (pf < 0.0) ? 0u : (pf > 255.0 ? 255u : (uint32_t)(pf + 0.5));
                out = apply_fog(out, frag_fog);
                gs_finish_draw_pixel(xx, yy, out, frag_z, g_gif.zbuf_configured && !g_gif.zmsk);
            }
        }

        px += step_x; py += step_y; pz += step_z; pf += step_fog;
    }
    g_gif.lines_drawn++;
}
static void rasterize_line(int32_t x0, int32_t y0, int32_t x1, int32_t y1,
                            uint32_t c0, uint32_t c1, uint32_t z0, uint32_t z1,
                            uint32_t f0, uint32_t f1)
{
 unsigned profile_previous=gp_enter(GP_GS_RASTER);
 rasterize_line_profile_impl(x0,y0,x1,y1,c0,c1,z0,z1,f0,f1);
 gp_leave(profile_previous);
}


static void apply_xyz2_kick(uint32_t word0, uint32_t word1, uint32_t word2, int do_draw_kick)
{
    /* PACKED XYZ2 layout (GS/GSRegs.h-compatible bit positions): X in
     * bits 0-15 of word0, Y in bits 0-15 of word1 (both 12.4
     * fixed-point, offset-relative). Z (task #89) is the ENTIRE
     * word2 - a real, full 32-bit value, cross-checked against
     * PCSX2's GS/GSRegs.h GIFPackedXYZ2 layout. The ADC/context bit
     * (word3) still isn't used. IMPORTANT: word2 is only ever a real
     * Z value when apply_xyz2_kick() is reached via the genuine
     * PACKED-mode path - the A+D-mode call site passes 0 here instead
     * (see gif.h's tri_z field comment for why).
     *
     * Round 97 (138th finding, task #254): renamed from apply_xyz2()
     * and given a new do_draw_kick parameter so this same shared
     * vertex-kick logic can serve BOTH the original XYZ2/XYZF2 (kick
     * + draw when the vertex queue fills) and the new XYZ3/XYZF3
     * (kick only - "the Drawing Kick is not performed... only the
     * vertex queue is advanced", per the official GS Users Manual's
     * XYZ3 description). do_draw_kick=0 lets every vseq-increment/
     * rolling-window bookkeeping line below run exactly as before -
     * it only gates the terminal rasterize_*() calls. The vertex's
     * Fog coefficient (also new this round) is read from cur_fog,
     * which callers set immediately before invoking this function
     * when the register being processed carries its own F field
     * (XYZF2/XYZF3 in PACKED mode) - see process_one_packet()'s new
     * GIF_REG_XYZF2/XYZF3 cases - or simply left as whatever a prior
     * standalone FOG-register write (or the 0xFF default) already
     * set, for plain XYZ2/XYZ3/XYZF2-via-A+D. */
    int32_t raw_x = (int32_t)(word0 & 0xFFFFu);
    int32_t raw_y = (int32_t)(word1 & 0xFFFFu);
    uint32_t raw_z = word2;

    /* Select the vertex offset before assembly. Activating a context
     * only in the rasterizer is too late: the first vertex after a
     * CTXT switch would use the previous draw's cached XYOFFSET. */
    int ctx2 = (gs_effective_attr_prim() & PRIM_CTXT_MASK) != 0;
    uint32_t ox = ctx2 ? g_gif.ctx2_xyoffset_x : g_gif.ctx1_xyoffset_x;
    uint32_t oy = ctx2 ? g_gif.ctx2_xyoffset_y : g_gif.ctx1_xyoffset_y;
    int32_t x = (raw_x - (int32_t)ox) >> 4;
    int32_t y = (raw_y - (int32_t)oy) >> 4;

    uint32_t ptype = g_gif.prim & 0x7u;
    if(ptype>=PRIM_TYPE_TRIANGLE&&ptype<=PRIM_TYPE_TRIANGLE_FAN&&vertex_source_used<4u){
     uint32_t *sample=vertex_source[vertex_source_used++];
     sample[0]=s_gif_active_path;sample[1]=vertex_encoding;
#ifdef GEKKO
     sample[2]=ee_core_get_state()->pc;
#endif
     sample[3]=g_gif.prim;sample[4]=word0;sample[5]=word1;sample[6]=word2;
     sample[7]=ox;sample[8]=oy;sample[9]=(uint32_t)do_draw_kick;
    }

    if(ptype==PRIM_TYPE_SPRITE) {
        x=(raw_x-(int32_t)ox+15)>>4;
        y=(raw_y-(int32_t)oy+15)>>4;
    }


    if (ptype == PRIM_TYPE_POINT) {
        /* POINT: draws immediately on every single vertex - no
         * accumulation needed (real hardware: NumIndicesForPrim
         * returns 1 for POINTLIST, each incoming vertex is a
         * complete primitive on its own). XYZ3/XYZF3 (do_draw_kick=0)
         * on a POINT primitive means "advance the queue but don't
         * draw" - since POINT has no queue depth beyond the current
         * vertex, this simply means: don't draw this vertex at all. */
        if (do_draw_kick)
            rasterize_point(x, y, g_gif.rgba, raw_z, g_gif.cur_fog);
        return;
    }

    if (ptype == PRIM_TYPE_LINE || ptype == PRIM_TYPE_LINE_STRIP) {
        g_gif.line_vseq++;

        if (ptype == PRIM_TYPE_LINE) {
            /* Plain LINE: every pair of vertices is an independent
             * segment - no reuse across segments (matches real
             * hardware's NumIndicesForPrim==2 for LINELIST, same "no
             * carry-over" shape as this file's plain TRIANGLE case). */
            int slot = (g_gif.line_vseq - 1) % 2;
            g_gif.line_x[slot] = x;
            g_gif.line_y[slot] = y;
            g_gif.line_rgba[slot] = g_gif.rgba;
            g_gif.line_z[slot] = raw_z;
            g_gif.line_f[slot] = g_gif.cur_fog;
            /* One GS primitive type owns the vertex queue at a time.
             * Reuse the checkpointed texture lanes instead of adding
             * uncheckpointed side state or changing the GIF state ABI. */
            g_gif.tri_u[slot]=g_gif.cur_u;g_gif.tri_v[slot]=g_gif.cur_v;
            g_gif.tri_s[slot]=g_gif.cur_s;g_gif.tri_t[slot]=g_gif.cur_t;g_gif.tri_q[slot]=g_gif.cur_q;
            if (do_draw_kick && g_gif.line_vseq % 2 == 0)
                rasterize_line(g_gif.line_x[0], g_gif.line_y[0], g_gif.line_x[1], g_gif.line_y[1],
                                g_gif.line_rgba[0], g_gif.line_rgba[1],
                                g_gif.line_z[0], g_gif.line_z[1],
                                g_gif.line_f[0], g_gif.line_f[1]);
        } else { /* PRIM_TYPE_LINE_STRIP */
            /* LINE_STRIP: each new vertex (from the 2nd onward) forms
             * a segment with the previous one - a rolling 2-slot
             * window, same shape as this file's TRIANGLE_STRIP
             * handling above, just 2 slots instead of 3. The rolling
             * shift always happens (real hardware: the vertex queue
             * always advances on every vertex kick, draw or not);
             * only the rasterize_line() call itself is gated. */
            g_gif.line_x[0] = g_gif.line_x[1]; g_gif.line_y[0] = g_gif.line_y[1];
            g_gif.line_rgba[0] = g_gif.line_rgba[1]; g_gif.line_z[0] = g_gif.line_z[1];
            g_gif.line_f[0] = g_gif.line_f[1];
            g_gif.tri_u[0]=g_gif.tri_u[1];g_gif.tri_v[0]=g_gif.tri_v[1];
            g_gif.tri_s[0]=g_gif.tri_s[1];g_gif.tri_t[0]=g_gif.tri_t[1];g_gif.tri_q[0]=g_gif.tri_q[1];
            g_gif.line_x[1] = x; g_gif.line_y[1] = y;
            g_gif.line_rgba[1] = g_gif.rgba; g_gif.line_z[1] = raw_z;
            g_gif.line_f[1] = g_gif.cur_fog;
            g_gif.tri_u[1]=g_gif.cur_u;g_gif.tri_v[1]=g_gif.cur_v;
            g_gif.tri_s[1]=g_gif.cur_s;g_gif.tri_t[1]=g_gif.cur_t;g_gif.tri_q[1]=g_gif.cur_q;
            if (do_draw_kick && g_gif.line_vseq >= 2)
                rasterize_line(g_gif.line_x[0], g_gif.line_y[0], g_gif.line_x[1], g_gif.line_y[1],
                                g_gif.line_rgba[0], g_gif.line_rgba[1],
                                g_gif.line_z[0], g_gif.line_z[1],
                                g_gif.line_f[0], g_gif.line_f[1]);
        }
        return;
    }

    if (ptype == PRIM_TYPE_TRIANGLE || ptype == PRIM_TYPE_TRIANGLE_STRIP || ptype == PRIM_TYPE_TRIANGLE_FAN) {
        g_gif.tri_vseq++;

        if (ptype == PRIM_TYPE_TRIANGLE) {
            /* Plain TRIANGLE: every group of 3 vertices is
             * independent - no reuse across triangles. */
            int slot = (g_gif.tri_vseq - 1) % 3;
            g_gif.tri_x[slot] = x;
            g_gif.tri_y[slot] = y;
            g_gif.tri_rgba[slot] = g_gif.rgba;
            g_gif.tri_u[slot] = g_gif.cur_u;
            g_gif.tri_v[slot] = g_gif.cur_v;
            g_gif.tri_s[slot] = g_gif.cur_s;
            g_gif.tri_t[slot] = g_gif.cur_t;
            g_gif.tri_q[slot] = g_gif.cur_q;
            g_gif.tri_z[slot] = raw_z;
            g_gif.tri_f[slot] = g_gif.cur_fog;
            if (do_draw_kick && g_gif.tri_vseq % 3 == 0 && triangle_assembly_visible())
                rasterize_triangle(g_gif.tri_x[0], g_gif.tri_y[0], g_gif.tri_x[1], g_gif.tri_y[1], g_gif.tri_x[2], g_gif.tri_y[2],
                                    g_gif.tri_rgba[0], g_gif.tri_rgba[1], g_gif.tri_rgba[2],
                                    g_gif.tri_u[0], g_gif.tri_v[0], g_gif.tri_u[1], g_gif.tri_v[1], g_gif.tri_u[2], g_gif.tri_v[2],
                                    g_gif.tri_s[0], g_gif.tri_t[0], g_gif.tri_q[0],
                                    g_gif.tri_s[1], g_gif.tri_t[1], g_gif.tri_q[1],
                                    g_gif.tri_s[2], g_gif.tri_t[2], g_gif.tri_q[2],
                                    g_gif.tri_z[0], g_gif.tri_z[1], g_gif.tri_z[2],
                                    g_gif.tri_f[0], g_gif.tri_f[1], g_gif.tri_f[2]);
        } else if (ptype == PRIM_TYPE_TRIANGLE_STRIP) {
            /* TRIANGLE_STRIP: each new vertex (from the 3rd onward)
             * forms a triangle with the previous 2 - a rolling
             * 3-slot window. The rolling shift always happens; only
             * the rasterize_triangle() call itself is gated by
             * do_draw_kick (same "queue advances regardless" rule as
             * LINE_STRIP above). */
            g_gif.tri_x[0] = g_gif.tri_x[1]; g_gif.tri_y[0] = g_gif.tri_y[1]; g_gif.tri_rgba[0] = g_gif.tri_rgba[1];
            g_gif.tri_u[0] = g_gif.tri_u[1]; g_gif.tri_v[0] = g_gif.tri_v[1];
            g_gif.tri_s[0] = g_gif.tri_s[1]; g_gif.tri_t[0] = g_gif.tri_t[1]; g_gif.tri_q[0] = g_gif.tri_q[1];
            g_gif.tri_z[0] = g_gif.tri_z[1];
            g_gif.tri_f[0] = g_gif.tri_f[1];
            g_gif.tri_x[1] = g_gif.tri_x[2]; g_gif.tri_y[1] = g_gif.tri_y[2]; g_gif.tri_rgba[1] = g_gif.tri_rgba[2];
            g_gif.tri_u[1] = g_gif.tri_u[2]; g_gif.tri_v[1] = g_gif.tri_v[2];
            g_gif.tri_s[1] = g_gif.tri_s[2]; g_gif.tri_t[1] = g_gif.tri_t[2]; g_gif.tri_q[1] = g_gif.tri_q[2];
            g_gif.tri_z[1] = g_gif.tri_z[2];
            g_gif.tri_f[1] = g_gif.tri_f[2];
            g_gif.tri_x[2] = x; g_gif.tri_y[2] = y; g_gif.tri_rgba[2] = g_gif.rgba;
            g_gif.tri_u[2] = g_gif.cur_u; g_gif.tri_v[2] = g_gif.cur_v;
            g_gif.tri_s[2] = g_gif.cur_s; g_gif.tri_t[2] = g_gif.cur_t; g_gif.tri_q[2] = g_gif.cur_q;
            g_gif.tri_z[2] = raw_z;
            g_gif.tri_f[2] = g_gif.cur_fog;
            if (do_draw_kick && g_gif.tri_vseq >= 3 && triangle_assembly_visible())
                rasterize_triangle(g_gif.tri_x[0], g_gif.tri_y[0], g_gif.tri_x[1], g_gif.tri_y[1], g_gif.tri_x[2], g_gif.tri_y[2],
                                    g_gif.tri_rgba[0], g_gif.tri_rgba[1], g_gif.tri_rgba[2],
                                    g_gif.tri_u[0], g_gif.tri_v[0], g_gif.tri_u[1], g_gif.tri_v[1], g_gif.tri_u[2], g_gif.tri_v[2],
                                    g_gif.tri_s[0], g_gif.tri_t[0], g_gif.tri_q[0],
                                    g_gif.tri_s[1], g_gif.tri_t[1], g_gif.tri_q[1],
                                    g_gif.tri_s[2], g_gif.tri_t[2], g_gif.tri_q[2],
                                    g_gif.tri_z[0], g_gif.tri_z[1], g_gif.tri_z[2],
                                    g_gif.tri_f[0], g_gif.tri_f[1], g_gif.tri_f[2]);
        } else { /* PRIM_TYPE_TRIANGLE_FAN */
            /* TRIANGLE_FAN: the first vertex is a fixed anchor
             * (slot 0, never overwritten); each new vertex forms a
             * triangle with the anchor and the previous vertex. */
            if (g_gif.tri_vseq == 1) {
                g_gif.tri_x[0] = x; g_gif.tri_y[0] = y; g_gif.tri_rgba[0] = g_gif.rgba;
                g_gif.tri_u[0] = g_gif.cur_u; g_gif.tri_v[0] = g_gif.cur_v;
                g_gif.tri_s[0] = g_gif.cur_s; g_gif.tri_t[0] = g_gif.cur_t; g_gif.tri_q[0] = g_gif.cur_q;
                g_gif.tri_z[0] = raw_z;
                g_gif.tri_f[0] = g_gif.cur_fog;
                g_gif.tri_x[1] = x; g_gif.tri_y[1] = y; g_gif.tri_rgba[1] = g_gif.rgba; /* also seed "previous" so vseq==2 has something to pair with */
                g_gif.tri_u[1] = g_gif.cur_u; g_gif.tri_v[1] = g_gif.cur_v;
                g_gif.tri_s[1] = g_gif.cur_s; g_gif.tri_t[1] = g_gif.cur_t; g_gif.tri_q[1] = g_gif.cur_q;
                g_gif.tri_z[1] = raw_z;
                g_gif.tri_f[1] = g_gif.cur_fog;
            } else {
                g_gif.tri_x[2] = x; g_gif.tri_y[2] = y; g_gif.tri_rgba[2] = g_gif.rgba;
                g_gif.tri_u[2] = g_gif.cur_u; g_gif.tri_v[2] = g_gif.cur_v;
                g_gif.tri_s[2] = g_gif.cur_s; g_gif.tri_t[2] = g_gif.cur_t; g_gif.tri_q[2] = g_gif.cur_q;
                g_gif.tri_z[2] = raw_z;
                g_gif.tri_f[2] = g_gif.cur_fog;
                if (do_draw_kick && g_gif.tri_vseq >= 3 && triangle_assembly_visible())
                    rasterize_triangle(g_gif.tri_x[0], g_gif.tri_y[0], g_gif.tri_x[1], g_gif.tri_y[1], g_gif.tri_x[2], g_gif.tri_y[2],
                                        g_gif.tri_rgba[0], g_gif.tri_rgba[1], g_gif.tri_rgba[2],
                                        g_gif.tri_u[0], g_gif.tri_v[0], g_gif.tri_u[1], g_gif.tri_v[1], g_gif.tri_u[2], g_gif.tri_v[2],
                                        g_gif.tri_s[0], g_gif.tri_t[0], g_gif.tri_q[0],
                                        g_gif.tri_s[1], g_gif.tri_t[1], g_gif.tri_q[1],
                                        g_gif.tri_s[2], g_gif.tri_t[2], g_gif.tri_q[2],
                                        g_gif.tri_z[0], g_gif.tri_z[1], g_gif.tri_z[2],
                                        g_gif.tri_f[0], g_gif.tri_f[1], g_gif.tri_f[2]);
                g_gif.tri_x[1] = g_gif.tri_x[2]; g_gif.tri_y[1] = g_gif.tri_y[2]; g_gif.tri_rgba[1] = g_gif.tri_rgba[2];
                g_gif.tri_u[1] = g_gif.tri_u[2]; g_gif.tri_v[1] = g_gif.tri_v[2];
                g_gif.tri_s[1] = g_gif.tri_s[2]; g_gif.tri_t[1] = g_gif.tri_t[2]; g_gif.tri_q[1] = g_gif.tri_q[2];
                g_gif.tri_z[1] = g_gif.tri_z[2];
                g_gif.tri_f[1] = g_gif.tri_f[2];
            }
        }
        return;
    }

    if (!g_gif.has_vertex0) {
        g_gif.sprite_pos16=(uint64_t)(uint32_t)(raw_x-(int32_t)ox)
            |((uint64_t)(uint32_t)(raw_y-(int32_t)oy)<<32);
        g_gif.v0x = x;
        g_gif.v0y = y;
        g_gif.v0u = g_gif.cur_u;
        g_gif.v0v = g_gif.cur_v;
        g_gif.v0s = g_gif.cur_s;
        g_gif.v0t = g_gif.cur_t;
        g_gif.v0q = g_gif.cur_q;
        g_gif.v0z = raw_z;
        g_gif.v0f = g_gif.cur_fog;
        g_gif.has_vertex0 = 1;
        return;
    }

    /* Second vertex: if we're drawing a SPRITE, fill the rectangle
     * between v0 and this vertex now (unless do_draw_kick=0 - the
     * GS Users Manual's XYZ3/XYZF3 "no Drawing Kick" example is a
     * TRIANGLE_STRIP, but the same rule applies here for
     * consistency: the vertex queue is still consumed/advanced,
     * just without triggering the actual fill). */
    if (ptype == PRIM_TYPE_SPRITE) {
        if (do_draw_kick)
            rasterize_sprite_12_4((int32_t)(uint32_t)g_gif.sprite_pos16,
                              (int32_t)(uint32_t)(g_gif.sprite_pos16>>32),
                              raw_x-(int32_t)ox,raw_y-(int32_t)oy,
                              g_gif.v0u, g_gif.v0v, g_gif.cur_u, g_gif.cur_v,
                              g_gif.v0s, g_gif.v0t, g_gif.v0q, g_gif.cur_s, g_gif.cur_t, g_gif.cur_q,
                              g_gif.v0z, raw_z, g_gif.v0f, g_gif.cur_fog);
    } else {
        g_gif.unsupported_prims_seen++;
    }

    /* SPRITE only ever accumulates 2 vertices at a time before
     * restarting - it has no strip/fan continuation on real hardware
     * either (POINT/LINE, now implemented above this function's
     * TRIANGLE dispatch, follow the same restart-every-N pattern as
     * SPRITE, just with N=1/2). */
    g_gif.has_vertex0 = 0;
}

static void apply_rgbaq(uint32_t r, uint32_t g, uint32_t b, uint32_t a)
{
    g_gif.rgba = (r & 255u) | ((g & 255u) << 8) |
                 ((b & 255u) << 16) | ((a & 255u) << 24);
    /* PACKED RGBA copies the GIF Q latch; A+D RGBAQ sets GS Q directly. */
    g_gif.cur_q=u32_to_float((uint32_t)g_gif.gif_q_bits);
}

static void image_write_bytes(const uint8_t *q, uint32_t byte_count);

static void gs_mtba(unsigned context,unsigned bp,unsigned tw,unsigned psm)
{
 unsigned enabled=context?g_gif.ctx2_tex1_mtba:g_gif.ctx1_tex1_mtba;
 unsigned bpp=psm==2u||psm==10u?16u:psm==0x13u?8u:psm==0x14u?4u:32u;
 int color=psm==0u||psm==1u||psm==2u||psm==10u||psm==0x13u||psm==0x14u||psm==0x1bu||psm==0x24u||psm==0x2cu;
 if(!enabled||!color||tw<5u||tw>(bpp==32u?9u:10u))return;
 unsigned width=1u<<tw,bw=width>>6;if(!bw)bw=1;
 unsigned blocks=width*width*bpp/2048u;
 uint32_t *bases=context?g_gif.ctx2_tex_mip_tbp:g_gif.ctx1_tex_mip_tbp;
 uint32_t *strides=context?g_gif.ctx2_tex_mip_tbw:g_gif.ctx1_tex_mip_tbw;
 for(unsigned i=0;i<3;i++){
  bp=(bp+blocks)&0x3fffu;bw=bw>1u?bw/2u:1u;
  blocks=blocks>3u?blocks/4u:1u;bases[i]=bp;strides[i]=bw*64u;
  if(!context){g_gif.tex_mip_tbp[i]=bases[i];g_gif.tex_mip_tbw[i]=strides[i];}
 }
}

static void apply_ad_write(uint32_t addr, uint32_t data_lo, uint32_t data_hi)
{
    vertex_encoding=1;
    switch (addr) {
    case GS_REG_PRIM:
        g_gif.prim = data_lo;
        reset_tri_vseq();
        break;
    case GS_REG_RGBAQ: {
        /* A+D packs RGBAQ's R/G/B/A/Q into one 64-bit data value
         * rather than 4 separate qwords like PACKED mode does: R in
         * bits 0-7, G in 8-15, B in 16-23, A in 24-31 of the low word;
         * Q is the ENTIRE high word, as a real IEEE-754 float - cross-
         * checked against PCSX2's own GS/GSRegs.h GIFRegRGBAQ layout
         * (task #88 - previously data_hi/Q was read but discarded). */
        uint8_t r = (uint8_t)(data_lo & 0xFFu);
        uint8_t g = (uint8_t)((data_lo >> 8) & 0xFFu);
        uint8_t b = (uint8_t)((data_lo >> 16) & 0xFFu);
        uint8_t a = (uint8_t)((data_lo >> 24) & 0xFFu);
        g_gif.rgba = ((uint32_t)a << 24) | ((uint32_t)b << 16) | ((uint32_t)g << 8) | r;
        g_gif.cur_q = u32_to_float(data_hi);
    } break;
    case GS_REG_XYZ2:
    case GS_REG_XYZ3:
        /* Natural 64-bit GS register: X/Y in low16/high16 of lo,
         * Z in hi. PACKED uses different, expanded lanes. */
        apply_xyz2_kick(data_lo & 0xffffu, data_lo >> 16, data_hi,
                        addr == GS_REG_XYZ2);
        break;
    case GS_REG_XYZF2:
    case GS_REG_XYZF3:
        g_gif.cur_fog = data_hi >> 24;
        apply_xyz2_kick(data_lo & 0xffffu, data_lo >> 16,
                        data_hi & 0xffffffu, addr == GS_REG_XYZF2);
        break;
    case GS_REG_FOG:
        /* Round 97 (138th finding, task #254): standalone FOG
         * register - generic A+D 64-bit layout (data_lo=low32,
         * data_hi=high32, matching every OTHER A+D register in this
         * function except XYZ2/XYZF2's own established simplified
         * exception above), F occupying bits 63:56 per the official
         * GS Users Manual's BIT ASSIGN table - i.e. the top byte of
         * data_hi. */
        g_gif.cur_fog = (data_hi >> 24) & 0xFFu;
        break;
    case GS_REG_FOGCOL:
        /* Round 97 (138th finding, task #254): FOGCOL - FCR:bits0-7,
         * FCG:bits8-15, FCB:bits16-23 of data_lo (real GS Users Manual
         * BIT ASSIGN table), packed here via rgba_pack()'s existing
         * channel convention (alpha byte unused/0, matching FOGCOL
         * having no real alpha field). */
        g_gif.fogcol = rgba_pack(data_lo & 0xFFu, (data_lo >> 8) & 0xFFu, (data_lo >> 16) & 0xFFu, 0u);
        break;
    case GS_REG_PRMODECONT:
        /* Round 99 (140th finding, task #254): PRMODECONT.AC (bit 0
         * only, per the manual's BIT ASSIGN table) - see the
         * GS_REG_PRMODECONT/GS_REG_PRMODE comment in gif.h and
         * gs_effective_attr_prim() above for the full citation and
         * how this actually takes effect. */
        g_gif.prmodecont_ac = data_lo & 0x1u;
        break;
    case GS_REG_PRMODE:
        /* Round 99: PRMODE mirrors PRIM's bits 3-10 only (IIP/TME/
         * FGE/ABE/AA1/FST/CTXT/FIX) - bits 0-2 (TYPE) have no
         * counterpart in PRMODE per the manual's own field list, so
         * masked off here defensively (gs_effective_attr_prim()
         * always sources TYPE from PRIM regardless, but keeping
         * g_gif.prmode itself clean avoids any confusion if it's
         * ever read directly elsewhere in the future). Only takes
         * effect while PRMODECONT.AC=0, per the manual. */
        g_gif.prmode = data_lo & PRIM_ATTR_MASK;
        break;
    case GS_REG_FRAME_1: {
        /* FBP: bits 0-8, FBW: bits 16-21 (units of 64px - real hardware
         * convention), PSM: bits 24-29 (ignored, PSMCT32 assumed).
         *
         * Round 748 fix: FBP is a real "Address/2048 words" page index
         * on actual hardware (8192 bytes/unit - see gs_mem.h's Round
         * 640 comment), the SAME unit gs_decode_dispfb() already
         * scales by (*2048) for DISPFB1/DISPFB2. Previously FBP was
         * stored raw/unscaled here and fed directly into gs_mem_read/
         * write_psmct32()'s "word offset" bp parameter - Round 640
         * explicitly considered this exact question for FRAME/ZBUF and
         * concluded "no aliasing was observed for that register pair",
         * but that was wrong: GT3's real disc-boot fbp=70/zbp=140
         * landed only 280/560 bytes apart under the old raw-field
         * convention (should be 573,440/1,146,880 bytes apart),
         * causing the color framebuffer and Z-buffer to alias almost
         * completely - see docs/STATUS.md Round 747/748 for the full
         * evidence trail (pixel-identical draw-target/Z-buffer PPM
         * dumps). Scaling here (matching gs_decode_dispfb's existing,
         * already-correct, already-tested convention) makes FRAME's
         * bp consistent with DISPFB's bp for the first time - every
         * downstream consumer (gs_finish_pixel, rasterize_triangle's
         * Z-test, gs_activate_context's ctx1/ctx2 copy) already treats
         * g_gif.fbp/zbp as an opaque pre-scaled word offset and needs
         * no further change. Round 27: also mirrors into ctx1_fbp/
         * ctx1_fbw (context 1's permanent storage - see gif.h's
         * dual-context field comment). */
        uint32_t fbp = (data_lo & 0x1FFu) * 2048u;
        uint32_t fbw_field = (data_lo >> 16) & 0x3Fu;
        uint32_t fbw = fbw_field * 64u;
        if (fbw == 0) fbw = 640; /* guard against a zero FBW making every pixel alias */
        g_gif.fbp = fbp;
        g_gif.fbw = fbw;
        g_gif.ctx1_fbp = fbp;
        g_gif.ctx1_fbw = fbw;
        g_gif.fbmask = g_gif.ctx1_fbmask = data_hi;
        g_gif.frame_psm = g_gif.ctx1_frame_psm = (data_lo >> 24) & 0x3fu;
    } break;
    case GS_REG_FRAME_2: {
        /* Context 2's FRAME - identical bitfield to FRAME_1 above,
         * written ONLY into ctx2_fbp/ctx2_fbw (context 2 only becomes
         * "live" in the flat/active fields once a primitive is
         * actually drawn with PRIM.CTXT=1 - see gs_activate_context()).
         * Round 748: same *2048 page-scale fix as FRAME_1 above. */
        uint32_t fbp = (data_lo & 0x1FFu) * 2048u;
        uint32_t fbw_field = (data_lo >> 16) & 0x3Fu;
        uint32_t fbw = fbw_field * 64u;
        if (fbw == 0) fbw = 640;
        g_gif.ctx2_fbp = fbp;
        g_gif.ctx2_fbw = fbw;
        g_gif.ctx2_fbmask = data_hi;
        g_gif.ctx2_frame_psm = (data_lo >> 24) & 0x3fu;
    } break;
    case GS_REG_XYOFFSET_1:
        g_gif.xyoffset_x = data_lo & 0xFFFFu;
        g_gif.xyoffset_y = data_hi & 0xFFFFu;
        g_gif.ctx1_xyoffset_x = g_gif.xyoffset_x;
        g_gif.ctx1_xyoffset_y = g_gif.xyoffset_y;
        break;
    case GS_REG_XYOFFSET_2:
        g_gif.ctx2_xyoffset_x = data_lo & 0xFFFFu;
        g_gif.ctx2_xyoffset_y = data_hi & 0xFFFFu;
        break;
    case GS_REG_UV:
        /* UV has fourteen meaningful bits: 10 integer, 4 fractional.
         * Keep the phase through vertex assembly and both render paths. */
        g_gif.cur_u = (double)(data_lo & 0x3fffu) / 16.0;
        g_gif.cur_v = (double)((data_lo >> 16) & 0x3fffu) / 16.0;
        break;
    case GS_REG_ST:
        /* Real hardware (FST=0 mode, task #88): S/T are real IEEE-754
         * floats, one per word - cross-checked against PCSX2's own
         * GS/GSRegs.h GIFRegST layout (`float S; float T;`, no Q -
         * unlike PACKED mode's STQ tag, A+D mode's Q instead arrives
         * together with RGBAQ, see above). */
        g_gif.cur_s = u32_to_float(data_lo);
        g_gif.cur_t = u32_to_float(data_hi);
        break;
    case GS_REG_TEX0_1:
    case GS_REG_TEX0_2: {
        /* TEX0 bitfield cross-checked against PCSX2's own
         * GS/GSRegs.h GIFRegTEX0: word0 = TBP0(14):TBW(6):PSM(6):
         * TW(4):pad(2); word1 = pad(2):TCC(1):TFX(2):CBP(14):CPSM(4):
         * CSM(1):CSA(5):CLD(3). TBP0/TBW are used directly as OUR
         * gs_mem bp/bw convention, exactly like FRAME_1's FBP/FBW
         * above - not a claim of matching real hardware block-
         * swizzled addressing (see gs_mem.h). Round 27: TEX0_1 and
         * TEX0_2 share this parsing logic (identical bitfield),
         * writing into ctx1_xxx (+ the flat fields, for immediate
         * visibility) or ctx2_xxx respectively - see gif.h's dual-
         * context field comment. */
        uint32_t tbp0 = data_lo & 0x3FFFu;
        uint32_t tbw_field = (data_lo >> 14) & 0x3Fu;
        uint32_t tfx = (data_hi >> 3) & 0x3u;
        uint32_t tbw = tbw_field * 64u;
        if (tbw == 0) tbw = 640; /* guard against a zero TBW making every texel alias, same as FRAME_1's FBW guard */
        /* TW (bits 26-29 of word0) / TH (task #88: a 4-bit field that
         * straddles the 64-bit register - 2 bits from word0's top,
         * bits 30-31, plus 2 bits from word1's bottom, bits 0-1) -
         * cross-checked against PCSX2's own GS/GSRegs.h GIFRegTEX0's
         * union of two overlapping bitfield layouts. */
        uint32_t tw = (data_lo >> 26) & 0xFu;
        uint32_t th = ((data_lo >> 30) & 0x3u) | ((data_hi & 0x3u) << 2);
        /* Round 24: PSM (word0 bits 20-25) + CLUT fields (word1 bits
         * 5-31: CBP:14, CPSM:4, CSM:1 (ignored - CSM2's separate
         * load-list mode is a documented, unsupported gap; only CSM1
         * is modeled), CSA:5, CLD:3). See TEX_PSM_xxx and
         * CLUT_ROW_WIDTH's header comments for the full scope and
         * citation-honesty note. */
        uint32_t psm = (data_lo >> 20) & 0x3Fu;
        uint32_t cbp = (data_hi >> 5) & 0x3FFFu;
        uint32_t cpsm = (data_hi >> 19) & 0xFu;
        uint32_t csa = (data_hi >> 24) & 0x1Fu;
        uint32_t cld = (data_hi >> 29) & 0x7u;
        uint32_t csm = (data_hi >> 23) & 1u;
        gs_load_clut(psm,cbp,cpsm,csm,csa,cld);
        gs_mtba(addr==GS_REG_TEX0_2,tbp0,tw,psm);

        if (addr == GS_REG_TEX0_1) {
            g_gif.tex_tbp0 = tbp0; g_gif.tex_tbw = tbw; g_gif.tex_tfx = tfx;
            g_gif.tex_tw = tw; g_gif.tex_th = th; g_gif.tex_tcc = (data_hi >> 2) & 1u;
            g_gif.tex_psm = psm; g_gif.tex_cbp = cbp; g_gif.tex_cpsm = cpsm;
            g_gif.tex_csa = csa; g_gif.tex_cld = cld; g_gif.tex_csm = csm;
            g_gif.ctx1_tex_tbp0 = tbp0; g_gif.ctx1_tex_tbw = tbw; g_gif.ctx1_tex_tfx = tfx;
            g_gif.ctx1_tex_tw = tw; g_gif.ctx1_tex_th = th; g_gif.ctx1_tex_tcc = (data_hi >> 2) & 1u;
            g_gif.ctx1_tex_psm = psm; g_gif.ctx1_tex_cbp = cbp; g_gif.ctx1_tex_cpsm = cpsm;
            g_gif.ctx1_tex_csa = csa; g_gif.ctx1_tex_cld = cld; g_gif.ctx1_tex_csm = csm;
        } else {
            g_gif.ctx2_tex_tbp0 = tbp0; g_gif.ctx2_tex_tbw = tbw; g_gif.ctx2_tex_tfx = tfx;
            g_gif.ctx2_tex_tw = tw; g_gif.ctx2_tex_th = th; g_gif.ctx2_tex_tcc = (data_hi >> 2) & 1u;
            g_gif.ctx2_tex_psm = psm; g_gif.ctx2_tex_cbp = cbp; g_gif.ctx2_tex_cpsm = cpsm;
            g_gif.ctx2_tex_csa = csa; g_gif.ctx2_tex_cld = cld; g_gif.ctx2_tex_csm = csm;
        }
    } break;
    case GS_REG_COLCLAMP:
        /* Round 101 (142nd finding, task #254): COLCLAMP.CLAMP (bit 0
         * only, per the manual's BIT ASSIGN table) - see gs_colclamp_channel()
         * above for the full citation and how this actually takes effect. */
        g_gif.colclamp = data_lo & 0x1u;
        g_gif.colclamp_configured = 1;
        break;
    case GS_REG_TEXFLUSH:
        /* Round 102 (143rd finding, task #254): TEXFLUSH - genuine
         * no-op, see gif.h's GS_REG_TEXFLUSH comment for the full
         * citation/reasoning. Accepted (not falling through to any
         * "unknown register" path) but intentionally does nothing. */
        break;
    case GS_REG_DTHE:
        /* Round 102: DTHE.DTHE (bit 0 only, per the manual's BIT
         * ASSIGN table) - see gs_finish_draw_pixel()'s dithering block
         * above for the full citation and how this takes effect. */
        g_gif.dthe = data_lo & 0x1u;
        break;
    case GS_REG_DIMX: {
        /* Round 102: DIMX - 16 signed 3-bit (int1:2:0, range -4..3)
         * entries, DM00-DM13 in data_lo (bits 0-31, 4-bit-aligned
         * nibbles with only the low 3 bits meaningful per the
         * manual's own BIT ASSIGN diagram), DM20-DM33 in data_hi
         * (bits 32-63 of the full 64-bit register, i.e. bits 0-31 of
         * data_hi here). Sign-extended at parse time so gs_finish_draw_pixel()
         * can just add the stored value directly. */
        for (int row = 0; row < 4; row++) {
            for (int col = 0; col < 4; col++) {
                int idx = row * 4 + col; /* 0..15, matching DM(row)(col) naming */
                uint32_t word = (idx < 8) ? data_lo : data_hi;
                int shift = (idx % 8) * 4;
                int32_t raw = (int32_t)((word >> shift) & 0x7u);
                if (raw & 0x4) raw -= 8; /* sign-extend the 3-bit field */
                g_gif.dimx[row][col] = raw;
            }
        }
    } break;
    case GS_REG_FBA_1: {
        /* Round 103 (144th finding, task #254): FBA_1 - see gif.h's
         * GS_REG_FBA_1/GS_REG_FBA_2 comment for the full citation.
         * Single 1-bit FBA field (bit 0), per-context (this is
         * context 1's copy plus the flat "currently active" copy,
         * mirroring the exact CLAMP_1/CLAMP_2 pattern above). */
        uint32_t fba = data_lo & 0x1u;
        g_gif.fba = fba;
        g_gif.fba_configured = 1;
        g_gif.ctx1_fba = fba;
        g_gif.ctx1_fba_configured = 1;
    } break;
    case GS_REG_FBA_2: {
        uint32_t fba = data_lo & 0x1u;
        g_gif.ctx2_fba = fba;
        g_gif.ctx2_fba_configured = 1;
    } break;
    case GS_REG_PABE:
        /* Round 104 (145th finding, task #254): PABE.PABE (bit 0
         * only, per the manual's BIT ASSIGN table) - see
         * gs_finish_draw_pixel()'s ABE-gating check for the full citation
         * and how this takes effect. Not per-context. */
        g_gif.pabe = data_lo & 0x1u;
        break;
    case GS_REG_TEXCLUT: {
        /* Round 105 (146th finding, task #254): TEXCLUT - real bit
         * layout per the manual: CBW bits[5:0], COU bits[11:6], COV
         * bits[21:12] (all within data_lo, since the whole register
         * fits in the low 32 bits). Parsed and stored for
         * completeness, but - per the manual's own words, "disabled
         * when CSM=0 (CSM1 mode)" - deliberately never consumed by
         * gs_sample_clut()'s CSM1-only addressing math. See gif.h's
         * GS_REG_TEXCLUT comment for the full citation. */
        g_gif.texclut_cbw = data_lo & 0x3Fu;
        g_gif.texclut_cou = (data_lo >> 6) & 0x3Fu;
        g_gif.texclut_cov = (data_lo >> 12) & 0x3FFu;
    } break;
    case GS_REG_SCANMSK:
        /* Round 106 (147th finding, task #254): SCANMSK.MSK (bits
         * 1:0, per the manual's BIT ASSIGN table) - see
         * scanmsk_allows_y()'s comment for the full citation and how
         * this takes effect. Not per-context. */
        g_gif.scanmsk = data_lo & 0x3u;
        break;
    case GS_REG_TEXA: {
        /* Round 107 (148th finding, task #254): TEXA - real bit
         * layout per the manual: TA0 bits[7:0] (data_lo), AEM bit 15
         * (data_lo), TA1 bits[39:32] (data_hi bits[7:0], since bit 32
         * of the full 64-bit register is bit 0 of data_hi). Parsed
         * and stored for completeness, but - since this codebase's
         * texture sampler only supports PSMCT32/PSMT8/PSMT4, none of
         * which lack a real alpha channel - deliberately never
         * consumed by gs_sample_texel(). See gif.h's GS_REG_TEXA
         * comment for the full citation. */
        g_gif.texa_ta0 = data_lo & 0xFFu;
        g_gif.texa_aem = (data_lo >> 15) & 0x1u;
        g_gif.texa_ta1 = data_hi & 0xFFu;
    } break;
    case GS_REG_SIGNAL: {
        /* Round 108 (149th finding, task #254 - FINAL): SIGNAL -
         * real masked-update formula per the manual: SIGLBLID.SIGID
         * = (old_SIGID & ~IDMSK) | (ID & IDMSK). ID is data_lo,
         * IDMSK is data_hi (both full 32-bit fields). See gif.h's
         * GS_REG_SIGNAL/FINISH/LABEL comment for the full citation
         * and honest scope (SIGLBLID storage only, no EE/IOP
         * interrupt-controller wiring). */
        game_trace_record(GT_SIGNAL,s_gif_active_path,data_lo,data_hi,(uint32_t)gs_get_state()->csr);
        uint32_t id = data_lo, idmsk = data_hi;
        g_gif.siglblid_sigid = (g_gif.siglblid_sigid & ~idmsk) | (id & idmsk);
        gs_get_state()->siglblid=((uint64_t)g_gif.siglblid_lblid<<32)|g_gif.siglblid_sigid;
        if (gs_raise_event(0u)) ee_intc_raise(0); /* INTC_GS */
    } break;
    case GS_REG_FINISH:
        /* Round 108 (149th finding, task #254 - FINAL): FINISH -
         * "Any data can be written" per the manual, a genuine no-op
         * for this codebase (same reasoning as GS_REG_TEXFLUSH - no
         * drawing-completion event/interrupt infrastructure exists
         * here to request against). finish_pending is incremented
         * purely for test-observability that the write was accepted
         * as a real, distinct register (not falling through to an
         * unknown-register path). */
        g_gif.finish_pending++;
        if (gs_raise_event(1u)) ee_intc_raise(0); /* INTC_GS */
        break;
    case GS_REG_LABEL: {
        /* Round 108 (149th finding, task #254 - FINAL): LABEL -
         * identical masked-update formula to SIGNAL, but targets
         * SIGLBLID.LBLID instead of SIGID. */
        game_trace_record(GT_SIGNAL,s_gif_active_path,data_lo,data_hi,(uint32_t)gs_get_state()->csr);
        uint32_t id = data_lo, idmsk = data_hi;
        g_gif.siglblid_lblid = (g_gif.siglblid_lblid & ~idmsk) | (id & idmsk);
        gs_get_state()->siglblid=((uint64_t)g_gif.siglblid_lblid<<32)|g_gif.siglblid_sigid;
    } break;
    case GS_REG_TEX2_1:
    case GS_REG_TEX2_2: {
        /* Round 100 (141st finding, task #254): TEX2 - "subset of
         * TEX0" (see gif.h's GS_REG_TEX2_1/2 comment). Reuses TEX0's
         * exact PSM/CBP/CPSM/CSA/CLD bit positions (data_lo bits
         * 20-25 / data_hi bits 5-31) but deliberately does NOT touch
         * tex_tbp0/tex_tbw/tex_tfx/tex_tw/tex_th - those keep
         * whatever the most recent TEX0 write set them to, per the
         * manual's real hardware behavior. */
        uint32_t psm = (data_lo >> 20) & 0x3Fu;
        uint32_t cbp = (data_hi >> 5) & 0x3FFFu;
        uint32_t cpsm = (data_hi >> 19) & 0xFu;
        uint32_t csa = (data_hi >> 24) & 0x1Fu;
        uint32_t cld = (data_hi >> 29) & 0x7u;
        uint32_t csm = (data_hi >> 23) & 1u;
        gs_load_clut(psm,cbp,cpsm,csm,csa,cld);

        if (addr == GS_REG_TEX2_1) {
            g_gif.tex_psm = psm; g_gif.tex_cbp = cbp; g_gif.tex_cpsm = cpsm;
            g_gif.tex_csa = csa; g_gif.tex_cld = cld; g_gif.tex_csm = csm;
            g_gif.ctx1_tex_psm = psm; g_gif.ctx1_tex_cbp = cbp; g_gif.ctx1_tex_cpsm = cpsm;
            g_gif.ctx1_tex_csa = csa; g_gif.ctx1_tex_cld = cld; g_gif.ctx1_tex_csm = csm;
        } else {
            g_gif.ctx2_tex_psm = psm; g_gif.ctx2_tex_cbp = cbp; g_gif.ctx2_tex_cpsm = cpsm;
            g_gif.ctx2_tex_csa = csa; g_gif.ctx2_tex_cld = cld; g_gif.ctx2_tex_csm = csm;
        }
    } break;
    case GS_REG_ZBUF_1: {
        /* ZBP uses 8192-byte pages; format selects native Z32/24/16/16S
         * addressing. Depth width comes from the context FRAME.FBW. */
        g_gif.zbp = (data_lo & 0x1FFu) * 2048u;
        g_gif.zpsm = g_gif.ctx1_zpsm = (data_lo >> 24) & 0xfu;
        g_gif.zmsk = (int)(data_hi & 0x1u);
        g_gif.zbuf_configured = 1;
        g_gif.ctx1_zbp = g_gif.zbp;
        g_gif.ctx1_zmsk = g_gif.zmsk;
        g_gif.ctx1_zbuf_configured = 1;
    } break;
    case GS_REG_ZBUF_2: {
        /* Context 2's ZBUF - identical bitfield to ZBUF_1 above,
         * written ONLY into the ctx2_zxxx permanent fields. Round 748:
         * same *2048 page-scale fix. */
        g_gif.ctx2_zbp = (data_lo & 0x1FFu) * 2048u;
        g_gif.ctx2_zpsm = (data_lo >> 24) & 0xfu;
        g_gif.ctx2_zmsk = (int)(data_hi & 0x1u);
        g_gif.ctx2_zbuf_configured = 1;
    } break;
    case GS_REG_TEST_1: {
        /* GIFRegTEST bitfield cross-checked against PCSX2's own
         * GS/GSRegs.h (see TEST_ZTE_MASK, TEST_ZTST_xxx, TEST_ATE_MASK,
         * etc in gif.h). Round 23 adds real ATE/ATST/AREF/AFAIL
         * (alpha test) - see gs_finish_draw_pixel() below. R1378 models DATE/DATM
         * destination-alpha rejection before color and Z writes. Round 27: also mirrors into ctx1_zte/
         * ctx1_ztst/ctx1_ate/ctx1_atst/ctx1_aref/ctx1_afail. */
        g_gif.zte = (data_lo & TEST_ZTE_MASK) ? 1 : 0;
        g_gif.ztst = (int)((data_lo >> TEST_ZTST_SHIFT) & TEST_ZTST_MASK);
        g_gif.ate = (data_lo & TEST_ATE_MASK) ? 1 : 0;
        g_gif.atst = (int)((data_lo >> TEST_ATST_SHIFT) & TEST_ATST_MASK);
        g_gif.aref = (data_lo >> TEST_AREF_SHIFT) & TEST_AREF_MASK;
        g_gif.afail = (int)((data_lo >> TEST_AFAIL_SHIFT) & TEST_AFAIL_MASK);
        g_gif.date=g_gif.ctx1_date=(data_lo>>14)&1u;
        g_gif.datm=g_gif.ctx1_datm=(data_lo>>15)&1u;
        g_gif.ctx1_zte = g_gif.zte;
        g_gif.ctx1_ztst = g_gif.ztst;
        g_gif.ctx1_ate = g_gif.ate;
        g_gif.ctx1_atst = g_gif.atst;
        g_gif.ctx1_aref = g_gif.aref;
        g_gif.ctx1_afail = g_gif.afail;
    } break;
    case GS_REG_TEST_2: {
        /* Context 2's TEST - identical bitfield to TEST_1 above,
         * written ONLY into the ctx2_xxx permanent fields. */
        g_gif.ctx2_date=(data_lo>>14)&1u;
        g_gif.ctx2_datm=(data_lo>>15)&1u;
        g_gif.ctx2_zte = (data_lo & TEST_ZTE_MASK) ? 1 : 0;
        g_gif.ctx2_ztst = (int)((data_lo >> TEST_ZTST_SHIFT) & TEST_ZTST_MASK);
        g_gif.ctx2_ate = (data_lo & TEST_ATE_MASK) ? 1 : 0;
        g_gif.ctx2_atst = (int)((data_lo >> TEST_ATST_SHIFT) & TEST_ATST_MASK);
        g_gif.ctx2_aref = (data_lo >> TEST_AREF_SHIFT) & TEST_AREF_MASK;
        g_gif.ctx2_afail = (int)((data_lo >> TEST_AFAIL_SHIFT) & TEST_AFAIL_MASK);
    } break;
    case GS_REG_ALPHA_1: {
        /* GIFRegALPHA bitfield (Round 23) - see ALPHA_*_SHIFT/
         * GS_ALPHA_* in gif.h. A/B/C/D live in word0 (data_lo)'s low
         * byte. FIX is bits 32-39 of the 64-bit register - i.e. the
         * LOW byte of word1 (data_hi), since data_lo/data_hi split
         * the 64-bit A+D value at the 32-bit word boundary the same
         * way every other A+D register in this file already does
         * (confirmed against this same function's GS_REG_ZBUF_1 case
         * just above: ZBP comes from data_lo, ZMSK - a word1 field -
         * comes from data_hi). Round 27: also mirrors into
         * ctx1_alpha_a/b/c/d/fix. */
        g_gif.alpha_a = (data_lo >> ALPHA_A_SHIFT) & ALPHA_ABCD_MASK;
        g_gif.alpha_b = (data_lo >> ALPHA_B_SHIFT) & ALPHA_ABCD_MASK;
        g_gif.alpha_c = (data_lo >> ALPHA_C_SHIFT) & ALPHA_ABCD_MASK;
        g_gif.alpha_d = (data_lo >> ALPHA_D_SHIFT) & ALPHA_ABCD_MASK;
        g_gif.alpha_fix = data_hi & ALPHA_FIX_MASK;
        g_gif.ctx1_alpha_a = g_gif.alpha_a;
        g_gif.ctx1_alpha_b = g_gif.alpha_b;
        g_gif.ctx1_alpha_c = g_gif.alpha_c;
        g_gif.ctx1_alpha_d = g_gif.alpha_d;
        g_gif.ctx1_alpha_fix = g_gif.alpha_fix;
    } break;
    case GS_REG_ALPHA_2: {
        /* Context 2's ALPHA - identical bitfield to ALPHA_1 above,
         * written ONLY into the ctx2_alpha_xxx permanent fields. */
        g_gif.ctx2_alpha_a = (data_lo >> ALPHA_A_SHIFT) & ALPHA_ABCD_MASK;
        g_gif.ctx2_alpha_b = (data_lo >> ALPHA_B_SHIFT) & ALPHA_ABCD_MASK;
        g_gif.ctx2_alpha_c = (data_lo >> ALPHA_C_SHIFT) & ALPHA_ABCD_MASK;
        g_gif.ctx2_alpha_d = (data_lo >> ALPHA_D_SHIFT) & ALPHA_ABCD_MASK;
        g_gif.ctx2_alpha_fix = data_hi & ALPHA_FIX_MASK;
    } break;

    case GS_REG_SCISSOR_1: {
        /* Round 96: real SCISSOR bit layout per the official GS
         * Users Manual: word0 bits[10:0]=SCAX0, bits[26:16]=SCAX1;
         * word1(data_hi) bits[10:0]=SCAY0, bits[26:16]=SCAY1 -
         * upper-left/lower-right corners of the enabled drawing area,
         * inclusive, in the same window coordinate system this
         * project's rasterizers already use for x/y. */
        uint32_t x0 = data_lo & 0x7FFu;
        uint32_t x1 = (data_lo >> 16) & 0x7FFu;
        uint32_t y0 = data_hi & 0x7FFu;
        uint32_t y1 = (data_hi >> 16) & 0x7FFu;
        g_gif.scissor_x0 = x0; g_gif.scissor_x1 = x1;
        g_gif.scissor_y0 = y0; g_gif.scissor_y1 = y1;
        g_gif.scissor_configured = 1;
        g_gif.ctx1_scissor_x0 = x0; g_gif.ctx1_scissor_x1 = x1;
        g_gif.ctx1_scissor_y0 = y0; g_gif.ctx1_scissor_y1 = y1;
        g_gif.ctx1_scissor_configured = 1;
    } break;
    case GS_REG_SCISSOR_2: {
        uint32_t x0 = data_lo & 0x7FFu;
        uint32_t x1 = (data_lo >> 16) & 0x7FFu;
        uint32_t y0 = data_hi & 0x7FFu;
        uint32_t y1 = (data_hi >> 16) & 0x7FFu;
        g_gif.ctx2_scissor_x0 = x0; g_gif.ctx2_scissor_x1 = x1;
        g_gif.ctx2_scissor_y0 = y0; g_gif.ctx2_scissor_y1 = y1;
        g_gif.ctx2_scissor_configured = 1;
    } break;
    case GS_REG_CLAMP_1: {
        /* Round 98 (139th finding, task #254): real CLAMP bit layout
         * per the official GS Users Manual: word0(data_lo) bits[1:0]=
         * WMS, bits[3:2]=WMT, bits[13:4]=MINU, bits[23:14]=MAXU;
         * MINV/MAXV (10-bit fields each) straddle the 64-bit
         * register's word boundary - MINV is bits[33:24] (low 8 bits
         * in data_lo's top byte, top 2 bits in data_hi's bottom 2
         * bits), MAXV is bits[43:34] (entirely within data_hi,
         * bits[11:2]) - same generic 64-bit A+D word0/word1 mapping
         * this file already uses for FOG/FOGCOL (Round 97). */
        uint32_t wms = data_lo & 0x3u;
        uint32_t wmt = (data_lo >> 2) & 0x3u;
        uint32_t minu = (data_lo >> 4) & 0x3FFu;
        uint32_t maxu = (data_lo >> 14) & 0x3FFu;
        uint32_t minv = ((data_lo >> 24) & 0xFFu) | ((data_hi & 0x3u) << 8);
        uint32_t maxv = (data_hi >> 2) & 0x3FFu;
        g_gif.clamp_wms = wms; g_gif.clamp_wmt = wmt;
        g_gif.clamp_minu = minu; g_gif.clamp_maxu = maxu;
        g_gif.clamp_minv = minv; g_gif.clamp_maxv = maxv;
        g_gif.clamp_configured = 1;
        g_gif.ctx1_clamp_wms = wms; g_gif.ctx1_clamp_wmt = wmt;
        g_gif.ctx1_clamp_minu = minu; g_gif.ctx1_clamp_maxu = maxu;
        g_gif.ctx1_clamp_minv = minv; g_gif.ctx1_clamp_maxv = maxv;
        g_gif.ctx1_clamp_configured = 1;
    } break;
    case GS_REG_CLAMP_2: {
        uint32_t wms = data_lo & 0x3u;
        uint32_t wmt = (data_lo >> 2) & 0x3u;
        uint32_t minu = (data_lo >> 4) & 0x3FFu;
        uint32_t maxu = (data_lo >> 14) & 0x3FFu;
        uint32_t minv = ((data_lo >> 24) & 0xFFu) | ((data_hi & 0x3u) << 8);
        uint32_t maxv = (data_hi >> 2) & 0x3FFu;
        g_gif.ctx2_clamp_wms = wms; g_gif.ctx2_clamp_wmt = wmt;
        g_gif.ctx2_clamp_minu = minu; g_gif.ctx2_clamp_maxu = maxu;
        g_gif.ctx2_clamp_minv = minv; g_gif.ctx2_clamp_maxv = maxv;
        g_gif.ctx2_clamp_configured = 1;
    } break;
    case GS_REG_TEX1_1: {
        /* Native GIFRegTEX1 layout: LCM 0, MXL 2..4, MMAG 5,
         * MMIN 6..8, MTBA 9, L 19..20, signed K 32..43. */
        g_gif.tex1_lcm = (data_lo & 0x1u) ? 1 : 0;
        g_gif.tex1_mxl = (data_lo >> 2) & 0x7u;
        g_gif.tex1_mmag = (data_lo & 0x20u) ? 1 : 0;
        g_gif.tex1_mmin = (data_lo >> 6) & 0x7u;
        g_gif.tex1_mtba = (data_lo & 0x200u) ? 1 : 0;
        g_gif.tex1_l = (data_lo >> 19) & 0x3u;
        {
            /* K is signed 12 bits (bits 0-11 of word1) - sign-extend
             * from bit 11 (the field's own top bit). */
            int32_t k_raw = (int32_t)(data_hi & 0xFFFu);
            if (k_raw & 0x800) k_raw -= 0x1000; /* sign-extend a 12-bit value */
            g_gif.tex1_k = k_raw;
        }
        g_gif.ctx1_tex1_lcm = g_gif.tex1_lcm;
        g_gif.ctx1_tex1_mxl = g_gif.tex1_mxl;
        g_gif.ctx1_tex1_mmag = g_gif.tex1_mmag;
        g_gif.ctx1_tex1_mmin = g_gif.tex1_mmin;
        g_gif.ctx1_tex1_mtba = g_gif.tex1_mtba;
        g_gif.ctx1_tex1_l = g_gif.tex1_l;
        g_gif.ctx1_tex1_k = g_gif.tex1_k;
    } break;
    case GS_REG_TEX1_2: {
        /* Context 2's TEX1 - identical bitfield to TEX1_1 above,
         * written ONLY into the ctx2_tex1_xxx permanent fields
         * (Round 29 continued, 15th change). */
        g_gif.ctx2_tex1_lcm = (data_lo & 0x1u) ? 1 : 0;
        g_gif.ctx2_tex1_mxl = (data_lo >> 2) & 0x7u;
        g_gif.ctx2_tex1_mmag = (data_lo & 0x20u) ? 1 : 0;
        g_gif.ctx2_tex1_mmin = (data_lo >> 6) & 0x7u;
        g_gif.ctx2_tex1_mtba = (data_lo & 0x200u) ? 1 : 0;
        g_gif.ctx2_tex1_l = (data_lo >> 19) & 0x3u;
        {
            int32_t k_raw = (int32_t)(data_hi & 0xFFFu);
            if (k_raw & 0x800) k_raw -= 0x1000;
            g_gif.ctx2_tex1_k = k_raw;
        }
    } break;
    case GS_REG_MIPTBP1_1: {
        /* GIFRegMIPTBP1 (Round 28) - modeled as a plain sequential
         * 64-bit bitfield (TBP1:14, TBW1:6, TBP2:14, TBW2:6, TBP3:14,
         * TBW3:6, spare:4 = 64 bits total, no word-alignment padding
         * between fields) - moderate confidence, same citation-
         * honesty note as TEX1_1 above. TBP2/TBP3 straddle the
         * word0/word1 boundary, decoded with the same cross-word
         * technique this project already uses for TEX0's TW/TH
         * field (see that case's own comment, several rounds ago).
         * Round 29 continued (15th change): also mirrors into
         * ctx1_tex_mip_tbp/tbw[0..2]. */
        g_gif.tex_mip_tbp[0] = data_lo & 0x3FFFu;             /* TBP1: bits 0-13 */
        g_gif.tex_mip_tbw[0] = ((data_lo >> 14) & 0x3Fu) * 64u; /* TBW1: bits 14-19 */
        if (g_gif.tex_mip_tbw[0] == 0) g_gif.tex_mip_tbw[0] = 640;
        g_gif.tex_mip_tbp[1] = ((data_lo >> 20) & 0xFFFu) | ((data_hi & 0x3u) << 12); /* TBP2: bits 20-33 */
        g_gif.tex_mip_tbw[1] = (((data_hi >> 2) & 0x3Fu)) * 64u; /* TBW2: bits 34-39 */
        if (g_gif.tex_mip_tbw[1] == 0) g_gif.tex_mip_tbw[1] = 640;
        g_gif.tex_mip_tbp[2] = (data_hi >> 8) & 0x3FFFu;      /* TBP3: bits 40-53 */
        g_gif.tex_mip_tbw[2] = ((data_hi >> 22) & 0x3Fu) * 64u; /* TBW3: bits 54-59 */
        if (g_gif.tex_mip_tbw[2] == 0) g_gif.tex_mip_tbw[2] = 640;
        g_gif.ctx1_tex_mip_tbp[0] = g_gif.tex_mip_tbp[0]; g_gif.ctx1_tex_mip_tbw[0] = g_gif.tex_mip_tbw[0];
        g_gif.ctx1_tex_mip_tbp[1] = g_gif.tex_mip_tbp[1]; g_gif.ctx1_tex_mip_tbw[1] = g_gif.tex_mip_tbw[1];
        g_gif.ctx1_tex_mip_tbp[2] = g_gif.tex_mip_tbp[2]; g_gif.ctx1_tex_mip_tbw[2] = g_gif.tex_mip_tbw[2];
    } break;
    case GS_REG_MIPTBP1_2: {
        /* Context 2's MIPTBP1 - identical layout to MIPTBP1_1 above,
         * written ONLY into ctx2_tex_mip_tbp/tbw[0..2] (Round 29
         * continued, 15th change). */
        g_gif.ctx2_tex_mip_tbp[0] = data_lo & 0x3FFFu;
        g_gif.ctx2_tex_mip_tbw[0] = ((data_lo >> 14) & 0x3Fu) * 64u;
        if (g_gif.ctx2_tex_mip_tbw[0] == 0) g_gif.ctx2_tex_mip_tbw[0] = 640;
        g_gif.ctx2_tex_mip_tbp[1] = ((data_lo >> 20) & 0xFFFu) | ((data_hi & 0x3u) << 12);
        g_gif.ctx2_tex_mip_tbw[1] = (((data_hi >> 2) & 0x3Fu)) * 64u;
        if (g_gif.ctx2_tex_mip_tbw[1] == 0) g_gif.ctx2_tex_mip_tbw[1] = 640;
        g_gif.ctx2_tex_mip_tbp[2] = (data_hi >> 8) & 0x3FFFu;
        g_gif.ctx2_tex_mip_tbw[2] = ((data_hi >> 22) & 0x3Fu) * 64u;
        if (g_gif.ctx2_tex_mip_tbw[2] == 0) g_gif.ctx2_tex_mip_tbw[2] = 640;
    } break;
    case GS_REG_MIPTBP2_1: {
        /* GIFRegMIPTBP2 - identical layout to MIPTBP1 above, for
         * levels 4/5/6 instead of 1/2/3. Round 29 continued (15th
         * change): also mirrors into ctx1_tex_mip_tbp/tbw[3..5]. */
        g_gif.tex_mip_tbp[3] = data_lo & 0x3FFFu;
        g_gif.tex_mip_tbw[3] = ((data_lo >> 14) & 0x3Fu) * 64u;
        if (g_gif.tex_mip_tbw[3] == 0) g_gif.tex_mip_tbw[3] = 640;
        g_gif.tex_mip_tbp[4] = ((data_lo >> 20) & 0xFFFu) | ((data_hi & 0x3u) << 12);
        g_gif.tex_mip_tbw[4] = (((data_hi >> 2) & 0x3Fu)) * 64u;
        if (g_gif.tex_mip_tbw[4] == 0) g_gif.tex_mip_tbw[4] = 640;
        g_gif.tex_mip_tbp[5] = (data_hi >> 8) & 0x3FFFu;
        g_gif.tex_mip_tbw[5] = ((data_hi >> 22) & 0x3Fu) * 64u;
        if (g_gif.tex_mip_tbw[5] == 0) g_gif.tex_mip_tbw[5] = 640;
        g_gif.ctx1_tex_mip_tbp[3] = g_gif.tex_mip_tbp[3]; g_gif.ctx1_tex_mip_tbw[3] = g_gif.tex_mip_tbw[3];
        g_gif.ctx1_tex_mip_tbp[4] = g_gif.tex_mip_tbp[4]; g_gif.ctx1_tex_mip_tbw[4] = g_gif.tex_mip_tbw[4];
        g_gif.ctx1_tex_mip_tbp[5] = g_gif.tex_mip_tbp[5]; g_gif.ctx1_tex_mip_tbw[5] = g_gif.tex_mip_tbw[5];
    } break;
    case GS_REG_MIPTBP2_2: {
        /* Context 2's MIPTBP2 - identical layout to MIPTBP2_1 above,
         * written ONLY into ctx2_tex_mip_tbp/tbw[3..5] (Round 29
         * continued, 15th change). */
        g_gif.ctx2_tex_mip_tbp[3] = data_lo & 0x3FFFu;
        g_gif.ctx2_tex_mip_tbw[3] = ((data_lo >> 14) & 0x3Fu) * 64u;
        if (g_gif.ctx2_tex_mip_tbw[3] == 0) g_gif.ctx2_tex_mip_tbw[3] = 640;
        g_gif.ctx2_tex_mip_tbp[4] = ((data_lo >> 20) & 0xFFFu) | ((data_hi & 0x3u) << 12);
        g_gif.ctx2_tex_mip_tbw[4] = (((data_hi >> 2) & 0x3Fu)) * 64u;
        if (g_gif.ctx2_tex_mip_tbw[4] == 0) g_gif.ctx2_tex_mip_tbw[4] = 640;
        g_gif.ctx2_tex_mip_tbp[5] = (data_hi >> 8) & 0x3FFFu;
        g_gif.ctx2_tex_mip_tbw[5] = ((data_hi >> 22) & 0x3Fu) * 64u;
        if (g_gif.ctx2_tex_mip_tbw[5] == 0) g_gif.ctx2_tex_mip_tbw[5] = 640;
    } break;
    case GS_REG_BITBLTBUF: {
        /* GS BITBLTBUF: source in low 32 bits, destination in high.
         * Both fields are needed for XDIR=2 local-to-local transfers. */
        g_gif.trx_sbp = data_lo & 0x3fffu;
        g_gif.trx_sbw = ((data_lo >> 16) & 0x3fu) * 64u;
        g_gif.trx_spsm = (data_lo >> 24) & 0x3fu;
        g_gif.trx_dbp = data_hi & 0x3FFFu;
        uint32_t dbw_field = (data_hi >> 16) & 0x3Fu;
        g_gif.trx_dbw = dbw_field * 64u;
        if (g_gif.trx_dbw == 0) g_gif.trx_dbw = 640;
        g_gif.trx_dpsm = (data_hi >> 24) & 0x3Fu;
    } break;
    case GS_REG_TRXPOS: {
        /* GS TRXPOS: 11-bit SSAX/SSAY and DSAX/DSAY;
         * DIRX/DIRY are high-word bits 27/28. */
        g_gif.trx_ssax = data_lo & 0x7ffu;
        g_gif.trx_ssay = (data_lo >> 16) & 0x7ffu;
        g_gif.trx_dirx = (data_hi >> 27) & 1u;
        g_gif.trx_diry = (data_hi >> 28) & 1u;
        g_gif.trx_dsax = data_hi & 0x7FFu;
        g_gif.trx_dsay = (data_hi >> 16) & 0x7FFu;
    } break;
    case GS_REG_TRXREG:
        /* GIFRegTRXREG (Round 636 fix, task #536/#614): real GS
         * register layout (confirmed against pcsx2 reference source's
         * GSRegs.h REG64_ macro, which packs every GS A+D register as
         * two 32-bit words - word0 = bits[0:31], word1 = bits[32:63]
         * of the 64-bit register) is:
         *   word0 (data_lo): RRW:12(0-11), pad:20
         *   word1 (data_hi): RRH:12(0-11), pad:20
         * The PREVIOUS code read RRH from data_lo's bits[16:27] -
         * that's word0's padding region, which real hardware always
         * leaves 0. This made trx_rrh always 0, so every IMAGE-mode
         * host-to-local transfer's rectangle height collapsed to 0:
         * gif.c's image_write_pixel_qwords()/trx_cur_y wrap logic
         * checks "trx_cur_y >= trx_rrh" after each row, and with
         * rrh=0 that's true after the very FIRST row (rrw pixels),
         * silently ending the transfer there - regardless of how
         * many rows of real texture data NLOOP actually described.
         * This is the root cause of Round 635's "solid bar instead
         * of glyphs" finding: every multi-row glyph/label texture
         * upload was being truncated to exactly 1 pixel row before
         * ever reaching row 2, so distinct glyph shapes never had a
         * chance to form - confirmed via direct instrumentation
         * showing trx_rrh=0 on every real TRXREG write captured
         * during a 100M-slice diskless boot survey. Fix: read RRH
         * from data_hi's bits[0:11], matching real hardware and the
         * TRXPOS handler's own already-correct high/low word split
         * just above. */
        g_gif.trx_rrw = data_lo & 0xFFFu;
        g_gif.trx_rrh = data_hi & 0xFFFu;
        break;
    case GS_REG_HWREG: {
        /* PCSX2 GSState::GIFRegHandlerHWREG feeds eight transfer bytes
         * for host-to-local; IMAGE and HWREG share the same cursor. */
        uint8_t bytes[8];
        for(unsigned i=0;i<4;i++){bytes[i]=(uint8_t)(data_lo>>(i*8));bytes[i+4]=(uint8_t)(data_hi>>(i*8));}
        if(g_gif.trx_xdir==TRXDIR_HOST_TO_LOCAL)image_write_bytes(bytes,8);
    } break;
    case GS_REG_TRXDIR: {
        /* XDIR=2 performs a synchronous VRAM move immediately.
         * XDIR=0 keeps the existing IMAGE/HWREG stream semantics.
         * XDIR=1 is not supported and never fabricates host data. */
        g_gif.trx_xdir = data_lo & 0x3u;
        g_gif.trx_cur_x = 0;
        g_gif.trx_cur_y = 0;
        g_gif_read_fifo_qword=0;
        g_gif.trx_partial_pixel = g_gif.trx_partial_bytes = 0;
        if (g_gif.trx_xdir == TRXDIR_LOCAL_TO_LOCAL) {
            gs_local_copy_desc_t d = {
                .sbp=g_gif.trx_sbp,.sbw=g_gif.trx_sbw,.spsm=g_gif.trx_spsm,
                .dbp=g_gif.trx_dbp,.dbw=g_gif.trx_dbw,.dpsm=g_gif.trx_dpsm,
                .ssax=g_gif.trx_ssax,.ssay=g_gif.trx_ssay,
                .dsax=g_gif.trx_dsax,.dsay=g_gif.trx_dsay,
                .rrw=g_gif.trx_rrw,.rrh=g_gif.trx_rrh,
                .dirx=g_gif.trx_dirx,.diry=g_gif.trx_diry
            };
            if (gs_mem_copy_local(&d)) {
                g_gif_local_copy_ok++;
                g_gif_local_copy_pixels+=(uint64_t)d.rrw*d.rrh;
            } else g_gif_local_copy_declines++;
            /* Hardware runs immediately; no following IMAGE payload. */
            g_gif.trx_xdir=TRXDIR_OFF;
        }
        g_gif.trx_active = (g_gif.trx_xdir == TRXDIR_HOST_TO_LOCAL) &&
                            (g_gif.trx_dpsm == TEX_PSM_PSMCT32 ||
                             g_gif.trx_dpsm == TEX_PSM_PSMCT24 ||
                             g_gif.trx_dpsm == 2u || g_gif.trx_dpsm == 10u ||
                             g_gif.trx_dpsm == 0x13u || g_gif.trx_dpsm == 0x14u || g_gif.trx_dpsm == 0x1bu ||
                             g_gif.trx_dpsm == 0x24u || g_gif.trx_dpsm == 0x2cu);
    } break;
    default:
        break; /* unhandled register - ignored, not an error */
    }
}

/* Extracts the 4-bit register-descriptor nibble for register index
 * 'idx' (0-15) from the GIFtag's REGS field (tag words 2 and 3 - 8
 * nibbles each, low nibble = register 0). */
static inline uint32_t regs_nibble(uint32_t w2, uint32_t w3, uint32_t idx)
{
    if (idx < 8)
        return (w2 >> (idx * 4)) & 0xFu;
    return (w3 >> ((idx - 8) * 4)) & 0xFu;
}

/* Processes one complete PACKED-mode GIF packet (tag + NLOOP*NREG data
 * qwords) starting at 'p', which must have at least 16 bytes (the
 * tag) available. Returns the number of bytes consumed, or 0 if 'len'
 * isn't enough for even the tag. */
/* Round 634 (task #536/#614): shared IMAGE-mode raw-pixel writer,
 * extracted so both the "whole transfer fits in this call" path and
 * the "only part of it fits" path (see process_one_packet()'s IMAGE
 * branch below) drive the exact same trx_active/trx_cur_x/trx_cur_y
 * state machine - no behavioral change for the common case where a
 * transfer fits in one call, just no duplicated logic. */
static void image_write_bytes(const uint8_t *q, uint32_t byte_count)
{
    if(g_gif.trx_dpsm==0x13 || g_gif.trx_dpsm==0x14 || g_gif.trx_dpsm==0x1b || g_gif.trx_dpsm==0x24 || g_gif.trx_dpsm==0x2c){
        unsigned count=(g_gif.trx_dpsm==0x14 || g_gif.trx_dpsm==0x24 || g_gif.trx_dpsm==0x2c)?2:1;
        for(uint32_t i=0;i<byte_count&&g_gif.trx_active;i++)for(unsigned n=0;n<count&&g_gif.trx_active;n++){
            unsigned value=count==2?(q[i]>>(n*4))&15:q[i];
            gs_mem_write_index(g_gif.trx_dbp*64u,g_gif.trx_dbw,g_gif.trx_dsax+g_gif.trx_cur_x,g_gif.trx_dsay+g_gif.trx_cur_y,g_gif.trx_dpsm,value);
            if(++g_gif.trx_cur_x>=g_gif.trx_rrw){g_gif.trx_cur_x=0;if(++g_gif.trx_cur_y>=g_gif.trx_rrh)g_gif.trx_active=0;}
        }
        return;
    }
    uint32_t bytes_per_pixel = (g_gif.trx_dpsm == 2u || g_gif.trx_dpsm == 10u) ? 2u :
                               g_gif.trx_dpsm == TEX_PSM_PSMCT24 ? 3u : 4u;
    for (uint32_t i = 0; i < byte_count && g_gif.trx_active; i++) {
        g_gif.trx_partial_pixel |= (uint32_t)q[i] << (g_gif.trx_partial_bytes * 8u);
        if (++g_gif.trx_partial_bytes < bytes_per_pixel) continue;
        uint32_t x = g_gif.trx_dsax + g_gif.trx_cur_x;
        uint32_t y = g_gif.trx_dsay + g_gif.trx_cur_y;
        uint32_t pixel = g_gif.trx_partial_pixel;
        if (bytes_per_pixel == 3u)
            pixel |= gs_mem_read_psmct32_blk(g_gif.trx_dbp, g_gif.trx_dbw, x, y) & 0xff000000u;
        if (bytes_per_pixel == 2u)
            (g_gif.trx_dpsm == 10u ? gs_mem_write_psmct16s : gs_mem_write_psmct16)(g_gif.trx_dbp * 64u, g_gif.trx_dbw, x, y, (uint16_t)pixel);
        else
            gs_mem_write_psmct32_blk(g_gif.trx_dbp, g_gif.trx_dbw, x, y, pixel);
        g_gif.trx_partial_pixel = g_gif.trx_partial_bytes = 0;
        if (++g_gif.trx_cur_x >= g_gif.trx_rrw) {
            g_gif.trx_cur_x = 0;
            if (++g_gif.trx_cur_y >= g_gif.trx_rrh) g_gif.trx_active = 0;
        }
    }
}

static void image_write_pixel_qwords(const uint8_t *q,uint32_t n_qwords)
{
    image_write_bytes(q,n_qwords*16u);
}

static void apply_packed_register(uint32_t reg_code, const uint8_t *q)
{
    vertex_encoding=0;
    uint32_t w0=rd_le32(q), w1=rd_le32(q+4), w2=rd_le32(q+8), w3=rd_le32(q+12);
            switch (reg_code) {
            case GIF_REG_PRIM:  g_gif.prim = w0; reset_tri_vseq(); break;
            case GS_REG_ST:
                g_gif.cur_s = u32_to_float(w0);
                g_gif.cur_t = u32_to_float(w1);
                g_gif.gif_q_bits = w2;
                break;
            case GS_REG_UV:
                g_gif.cur_u = (double)(w0 & 0x3fffu) / 16.0;
                g_gif.cur_v = (double)(w1 & 0x3fffu) / 16.0;
                break;
            /* Packed TEX0/CLAMP carry their natural 64-bit register in
             * the low half of the quadword. GSState::ResetHandlers in
             * docs/reference/pcsx2 uses the same handlers as A+D. */
            case GS_REG_TEX0_1:
            case GS_REG_TEX0_2:
            case GS_REG_CLAMP_1:
            case GS_REG_CLAMP_2:
                apply_ad_write(reg_code, w0, w1);
                break;
            case GIF_REG_RGBAQ: apply_rgbaq(w0, w1, w2, w3); break;
            case GIF_REG_XYZ2:  apply_xyz2_kick(w0, w1, w2, !(w3 & 0x8000u)); break; /* w2 = real Z (task #89) */
            /* PACKED XYZF: Z in w2 bits 4..27, F in w3 bits
             * 4..11, ADC in w3 bit 15. Natural A+D differs. */
            case GIF_REG_XYZF2:
                g_gif.cur_fog = (w3 >> 4) & 0xFFu;
                apply_xyz2_kick(w0, w1, (w2 >> 4) & 0xFFFFFFu, !(w3 & 0x8000u));
                break;
            /* XYZ3/XYZF3: same field layouts as XYZ2/XYZF2 above, but
             * "vertex kick WITHOUT drawing kick" (do_draw_kick=0) -
             * see apply_xyz2_kick()'s own comment and the official GS
             * Users Manual's XYZ3 description. */
            case GIF_REG_XYZ3:
                apply_xyz2_kick(w0, w1, w2, 0);
                break;
            case GIF_REG_XYZF3:
                g_gif.cur_fog = (w3 >> 4) & 0xFFu;
                apply_xyz2_kick(w0, w1, (w2 >> 4) & 0xFFFFFFu, 0);
                break;
            /* PACKED FOG uses the expanded lane w3 bits 4..11. */
            case GIF_REG_FOG:
                g_gif.cur_fog = (w3 >> 4) & 0xFFu;
                break;
            case GIF_REG_AD:    apply_ad_write(w2 & 0xFFu, w0, w1); break; /* A+D: DATA in words 0-1, ADDR in word2's low byte */
            case GIF_REG_NOP:   default: break;
            }
}

/* PACKED/REGLIST payloads survive DMA/VIF boundaries on their own path.
 * REGLIST padding is consumed only after the final odd register. */
static uint32_t consume_register_payload(const uint8_t *p, uint32_t len)
{
    gif_register_carry_t *c=&g_gif.register_carry_path[s_gif_active_path];
    uint32_t off=0;
    while(c->remaining && off+16u<=len) {
        unsigned slots=c->mode==1u?2u:1u;
        for(unsigned half=0;half<slots && c->remaining;half++) {
            uint32_t code=regs_nibble(c->regs_lo,c->regs_hi,c->index);
            if(c->mode==1u)apply_ad_write(code,rd_le32(p+off+half*8u),rd_le32(p+off+half*8u+4u));
            else apply_packed_register(code,p+off);
            c->index=(c->index+1u)%c->nreg;
            c->remaining--;
        }
        off+=16u;g_gif.quadwords_seen++;
    }
    if(!c->remaining)g_gif.gif_last_eop=c->eop;
    return off;
}

static uint32_t process_one_packet(const uint8_t *p, uint32_t len)
{
    if (len < 16) return 0;

    uint32_t tag_w0 = rd_le32(p + 0);
    uint32_t tag_w1 = rd_le32(p + 4);
    uint32_t tag_w2 = rd_le32(p + 8);
    uint32_t tag_w3 = rd_le32(p + 12);

    uint32_t nloop = tag_w0 & 0x7FFFu;
    uint32_t flg   = (tag_w1 >> 26) & 0x3u;
    uint32_t nreg  = (tag_w1 >> 28) & 0xFu;
    /* Round 641 (task #536): real GS hardware's NREG field uses the
     * same "0 means max" convention as NLOOP's siblings elsewhere in
     * this file - NREG=0 in the tag means 16 registers per loop, not
     * zero. Confirmed against PCSX2's own real GIFTagBits::EnableAlgo
     * parsing (docs/reference/pcsx2/pcsx2/GS/GSRegs.h:1140,
     * "nreg = (b & 0xf0000000) ? (b >> 28) : 16") - this project's
     * gif_tag0/gif_cnt raw-register snapshots above still report the
     * raw 4-bit field unchanged (real GIF_CNT.REGCNT also reads the
     * raw, un-substituted field per the manual), only the *parsing*
     * below needs the 16-substitution. Before this fix, a REGLIST- or
     * PACKED-mode tag with a real NREG=0 (16) fell through into the
     * IMAGE-mode/degenerate-skip branch below instead (guarded by
     * "|| nreg == 0"), silently misinterpreting real register-list
     * draw data (PRIM/RGBAQ/XYZ2/TEX0 writes) as raw pixel bytes to
     * skip. This is a genuine, real-hardware-cited correctness fix,
     * kept on that basis - but Round 641's own live instrumentation
     * (see docs/STATUS.md) found it empirically INERT against this
     * project's captured boot trace: nreg==0 was observed occurring
     * only when flg==2 (already IMAGE mode, where NREG is unused/
     * irrelevant), never in the flg==0/1 misrouting scenario this
     * fix targets. The garbled PRIM values described below (reserved
     * TYPE=7, high-entropy attribute bits, repeated 0x7ff) are still
     * observed live with this fix applied - see gif.h's gif_last_eop
     * comment and gif_process_quadwords() below for the transfer-
     * boundary fix that was ALSO tried and ALSO found insufficient
     * alone; the real source of the corruption is still open as of
     * Round 641 and is narrowed to a within-packet NLOOP/NREG or
     * upstream VU1-content desync, not a transfer-boundary or
     * NREG-substitution issue. Do not re-claim this fix (or the EOP
     * fix) as "the" root cause without fresh empirical confirmation -
     * both were disproven by direct instrumentation after initially
     * being written up with this over-confident claim. */
    uint32_t nreg_raw = nreg;
    if (nreg_raw == 0) nreg = 16;
    uint32_t pre   = (tag_w1 >> 14) & 0x1u;
    uint32_t prim  = (tag_w1 >> 15) & 0x7FFu;
    uint32_t eop   = (tag_w0 >> 15) & 0x1u; /* real tGIF_TAG0::EOP, bit 15 - see Gif.h */

    /* Round 542: real GIF_TAG0-3/GIF_CNT register snapshot. Real
     * hardware latches the just-parsed tag's raw 128 bits into
     * GIF_TAG0-3 and derives GIF_CNT's LOOPCNT/REGCNT fields from it -
     * this is a genuine, direct 1:1 mapping of values this function
     * already computes/reads, not a fabrication (see gif.h's
     * gif_tag0-3/gif_cnt field comments for the full citation). VUADDR
     * always reads 0: it tracks VU1 micromem write offset during real
     * PATH1 (XGKICK) transfers; Round 571 implemented real XGKICK
     * (vu.c) and this project's transfers complete synchronously
     * within one call here, so there is never a genuine in-flight
     * offset to report - see gif_path1_transfers (Round 577) for the
     * real way to observe PATH1 activity instead. */
    game_trace_record(GT_TAG_PATH1+s_gif_active_path,tag_w0,tag_w1,tag_w2,tag_w3);
    g_gif.gif_tag0 = tag_w0;
    g_gif.gif_tag1 = tag_w1;
    g_gif.gif_tag2 = tag_w2;
    g_gif.gif_tag3 = tag_w3;
    g_gif.gif_cnt = (nloop & 0x7FFFu) | ((nreg & 0xFu) << 16);
    if (s_gif_active_path == GIF_PATH_3) {
        /* GIF_P3CNT/GIF_P3TAG: PATH3-only shadow registers (real
         * hardware dedicates these specifically to PATH3 progress
         * monitoring - see Gif.h's tGIF_P3CNT/tGIF_P3TAG and gif.h's
         * gif_p3cnt/gif_p3tag field comment). */
        g_gif.gif_p3cnt = nloop & 0x7FFFu;
        g_gif.gif_p3tag = (nloop & 0x7FFFu) | (eop << 15);
    }
    /* Round 641: unconditionally mirror EOP (not gated on PATH_3 like
     * gif_p3cnt/gif_p3tag above) for gif_process_quadwords()'s real
     * transfer-boundary stop check below - see gif.h's gif_last_eop
     * comment for the full citation/rationale. */
    g_gif.gif_last_eop = eop;

    /* GSState.cpp Transfer: every nonempty new tag resets temporary Q.
     * Continued payload fragments keep the latch; GS RGBAQ.Q is unchanged. */
    if(nloop)g_gif.gif_q_bits=UINT32_C(0x3f800000);

    /* Empty tags disregard everything except EOP; PRE applies only to PACKED.
     * Primary reference: GSState.cpp GIF transfer tag dispatch. */
    if (nloop && flg == 0u && pre) {
        g_gif.prim = prim;
        reset_tri_vseq();
    }

    uint32_t consumed = 16;

    if (flg == 0 || flg == 1) {
        gif_register_carry_t *c=&g_gif.register_carry_path[s_gif_active_path];
        c->remaining=nloop*nreg;c->index=0;c->nreg=nreg;c->mode=flg;
        c->regs_lo=tag_w2;c->regs_hi=tag_w3;c->eop=eop;
        return consumed+consume_register_payload(p+consumed,len-consumed);
    }

    if (flg == 2 || flg == 3 /* IMAGE (3 is the reserved/disabled variant, treated the same) */) {
        /* IMAGE mode: NLOOP qwords of completely raw pixel data - no
         * register interpretation, no REGS descriptor involved at
         * all (byte accounting was already correct before this
         * round: IMAGE's data size really is exactly NLOOP qwords).
         * Round 26 adds REAL pixel writing when a host-to-local
         * PSMCT32 transfer is active (g_gif.trx_active, set by a
         * prior TRXDIR write - see apply_ad_write's GS_REG_TRXDIR
         * case) - each qword holds exactly 4 raw PSMCT32 pixels,
         * consumed in raster order and written via the destination
         * rectangle's (trx_dbp,trx_dbw) at (trx_dsax+cur_x,
         * trx_dsay+cur_y), wrapping at trx_rrw and stopping once
         * trx_rrh rows are filled (matching real hardware's
         * rectangle-bounded transfer). Anything trx_active doesn't
         * cover (unsupported XDIR, non-PSMCT32 destination, or a
         * degenerate nreg==0 tag with flg=0/PACKED that isn't really
         * IMAGE data at all) falls back to the pre-existing safe
         * byte-skip - not interpreted, but the stream stays in sync. */
        uint32_t skip_qwords = nloop;
        uint32_t skip_bytes = skip_qwords * 16u;

        /* DMA boundaries do not terminate an IMAGE packet. Consume the
         * full NLOOP even if its rectangle fills before the packet ends. */
        if (consumed + skip_bytes > len) {
            uint32_t avail_bytes = (len > consumed) ? (len - consumed) : 0u;
            uint32_t avail_qwords = avail_bytes / 16u;
            uint32_t shortfall_qwords = skip_qwords - avail_qwords;

            if ((flg == 2 || flg == 3) && g_gif.trx_active && avail_qwords > 0)
                image_write_pixel_qwords(p + consumed, avail_qwords);

            g_gif.image_carry_remaining_qwords = shortfall_qwords;
            g_gif.image_eop_path[s_gif_active_path] = eop;

            return len; /* fully consumed - nothing left in this buffer to misparse as a fresh tag */
        }

        if ((flg == 2 || flg == 3) && g_gif.trx_active)
            image_write_pixel_qwords(p + consumed, nloop);

        return consumed + skip_bytes;
    }


    return consumed;
}

static void gif_process_quadwords_impl(int channel, const uint8_t *data,
                                       uint32_t qwc, int count_kick)
{
    /* Round 542: `channel` is now a real GIF_PATH_1/2/3 selector (see
     * gif.h) - clamp defensively to PATH_3 for any out-of-range value
     * a future caller might pass, rather than silently mis-tagging
     * PATH3-shadow-register updates (this project's established
     * safety-gate convention - see e.g. gif_init()'s colclamp/prim
     * default comments). */
    s_gif_active_path = (channel == GIF_PATH_1 || channel == GIF_PATH_2 || channel == GIF_PATH_3)
                         ? (uint32_t)channel : GIF_PATH_3;

    /* Round 577 (task #551): real diagnostic counter - see gif.h's
     * gif_path1_transfers comment. Counts the call, not the quadword
     * count, matching "one XGKICK = one transfer" semantics. */
    if (s_gif_active_path == GIF_PATH_1 && count_kick)
        g_gif.gif_path1_transfers++;

    uint32_t len = qwc * 16u;
    uint32_t off = 0;

    /* IMAGE continuation belongs to its GIF path, including padding after
     * the destination rectangle completes. Other paths retain their parser. */
    g_gif.image_carry_remaining_qwords = g_gif.image_carry_path[s_gif_active_path];
    if (g_gif.image_carry_remaining_qwords > 0) {
        uint32_t owed_qwords = g_gif.image_carry_remaining_qwords;
        uint32_t avail_qwords = len / 16u;
        uint32_t take_qwords = owed_qwords < avail_qwords ? owed_qwords : avail_qwords;
        if (g_gif.trx_active) image_write_pixel_qwords(data, take_qwords);
        g_gif.image_carry_remaining_qwords = owed_qwords - take_qwords;
        g_gif.image_carry_path[s_gif_active_path] = g_gif.image_carry_remaining_qwords;
        off = take_qwords * 16u;
        if(!g_gif.image_carry_remaining_qwords && s_gif_active_path==GIF_PATH_1 &&
           g_gif.image_eop_path[GIF_PATH_1])return;
    }

    gif_register_carry_t *carry=&g_gif.register_carry_path[s_gif_active_path];
    if(carry->remaining) {
        off+=consume_register_payload(data+off,len-off);
        if(carry->remaining || (s_gif_active_path==GIF_PATH_1 && carry->eop))return;
    }
    while (off < len) {
        uint32_t used = process_one_packet(data + off, len - off);
        if (used == 0)
            break; /* not enough data for even a tag - stop, nothing more we can do this call */
        off += used;
        if (used < 16)
            break; /* incomplete packet - safety, shouldn't normally happen */
        /* XGKICK supplies an upper bound, so PATH1 stops at EOP.
         * DMA and VIF DIRECT supply an exact span which may contain
         * multiple EOP-terminated GIF packets. */
        if (s_gif_active_path == GIF_PATH_1 && g_gif.gif_last_eop && !carry->remaining && !g_gif.image_carry_remaining_qwords)
            break;
    }
    g_gif.image_carry_path[s_gif_active_path] = g_gif.image_carry_remaining_qwords;
}

/* Ownership persists across producer fragments until EOP. PATH3 IMAGE
 * permits interruption only with IMT; M3R/M3P apply at packet boundaries.
 * No unbounded queue or borrowed producer pointer survives a call. */
uint32_t gif_try_process_quadwords(int path,const uint8_t *data,uint32_t qwc) {
    if(path<0||path>2||!data)return 0;
    uint32_t done=0;
    for(;done<qwc;done++) {
        unsigned owner=g_gif.arb_owner;
        int slice=owner==3u&&path!=GIF_PATH_3&&(g_gif.gif_mode&4u)&&
                  g_gif.image_carry_path[GIF_PATH_3];
        unsigned wait=(g_gif.gif_ctrl&8u)?1u:
            (owner&&owner!=(unsigned)path+1u&&!slice)?2u:
            (path==GIF_PATH_3&&owner!=3u&&((g_gif.gif_mode&1u)||g_gif.arb_m3p))?3u:
            (path==GIF_PATH_3&&owner!=3u&&(g_gif.arb_pending&3u))?4u:
            (path==GIF_PATH_2&&owner!=2u&&(g_gif.arb_pending&1u))?5u:0u;
        if(wait){if(path_wait[path]!=wait){path_wait[path]=(uint8_t)wait;game_trace_record(GT_GIF_WAIT,path,wait,owner,g_gif.arb_pending);}break;}
        if(path_wait[path]){game_trace_record(GT_GIF_RESUME,path,path_wait[path],owner,g_gif.arb_pending);path_wait[path]=0;}
        /* The synchronous consumer has no hidden borrowed-payload queue.
         * Keep a second SIGNAL at its producer until CSR.SIGNAL is cleared.
         * The entire qword is still unaccepted: DMA/VIF/VU may retry it
         * without duplicate writes, lost parser position or a fake IRQ.
         * A+D exists only in PACKED, one register per qword. */
        const gif_register_carry_t *c=&g_gif.register_carry_path[path];
        if(c->remaining&&c->mode==0u&&
           regs_nibble(c->regs_lo,c->regs_hi,c->index)==GIF_REG_AD&&
           (rd_le32(data+done*16u+8u)&255u)==GS_REG_SIGNAL&&
           (gs_get_state()->csr&1u)) {
            if(!signal_wait[path]){signal_wait[path]=1;game_trace_record(GT_SIGNAL_WAIT,path,c->remaining,rd_le32(data+done*16u),rd_le32(data+done*16u+4u));}
            g_signal_stalls++;break;
        }
        if(signal_wait[path]){signal_wait[path]=0;game_trace_record(GT_SIGNAL_RESUME,path,c->remaining,(uint32_t)gs_get_state()->csr,0);}
        if(!owner||slice)g_gif.arb_owner=(uint8_t)(path+1);
        int tag=!g_gif.register_carry_path[path].remaining&&!g_gif.image_carry_path[path];
        if(tag)g_gif.arb_eop[path]=!!(data[done*16u+1u]&0x80u);
        uint32_t saved=s_gif_active_path;
        gif_process_quadwords_impl(path,data+done*16u,1u,0);
        s_gif_active_path=saved;
        if(!g_gif.register_carry_path[path].remaining&&!g_gif.image_carry_path[path]&&g_gif.arb_eop[path])
            g_gif.arb_owner=(path!=GIF_PATH_3&&g_gif.image_carry_path[GIF_PATH_3])?3u:0u;
    }
    if(done<qwc)g_gif.arb_pending|=(uint8_t)(1u<<path);
    else g_gif.arb_pending&=(uint8_t)~(1u<<path);
    return done;
}
void gif_set_path3_mask(int masked){g_gif.arb_m3p=!!masked;}
/* Actual bounded PATH3 FIFO for CPU quadword writes. Producer memory is
 * copied on acceptance; a full FIFO declines without overwriting bytes. */
void gif_fifo_service(void) {
    while(g_gif.fifo_count) {
        if(!gif_try_process_quadwords(GIF_PATH_3,g_gif.fifo[g_gif.fifo_head],1))break;
        g_gif.fifo_head=(g_gif.fifo_head+1u)&15u;g_gif.fifo_count--;
    }
}
int gif_fifo_write(const uint8_t *quadword) {
    gif_fifo_service();if(g_gif.fifo_count==16u)return 0;
    unsigned tail=(g_gif.fifo_head+g_gif.fifo_count)&15u;
    memcpy(g_gif.fifo[tail],quadword,16);g_gif.fifo_count++;
    gif_fifo_service();return 1;
}


void gif_process_quadwords(int channel, const uint8_t *data, uint32_t qwc)
{
    uint32_t saved=s_gif_active_path;
    gif_process_quadwords_impl(channel,data,qwc,1);
    s_gif_active_path=saved;
}

/* A synchronous XGKICK submits at most one complete VU1 ring traversal.
 * PCSX2 GSState clears an incomplete PATH1 NLOOP at this boundary (BIOS
 * packets can omit EOP). Do not let a stale tag consume the next kick.
 * Generic DMA/DIRECT streams keep their cross-call continuation state. */
void gif_process_xgkick(const uint8_t *data, uint32_t qwc)
{
    gif_begin_xgkick();
    gif_process_xgkick_fragment(data,qwc);
    gif_end_xgkick();
}

void gif_end_xgkick(void)
{
    g_gif.arb_pending&=~1u;
    memset(&g_gif.register_carry_path[GIF_PATH_1], 0,
           sizeof(g_gif.register_carry_path[GIF_PATH_1]));
    g_gif.image_carry_path[GIF_PATH_1] = 0;
    g_gif.image_eop_path[GIF_PATH_1] = 0;
    if(g_gif.arb_owner==1u)g_gif.arb_owner=g_gif.image_carry_path[GIF_PATH_3]?3u:0;
    if(s_gif_active_path==GIF_PATH_1)g_gif.image_carry_remaining_qwords = 0;
}

void gif_begin_xgkick(void)
{
    gif_end_xgkick();
    g_gif.gif_path1_transfers++;
}

void gif_process_xgkick_fragment(const uint8_t *data,uint32_t qwc)
{
    uint32_t saved=s_gif_active_path;
    gif_process_quadwords_impl(GIF_PATH_1,data,qwc,0);
    s_gif_active_path=saved;
}

/* Round 542: real GIF MMIO register block (0x10003000-0x100030A0).
 * See gif.h's field comments (gif_ctrl/gif_mode/gif_tag0-3/gif_cnt/
 * gif_p3cnt/gif_p3tag) for the full per-register citation/rationale;
 * this is just the bus-facing read/write dispatch, following the
 * exact same shape as dma_mmio_read32/write32 (dma.c) and every other
 * *_mmio_read32/write32 handler in this codebase. */
int gif_mmio_read32(uint32_t addr, uint32_t *out_val)
{
    switch (addr) {
    case GIF_CTRL_ADDR:
        *out_val = g_gif.gif_ctrl & 0x8u; /* only PSE (bit 3) is real readable state - RST self-clears, never stored */
        return 1;
    case GIF_MODE_ADDR:
        *out_val = g_gif.gif_mode & 0x5u; /* M3R (bit 0) / IMT (bit 2) - the only two real writable MODE bits */
        return 1;
    case GIF_STAT_ADDR: {
        /* Derived, not stored - see gif.h's gif_ctrl/gif_mode/(absence
         * of a gif_stat field) comment. M3R/IMT mirror MODE live;
         * PSE mirrors CTRL live; M3P and every dynamic APATH/OPH/DIR/
         * IP3/PxQ/FQC bit read 0 (documented gaps / genuine idle
         * state - see gif.h). */
        uint32_t m3r = g_gif.gif_mode & 0x1u;
        uint32_t imt = (g_gif.gif_mode >> 2) & 0x1u;
        uint32_t pse = (g_gif.gif_ctrl >> 3) & 0x1u;
        *out_val = m3r | ((uint32_t)g_gif.arb_m3p<<1) | (imt << 2) | (pse << 3) |
            ((uint32_t)g_gif.arb_owner<<10) | (g_gif.arb_owner?1u<<9:0u) |
            ((uint32_t)g_gif.fifo_count<<24) |
            ((g_gif.arb_owner&&g_gif.arb_owner!=3u&&g_gif.image_carry_path[GIF_PATH_3])?1u<<5:0u) |
            ((g_gif.arb_pending&1u)?1u<<8:0u) |
            ((g_gif.arb_pending&2u)?1u<<7:0u) |
            ((g_gif.arb_pending&4u)?1u<<6:0u);
        return 1;
    }
    case GIF_TAG0_ADDR: *out_val = g_gif.gif_tag0; return 1;
    case GIF_TAG1_ADDR: *out_val = g_gif.gif_tag1; return 1;
    case GIF_TAG2_ADDR: *out_val = g_gif.gif_tag2; return 1;
    case GIF_TAG3_ADDR: *out_val = g_gif.gif_tag3; return 1;
    case GIF_CNT_ADDR:  *out_val = g_gif.gif_cnt;  return 1;
    case GIF_P3CNT_ADDR: *out_val = g_gif.gif_p3cnt; return 1;
    case GIF_P3TAG_ADDR: *out_val = g_gif.gif_p3tag; return 1;
    default: return 0;
    }
}

int gif_mmio_write32(uint32_t addr, uint32_t val)
{
    switch (addr) {
    case GIF_CTRL_ADDR:
        /* RST (bit 0): real hardware resets CTRL/MODE/STAT themselves
         * (Gif_Unit.h's ResetRegs(): "gifRegs.stat.reset();
         * gifRegs.ctrl.reset(); gifRegs.mode.reset();") but explicitly
         * does NOT touch TAG0-3/CNT/P3CNT/P3TAG - cross-checked and
         * cited in gif.h's Key Technical Concepts. It's a one-shot
         * action, not stored state, so gif_ctrl only ever retains PSE. */
        if (val & 0x1u) {
            g_gif.gif_ctrl = 0;
            g_gif.gif_mode = 0;
            g_gif.arb_owner=g_gif.arb_pending=g_gif.arb_m3p=0;
            g_gif.fifo_count=g_gif.fifo_head=0;
            memset(g_gif.arb_eop,0,sizeof(g_gif.arb_eop));
            memset(g_gif.register_carry_path,0,sizeof(g_gif.register_carry_path));
            memset(g_gif.image_carry_path,0,sizeof(g_gif.image_carry_path));
        } else {
            g_gif.gif_ctrl = val & 0x8u; /* PSE only - bits 1-2/4-31 are reserved/unwritable */
        }
        return 1;
    case GIF_MODE_ADDR:
        g_gif.gif_mode = val & 0x5u; /* M3R (bit 0) / IMT (bit 2) only - bit 1/3-31 reserved */
        return 1;
    /* GIF_STAT/TAG0-3/CNT/P3CNT/P3TAG are real hardware read-only
     * registers (Gif.h defines no software-write path for any of
     * them) - fall through to "not a GIF register" for a write,
     * same policy this codebase already uses for other read-only
     * MMIO (e.g. DMA channel STAT-only fields). */
    default: return 0;
    }
}
