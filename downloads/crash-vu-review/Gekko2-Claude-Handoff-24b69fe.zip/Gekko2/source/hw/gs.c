#include "core/hw/game_trace.h"
/*
 * gs.c - GS privileged register skeleton. See include/core/hw/gs.h
 * for scope notes. Addresses cross-checked against PCSX2's
 * pcsx2/Hw.h (GS_PMODE .. GS_SIGLBLID).
 */

#include "core/hw/gs.h"
#include "core/hw/ee_intc.h"
#include <string.h>
#include <stddef.h>

static gs_state_t g_gs;

void gs_init(void)
{
    memset(&g_gs, 0, sizeof(g_gs));
    g_gs.imr = GS_IMR_RESET_ALL_MASKED;
}
gs_state_t *gs_get_state(void) { return &g_gs; }

/* CSR event bits 0..4 map directly to IMR mask bits 8..12. */
int gs_raise_event(unsigned event)
{
    if (event > 4u) return 0;
    g_gs.csr |= 1ull << event;
    return (g_gs.imr & (1ull << (event + 8u))) == 0;
}

typedef struct { uint32_t addr; uint64_t *reg; } gs_reg_map_t;

static uint64_t *reg_for_addr(uint32_t addr)
{
    static const struct { uint32_t addr; size_t offset; } map[] = {
        { 0x12000000u, offsetof(gs_state_t, pmode) },
        { 0x12000010u, offsetof(gs_state_t, smode1) },
        { 0x12000020u, offsetof(gs_state_t, smode2) },
        { 0x12000030u, offsetof(gs_state_t, srfsh) },
        { 0x12000040u, offsetof(gs_state_t, synch1) },
        { 0x12000050u, offsetof(gs_state_t, synch2) },
        { 0x12000060u, offsetof(gs_state_t, syncv) },
        { 0x12000070u, offsetof(gs_state_t, dispfb1) },
        { 0x12000080u, offsetof(gs_state_t, display1) },
        { 0x12000090u, offsetof(gs_state_t, dispfb2) },
        { 0x120000A0u, offsetof(gs_state_t, display2) },
        { 0x120000B0u, offsetof(gs_state_t, extbuf) },
        { 0x120000C0u, offsetof(gs_state_t, extdata) },
        { 0x120000D0u, offsetof(gs_state_t, extwrite) },
        { 0x120000E0u, offsetof(gs_state_t, bgcolor) },
        { 0x12001000u, offsetof(gs_state_t, csr) },
        { 0x12001010u, offsetof(gs_state_t, imr) },
        { 0x12001040u, offsetof(gs_state_t, busdir) },
        { 0x12001080u, offsetof(gs_state_t, siglblid) },
    };
    for (size_t i = 0; i < sizeof(map) / sizeof(map[0]); i++) {
        if (map[i].addr == addr)
            return (uint64_t *)((uint8_t *)&g_gs + map[i].offset);
    }
    return NULL;
}

int gs_mmio_read64(uint32_t addr, uint64_t *out_val)
{
    if (addr < 0x12000000u || addr > 0x12001FFFu)
        return 0;
    uint64_t *reg = reg_for_addr(addr);
    *out_val = reg ? *reg : 0;
    return 1;
}

int gs_mmio_write64(uint32_t addr, uint64_t val)
{
    if (addr < 0x12000000u || addr > 0x12001FFFu)
        return 0;
    uint64_t *reg = reg_for_addr(addr);
    if (reg) {
        if (addr == 0x12001000u) {
            /* GS_CSR write-1-to-clear semantics for interrupt status. */
            if(val&1u)game_trace_record(GT_CSR_ACK,(uint32_t)g_gs.csr,(uint32_t)val,(uint32_t)g_gs.imr,0);
            g_gs.csr &= ~(val & 0x1full); /* FIELD is read-only. */
        } else if(addr==0x12001010u) {
            /* A masked event stays in CSR. Only a 1->0 mask transition
             * delivers its pending interrupt; repeated writes do not. */
            uint64_t unmasked=(*reg & ~val & 0x1f00u)>>8;
            if(unmasked & g_gs.csr)ee_intc_raise(0);
            uint64_t next=(val&0x1f00u)|0x6000u;
            if(*reg!=next)game_trace_record(GT_IMR,(uint32_t)*reg,(uint32_t)next,(uint32_t)g_gs.csr,0);
            *reg=next;
        } else {
            *reg = val;
        }
    }
    return 1;
}

/* Lane-aware narrow accesses. CSR writes are actions: never read/merge
 * unwritten CSR bits, which would incorrectly acknowledge other events. */
int gs_mmio_read(uint32_t addr,unsigned bytes,uint64_t *value)
{
 if(!value||!(bytes==1u||bytes==2u||bytes==4u||bytes==8u)||
    (addr&(bytes-1u))||addr<0x12000000u||addr>0x12001fffu)return 0;
 unsigned lane=addr&15u;uint64_t raw=0;
 gs_mmio_read64(addr&~15u,&raw);
 *value=lane>=8u?0u:raw>>(lane*8u);
 if(bytes<8u)*value&=(UINT64_C(1)<<(bytes*8u))-1u;
 return 1;
}
int gs_mmio_write(uint32_t addr,unsigned bytes,uint64_t value)
{
 if(!(bytes==1u||bytes==2u||bytes==4u||bytes==8u)||
    (addr&(bytes-1u))||addr<0x12000000u||addr>0x12001fffu)return 0;
 unsigned lane=addr&15u;if(lane>=8u)return 1;
 uint32_t base=addr&~15u;uint64_t mask=bytes==8u?UINT64_MAX:((UINT64_C(1)<<(bytes*8u))-1u);
 value=(value&mask)<<(lane*8u);mask<<=lane*8u;
 if(base==0x12001000u)return gs_mmio_write64(base,value);
 uint64_t before=0;gs_mmio_read64(base,&before);
 return gs_mmio_write64(base,(before&~mask)|value);
}
