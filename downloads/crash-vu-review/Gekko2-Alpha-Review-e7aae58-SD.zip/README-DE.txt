Gekko2: privater Alpha-Pruefkandidat e7aae58

Kein oeffentlich freigegebener Alpha-Build. Keine bestaetigte Spielbarkeit,
FPS-Steigerung oder BIOS-Kachelkorrektur. Der Build bleibt BETA12.33.

Vor dem Kopieren vorhandene boot.dol und Einstellungen sichern.
Dieses Paket enthaelt und ueberschreibt keine BIOS-, Disc- oder Kartendaten
und schreibt keine Optionsdatei. Bestehende Einstellungen gelten weiterhin.
Zum Abnahmetest Event-Scheduler, PSM-Konvertierung und GX-Risiko deaktivieren;
128-Bit-Kettenresidenz ist in diesem Kontrollbuild nicht einkompiliert.

Ladebildschirm ist Standard. Settings > On-screen logs schaltet die
gespeicherte Bildschirmdiagnose um; SD-/Netzwerklogs sind unabhaengig.
Alte gespeicherte HUD-ON-Einstellungen bleiben ON.

Wii-Abnahme: HBC-Start, Controller, Einstellungen speichern, Cold Boot,
erste BIOS-Ausgabe, Rueckkehr ins Menue und HBC. Release-ID, Build-ID und
aktive Optionen im Log kontrollieren. Der Agent hat keine echte Wii getestet.

GT2000-Demo erreicht im untersuchten Hostpfad noch keine Bildausgabe.
GT3-Vollversion, Crash und Tekken sind nicht als spielbar bestaetigt.
