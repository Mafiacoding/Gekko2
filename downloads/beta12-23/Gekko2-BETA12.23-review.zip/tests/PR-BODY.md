BETA12.22 owner sessions show Crash stalled in GIF SIGNAL/PATH1 retries and Tekken with graphics/performance issues. This batch fixes independently reproduced VU integer memory mask semantics in scalar/PPC paths, VIF commands passing a yielded microprogram and fractional UV loss before GS rendering. It preserves legitimate SIGNAL backpressure and software fallback.

Standard 4:3 PS2 presentation is pillarboxed on a Wii configured for 16:9; GS resolution stays unchanged. Added bounded transport/display diagnostics and a source comparison with PCSX2/Play! identifying remaining gaps.

Validation: 47 host suites, 512 independent emitted-PPC mask/ABI cases, 1,024 synthetic VU AOT pipeline comparisons, linked Wii PPC VIF/UV/aspect and inherited GS/GX/IPU/DMA tests, 20 chain/PSM combinations. Both Wii DOL/ELF and MEM1 checks pass. Synthetic corrected VU memory cases reduce PPC instructions 8,448 to 6,272; no overall FPS claim. Both experiments factory OFF. No confirmed new Wii gameplay, complete graphics correction or Crash stall resolution. See docs/BETA12.23-GAME-LOG-REVIEW.md.

Raw owner logs, BIOS and discs are excluded.
