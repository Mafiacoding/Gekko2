#include "ps2_wii_progress.h"
#include "ps2_wii_host.h"
#include "runtime/ps2_progress_policy.h"
#include <gccore.h>
#include <ogc/lwp_watchdog.h>
#include <atomic>
#include <cstdio>
#include <thread>
#include <unistd.h>
namespace {
 static_assert(std::atomic<uint32_t>::is_always_lock_free);
 std::atomic<uint32_t> pc{},ra{},sp{},cycles{},waitReason{},phase{},uiPhase{},eeCount{},uiCount{};
 std::atomic<uint32_t> history[32]{};
 std::atomic<bool> stopping{false};
 std::thread observer;
 // Only the EE executor touches these throttle fields.
 uint32_t throttle=0;uint64_t lastYield=0;
 void monitor(){
  // Wake briefly above the guest worker; sleep between samples. No guest/GS
  // locks, heap snapshots, live-context reads or rendering in this thread.
  LWP_SetThreadPriority(LWP_GetSelf(),LWP_PRIO_HIGHEST);
  Ps2ProgressPolicy policy;
  for(unsigned seconds=0;!stopping.load();++seconds){
   if(seconds%5==0){
    FILE*f=std::fopen("sd:/ps2recomp/progress.txt","w");
    if(f){
     std::fprintf(f,"seconds=%u state=%s ee_points=%lu ui_frames=%lu ee_quiet=%lu ui_quiet=%lu\npc=%08lx ra=%08lx sp=%08lx cycles_low=%lu wait=%lu ee_phase=%lu ui_phase=%lu\nrecent_pcs=",seconds,policy.state(),(unsigned long)eeCount.load(),(unsigned long)uiCount.load(),(unsigned long)policy.eeQuiet,(unsigned long)policy.uiQuiet,(unsigned long)pc.load(),(unsigned long)ra.load(),(unsigned long)sp.load(),(unsigned long)cycles.load(),(unsigned long)waitReason.load(),(unsigned long)phase.load(),(unsigned long)uiPhase.load());
     uint32_t n=eeCount.load();for(unsigned i=0;i<32;++i)std::fprintf(f," %08lx",(unsigned long)history[(n+i)%32].load());
     std::fprintf(f,"\nSamples are independent; not a coherent guest snapshot.\n");std::fflush(f);std::fclose(f);
    }
   }
   for(unsigned i=0;i<4&&!stopping.load();++i)usleep(250000);
   policy.observe(eeCount.load(),uiCount.load());
  }
 }
}
void PS2WiiProgressStart(){stopping=false;eeCount=0;uiCount=0;pc=0;ra=0;sp=0;cycles=0;waitReason=0;phase=0;uiPhase=0;for(auto &v:history)v=0;throttle=0;lastYield=gettime();observer=std::thread(monitor);}
void PS2WiiProgressStop(){stopping=true;if(observer.joinable())observer.join();}
bool PS2WiiProgressStopRequested(){return WindowShouldClose();}
void PS2WiiProgressPhase(uint32_t p){phase.store(p,std::memory_order_relaxed);}
void PS2WiiProgressUi(uint32_t p){uiPhase.store(p,std::memory_order_relaxed);if(p==1)uiCount.fetch_add(1,std::memory_order_relaxed);}
void PS2WiiProgressPoint(uint32_t p,uint32_t r,uint32_t s,uint32_t c,uint32_t w){
 pc.store(p,std::memory_order_relaxed);ra.store(r,std::memory_order_relaxed);sp.store(s,std::memory_order_relaxed);cycles.store(c,std::memory_order_relaxed);waitReason.store(w,std::memory_order_relaxed);
 auto n=eeCount.fetch_add(1,std::memory_order_relaxed);history[n%32].store(p,std::memory_order_relaxed);
 (void)PS2WiiServicePoll();
}

uint32_t PS2WiiProgressEnter(uint32_t p){return phase.exchange(p,std::memory_order_relaxed);}

bool PS2WiiServicePoll(){
 if((++throttle&127)==0){auto now=gettime();if(ticks_to_microsecs(now-lastYield)>=2000){lastYield=now;usleep(1000);}}
 return WindowShouldClose();
}
