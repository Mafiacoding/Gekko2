#pragma once
#include <cstdint>
// Lock-free scalar samples: observer never reads live guest contexts or takes
// scheduler/GS locks. Individual fields are diagnostic, not a savestate.
void PS2WiiProgressStart();
void PS2WiiProgressStop();
void PS2WiiProgressPoint(uint32_t pc,uint32_t ra,uint32_t sp,uint32_t cycles,uint32_t wait);
void PS2WiiProgressPhase(uint32_t phase);
void PS2WiiProgressUi(uint32_t phase);
bool PS2WiiProgressStopRequested();

uint32_t PS2WiiProgressEnter(uint32_t phase);
class PS2WiiProgressScope {
 uint32_t previous_;
public:
 explicit PS2WiiProgressScope(uint32_t p):previous_(PS2WiiProgressEnter(p)){}
 ~PS2WiiProgressScope(){PS2WiiProgressPhase(previous_);}
};

bool PS2WiiServicePoll();
