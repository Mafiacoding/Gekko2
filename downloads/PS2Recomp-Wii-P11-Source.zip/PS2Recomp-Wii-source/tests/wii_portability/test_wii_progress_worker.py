#!/usr/bin/env python3
"""Run the actual observer with mock timebase/LWP, real threads and file IO."""
from pathlib import Path
import tempfile,subprocess
root=Path(__file__).resolve().parents[2]
with tempfile.TemporaryDirectory() as temp:
 p=Path(temp);(p/'ogc').mkdir();(p/'sd:/ps2recomp').mkdir(parents=True)
 (p/'gccore.h').write_text('''#pragma once
#include <chrono>
#include <cstdint>
inline constexpr unsigned LWP_PRIO_HIGHEST=127;
inline unsigned LWP_GetSelf(){return 0;}
inline void LWP_SetThreadPriority(unsigned,unsigned){}
inline uint64_t gettime(){return std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
inline uint64_t ticks_to_microsecs(uint64_t x){return x;}
''')
 (p/'ogc/lwp_watchdog.h').write_text('#pragma once\n')
 (p/'test.cpp').write_text('''#include "ps2_wii_progress.h"
#include <cassert>
#include <fstream>
#include <string>
#include <thread>
#include <chrono>
static bool closed=false;
bool WindowShouldClose(){return closed;}
int main(){
 PS2WiiProgressStart();
 for(unsigned i=0;i<1024;++i)PS2WiiProgressPoint(0x100000+i*4,0x1234,0x5678,i,0);
 PS2WiiProgressPhase(5);
 try{PS2WiiProgressScope scope(10);throw 1;}catch(int){}
 PS2WiiProgressUi(2);
 // No producer activity: observer must still create its next durable sample.
 std::this_thread::sleep_for(std::chrono::seconds(6));
 PS2WiiProgressStop();
 std::ifstream file("sd:/ps2recomp/progress.txt");std::string s((std::istreambuf_iterator<char>(file)),{});
 assert(s.find("seconds=5 ")!=s.npos);
 assert(s.find("ee_points=1024")!=s.npos);
 assert(s.find("pc=00100ffc")!=s.npos);
 assert(s.find("ee_phase=5 ui_phase=2")!=s.npos);
 closed=true;assert(PS2WiiProgressStopRequested());assert(PS2WiiServicePoll());
 PS2WiiProgressStart();PS2WiiProgressStop(); // repeat lifecycle joins safely
}
''')
 subprocess.run(['c++','-std=c++20','-pthread','-fsanitize=address,undefined','-I'+str(p),'-I'+str(root/'ps2xRuntime/platform/wii'),'-I'+str(root/'ps2xRuntime/include'),str(p/'test.cpp'),str(root/'ps2xRuntime/platform/wii/ps2_wii_progress.cpp'),'-o',str(p/'test')],check=True)
 subprocess.run([str(p/'test')],cwd=p,check=True)
 print('PASS: independent observer, durable idle sample, bounded stop/restart, stop flag')
